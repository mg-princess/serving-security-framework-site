# 개발용 시험 명세와 엔진 자료

79개 점검을 HTML 밖에서도 읽고 구현에 참고할 수 있도록 나눈 자료다. 기존 125개 적용 분기와 4개 조건부 하위시험을 유지했다.

## 읽는 순서

1. 아래에서 구현할 CHK의 **공통 시험 명세**를 연다. 준비·정상 대조·시험 순서·필수 증거·판정을 확인한다.
2. **기준판 상세 구현**에서 기존 명령·API·관측 위치·기술 근거를 확인한다.
3. 사용할 엔진의 **판본 차이**를 확인한다. 추가 비교판은 vLLM v0.30.0·v0.32.0, SGLang v0.5.21·v0.5.23이다.
4. 시험 실행·자동 판정에 BYUL을 사용한다면 [도구 연계 범위](tooling/BYUL.md)를 확인한다.

공통 보호 조건과 판본별 구현 차이를 나눠 보며, 시험 결과는 실제 실행 증거에 따라 기록해야 한다. 이번 작업에서 새 엔진·GPU 시험은 수행하지 않았다.

[79개 NIST 대응표](NIST_79개_대응표.json) · [ISMS-P 관련 36개 요구와 추가 운영 확인](ISMS-P_관련요구_대응.json) · [보존·분리 원장](coverage.json) · [조립 원본](authoring/README.md) · [로컬 HTML](../site/index.html)

## 설정·명령 참고

[공통 준비와 전체 실행 방법](reference/공통준비와_엔진별_실행방법.md) · [기존 평가 양식 코드 예시](reference/평가양식_코드예시.md)

[vllm 분야 1](adapters/vllm/field-1.md) · [vllm 분야 2](adapters/vllm/field-2.md) · [vllm 분야 3](adapters/vllm/field-3.md) · [vllm 분야 4](adapters/vllm/field-4.md) · [vllm 분야 5](adapters/vllm/field-5.md) · [vllm 분야 6](adapters/vllm/field-6.md) · [vllm 분야 7](adapters/vllm/field-7.md) · [vllm 분야 8](adapters/vllm/field-8.md) · [sglang 분야 1](adapters/sglang/field-1.md) · [sglang 분야 2](adapters/sglang/field-2.md) · [sglang 분야 3](adapters/sglang/field-3.md) · [sglang 분야 4](adapters/sglang/field-4.md) · [sglang 분야 5](adapters/sglang/field-5.md) · [sglang 분야 6](adapters/sglang/field-6.md) · [sglang 분야 7](adapters/sglang/field-7.md) · [sglang 분야 8](adapters/sglang/field-8.md)

## 점검 목록

| ID | 점검 | 구현 자료 |
| --- | --- | --- |
| [CHK-LIF-001](checks/CHK-LIF-001.md) | 모델 준비의 각 단계와 전체 과정이 정한 자원 한도를 지키는가? | [기준판](adapters/baseline/CHK-LIF-001.md) · [vLLM](adapters/vllm/CHK-LIF-001.md) · [SGLang](adapters/sglang/CHK-LIF-001.md) |
| [CHK-LIF-002](checks/CHK-LIF-002.md) | 모델을 다시 가져오는 횟수와 누적 비용이 정한 한도를 넘지 않는가? | [기준판](adapters/baseline/CHK-LIF-002.md) · [vLLM](adapters/vllm/CHK-LIF-002.md) · [SGLang](adapters/sglang/CHK-LIF-002.md) |
| [CHK-LIF-003](checks/CHK-LIF-003.md) | 요청 빈도·고비용 요청·동시 부하를 제한하면서 정상 요청의 처리 기회를 유지하는가? | [기준판](adapters/baseline/CHK-LIF-003.md) · [vLLM](adapters/vllm/CHK-LIF-003.md) · [SGLang](adapters/sglang/CHK-LIF-003.md) |
| [CHK-LIF-004](checks/CHK-LIF-004.md) | 느린 응답 수신과 진단용 버퍼의 자원 점유를 정한 범위로 제한하는가? | [기준판](adapters/baseline/CHK-LIF-004.md) · [vLLM](adapters/vllm/CHK-LIF-004.md) · [SGLang](adapters/sglang/CHK-LIF-004.md) |
| [CHK-LIF-005](checks/CHK-LIF-005.md) | 재배포할 때 이전 요청과 새 모델·설정이 섞이지 않도록 전환하는가? | [기준판](adapters/baseline/CHK-LIF-005.md) · [vLLM](adapters/vllm/CHK-LIF-005.md) · [SGLang](adapters/sglang/CHK-LIF-005.md) |
| [CHK-LIF-006](checks/CHK-LIF-006.md) | 실행 중 모델 변경이나 순차 교체를 해도 각 요청의 모델·상태가 일관되는가? | [기준판](adapters/baseline/CHK-LIF-006.md) · [vLLM](adapters/vllm/CHK-LIF-006.md) · [SGLang](adapters/sglang/CHK-LIF-006.md) |
| [CHK-LIF-007](checks/CHK-LIF-007.md) | 필요한 worker와 모델의 실행 준비를 확인한 뒤 요청을 받는가? | [기준판](adapters/baseline/CHK-LIF-007.md) · [vLLM](adapters/vllm/CHK-LIF-007.md) · [SGLang](adapters/sglang/CHK-LIF-007.md) |
| [CHK-LIF-008](checks/CHK-LIF-008.md) | GPU 실행 프로세스의 장애를 감지해 상위 제어 프로세스에 알리는가? | [기준판](adapters/baseline/CHK-LIF-008.md) · [vLLM](adapters/vllm/CHK-LIF-008.md) · [SGLang](adapters/sglang/CHK-LIF-008.md) |
| [CHK-LIF-009](checks/CHK-LIF-009.md) | 일부 worker의 초기화·모델 준비 실패가 전체 기동 결과에 반영되는가? | [기준판](adapters/baseline/CHK-LIF-009.md) · [vLLM](adapters/vllm/CHK-LIF-009.md) · [SGLang](adapters/sglang/CHK-LIF-009.md) |
| [CHK-LIF-010](checks/CHK-LIF-010.md) | 요청 취소·연결 종료 후 실제 작업을 기한 안에 멈추고 불필요한 상태·자원을 정리하는가? | [기준판](adapters/baseline/CHK-LIF-010.md) · [vLLM](adapters/vllm/CHK-LIF-010.md) · [SGLang](adapters/sglang/CHK-LIF-010.md) |
| [CHK-LIF-011](checks/CHK-LIF-011.md) | worker 장애 후 프로세스·통신·공유 자원을 정리하고 다시 기동할 수 있는가? | [기준판](adapters/baseline/CHK-LIF-011.md) · [vLLM](adapters/vllm/CHK-LIF-011.md) · [SGLang](adapters/sglang/CHK-LIF-011.md) |
| [CHK-LIF-012](checks/CHK-LIF-012.md) | 자동 재시도 때 이전 작업의 잔존과 중복 실행 비용을 통제하는가? | [기준판](adapters/baseline/CHK-LIF-012.md) · [vLLM](adapters/vllm/CHK-LIF-012.md) · [SGLang](adapters/sglang/CHK-LIF-012.md) |
| [CHK-LIF-013](checks/CHK-LIF-013.md) | 공유 가중치의 전체 해제 권한과 이후 재취득·참조 사용을 통제하는가? | [기준판](adapters/baseline/CHK-LIF-013.md) · [vLLM](adapters/vllm/CHK-LIF-013.md) · [SGLang](adapters/sglang/CHK-LIF-013.md) |
| [CHK-LIF-014](checks/CHK-LIF-014.md) | 성능 진단을 종료하면 실제 수집과 관련 자원 사용도 정한 기준대로 끝나는가? | [기준판](adapters/baseline/CHK-LIF-014.md) · [vLLM](adapters/vllm/CHK-LIF-014.md) · [SGLang](adapters/sglang/CHK-LIF-014.md) |
| [CHK-LIF-015](checks/CHK-LIF-015.md) | 이전 구성으로 되돌릴 때도 현재 승인된 대상만 사용하는가? | [기준판](adapters/baseline/CHK-LIF-015.md) · [vLLM](adapters/vllm/CHK-LIF-015.md) · [SGLang](adapters/sglang/CHK-LIF-015.md) |
| [CHK-LIF-016](checks/CHK-LIF-016.md) | 복구할 때 변조된 자료나 이전 실행의 남은 상태가 결과에 섞이지 않는가? | [기준판](adapters/baseline/CHK-LIF-016.md) · [vLLM](adapters/vllm/CHK-LIF-016.md) · [SGLang](adapters/sglang/CHK-LIF-016.md) |
| [CHK-OBS-001](checks/CHK-OBS-001.md) | 접근·관리·승인 기록으로 누가 어떤 대상에 무엇을 했는지 실행별로 확인할 수 있는가? | [기준판](adapters/baseline/CHK-OBS-001.md) · [vLLM](adapters/vllm/CHK-OBS-001.md) · [SGLang](adapters/sglang/CHK-OBS-001.md) |
| [CHK-OBS-002](checks/CHK-OBS-002.md) | 준비·실패·종료 기록이 실제 worker·작업·수집 상태와 일치하는가? | [기준판](adapters/baseline/CHK-OBS-002.md) · [vLLM](adapters/vllm/CHK-OBS-002.md) · [SGLang](adapters/sglang/CHK-OBS-002.md) |
| [CHK-OBS-003](checks/CHK-OBS-003.md) | 로그·진단·추적·덤프에 수집을 허용한 정보만 남기는가? | [기준판](adapters/baseline/CHK-OBS-003.md) · [vLLM](adapters/vllm/CHK-OBS-003.md) · [SGLang](adapters/sglang/CHK-OBS-003.md) |
| [CHK-OBS-004](checks/CHK-OBS-004.md) | 사용·환경 정보의 수집과 전송이 승인한 허용·금지 정책을 따르는가? | [기준판](adapters/baseline/CHK-OBS-004.md) · [vLLM](adapters/vllm/CHK-OBS-004.md) · [SGLang](adapters/sglang/CHK-OBS-004.md) |
| [CHK-OBS-005](checks/CHK-OBS-005.md) | 수집·전송을 허용한 사용·환경 정보가 승인된 항목·수신지·주기를 따르는가? | [기준판](adapters/baseline/CHK-OBS-005.md) · [vLLM](adapters/vllm/CHK-OBS-005.md) · [SGLang](adapters/sglang/CHK-OBS-005.md) |
| [CHK-OBS-006](checks/CHK-OBS-006.md) | 기록·진단 자료의 조회·반출을 허용된 계정으로 제한하고, 필요한 저장 암호화를 적용하는가? | [기준판](adapters/baseline/CHK-OBS-006.md) · [vLLM](adapters/vllm/CHK-OBS-006.md) · [SGLang](adapters/sglang/CHK-OBS-006.md) |
| [CHK-OBS-007](checks/CHK-OBS-007.md) | 진단 자료를 읽을 수 있는 계정이 별도 허가 없이 재실행할 수 없는가? | [기준판](adapters/baseline/CHK-OBS-007.md) · [vLLM](adapters/vllm/CHK-OBS-007.md) · [SGLang](adapters/sglang/CHK-OBS-007.md) |
| [CHK-OBS-008](checks/CHK-OBS-008.md) | 변조된 진단 자료를 거부하고 재실행 도구의 파일·통신·코드 실행 권한을 제한하는가? | [기준판](adapters/baseline/CHK-OBS-008.md) · [vLLM](adapters/vllm/CHK-OBS-008.md) · [SGLang](adapters/sglang/CHK-OBS-008.md) |
| [CHK-OBS-009](checks/CHK-OBS-009.md) | 요청값을 조작해 로그의 사용자·대상·상태를 위조할 수 없는가? | [기준판](adapters/baseline/CHK-OBS-009.md) · [vLLM](adapters/vllm/CHK-OBS-009.md) · [SGLang](adapters/sglang/CHK-OBS-009.md) |
| [CHK-OBS-010](checks/CHK-OBS-010.md) | 기록의 무단 변경·삭제를 막고 필요한 탐지를 수행하는가? | [기준판](adapters/baseline/CHK-OBS-010.md) · [vLLM](adapters/vllm/CHK-OBS-010.md) · [SGLang](adapters/sglang/CHK-OBS-010.md) |
| [CHK-OBS-011](checks/CHK-OBS-011.md) | 필수 운영 기록의 수집 중단·누락을 감지하고 담당자에게 알리는가? | [기준판](adapters/baseline/CHK-OBS-011.md) · [vLLM](adapters/vllm/CHK-OBS-011.md) · [SGLang](adapters/sglang/CHK-OBS-011.md) |
| [CHK-OBS-012](checks/CHK-OBS-012.md) | 자료의 원본·사본을 정한 기간 동안 보관하고 만료 후에는 정책대로 처리하는가? | [기준판](adapters/baseline/CHK-OBS-012.md) · [vLLM](adapters/vllm/CHK-OBS-012.md) · [SGLang](adapters/sglang/CHK-OBS-012.md) |
| [CHK-PLT-001](checks/CHK-PLT-001.md) | 엔진과 worker가 실행에 필요한 호스트·파일·장치 권한만 갖고 있는가? | [기준판](adapters/baseline/CHK-PLT-001.md) · [vLLM](adapters/vllm/CHK-PLT-001.md) · [SGLang](adapters/sglang/CHK-PLT-001.md) |
| [CHK-PLT-002](checks/CHK-PLT-002.md) | 같은 호스트의 내부 통신에 허용된 프로세스만 접속할 수 있는가? | [기준판](adapters/baseline/CHK-PLT-002.md) · [vLLM](adapters/vllm/CHK-PLT-002.md) · [SGLang](adapters/sglang/CHK-PLT-002.md) |
| [CHK-PLT-003](checks/CHK-PLT-003.md) | 모델을 가져오는 계정이 허용된 저장소·파일에만 접근하는가? | [기준판](adapters/baseline/CHK-PLT-003.md) · [vLLM](adapters/vllm/CHK-PLT-003.md) · [SGLang](adapters/sglang/CHK-PLT-003.md) |
| [CHK-PLT-004](checks/CHK-PLT-004.md) | worker에 실행에 필요한 인증정보와 비밀정보만 전달하는가? | [기준판](adapters/baseline/CHK-PLT-004.md) · [vLLM](adapters/vllm/CHK-PLT-004.md) · [SGLang](adapters/sglang/CHK-PLT-004.md) |
| [CHK-PLT-005](checks/CHK-PLT-005.md) | 인증정보가 없거나 만료돼도 승인하지 않은 다른 접근 방식으로 전환하지 않는가? | [기준판](adapters/baseline/CHK-PLT-005.md) · [vLLM](adapters/vllm/CHK-PLT-005.md) · [SGLang](adapters/sglang/CHK-PLT-005.md) |
| [CHK-PLT-006](checks/CHK-PLT-006.md) | Core와 worker의 권한 공유가 정한 격리 기준에 맞는가? worker 하나가 침해됐을 때의 영향도 확인했는가? | [기준판](adapters/baseline/CHK-PLT-006.md) · [vLLM](adapters/vllm/CHK-PLT-006.md) · [SGLang](adapters/sglang/CHK-PLT-006.md) |
| [CHK-PLT-007](checks/CHK-PLT-007.md) | 엔진이 허용된 목적지로 허용된 작업만 송신하는가? | [기준판](adapters/baseline/CHK-PLT-007.md) · [vLLM](adapters/vllm/CHK-PLT-007.md) · [SGLang](adapters/sglang/CHK-PLT-007.md) |
| [CHK-PLT-008](checks/CHK-PLT-008.md) | API와 내부 통신의 각 구간에서 상대를 확인하고 전송 자료를 보호하는가? | [기준판](adapters/baseline/CHK-PLT-008.md) · [vLLM](adapters/vllm/CHK-PLT-008.md) · [SGLang](adapters/sglang/CHK-PLT-008.md) |
| [CHK-PLT-009](checks/CHK-PLT-009.md) | 엔진에서 기록 수집기와 최종 저장소까지 각 전송 구간을 보호하는가? | [기준판](adapters/baseline/CHK-PLT-009.md) · [vLLM](adapters/vllm/CHK-PLT-009.md) · [SGLang](adapters/sglang/CHK-PLT-009.md) |
| [CHK-PLT-010](checks/CHK-PLT-010.md) | 인증정보의 권한을 철회하면 새 접근이 정한 기한 안에 차단되는가? | [기준판](adapters/baseline/CHK-PLT-010.md) · [vLLM](adapters/vllm/CHK-PLT-010.md) · [SGLang](adapters/sglang/CHK-PLT-010.md) |
| [CHK-PLT-011](checks/CHK-PLT-011.md) | 권한을 철회한 뒤 기존 연결과 공유 자원 접근도 정한 정책에 따라 제한하는가? | [기준판](adapters/baseline/CHK-PLT-011.md) · [vLLM](adapters/vllm/CHK-PLT-011.md) · [SGLang](adapters/sglang/CHK-PLT-011.md) |
| [CHK-PLT-012](checks/CHK-PLT-012.md) | 폐기할 인증정보의 사본을 정한 정책대로 처리하고 재사용을 막는가? | [기준판](adapters/baseline/CHK-PLT-012.md) · [vLLM](adapters/vllm/CHK-PLT-012.md) · [SGLang](adapters/sglang/CHK-PLT-012.md) |
| [CHK-PLT-013](checks/CHK-PLT-013.md) | 모델·저장 입력·결과·영속 캐시·백업을 허용된 주체만 읽고 반출할 수 있는가? | [기준판](adapters/baseline/CHK-PLT-013.md) · [vLLM](adapters/vllm/CHK-PLT-013.md) · [SGLang](adapters/sglang/CHK-PLT-013.md) |
| [CHK-REQ-001](checks/CHK-REQ-001.md) | 실제 사용하는 모든 요청 경로에서 허용받지 않은 작업을 차단하는가? | [기준판](adapters/baseline/CHK-REQ-001.md) · [vLLM](adapters/vllm/CHK-REQ-001.md) · [SGLang](adapters/sglang/CHK-REQ-001.md) |
| [CHK-REQ-002](checks/CHK-REQ-002.md) | 요청 경로가 바뀌어도 실제 실행할 API에 필요한 인증·권한 검사를 거치는가? | [기준판](adapters/baseline/CHK-REQ-002.md) · [vLLM](adapters/vllm/CHK-REQ-002.md) · [SGLang](adapters/sglang/CHK-REQ-002.md) |
| [CHK-REQ-003](checks/CHK-REQ-003.md) | 일반 사용자에게 허용하지 않은 관리·진단 작업이 차단되는가? | [기준판](adapters/baseline/CHK-REQ-003.md) · [vLLM](adapters/vllm/CHK-REQ-003.md) · [SGLang](adapters/sglang/CHK-REQ-003.md) |
| [CHK-REQ-004](checks/CHK-REQ-004.md) | 사용자가 요청값을 조작해 권한 검사에 쓰이는 신원을 바꿀 수 없는가? | [기준판](adapters/baseline/CHK-REQ-004.md) · [vLLM](adapters/vllm/CHK-REQ-004.md) · [SGLang](adapters/sglang/CHK-REQ-004.md) |
| [CHK-REQ-005](checks/CHK-REQ-005.md) | 호출자에게 허용된 모델만 실행되고, 사용을 종료한 모델은 실행되지 않는가? | [기준판](adapters/baseline/CHK-REQ-005.md) · [vLLM](adapters/vllm/CHK-REQ-005.md) · [SGLang](adapters/sglang/CHK-REQ-005.md) |
| [CHK-REQ-006](checks/CHK-REQ-006.md) | 저장한 추론 응답을 조회·이어 쓰거나 응답 생성을 취소할 때, 해당 작업의 권한을 확인하는가? | [기준판](adapters/baseline/CHK-REQ-006.md) · [vLLM](adapters/vllm/CHK-REQ-006.md) · [SGLang](adapters/sglang/CHK-REQ-006.md) |
| [CHK-REQ-007](checks/CHK-REQ-007.md) | chat template으로 변환한 뒤의 입력에도 필요한 제한이 적용되는가? | [기준판](adapters/baseline/CHK-REQ-007.md) · [vLLM](adapters/vllm/CHK-REQ-007.md) · [SGLang](adapters/sglang/CHK-REQ-007.md) |
| [CHK-REQ-008](checks/CHK-REQ-008.md) | 미리 만든 토큰 ID를 다시 입력할 때도 필수 검사를 거치는가? | [기준판](adapters/baseline/CHK-REQ-008.md) · [vLLM](adapters/vllm/CHK-REQ-008.md) · [SGLang](adapters/sglang/CHK-REQ-008.md) |
| [CHK-REQ-009](checks/CHK-REQ-009.md) | 입력이 모델과 각 처리 단계의 조건에 맞는지 검사하는가? | [기준판](adapters/baseline/CHK-REQ-009.md) · [vLLM](adapters/vllm/CHK-REQ-009.md) · [SGLang](adapters/sglang/CHK-REQ-009.md) |
| [CHK-REQ-010](checks/CHK-REQ-010.md) | 생성 옵션과 구조화 출력·도구 선택의 설정이 처리 조건에 맞는지 검사하는가? | [기준판](adapters/baseline/CHK-REQ-010.md) · [vLLM](adapters/vllm/CHK-REQ-010.md) · [SGLang](adapters/sglang/CHK-REQ-010.md) |
| [CHK-REQ-011](checks/CHK-REQ-011.md) | 동시에 들어온 요청의 일반·스트리밍 응답이 각각 올바른 요청자에게 돌아가는가? | [기준판](adapters/baseline/CHK-REQ-011.md) · [vLLM](adapters/vllm/CHK-REQ-011.md) · [SGLang](adapters/sglang/CHK-REQ-011.md) |
| [CHK-REQ-012](checks/CHK-REQ-012.md) | 취소·연결 종료 후 늦게 나온 결과가 다른 요청이나 재시도에 섞이지 않는가? | [기준판](adapters/baseline/CHK-REQ-012.md) · [vLLM](adapters/vllm/CHK-REQ-012.md) · [SGLang](adapters/sglang/CHK-REQ-012.md) |
| [CHK-REQ-013](checks/CHK-REQ-013.md) | 응답 옵션이나 오류 메시지를 통해 허용하지 않은 정보가 전달되지 않는가? | [기준판](adapters/baseline/CHK-REQ-013.md) · [vLLM](adapters/vllm/CHK-REQ-013.md) · [SGLang](adapters/sglang/CHK-REQ-013.md) |
| [CHK-REQ-014](checks/CHK-REQ-014.md) | 여러 프로세스가 나눠 처리한 중간 자료와 최종 결과가 원래 요청에 맞게 처리·반환되는가? | [기준판](adapters/baseline/CHK-REQ-014.md) · [vLLM](adapters/vllm/CHK-REQ-014.md) · [SGLang](adapters/sglang/CHK-REQ-014.md) |
| [CHK-REQ-015](checks/CHK-REQ-015.md) | 검증된 호출자 신원에 따라 캐시 공유 집단을 정하는가? | [기준판](adapters/baseline/CHK-REQ-015.md) · [vLLM](adapters/vllm/CHK-REQ-015.md) · [SGLang](adapters/sglang/CHK-REQ-015.md) |
| [CHK-REQ-016](checks/CHK-REQ-016.md) | 캐시 식별값으로 재사용에 필요한 모델·설정·입력 자료의 차이를 구분하는가? | [기준판](adapters/baseline/CHK-REQ-016.md) · [vLLM](adapters/vllm/CHK-REQ-016.md) · [SGLang](adapters/sglang/CHK-REQ-016.md) |
| [CHK-REQ-017](checks/CHK-REQ-017.md) | 캐시 적중에 따른 시간 차이로 비공개 정보를 허용 범위 밖에서 추정할 수 없는가? | [기준판](adapters/baseline/CHK-REQ-017.md) · [vLLM](adapters/vllm/CHK-REQ-017.md) · [SGLang](adapters/sglang/CHK-REQ-017.md) |
| [CHK-REQ-018](checks/CHK-REQ-018.md) | 요청 처리 자리를 옮기거나 다시 쓸 때 이전 요청의 제한 상태가 다음 요청에 남지 않는가? | [기준판](adapters/baseline/CHK-REQ-018.md) · [vLLM](adapters/vllm/CHK-REQ-018.md) · [SGLang](adapters/sglang/CHK-REQ-018.md) |
| [CHK-REQ-019](checks/CHK-REQ-019.md) | GPU 연산이 입력·버퍼 범위를 지키고 필요한 메모리를 초기화하는가? | [기준판](adapters/baseline/CHK-REQ-019.md) · [vLLM](adapters/vllm/CHK-REQ-019.md) · [SGLang](adapters/sglang/CHK-REQ-019.md) |
| [CHK-REQ-020](checks/CHK-REQ-020.md) | CUDA Graph를 다시 실행할 때 현재 입력을 쓰고, 읽는 중인 출력은 덮어쓰지 않는가? | [기준판](adapters/baseline/CHK-REQ-020.md) · [vLLM](adapters/vllm/CHK-REQ-020.md) · [SGLang](adapters/sglang/CHK-REQ-020.md) |
| [CHK-REQ-021](checks/CHK-REQ-021.md) | TP의 GPU 작업을 다시 실행할 때 현재 실행에 속한 유효한 통신 버퍼만 사용하는가? | [기준판](adapters/baseline/CHK-REQ-021.md) · [vLLM](adapters/vllm/CHK-REQ-021.md) · [SGLang](adapters/sglang/CHK-REQ-021.md) |
| [CHK-SUP-001](checks/CHK-SUP-001.md) | 파일 제출·수정 권한과 승인 기록을 바꾸는 권한이 분리되어 있는가? | [기준판](adapters/baseline/CHK-SUP-001.md) · [vLLM](adapters/vllm/CHK-SUP-001.md) · [SGLang](adapters/sglang/CHK-SUP-001.md) |
| [CHK-SUP-002](checks/CHK-SUP-002.md) | 배포 담당자가 허용된 모델·환경 조합으로만 배포할 수 있는가? | [기준판](adapters/baseline/CHK-SUP-002.md) · [vLLM](adapters/vllm/CHK-SUP-002.md) · [SGLang](adapters/sglang/CHK-SUP-002.md) |
| [CHK-SUP-003](checks/CHK-SUP-003.md) | 모델 실행에 함께 쓰는 설정·tokenizer·template와 추가 모델 파일도 승인 대상에 포함되어 있는가? | [기준판](adapters/baseline/CHK-SUP-003.md) · [vLLM](adapters/vllm/CHK-SUP-003.md) · [SGLang](adapters/sglang/CHK-SUP-003.md) |
| [CHK-SUP-004](checks/CHK-SUP-004.md) | 실행 이미지·패키지와 함께 설치되는 의존성이 승인 내용과 일치하는가? | [기준판](adapters/baseline/CHK-SUP-004.md) · [vLLM](adapters/vllm/CHK-SUP-004.md) · [SGLang](adapters/sglang/CHK-SUP-004.md) |
| [CHK-SUP-005](checks/CHK-SUP-005.md) | 승인 후 파일이나 경로가 바뀌어도 승인하지 않은 자료의 사용을 차단하는가? | [기준판](adapters/baseline/CHK-SUP-005.md) · [vLLM](adapters/vllm/CHK-SUP-005.md) · [SGLang](adapters/sglang/CHK-SUP-005.md) |
| [CHK-SUP-006](checks/CHK-SUP-006.md) | 각 worker가 자신에게 배정된 승인 모델 파일·shard를 실제로 적재하는가? | [기준판](adapters/baseline/CHK-SUP-006.md) · [vLLM](adapters/vllm/CHK-SUP-006.md) · [SGLang](adapters/sglang/CHK-SUP-006.md) |
| [CHK-SUP-007](checks/CHK-SUP-007.md) | 생성된 코드·파일과 공유 컴파일 캐시를 허가 없이 바꾸지 못하게 하는가? | [기준판](adapters/baseline/CHK-SUP-007.md) · [vLLM](adapters/vllm/CHK-SUP-007.md) · [SGLang](adapters/sglang/CHK-SUP-007.md) |
| [CHK-SUP-008](checks/CHK-SUP-008.md) | 요청값을 바꿔 승인하지 않은 코드 판본을 선택할 수 없는가? | [기준판](adapters/baseline/CHK-SUP-008.md) · [vLLM](adapters/vllm/CHK-SUP-008.md) · [SGLang](adapters/sglang/CHK-SUP-008.md) |
| [CHK-SUP-009](checks/CHK-SUP-009.md) | 모델의 추가 코드와 동적 모듈은 승인한 조건에서만 실행되는가? | [기준판](adapters/baseline/CHK-SUP-009.md) · [vLLM](adapters/vllm/CHK-SUP-009.md) · [SGLang](adapters/sglang/CHK-SUP-009.md) |
| [CHK-SUP-010](checks/CHK-SUP-010.md) | 플러그인을 실행하기 전에 승인된 대상인지 검사하는가? | [기준판](adapters/baseline/CHK-SUP-010.md) · [vLLM](adapters/vllm/CHK-SUP-010.md) · [SGLang](adapters/sglang/CHK-SUP-010.md) |
| [CHK-SUP-011](checks/CHK-SUP-011.md) | Python 실행 모드가 달라도 동적으로 불러올 모듈의 허용 여부를 검사하는가? | [기준판](adapters/baseline/CHK-SUP-011.md) · [vLLM](adapters/vllm/CHK-SUP-011.md) · [SGLang](adapters/sglang/CHK-SUP-011.md) |
| [CHK-SUP-012](checks/CHK-SUP-012.md) | 파일·메시지를 읽을 때 허용하지 않은 객체 생성이나 동작을 막는가? | [기준판](adapters/baseline/CHK-SUP-012.md) · [vLLM](adapters/vllm/CHK-SUP-012.md) · [SGLang](adapters/sglang/CHK-SUP-012.md) |
| [CHK-SUP-013](checks/CHK-SUP-013.md) | 모델의 chat template을 해석할 때 허용된 동작만 수행하는가? | [기준판](adapters/baseline/CHK-SUP-013.md) · [vLLM](adapters/vllm/CHK-SUP-013.md) · [SGLang](adapters/sglang/CHK-SUP-013.md) |
| [CHK-SUP-014](checks/CHK-SUP-014.md) | 필수 검사에서 통과 근거를 확보하지 못하면 승인·운영 사용을 보류하는가? | [기준판](adapters/baseline/CHK-SUP-014.md) · [vLLM](adapters/vllm/CHK-SUP-014.md) · [SGLang](adapters/sglang/CHK-SUP-014.md) |
| [CHK-SUP-015](checks/CHK-SUP-015.md) | 모델·도구·설정이 바뀌면 생성물·캐시를 계속 써도 되는지 확인하는가? | [기준판](adapters/baseline/CHK-SUP-015.md) · [vLLM](adapters/vllm/CHK-SUP-015.md) · [SGLang](adapters/sglang/CHK-SUP-015.md) |
| [CHK-SUP-016](checks/CHK-SUP-016.md) | 생성이 끝나지 않았거나 실패한 파일을 완성된 자료로 사용하지 않는가? | [기준판](adapters/baseline/CHK-SUP-016.md) · [vLLM](adapters/vllm/CHK-SUP-016.md) · [SGLang](adapters/sglang/CHK-SUP-016.md) |
| [CHK-SUP-017](checks/CHK-SUP-017.md) | 실제 사용하는 엔진·의존성의 알려진 취약점을 평가하고 조치했는가? | [기준판](adapters/baseline/CHK-SUP-017.md) · [vLLM](adapters/vllm/CHK-SUP-017.md) · [SGLang](adapters/sglang/CHK-SUP-017.md) |

## 기존 시험 결과

[125개 적용 분기별 결과 원장](machine/branch_evidence_index.json). 체크리스트의 기술 근거에서 원문·관측 범위·추가 확인 사항을 확인한다.

## 위협 시나리오

[83개 시나리오 카드](scenarios/README.md) · [8개 공개 사례 카드](public-cases/README.md)
