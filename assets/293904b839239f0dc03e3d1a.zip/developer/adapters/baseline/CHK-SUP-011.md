# CHK-SUP-011 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-011.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### Python 실행 모드가 달라도 동적으로 불러올 모듈의 허용 여부를 검사하는가? · CHK-SUP-011

<a id="CHK-SUP-011"></a>
 
<a id="324-지원하는-python-실행-모드가-달라져도-같은-동적-import-허용-검사가-유지되는가"></a>
 
<a id="source-10-02514"></a>

CHK-SUP-009 안에서 확인하는 조건부 하위시험이다. 적용 여부·증거·결과는 이 ID로 구분해 기록해야 한다.

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 선정 동적 import 소비 경로와 실제 지원하는 Python 실행 모드가 있을 때 적용한다. 같은 모듈 선택값·허용 정책을 일반 실행과 지원하는 최적화 모드 등에서 비교한다. 코드 선택 출처별 조사 결과는 CHK-SUP-008·CHK-SUP-009·CHK-SUP-010과 연결한다. |
| --- | --- |
| 권장 설정·조치 | 지원하는 각 실행 모드에서 동적 import를 허용하는 모듈·경로·설정값을 제한한다. 보안 검사를 최적화 옵션으로 제거될 수 있는 assertion과 분리하고 실행 전에 유효성을 검사한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 같은 모듈 경로와 허용 목록을 사용하고, 실제 지원하는 실행 모드만 바꿔 비교한다. 승인 모듈의 정상 로딩과 비승인 모듈의 거부가 모두 유지되는지 확인한다.<br>**정상 동작:** 지원한다고 선언한 각 실행 모드가 승인 import 목록으로 기동한다. |
| 판정 기준 | 충족<br>지원하는 각 실행 모드에서 허용하지 않은 외부 모듈 로딩을 거부하고 정상 로딩은 가능하다.<br>미충족<br>지원 mode에서 승인 밖 dynamic import가 허용된다.<br>미확인<br>지원 mode 목록 또는 실제 import 대상을 확인하지 못했다. |
| 남길 자료 | - mode·entrypoint·module 선택값/import 파일/설정 집행 결과 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 실행 모드 변경으로 코드 허용 검사 생략 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**CM-7(5) · AC-25 — 요구 직접 대응**

비허용 모듈의 실행을 막고 검사 우회를 방지한다.

Python 실행 모드·최적화 옵션이 달라도 import 검사가 유지되는지 비교한다.

assertion 제거 등 실제 지원 모드의 검사 소실을 확인한다.

 

**시험 준비**

 

지원하는 실행 모드를 확인하고 import를 관측할 방법을 준비한다.

 

**시험에서 확인할 내용**

 

동적 import 경로와 허용 목록, 승인된 무해 모듈과 승인되지 않은 무해 모듈을 동일하게 유지한다. 실제로 지원하는 Python 실행 모드만 바꿔 검사·거부·import 결과를 비교한다. 보안 판단이 제거 가능한 assertion에만 의존해 특정 모드에서 사라지는지 확인한다. 각 모드에서 승인 모듈의 정상 로딩도 확인한다.

 

**시험 순서**

 

1. 지원하는 mode별로 승인 모듈이 정상 import되는지 확인한다.
2. 같은 허용 목록을 유지하고 선택 가능한 무해한 외부 module 경로를 입력한다.
3. mode별 실제 import·거부 위치와 결과를 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 실행 모드에 따라 코드 허용 검사 누락 | 선정한 구현에 동적 import를 사용하는 경로와 지원하는 Python 실행 모드가 있다. | SC-11-05 |

 

**엔진별 확인 사항**

 

**Python 실행 방식에 따른 동적 로딩 검사**

 

[평가 방법의 적용 사례](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_D_%ED%8F%89%EA%B0%80%EC%96%91%EC%8B%9D%EA%B3%BC_%EC%82%AC%EB%A1%80.md&anchor=source-05-00279)에서는 실행 방식에 따라 동적 로딩을 차단하는 호출이 빠지는 경우를 구별했다. 같은 허용 정책이 실제로 사용하는 실행 방식마다 적용되는지 확인할 때 참고한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.2 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59) / [서비스 제공자 2.1.2 · 인쇄 83·84 / PDF 93·94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=93)

코드 검토와 실행 기반 보안 문제 확인의 방법론적 근거가 있다.

**OWASP ASVS:** [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.5.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 지원 실행 모드에서도 코드 실행의 보호 검사가 사라져 fail-open하지 않는지 확인한다.

Python 최적화 모드·assertion 문제는 일반 SW에도 적용된다. ASVS에 특정 Python 실행 모드 시험이 명시돼 있다는 뜻은 아니다.

**NIST SP 800-53 Rev.5:** [CM-7(5)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 소프트웨어만 실행하는 제한을 지원하는 실행 모드에서도 유지한다.

**관련 위협 시나리오:** [SC-11-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-05)

 

**관련 근거:** [Q-R05-06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-06) · [SC-11-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-05)

