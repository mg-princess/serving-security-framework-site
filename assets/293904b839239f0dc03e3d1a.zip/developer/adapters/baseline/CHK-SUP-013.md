# CHK-SUP-013 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-013.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 모델의 chat template을 해석할 때 허용된 동작만 수행하는가? · CHK-SUP-013

<a id="CHK-SUP-013"></a>
 
<a id="332-모델이-제공한-chat-template을-해석할-때-허용된-동작-범위를-지키는가"></a>
 
<a id="source-10-02654"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 공급물의 template가 실제 renderer에서 해석될 때 적용한다. 요청 override 허용 여부와 공급 template 소비는 별도로 확인한다. |
| --- | --- |
| 권장 설정·조치 | 모델이 제공한 chat 템플릿의 버전과 출처를 승인하고 실제 렌더러의 허용 동작을 제한한다. 외부 객체 참조·호출과 렌더링 비용을 정한 범위로 제한하고 실패한 변환 결과의 사용을 막는다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 실제 템플릿과 해석기·격리 설정·의존성에서 금지된 참조나 동작이 차단되는지 확인한다. 처리 시간·비용 제한도 확인하며, 변환된 입력의 길이·내용 제한은 별도로 판정한다.<br>**정상 동작:** 승인한 template가 정상 메시지를 기대 형식으로 렌더링한다. |
| 판정 기준 | 충족<br>금지 동작을 막고 정상 입력 해석은 유지한다.<br>미충족<br>허용하지 않은 참조·동작이 실행되거나 정한 처리 한도를 넘긴다.<br>미확인<br>sandbox 이름만 확인했거나 해당 template·renderer 분기에 도달하지 못했다. |
| 남길 자료 | - template digest/renderer·sandbox·의존성/출력·오류·제한 집행 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 모델 template의 위험 동작·비용 유발 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SI-10(6) · AC-6 · SC-5 — 요구 직접 대응**

비신뢰 입력에 따른 코드 실행·권한 확대·자원 남용을 제한한다.

대화 템플릿 해석기의 금지 참조·호출·파일·렌더링 비용을 시험한다.

산술식 계산 성공만으로 sandbox 실패를 판정하지 않는다.

 

**시험의 검출 능력 확인 예**

금지한 속성 접근·호출 등 이 환경에서 허용 범위를 벗어나는 동작을 무해한 표식으로 구성하고, 선택한 renderer가 차단하는지 확인한다. 산술 계산이 허용된 template에서 7×7이 49로 나오는 결과는 위험 동작 차단 시험의 실패 근거로 쓰지 않는다.

 

**시험 준비**

 

허용할 템플릿 기능과 처리 예산을 정하고, 무해한 검증용 시험 자료를 준비한다.

 

**시험에서 확인할 내용**

 

실제로 선택된 공급 템플릿과 renderer, sandbox·의존성, 허용 동작과 처리 예산을 고정한다. 정상 템플릿 해석과 금지 참조·동작을 나타내는 무해 템플릿을 대조해 renderer의 실행·거부·비용을 확인한다. 렌더된 결과의 길이·내용·토큰 제한은 CHK-REQ-007의 별도 판정에 연결한다. 명시적 코드 선택·import 허용은 CHK-SUP-008·CHK-SUP-009·CHK-SUP-010·CHK-SUP-011에서 확인한다.

 

**시험 순서**

 

1. 공급 템플릿과 실제 적용된 renderer를 확인하고 정상 메시지의 렌더 결과를 기록한다.
2. 허용 기능·처리 예산의 경계를 확인하는 무해한 템플릿을 입력한다.
3. 렌더 결과·차단 여부·처리 시간을 정한 기준에 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 모델 템플릿으로 위험한 동작·과도한 자원 사용 유발 | 서버 지정·processor·tokenizer·fallback 등을 통해 실제로 선택된 공급 템플릿이 renderer에서 해석된다. | SC-11-07 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59) / [개발자 3.4.4 · 인쇄 52 / PDF 62](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=62)

위험 코드 격리와 입력·출력 검증의 관련 원칙은 있다.

**OWASP ASVS:** [V1.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V1.3.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V1.3.7](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).template injection·위험한 표현식 실행·과다 비용을 통제하는 기존 요구다.

모델이 template을 공급한다는 차이만으로 새 보안 원칙으로 세지 않는다.

**NIST SP 800-53 Rev.5:** [SI-10(6)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [AC-6](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 비신뢰 자료가 코드·명령으로 주입되는 것을 막고 해석기의 권한을 제한한다.

**관련 위협 시나리오:** [SC-11-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-07)

 

**관련 근거:** [Q-R05-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-05) · [SC-11-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-07)

