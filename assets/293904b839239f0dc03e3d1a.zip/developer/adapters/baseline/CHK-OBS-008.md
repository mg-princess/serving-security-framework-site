# CHK-OBS-008 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-OBS-008.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 변조된 진단 자료를 거부하고 재실행 도구의 파일·통신·코드 실행 권한을 제한하는가? · CHK-OBS-008

<a id="CHK-OBS-008"></a>
 
<a id="333-재실행-도구가-변조된-진단-자료를-거부하고-자료-해석-시-파일통신코드-실행-권한을-승인-범위로-제한하는가"></a>
 
<a id="source-10-02712"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | replay/역직렬화 consumer가 진단 자료를 소비할 때 적용한다. 단순 로그 보관과 구분한다. |
| --- | --- |
| 권장 설정·조치 | replay에 사용할 진단 자료의 출처·식별정보·형식과 reader를 제한한다. 변조 자료를 사용 전에 거부하고 해석 프로세스의 파일·통신·코드 실행 권한을 승인 범위로 제한한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 같은 승인 실행 역할로 정상 합성 자료와 무해하게 변조한 자료를 비교한다. 실제 해석기, 자료 검증·거부, 객체 생성과 추가 접근을 확인한다. 누가 재실행할 수 있는지는 별도 권한 항목에서 판정한다.<br>**정상 동작:** 승인 출처의 합성 진단 자료가 허용 reader로 처리된다. |
| 판정 기준 | 충족<br>비허용 자료 실행·고권한 부수 동작을 막는다. 공급물 해석 점검과 증거를 공유한다.<br>미충족<br>승인·출처·무결성 검증이 필수인 자료가 필요한 검증을 거치지 않거나 검증에 실패한 채 실제 재실행에 사용된다. 허용 밖 reader로 해석하거나 금지된 파일·통신·코드 부수 동작이 발생한 경우도 포함한다. 자료를 읽어 안전하게 검증·거부하는 과정과 실제 재실행을 구분한다.<br>미확인<br>외부 consumer·입력형식·실제 reader를 알 수 없다. |
| 남길 자료 | - 자료 출처·digest/parser·reader 선택/거부·부수 접근 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 변조한 진단 파일로 고권한 도구 동작 유도 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SI-7 · SI-10(6) · AC-6 — 요구 직접 대응**

재실행 자료의 무결성과 비신뢰 자료 실행을 통제한다.

동일 승인 역할에서 변조 진단 자료 거부와 reader의 권한을 확인한다.

실행 역할 권한은 OBS-007, 자료 검증·안전 실행은 OBS-008로 구분한다.

 

**시험 준비**

 

진단 자료 재실행 도구의 사용 여부와 자료를 읽는 구현(reader)을 먼저 확인한다. 3.3 자료 해석 안전성의 CHK-SUP-012와 근거를 함께 사용할 수 있으며, replay의 읽기·실행 권한은 CHK-OBS-007에서 따로 판정한다. Q-R05-07·Q-C11을 도출 근거로 사용한다.

 

**시험에서 확인할 내용**

 

같은 승인 실행 역할과 실제 재실행 도구를 사용해 정상 합성 자료와 무해하게 변조하거나 출처·구조를 바꾼 자료를 비교한다. 자료의 digest와 검증 결과, 최종 parser·reader, 거부 여부, 객체 생성과 파일 접근·통신·코드 실행의 부수 동작을 관측한다. 실행 계정이 허용된 권한 범위를 지키는지도 확인해야 한다. 외부 replay 시험은 도구가 실제로 배치돼 있고, 실행 계정·입력 형식을 확인했으며 해당 reader가 입력을 읽는 경우에 적용한다. 실행 역할의 허용 여부는 CHK-OBS-007에서 판정한다. 일반 파일·메시지도 같은 reader에서 해석한다면 CHK-SUP-012와 증거를 함께 사용할 수 있다. 근거 원문: [F24](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F24).

 

**시험 순서**

 

1. 정상 합성 자료를 별도로 복사하고 구조·출처 표식을 무해하게 변경한다.
2. 같은 승인 실행 역할로 정상 자료와 변경한 자료를 실제 replay consumer에 제출한다.
3. 검증·거부 결과, 최종 reader, 객체 생성과 파일·통신·코드 실행의 부수 동작을 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 진단 파일을 바꿔 고권한 도구의 동작 조작 | replay/역직렬화 consumer가 진단 자료를 실제 읽고 실행한다. | SC-21-04 |

 

**함께 확인할 보호 요구**

 

- [실제 사용의 무결성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-2-2): 진단 자료의 승인 출처·digest와 실제 consumer가 읽은 자료를 대조한다. 다른 모델/공급물의 승인 후 교체 통제 전체를 대신하지 않는다.
 
- [작업·대상 인가](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-2): 승인 실행 역할이 제출한 자료의 실제 reader 도달과 처리 결과를 제공한다. reader와 실행 역할의 replay 시작 인가는 CHK-OBS-007의 별도 결과다.
 
- [실행 최소 권한](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-4): 자료 해석 중 실행 계정의 파일·통신·코드 부수 동작이 허용 권한 범위를 지키는지 확인한다. 엔진 전체 최소 권한은 CHK-PLT-001에서 판정한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [부록 2.3 · 인쇄 170·171 / PDF 180·181](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=180) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

파일·결과물의 역직렬화 과정에서 발생하는 코드 실행 위험과 최소 권한·격리 원칙을 진단 자료 재실행 도구의 reader에 적용한다.

**OWASP ASVS:** [V1.5.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 진단 reader/replay 도구에서도 안전한 역직렬화와 제한된 부수 동작을 확인한다.

도구가 실제 배치·사용될 때 적용한다. 실행 권한과 자료 해석 안전성은 별도 판정이다.

**NIST SP 800-53 Rev.5:** [SI-7](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [AC-6](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 재실행에 사용하는 정보의 무단 변경을 검출·처리하고 도구의 실행 권한을 제한한다.

**관련 위협 시나리오:** [SC-21-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-21-04)

 

**관련 근거:** [Q-C11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C11) · [Q-R05-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-05) · [Q-R05-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-07) · [SC-21-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-21-04)

