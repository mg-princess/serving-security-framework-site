# CHK-SUP-004 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-004.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 실행 이미지·패키지와 함께 설치되는 의존성이 승인 내용과 일치하는가? · CHK-SUP-004

<a id="CHK-SUP-004"></a>
 
<a id="212-실제로-실행하는-이미지패키지와-함께-설치되는-의존성도-모두-승인되어-있는가"></a>
 
<a id="source-10-01719"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 엔진을 실행하는 모든 환경. 이미지·가상환경·패키지 중 실제 배포 방식을 기준으로 확인한다. |
| --- | --- |
| 권장 설정·조치 | 실제 배포 방식에 따라 이미지 digest 또는 가상환경·패키지·의존성 구성을 승인 묶음에 기록한다. 배포와 기동 시 실제 구성을 대조하고 승인하지 않은 차이를 처리한 뒤 사용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-supply) |
| 확인 방법 | 실행 중인 이미지의 digest, 시작 명령, 설치 패키지·의존성과 마운트로 덮어쓴 내용을 확인한다. 변경한 시험 사본이 승인 검사에서 식별되는지 비교한다.<br>**정상 동작:** 승인 digest 이미지와 고정 패키지로 기동한다. |
| 판정 기준 | 충족<br>승인 범위뿐 아니라 실제 실행 이미지·entrypoint·의존성의 일치까지 확인된다. 이미지 이름만으로 판정하지 않는다.<br>미충족<br>실행 코드 구성의 비승인 차이가 검사를 통과하고 사용된다.<br>미확인<br>태그만 있거나 실행 중 패키지·마운트 변경을 확인할 수 없다. |
| 남길 자료 | - 승인 manifest/실행 image digest/설치 패키지·entrypoint·마운트 덮어쓰기 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.10.8 패치관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-8)<br>설치된 엔진·OS·의존성에 보안 패치가 적용될 때<br>[공식 안내서 PDF 171쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=171) · 주요 확인사항 2 | **보조 자료**<br>승인한 이미지·패키지·의존성과 실제 설치·실행 구성의 식별 자료를 패치 현황 확인에 사용한다. | [2.10.8 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-10-8) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 이미지 tag·시작 명령 변경으로 코드 바꿔치기 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**CM-2 · CM-8 · SI-7 — 요구 직접 대응**

실행 구성의 기준·목록·무결성을 관리한다.

이미지 digest·명령·패키지·마운트 덮어쓰기를 실행 상태와 대조한다.

서명 필수 기준이 없으므로 CM-14를 직접 충족으로 연결하지 않는다.

#### 배포 자료와 실제 실행 구성을 대조하는 방법

배포 담당자는 이미지 태그와 함께 변경되지 않는 digest를 남기고, 실제 컨테이너의 이미지 식별값·실행 명령·마운트를 승인 명세와 비교해야 한다. Python 환경은 `python -m pip list --format=json`으로 설치 목록을 수집할 수 있다. 이 목록에는 OS 패키지와 별도로 설치한 CUDA·통신 라이브러리가 빠질 수 있으므로 실제 이미지의 패키지 목록도 확인해야 한다.

SBOM을 제공받았다면 이미지 digest와 생성 시점이 현재 배포 대상에 맞는지 확인하고, 실행 때 추가한 패키지와 마운트로 덮어쓴 코드까지 비교해야 한다. SBOM 보유 자체를 승인 일치나 취약점 조치의 증거로 삼지 않는다. 알려진 취약점의 적용 여부와 조치는 CHK-SUP-017에서 확인한다.

서명 검증을 채택한 환경은 승인한 서명자와 발급자를 정한 뒤 다음 명령을 사용할 수 있다. 변수에는 조직이 승인한 값을 넣어야 한다. 검증 실패 시 배포를 보류하고 이미지·서명자·신뢰 설정을 확인해야 한다.

```
cosign verify "$IMAGE_REF" --certificate-identity "$EXPECTED_SIGNER" --certificate-oidc-issuer "$EXPECTED_ISSUER"
```

`IMAGE_REF`는 `저장소/이미지@sha256:해시` 형식으로 고정해야 한다. 검증 출력과 이미지 digest를 남겨야 한다. 서명은 서명자와 이미지의 관계를 확인하며, 패키지의 안전성은 별도 검사해야 한다. 자체 신뢰 키를 쓰는 경우에는 `cosign verify --key "$TRUSTED_KEY" "$IMAGE_REF"`로 검증할 수 있다. SBOM·서명을 필수로 채택했는지는 승인 정책에 따라 판단해야 한다.

시험용 이미지·추가 패키지는 검증 환경에서만 사용하고 시험 후 제거해야 한다. 실제 배포 구성을 복원한 뒤 digest·실행 명령·설치 목록과 정상 요청을 다시 확인해야 한다. [Cosign 공식 검증 안내](https://docs.sigstore.dev/cosign/verifying/verify/)

 

**시험 준비**

 

이미지 생성·배포 도구와 실제 실행 코드를 수집할 방법을 정한다.

 

**시험에서 확인할 내용**

 

이미지 digest·entrypoint·실제 설치 패키지 목록과 승인 묶음을 비교한다.

 

**시험 순서**

 

1. 실제 실행에 사용한 image·entrypoint·패키지 정보를 수집한다.
2. 시험 사본에서 패키지 또는 entrypoint 한 항목을 변경한다.
3. 배포 검사가 그 차이를 식별하는지, 변경된 구성이 실제로 사용되는지 확인하고 승인 구성의 정상 기동과 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 이미지 태그·시작 명령을 바꿔 다른 코드 실행 | 이미지 또는 실제 실행 패키지·entrypoint를 선택해 배포한다. | SC-10-03 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.1 · 인쇄 48 / PDF 58](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=58) / [개발자 4.1.1 · 인쇄 55 / PDF 65](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=65)

오픈소스의 출처·목록·버전 및 종속성 점검을 본문에서 확인했다.

**OWASP ASVS:** [V15.1.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 실행 이미지·패키지·전이 의존성의 목록과 기대한 공급원을 확인하는 일반 공급망 점검이다.

조직의 승인 목록·digest 방식은 채택한 구현 방법이다.

**NIST SP 800-53 Rev.5:** [CM-2](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [SI-7](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 기준 구성을 관리하고 소프트웨어·정보의 무단 변경을 검출·처리한다. 실제 실행 구성과 승인 내용을 대조한다.

**관련 위협 시나리오:** [SC-10-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-10-03)

 

**관련 근거:** [Q-R05-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-02) · [Q-R05-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-04) · [SC-10-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-10-03)

