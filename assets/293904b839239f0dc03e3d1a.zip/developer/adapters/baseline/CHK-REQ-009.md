# CHK-REQ-009 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-009.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 입력이 모델과 각 처리 단계의 조건에 맞는지 검사하는가? · CHK-REQ-009

<a id="CHK-REQ-009"></a>
 
<a id="313-지원하는-모델-입력의-값길이차원과-구성요소의-정합성이-실제-모델처리-단계의-허용-범위-안에-있는가"></a>
 
<a id="source-10-02173"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 활성 입력 endpoint의 token·길이·변환 후 값을 선정 모델·runner 기준으로 확인한다. embedding을 실제 지원·수용하면 consumer가 요구하는 값·차원/shape·필요 dtype·입력 길이와 token/embedding·선택 mask의 대응을 추가 확인한다. routed_experts_prompt_start 등 offset 파라미터를 수용하면 embedding 사용이나 관련 출력 기능의 활성 여부와 별개로 그 의미·형식·유효 위치 범위를 확인한다. 금지·미지원 입력은 실제 거부·제거 근거와 지원 범위를 기록한다. |
| --- | --- |
| 권장 설정·조치 | 실제 모델·consumer의 token·길이와 지원 입력의 값·차원/shape·필요 dtype·정합성을 해당 집행 위치에서 검사한다. embedding·token/mask의 대응과 별도로 수용하는 offset의 의미·형식·유효 위치를 검증하고 비허용 값을 후속 소비 전에 제한한다. 절단·변환을 허용하면 방식·시점과 변환 뒤 소비값을 명시한다. vocab·버퍼 범위 등 구현상 제약을 유지하고 오류는 요청 단위에서 처리한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 입력값·길이·차원·필요한 자료형과 token·embedding·mask의 대응을 확인한다. offset을 받는 경로는 관련 기능의 활성 여부와 별개로 검사한다. 거부·변환한 위치와 실제 모델에 전달한 값을 확인하고, 다른 요청에 미친 영향은 따로 기록한다.<br>**정상 동작:** 선정 tokenizer·모델의 유효 ID와 길이 경계 안 요청이 정상 처리된다. embedding 지원 경로에서는 consumer 규칙에 맞는 값·shape/차원·dtype와 token/mask 대응을 가진 정상 입력을 실제 지원 조합에서 대조한다. offset 파라미터는 embedding·관련 출력의 활성 여부와 별개로 허용 범위 안 값이 정상 처리됨을 확인한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다. |
| 판정 기준 | 충족<br>채택한 입력 제한과 실제 consumer의 값·길이·차원/shape·필요 dtype·정합성 요구를 각 집행 위치에서 지키고 정상 입력은 처리된다. embedding·token/mask의 대응과, 별도로 수용하는 offset의 의미·유효 위치 범위가 유지되며 비허용 입력은 후속 소비 전에 제한된다. 절단·변환을 허용하면 채택한 방식·시점과 변환 뒤 소비값을 확인한다.<br>미충족<br>채택한 입력 제한이나 실제 consumer의 token·길이·embedding 값/차원/shape/필요 dtype·token/mask 정합성 또는 독립된 offset 유효 범위를 위반한 값이 해당 제한 지점을 넘어 수용·소비된다. 비허용 메모리 접근·상태 오염·다른 요청의 피해는 발생 여부와 증거를 별도로 기록한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.<br>미확인<br>적용할 제한·정합성 규칙·집행 위치·허용된 절단/변환 조건 또는 최종 소비값을 확인하지 못했다. 오류 응답만 있고 의도한 입력 처리기/모델 제출 경계의 실제 거부·미도달을 확인하지 못한 부분은 미확인으로 남긴다. 이미 확인한 제한·정합성 위반은 후속 영향의 증거 부족과 구분해 미충족으로 기록한다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다. |
| 남길 자료 | - 모델 vocab·처리 단계별 유효 범위와 입력 제한·집행 위치, 허용된 절단·변환 조건<br>- 실제 지원 embedding의 값·차원/shape·필요 dtype·입력 길이와 token/embedding·mask 대응 규칙 및 제출/변환/소비값<br>- offset 파라미터의 수용 경로·의미·형식·입력 길이에 따른 유효 위치 범위, embedding·관련 출력의 유효 설정과 독립된 offset 거부/소비 결과<br>- 실제 거부 지점·후속 worker/모델 제출의 도달/미도달, 메모리 오류·상태·후속 정상 요청 결과; 단위 mock과 실제 설치 경로의 증거 구분<br>- 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 잘못된 토큰 입력으로 공유 추론 서비스 방해 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-09-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | 토큰 오류 400과 정상 요청은 있으나 누적 비용·소비량은 미확인이다. embedding·멀티모달 분기와 구분한다. |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-09-20261103.json)<br>`/runs/1`<br>부분 결과<br>보안 UNKNOWN · 기능 PASS · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | 토큰 오류 400과 정상 요청은 있으나 누적 비용·소비량은 미확인이다. embedding·멀티모달 분기와 구분한다. |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-09-20261103.json)<br>`/runs/2`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | 토큰 오류 400과 정상 요청은 있으나 누적 비용·소비량은 미확인이다. embedding·멀티모달 분기와 구분한다. |

##### 지원 입력의 차원·정합성과 offset 유효 범위 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 멀티모달 입력 배치와 변환 정합성 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SI-10 · SI-10(3) — 요구 직접 대응**

입력 유효성과 잘못된 입력에 대한 예측 가능한 동작을 확인한다.

token·embedding·mask·offset의 값·shape·dtype·대응과 최종 소비값을 확인한다.

잘못된 입력의 요청 단위 거부와 다른 요청 피해를 분리한다.

 

**시험 준비**

 

선정 모델·endpoint·consumer의 token·길이 범위를 확인한다. embedding의 값·차원/shape·필요 dtype·token/mask 대응 규칙과 별도로 수용하는 offset의 규칙을 확인한다. 작은 경계 시험 자료와 실제 거부 지점·모델 제출 경계를 관측할 방법을 준비한다.

 

**시험에서 확인할 내용**

 

모델과 처리 단계마다 허용하는 token과 길이 범위를 확인한다. 적용할 입력 제한과 검사 위치를 정한 뒤, 정상 입력·경계값·범위 밖 입력이 최종적으로 어떤 값으로 사용되는지 비교한다. embedding을 지원하는 경로에서는 실제 사용 구성요소(consumer)가 요구하는 값, 차원과 배열 형태(shape), 자료형(dtype)을 확인한다. token·embedding·mask가 서로 어떻게 대응해야 하는지도 확인한다. 정상 입력과 이 조건 중 하나만 어긋나게 만든 작은 무해한 입력을 비교한다. routed_experts_prompt_start 등 수용 offset은 embedding 사용·관련 출력 활성 여부와 별개로 의미·형식·유효 위치 범위를 확인한다. 어디에서 입력을 거부하거나 정규화했는지, 그 입력이 후속 worker나 모델 제출 단계까지 도달했는지 기록한다. 절단·변환을 허용했다면 적용 시점과 변환한 값을 확인한다. 입력 제한·정합성을 지켰는지와 메모리 접근·상태 오염·다른 요청에 미친 영향은 각각 기록한다.

 

**시험 순서**

 

1. 모델·consumer의 token/길이 유효 범위와 채택한 입력 제한·집행 위치를 확인하고, 실제 지원 embedding의 값·차원/shape·필요 dtype와 token/embedding·mask 대응 규칙을 기록한다.
2. 정상값, 경계값과 경계를 최소한으로 벗어난 ID·길이를 각각 제출한다. 거부됐는지, 허용한 방식으로 절단·변환됐는지 확인하고 실제로 사용한 값과 비교한다.
3. embedding을 지원하는 경로에서는 정상 구조에서 차원·배열 형태(shape), 필요한 자료형(dtype), mask의 길이·대응 관계 중 하나만 바꾼 작은 무해한 입력을 제출한다.
4. offset을 수용하는 경로에서는 embedding·관련 출력 기능의 활성 여부와 별개로 offset 형식·경계 안/밖 값을 대조한다.
5. 입력을 거부·정규화한 위치와 최종 사용값, 후속 worker나 모델 제출 단계에 도달했는지를 기록한다. 메모리 오류와 실행 상태, 다른 요청과 후속 정상 요청에 미친 영향은 따로 남긴다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 잘못된 토큰 입력으로 추론 처리 방해 | 선정 endpoint가 token 또는 토큰화할 입력을 처리한다. | SC-04-01 |
| 지원 입력의 차원·정합성과 offset 유효 범위 | 선정 endpoint/입력 처리기가 embedding 또는 token/embedding 선택 mask를 실제 지원·수용하거나, 별도로 routed_experts_prompt_start 등 offset 파라미터를 수용할 때 추가한다. embedding은 값·차원/shape·필요 dtype·token/mask 대응을, offset은 embedding·관련 출력 활성 여부와 독립된 의미·형식·위치 범위를 확인한다. token·길이 기본 분기는 유지한다. 담당 CHK의 고유 추가 시험으로 선정하며 기존 SC 원문은 당시 범위로 보존한다. |  |
| 멀티모달 입력 배치와 변환 정합성 | 이미지·오디오·비디오 또는 미리 계산한 멀티모달 embedding을 받는 경로에 적용한다. 일반 API가 미디어를 처리하는 경로와 render 결과·features를 다시 받는 분리형 경로를 각각 확인한다. 지원하지 않는 입력은 실제 거부 여부를 확인한다. |  |

 

**함께 확인할 보호 요구**

 

- [실패 감지·상위 통지](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-6-3): 입력 경계 시험에서 발생한 오류·worker 상태·후속 정상 요청을 제공한다. worker 장애 종류별 감지·상위 통지 기한은 CHK-LIF-008에서 판정한다.

 

**멀티모달 경로의 세부 시험**

 

<a id="mm-input-layout"></a>

 

**미디어 항목과 모델 입력 배치의 정합성**

 

**적용할 환경:** 이미지·오디오·비디오 또는 미리 계산한 멀티모달 embedding을 받는 경로에 적용한다. 일반 API가 미디어를 처리하는 경로와 render 결과·features를 다시 받는 분리형 경로를 각각 확인한다. 지원하지 않는 입력은 실제 거부 여부를 확인한다.

 

**확인할 환경 정보:**

 

- 엔진·모델·processor 판본과 endpoint
 
- URL·base64·업로드·미리 계산한 embedding 중 실제 수용 방식
 
- token 길이, 미디어 종류별 항목·hash·kwargs·metadata 목록
 
- placeholder 위치·길이·겹침 규칙과 모델별 grid·patch·token 대응
 
- embedding 전체의 배열 형태(shape), 내부 차원(hidden dimension)과 필요한 자료형(dtype), worker가 입력을 사용하는 경계

 

**정책과 담당·검사 위치:** 모델·플랫폼 담당자가 지원할 입력과 길이·해상도를 바꿀 수 있는 범위를 정한다. API와 processor는 각각 받아들이는 입력 구조를 검사한다. worker가 실제로 입력을 사용하기 전에도 항목 수·위치·배열 형태 등이 서로 맞는지 확인한다. 일반 embedding·독립 offset 검사는 기존 절차대로 수행한다.

 

**호출 권한과 실패 경계:** 미디어·미리 계산한 embedding 또는 분리형 features를 제출할 수 있는 호출자를 전제로 한다. 제출한 구조가 맞지 않는데도 API·processor 검사를 통과해 모델별 위치 계산이나 worker의 입력 사용 단계까지 도달하는지 확인한다.

 

**정상 대조:** 지원 모델에서 정상 미디어와 가변 크기 입력, 허용한 미리 계산 embedding이 정상 처리된다. 분리형 경로는 해당 판본에서 생성한 정상 render 결과를 generate로 전달한다.

 

**조건을 달리한 시험:**

 

- 작은 정상 입력을 고정하고 병렬 목록의 항목 수 하나, placeholder의 위치·길이·겹침 하나 또는 embedding 전체 shape·필요 dtype 중 하나만 바꾼 시험을 각각 설계한다.
 
- grid·patch·token의 대응 관계는 시험할 모델이 요구하는 규칙에 따라 별도로 바꿔 시험한다. 모든 모델에 같은 배치 공식을 강제하지 않는다.
 
- 검사·변환·거부 위치와 worker 제출의 도달 여부를 대조하고 정상 입력의 과차단도 기록한다.

 

**필수 관측:**

 

- 원 입력·변환 입력·요청 ID와 endpoint
 
- 병렬 목록·placeholder·grid/patch·embedding 전체 shape·dtype의 제출값과 소비값
 
- 실제 검사 지점·거부 사유·후속 worker 도달/미도달
 
- worker 상태와 병행·후속 정상 요청 결과

 

**충족:** 지원하는 정상 입력과 허용한 변환은 처리하고, 어긋난 구조는 해당 검사 지점을 넘어 소비되기 전에 거부하거나 승인된 방식으로 정규화한다.

 

**미충족:** 선정 모델의 목록·placeholder·전체 shape·필요 dtype·grid/patch/token 정합성을 위반한 입력이 해당 검사 지점을 넘어 수용·소비된다. 실제 메모리 오류나 서비스 중단은 별도 영향으로 기록한다.

 

**미확인:** 모델별 입력 규칙이나 거부 위치, 변환 결과 또는 worker에 도달했는지를 확인하지 못했다면 해당 부분을 미확인으로 남긴다. 이미 확인한 입력 제한 위반은 후속 피해의 증거가 부족해도 미충족으로 유지한다.

 

**원복과 재시험:** 정상 미디어·텍스트 요청과 입력 처리 상태를 복원해 확인한다. 모델·processor·입력 schema·분리형 endpoint 또는 embedding 전송 경로가 바뀌면 해당 조건을 재시험한다.

 

**근거:** [병렬 필드·placeholder 공지](https://github.com/vllm-project/vllm/security/advisories/GHSA-34qw-q2h2-jp3m) · [전체 embedding shape 공지](https://github.com/vllm-project/vllm/security/advisories/GHSA-wv77-2vpf-vmmg) · [고정판 입력 검증](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/scale_out/token_in_token_out/protocol.py#L94-L144) · [공식 입력 검증 시험](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/tests/entrypoints/scale_out/token_in_token_out/test_protocol.py#L79-L115)

 

<a id="mm-transform-input"></a>

 

**미디어 변환 의미와 실제 모델 입력**

 

**적용할 환경:** 이미지·오디오·비디오를 decode·정규화·전처리해 모델 입력을 만드는 경로에 적용한다. 캐시 사용 여부와 관계없이 실제 지원하는 변환을 확인한다.

 

**확인할 환경 정보:**

 

- 미디어 종류·입력 방식·processor와 최종 모델 소비 경로
 
- 이미지 size·mode·palette·방향·투명도 처리
 
- 오디오 채널·다운믹스·sample rate
 
- 비디오 추출 프레임·순서·샘플링과 선택한 오디오 추출
 
- processor·decoder 판본과 유효 변환 옵션

 

**정책과 담당·검사 위치:** 모델·운영 담당자는 이미지 방향·투명도, 오디오 채널·다운믹스·sample rate, 비디오 프레임 추출·순서·샘플링을 어떻게 변환할지 정한다. processor 담당자는 정한 방식으로 변환되도록 적용한다. 특정 재생 장치의 표시·청취 방식이나 한 다운믹스 표준을 모든 모델의 정답으로 강제하지 않는다. 캐시 재사용의 정확성은 REQ-016에서 별도로 판정한다.

 

**호출 권한과 실패 경계:** 원본 미디어를 제출하거나 허용된 변환 옵션을 선택할 수 있는 호출자와 변환 설정 담당자의 범위를 기록한다. 정규화 후 이미지 방향·투명도, 오디오 채널이나 비디오 프레임이 승인한 방식과 달라진 채 모델에 전달되는지 확인한다.

 

**정상 대조:** 선정 모델·processor에서 승인한 방향·mode·투명도·채널·프레임 변환을 거친 정상 입력이 기대한 형태로 모델에 전달된다. 가변 해상도·허용 리샘플링 등 정상 변환을 포함한다.

 

**조건을 달리한 시험:**

 

- 작은 정상 입력에서 이미지 방향·투명도·palette, 오디오 채널·다운믹스·sample rate 또는 비디오 프레임·샘플링 중 하나만 바꾼다.
 
- 정책에서 정한 정규화 결과를 실제 전처리 결과와 최종 모델 입력에 비교한다. 정상 입력을 잘못 차단했는지도 기록한다. 캐시를 사용한다면 캐시를 끄거나 새 문맥에서 처리한 결과도 비교 기준으로 확보한다.

 

**필수 관측:**

 

- 원본의 식별값, 해당 모델에서 허용한 변환, 실제 적용된 processor·backend 옵션
 
- 변환 전후 이미지·오디오 파형(waveform)·비디오 프레임의 형태와 식별값, 최종 모델 입력
 
- 변환·거부 위치·후속 소비와 정상 입력 결과

 

**충족:** 허용한 변환 의미와 모델별 입력 계약을 지키고 정상 변환은 처리한다.

 

**미충족:** 승인한 변환 기준과 다른 입력이 해당 검사 지점을 넘어 모델에 전달·소비된다. 캐시 선택 위반은 REQ-016의 별도 결과로 기록한다.

 

**미확인:** 허용 변환 기준·전처리 결과 또는 최종 소비를 확인하지 못한 부분은 미확인이다. 모델 출력 문장만으로 입력 의미의 정합성을 확정하지 않는다. 이미 확인된 입력 위반은 후속 영향 미관측과 구분한다.

 

**원복과 재시험:** processor·decoder·미디어 입력과 임시 자료를 원복하고 정상 변환을 확인한다. 모델·허용 변환·backend·processor 옵션 변경 시 재시험한다.

 

**근거:** [이미지·비디오 hash 의미](https://github.com/vllm-project/vllm/security/advisories/GHSA-c65p-x677-fgj6) · [이미지 방향·투명도](https://github.com/vllm-project/vllm/security/advisories/GHSA-8jr5-v98p-w75m) · [오디오 다운믹스 차이](https://github.com/vllm-project/vllm/security/advisories/GHSA-6c4r-fmh3-7rh8) · [고정판 이미지·배열 hash](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/multimodal/hasher.py#L94-L179) · [공식 변환 설정·hash 시험](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/tests/multimodal/test_hasher.py#L238-L278)

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.4.4 · 인쇄 52 / PDF 62](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=62)

입력의 형식·유형·범위·길이를 정의하고 검증하는 요구가 대응한다.

**OWASP ASVS:** [V2.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V2.2.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 값·범위·구조·연관 필드 정합성을 검증하는 기존 요구다.

token·embedding shape·mask·offset은 이 시스템의 입력 명세다. 실제 GPU 메모리 접근 안전성은 REQ-019에서 별도로 다룬다.

**NIST SP 800-53 Rev.5:** [SI-10](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 정한 입력값의 유효성을 검사한다. 모델과 처리 단계별로 지원하는 값·형식·차원의 조건을 확인한다.

**관련 위협 시나리오:** [SC-04-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-04-01)

 

**관련 근거:** [Q-C04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C04) · [Q-C06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C06) · [SC-04-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-04-01) · [시험 코드 · 지원 입력의 차원·정합성과 offset 유효 범위](https://github.com/vllm-project/vllm/blob/5d35ce3934a7804b298559d2d99eec33792e1eb9/tests/test_request_input_bounds.py#L61-L122)

