# CHK-SUP-011 Python 실행 모드가 달라도 동적으로 불러올 모듈의 허용 여부를 검사하는가?

조건부 하위시험. 부모 점검: [CHK-SUP-009](CHK-SUP-009.md)

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-011.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-011.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-011.md)

## 적용 대상

선정 동적 import 소비 경로와 실제 지원하는 Python 실행 모드가 있을 때 적용한다. 같은 모듈 선택값·허용 정책을 일반 실행과 지원하는 최적화 모드 등에서 비교한다. 코드 선택 출처별 조사 결과는 CHK-SUP-008·CHK-SUP-009·CHK-SUP-010과 연결한다.

## 권장 설정·조치

- 지원하는 각 실행 모드에서 동적 import를 허용하는 모듈·경로·설정값을 제한한다. 보안 검사를 최적화 옵션으로 제거될 수 있는 assertion과 분리하고 실행 전에 유효성을 검사한다.

## 시험 전 준비

지원하는 실행 모드를 확인하고 import를 관측할 방법을 준비한다.

## 확인 방법

같은 동적 import 경로·허용 목록·승인/비승인 무해 모듈을 고정하고 실제 지원하는 Python 실행 모드만 바꿔 검사·거부·import 결과를 비교한다. 보안 판단이 제거 가능한 assertion에만 의존해 특정 모드에서 사라지는지 확인한다. 각 모드에서 승인 모듈의 정상 로딩도 확인한다.

## 정상 대조

지원한다고 선언한 각 실행 모드가 승인 import 목록으로 기동한다.

## 시험 순서

1. 지원 mode별 import 기준선을 확보한다.
2. 선택 가능한 무해 외부 module 경로를 입력한다.
3. 실제 import 또는 거부 위치를 확인한다.

## 필수 증거

1. mode·entrypoint·module 선택값/import 파일/설정 집행 결과

## 충족

지원하는 각 실행 모드에서 허용하지 않은 외부 모듈 로딩을 거부하고 정상 로딩은 가능하다.

## 미충족

지원 mode에서 승인 밖 dynamic import가 허용된다.

## 미확인

지원 mode 목록 또는 실제 import 대상을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 실행 모드 변경으로 코드 허용 검사 생략
- scenario_ids: 1. SC-11-05
- apply_when: 선정 구현에 동적 import 소비 경로와 지원 Python 실행 모드가 있다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-11-05

## 시험 식별자

1. Q-R05-06/SC-11-05

## 외부 기준과 대응 범위

CM-7(5), AC-25 / 요구 직접 대응

비허용 모듈의 실행을 막고 검사 우회를 방지한다.

Python 실행 모드·최적화 옵션이 달라도 import 검사가 유지되는지 비교한다.

assertion 제거 등 실제 지원 모드의 검사 소실을 확인한다.
