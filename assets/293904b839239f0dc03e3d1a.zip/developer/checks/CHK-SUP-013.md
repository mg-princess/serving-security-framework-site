# CHK-SUP-013 모델의 chat template을 해석할 때 허용된 동작만 수행하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-013.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-013.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-013.md)

## 적용 대상

공급물의 template가 실제 renderer에서 해석될 때 적용한다. 요청 override 허용 여부와 공급 template 소비는 별도로 확인한다.

## 권장 설정·조치

- 모델이 제공한 chat template의 버전과 출처를 승인하고 실제 렌더러의 허용 동작을 제한한다. 외부 객체 참조·호출과 렌더링 비용을 정한 범위로 제한하고 실패한 변환 결과의 사용을 막는다.

## 시험 전 준비

허용할 템플릿 기능과 처리 예산을 정하고, 무해한 검증용 시험 자료를 준비한다.

## 확인 방법

실제 선택된 공급 template·renderer·sandbox/의존성·허용 동작과 처리 예산을 고정한다. 정상 template 해석과 금지 참조·동작을 나타내는 무해 template를 대조해 renderer의 실행·거부·비용을 확인한다. 렌더된 결과의 길이·내용·토큰 제한은 CHK-REQ-007의 별도 판정에 연결한다. 명시적 코드 선택·import 허용은 CHK-SUP-008·CHK-SUP-009·CHK-SUP-010·CHK-SUP-011에서 확인한다.

## 정상 대조

승인한 template가 정상 메시지를 기대 형식으로 렌더링한다.

## 시험 순서

1. 공급 템플릿과 적용 renderer를 확인한다.
2. 제한 경계를 확인하는 무해 템플릿을 입력한다.
3. 렌더 결과·차단·시간 상한을 확인한다.

## 필수 증거

1. template digest/renderer·sandbox·의존성/출력·오류·제한 집행

## 충족

금지 동작을 막고 정상 입력 해석은 유지한다.

## 미충족

허용하지 않은 참조·동작이 실행되거나 정한 처리 한도를 넘긴다.

## 미확인

sandbox 이름만 확인했거나 해당 template·renderer 분기에 도달하지 못했다.

## 기능·환경별 분기

1. - name: 모델 template의 위험 동작·비용 유발
- scenario_ids: 1. SC-11-07
- apply_when: 서버 지정·processor/tokenizer·fallback 등 실제 선택된 공급 template가 renderer에서 소비된다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-11-07

## 시험 식별자

1. Q-R05-05/SC-11-07

## 외부 기준과 대응 범위

SI-10(6), AC-6, SC-5 / 요구 직접 대응

비신뢰 입력에 따른 코드 실행·권한 확대·자원 남용을 제한한다.

대화 템플릿 해석기의 금지 참조·호출·파일·렌더링 비용을 시험한다.

산술식 계산 성공만으로 sandbox 실패를 판정하지 않는다.
