# CHK-SUP-012 파일·메시지를 읽을 때 허용하지 않은 객체 생성이나 동작을 막는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-012.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-012.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-012.md)

## 적용 대상

기본 모델·설정의 reader를 확인한다. 대체 파일·compiled cache·공유 daemon 메시지·직렬화 engine은 실제 소비 경로별로 추가한다.

## 권장 설정·조치

- 실제로 읽는 파일·메시지 형식과 reader를 정하고 해당 reader·의존성의 검토된 버전을 사용한다. 허용하지 않은 형식으로의 자동 fallback을 제한하고, 해석 프로세스의 코드 실행·파일·통신 권한을 필요한 범위로 줄인다.

## 시험 전 준비

격리된 손상 시험 자료와 파일 읽기를 관측할 방법을 준비한다. 공유 weight·replay는 자료를 읽어 사용하는 구성요소의 조건에 맞춰 따로 확인한다.

## 확인 방법

모델·설정·compiled cache·공유 daemon 등 실제 파일·메시지 소비 경로마다 승인 형식·reader·의존성 판본을 고정한다. 정상 자료, 금지 형식, 허용 형식 안의 금지 객체·부수 동작을 나타내는 무해 fixture와 손상 자료를 대조해 최종 reader·fallback·객체 생성·파일/통신/코드 부수 동작을 확인한다. 공급원의 접근 자격 변경은 CHK-PLT-005, writer의 변조 가능성은 CHK-SUP-007에서 각각 판정한다. template renderer는 CHK-SUP-013, 외부 진단 자료 consumer는 CHK-OBS-008의 고유 조건과 같은 reader 증거를 공유한다. 멀티모달 경로는 이 항목의 multimodal_cases에서 적용 조건·책임/집행 위치·정상 대조·단일 조건 변형·필수 관측·판정·원복/재시험을 확인한다.

## 정상 대조

선정 엔진에서 승인한 형식·reader·의존성 조합으로 정상 모델·설정 또는 메시지 자료를 처리한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다.

## 시험 순서

1. 유효 형식 선택값·실제 파일/메시지 식별·reader를 기록한다.
2. 정상 자료와 금지 형식·허용 형식 안의 금지 객체/동작을 나타내는 무해 fixture·손상 자료를 각각 제공한다.
3. 거부 또는 fallback·대체 공급원과 최종 reader·객체 생성·파일/통신/코드 부수 동작을 확인한다.
4. 실제 적용하는 multimodal_cases의 정상 대조·한 조건 변형·원복/재시험 설계를 케이스별로 준비한다. 시험 자극의 도달과 실제 위반, 시험기 판정을 구분한다.

## 필수 증거

1. 파일 형식·magic·실제 reader/거부 또는 fallback 경로/실패 후 상태
2. 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측

## 충족

비허용 동작이 발생하지 않고 정상 공급물은 처리된다. PT 선택 자체를 코드 실행 결함으로 판정하지 않는다.

## 미충족

불허 reader·형식으로 조용히 fallback하거나 허용하지 않은 부수 동작이 발생한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.

## 미확인

확장자만 보거나 실제 reader·fallback·부수 접근을 관측하지 못했다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다.

## 기능·환경별 분기

1. - name: 모델 파일 역직렬화로 비승인 코드 실행
- scenario_ids: 1. SC-11-06
- apply_when: 선정 loader/reader가 파일·객체를 해석한다. serialized engine·pickle/cache는 해당 reader 사용 시 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-11-06
2. - name: 자동 파일 선택으로 승인 밖 형식 로딩
- scenario_ids: 1. SC-13-02
- apply_when: 기본 loader의 후보 형식·대체 파일 선택을 조사한다. 원격 취득·daemon 비사용만으로 제외하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-13-02
3. - name: 공유 공급 실패 뒤 승인 밖 파일로 전환
- scenario_ids: 1. SC-13-03
- apply_when: 공유 weights daemon/공급원과 실제 fallback 분기가 선택된다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-13-03
4. - name: 허용 client 메시지로 비허용 객체·명령 처리
- scenario_ids: 1. SC-16-02
- apply_when: 별도 weights daemon의 실제 메시지·역직렬화 경로를 사용한다. 접근 가능한 peer/UID를 조사한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-16-02
5. - name: 실제 미디어 형식과 decoder 선택
- scenario_ids: 
- apply_when: URL·data/base64·업로드·허용 로컬 파일에서 미디어 bytes를 해석하는 경로. 이미지·오디오·비디오별 실제 reader·의존성·외부 실행 프로그램과 fallback을 확인한다. weights reader와 따로 조사한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/security/advisories/GHSA-h3rc-j82p-2c3h
- multimodal_case_refs: 1. MM-DECODER
6. - name: 공개 미디어 입력과 내부 SHM 객체 해석
- scenario_ids: 
- apply_when: 공개 API나 분리형 generate가 받은 미디어 객체·직렬화 자료·참조가 내부 SHM 캐시와 worker reader로 전달되는 구성. 단순 내부 통신 비노출이나 insecure serialization 옵션 이름만으로 제외하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/security/advisories/GHSA-6757-hggm-hp2w
- multimodal_case_refs: 1. MM-SHM-READER

## 시험 식별자

1. Q-R05-07/SC-11-06
2. Q-R05-11/SC-13-02
3. Q-R05-11/SC-13-03
4. Q-C13/SC-16-02

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.10.9 악성코드 통제<br>엔진·주변 시스템의 악성코드 예방·탐지·대응을 관리할 때 | 부분 대응<br>파일·메시지 해석에서 비허용 객체·동작이 발생하지 않는지 확인한다. | [2.10.9 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-9) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

SI-10(6), SI-10, AC-6 / 요구 직접 대응

비신뢰 자료가 코드·명령으로 실행되는 것을 막는다.

파일·메시지 해석기의 객체 생성·파일·통신·역직렬화 경로와 fallback을 시험한다.

형식 검증과 해석기 실행 권한 제한을 함께 유지한다.
