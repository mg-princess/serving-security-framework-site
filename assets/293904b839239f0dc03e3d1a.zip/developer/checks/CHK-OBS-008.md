# CHK-OBS-008 변조된 진단 자료를 거부하고 재실행 도구의 파일·통신·코드 실행 권한을 제한하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-OBS-008.md) · [vLLM 판본 차이](../adapters/vllm/CHK-OBS-008.md) · [SGLang 판본 차이](../adapters/sglang/CHK-OBS-008.md)

## 적용 대상

replay/역직렬화 consumer가 진단 자료를 소비할 때 적용한다. 단순 로그 보관과 구분한다.

## 권장 설정·조치

- replay에 사용할 진단 자료의 출처·식별정보·형식과 reader를 제한한다. 변조 자료를 사용 전에 거부하고 해석 프로세스의 파일·통신·코드 실행 권한을 승인 범위로 제한한다.

## 시험 전 준비

기본 비사용 여부와 실제 reader를 먼저 확인한다. 3.3 자료 해석 안전성의 CHK-SUP-012와 근거를 공유하고, replay의 읽기·실행 인가는 CHK-OBS-007에서 별도로 판정한다. Q-R05-07·Q-C11은 도출 근거로 유지한다.

## 확인 방법

같은 승인 실행 역할과 실제 replay consumer를 고정하고 정상 합성 자료와 무해한 변조·출처/구조 변경 자료를 비교한다. digest·검증·최종 parser/reader·거부·객체 생성과 파일/통신/코드 부수 동작을 대조하고 실행 계정의 허용 권한 범위를 확인한다. 외부 replay 도구의 실제 배치·실행 계정·입력형식·reader 도달이 전제다. 누가 실행할 수 있는지는 CHK-OBS-007, 일반 파일·메시지 reader의 동일 해석 경로는 CHK-SUP-012와 증거를 공유한다. 근거 원문: [F24](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33733).

## 정상 대조

승인 출처의 합성 진단 자료가 허용 reader로 처리된다.

## 시험 순서

1. 별도 사본의 구조·출처 표식을 무해하게 변경한다.
2. replay consumer로 제출한다.
3. 검증·reader·부수 접근을 확인한다.

## 필수 증거

1. 자료 출처·digest/parser·reader 선택/거부·부수 접근

## 충족

비허용 자료 실행·고권한 부수 동작을 막는다. 공급물 해석 점검과 증거를 공유한다.

## 미충족

승인·출처·무결성 검증이 필수인 자료가 필요한 검증을 거치지 않거나 검증에 실패한 채 실제 재실행에 사용된다. 허용 밖 reader로 해석하거나 금지된 파일·통신·코드 부수 동작이 발생한 경우도 포함한다. 자료를 읽어 안전하게 검증·거부하는 과정과 실제 재실행을 구분한다.

## 미확인

외부 consumer·입력형식·실제 reader를 알 수 없다.

## 기능·환경별 분기

1. - name: 변조한 진단 파일로 고권한 도구 동작 유도
- scenario_ids: 1. SC-21-04
- apply_when: replay/역직렬화 consumer가 진단 자료를 실제 읽고 실행한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-21-04

## 시험 식별자

1. Q-C11/SC-21-04

## 외부 기준과 대응 범위

SI-7, SI-10(6), AC-6 / 요구 직접 대응

재실행 자료의 무결성과 비신뢰 자료 실행을 통제한다.

동일 승인 역할에서 변조 진단 자료 거부와 reader의 권한을 확인한다.

실행 역할 권한은 OBS-007, 자료 검증·안전 실행은 OBS-008로 구분한다.
