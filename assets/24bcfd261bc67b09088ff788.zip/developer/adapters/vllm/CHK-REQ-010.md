# CHK-REQ-010 — vLLM

[공통 시험 명세](../../checks/CHK-REQ-010.md) · [기준판 상세 구현](../baseline/CHK-REQ-010.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0에는 기준판의 prompt_is_token_ids 길이 검사와 max_tokens 자동 산정 후 min_tokens 재검사가 없다. |
| --- | --- |
| 수행 방법 | 실제 지원 입력에 한해 embedding 길이 불일치와 max_tokens 생략·min_tokens 초과를 정상 요청과 비교한다. API와 renderer·worker 중 어디에서 거부하는지 기록한다. |
| 확인할 결과·남길 자료 | 지원 스키마, 오류·작업 생성 여부, 후속 정상 요청. 지원하지 않는 필드는 기능 부재로 구분한다. |



### 고정 소스와 확인 범위



[vllm/sampling_params.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/sampling_params.py) · [vllm/v1/engine/input_processor.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/input_processor.py) · [vllm/v1/worker/gpu/sample/logit_bias.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/worker/gpu/sample/logit_bias.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 3건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | /v1/systemone이 새로 등록되고 개발 모드의 RL 관리 라우터가 entrypoints/rl/online으로 이동한다. /abort_requests는 request_ids를 생략하면 모든 진행 요청을 대상으로 한다. |
| --- | --- |
| 수행 방법 | 실제 라우트 목록에서 /v1/systemone과 활성 관리 API를 확인한다. 공개 경로에서는 관리 기능을 제한하고, 중단 시험은 격리된 인스턴스의 지정 요청으로 수행한다. 경로 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | 등록 조건, 호출자별 거부 결과, 지정 요청·전체 요청 구분, 실제 중단과 모델 변경 기록. |



| 코드에서 확인한 차이 | 토큰 범위 검사가 renderer.validate_token_ids로 이동하고, 구조화 출력에는 JSON 중첩 깊이 검사와 Guidance tokenizer 적합성 검사가 추가된다. |
| --- | --- |
| 수행 방법 | 음수·상한 밖 token ID와 깊이가 다른 무해한 schema를 정상 요청과 비교한다. 선택한 tokenizer와 구조화 출력 backend를 기록하고 API 오류뿐 아니라 worker 생존과 후속 정상 요청을 확인한다. |
| 확인할 결과·남길 자료 | 실제 validator·backend, 오류 응답, worker 상태·메모리·후속 정상 요청. 소스의 제한값을 조직 공통 정책값으로 옮기지 않는다. |



| 코드에서 확인한 차이 | prompt_logprob_token_ids가 기준판의 1차원 목록에서 행별 2차원 정수 배열로 바뀐다. 행·열 수를 제한한 뒤 padding하며 -1은 padding 값이다. |
| --- | --- |
| 수행 방법 | 실제 지원 API에서 행 수·행별 ID 수·범위·padding·prompt_logprob_start를 정상·경계 입력으로 비교한다. 기준판의 1차원 시험 파일을 그대로 재사용하지 말고 반환할 점수 필드도 허용 정책과 대조한다. |
| 확인할 결과·남길 자료 | 지원 schema·정규화 뒤 배열·선택 runner·거부 위치·실제 반환 필드와 비용. |



### 고정 소스와 확인 범위



[vllm/entrypoints/generate/structured_decisions/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/generate/structured_decisions/api_router.py) · [vllm/entrypoints/launchers/api_server/routers.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/api_server/routers.py) · [vllm/entrypoints/rl/online/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/rl/online/api_router.py) · [vllm/entrypoints/serve/middleware/authenticate.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/middleware/authenticate.py) · [vllm/sampling_params.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/sampling_params.py) · [vllm/v1/engine/input_processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/input_processor.py) · [vllm/v1/worker/gpu/sample/logit_bias.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu/sample/logit_bias.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



