# CHK-SUP-013 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-013.md) · [기준판 상세 구현](../baseline/CHK-SUP-013.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/entrypoints/chat_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/chat_utils.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/cli/serve.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/launcher.py) · [vllm/renderers/hf.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/renderers/hf.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | 비동기 template 렌더에 VLLM_CHAT_TEMPLATE_RENDER_TIMEOUT 제한과 executor 교체가 추가된다. timeout 뒤 기존 Python thread의 CPU 작업은 계속될 수 있다. |
| --- | --- |
| 수행 방법 | 승인한 무해한 지연 template로 timeout·후속 정상 요청을 비교하고 기존 thread의 CPU·메모리도 관측한다. 제한을 시험 때문에 바꿨다면 승인값으로 복원하고 필요하면 프로세스를 다시 기동한다. |
| 확인할 결과·남길 자료 | 유효 timeout, API 오류·후속 요청, 이전 thread·CPU·메모리의 종결. 응답 timeout을 실제 연산 종료로 판정하지 않는다. |



### 고정 소스와 확인 범위



[vllm/renderers/chat_utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/chat_utils.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/cli/serve.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/launcher.py) · [vllm/envs.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/envs.py) · [vllm/renderers/hf.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/hf.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



