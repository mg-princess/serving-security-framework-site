# CHK-REQ-007 — vLLM

[공통 시험 명세](../../checks/CHK-REQ-007.md) · [기준판 상세 구현](../baseline/CHK-REQ-007.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



### 고정 소스와 확인 범위



[vllm/entrypoints/chat_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/chat_utils.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/cli/serve.py) · [vllm/entrypoints/generate/base/protocol.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/generate/base/protocol.py) · [vllm/entrypoints/launchers/cli_args.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/cli_args.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/launcher.py) · [vllm/renderers/hf.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/renderers/hf.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/renderers/online_renderer.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 3건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



| 코드에서 확인한 차이 | 비동기 template 렌더에 VLLM_CHAT_TEMPLATE_RENDER_TIMEOUT 제한과 executor 교체가 추가된다. timeout 뒤 기존 Python thread의 CPU 작업은 계속될 수 있다. |
| --- | --- |
| 수행 방법 | 승인한 무해한 지연 template로 timeout·후속 정상 요청을 비교하고 기존 thread의 CPU·메모리도 관측한다. 제한을 시험 때문에 바꿨다면 승인값으로 복원하고 필요하면 프로세스를 다시 기동한다. |
| 확인할 결과·남길 자료 | 유효 timeout, API 오류·후속 요청, 이전 thread·CPU·메모리의 종결. 응답 timeout을 실제 연산 종료로 판정하지 않는다. |



| 코드에서 확인한 차이 | 기존 return_mm_kwargs=False를 mm_payload="none"으로 옮기는 alias와 mm_payload 선택이 추가되고, 미디어가 있는 chat의 forwarded prompt_token_ids는 제거한 뒤 messages를 렌더한다. 존재하지 않는 모델 오류에는 유효 alias 이름이 추가된다. |
| --- | --- |
| 수행 방법 | 원래 옵션과 alias 모두에서 미디어 tensor·metadata·token ID 반환을 확인한다. 미디어+forwarded ID 조합의 실제 입력을 대조하고 모델 오류의 alias 노출도 허용 필드 정책에 포함한다. |
| 확인할 결과·남길 자료 | 최종 입력·반환 필드·alias 처리·오류 응답, 일반·stream의 정상 대조. |



### 고정 소스와 확인 범위



[vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/multimodal.py) · [vllm/renderers/chat_utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/chat_utils.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/cli/serve.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/launcher.py) · [vllm/entrypoints/openai/chat_completion/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/chat_completion/protocol.py) · [vllm/entrypoints/openai/responses/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/responses/protocol.py) · [vllm/entrypoints/scale_out/token_in_token_out/mm_features.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/scale_out/token_in_token_out/mm_features.py) · [vllm/entrypoints/serve/engine/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/engine/serving.py) · [vllm/envs.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/envs.py) · [vllm/renderers/hf.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/hf.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/processor.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



