

### vLLM · 1. 인증·접근 통제

 

<a id="f-vllm-field-1-content"></a>

 

<a id="model-selector-evidence"></a>

 

##### 최종 모델·adapter 선택

 

모델명 외에 기본 멀티모달 LoRA·resolver·SageMaker adapter 주입을 실제 사용하는지 확인해야 한다. 제출 선택값에서 최종 adapter·revision·파일 경로까지 추적하고 허용 주체·모델의 정책에 대조해야 한다. 외부 decorator의 header와 검증 효과는 설치 패키지와 실제 처리에서 확인해야 한다.

 

공식 고정 소스: [vllm/entrypoints/openai/chat_completion/serving.py:299](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/openai/chat_completion/serving.py#L299) · [vllm/entrypoints/serve/engine/serving.py:156-192](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/serve/engine/serving.py#L156-L192) · [vllm/entrypoints/openai/models/serving.py:113-117](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/openai/models/serving.py#L113-L117) · [vllm/entrypoints/serve/sagemaker/api_router.py:109](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/serve/sagemaker/api_router.py#L109)

 

<a id="추론-요청자료공유-상태--상세"></a>
 
<a id="부족할-때-보완할-방향"></a>
 신원 확인부터 최종 모델·작업의 인가까지 실제 요청 경로를 따라 확인한다. Gateway 우회 경로와 관리 route도 조사한다. [CHK-REQ-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002)는 서버가 최종 선택한 작업과 권한 검사를 대조하며, ASGI에서는 path·root_path와 경로 재작성을 함께 확인한다.

 

v0.11.0 인증 middleware는 `/v1` 접두사를 검사하고, 고정 v0.31.0은 `/v1`, `/v2`, `/inference`, `/cohere`를 검사한다. root_path 제거에 사용하는 값도 URL(scope).path에서 scope[path]로 바뀌었다. 실제 등록 route마다 Gateway 경유·직통과 자격 유무를 시험해 보호되는 작업을 확인한다. 근거: [v0.11.0](https://github.com/vllm-project/vllm/blob/v0.11.0/vllm/entrypoints/openai/api_server.py#L1253) · [고정 v0.31.0](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/serve/middleware/authenticate.py#L10)

 

**연결할 점검과 증거** [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001)·[CHK-REQ-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002)·[CHK-REQ-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-003)에서 일반 API·관리 작업과 Gateway 우회 경로를 확인한다. [CHK-PLT-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-001)·[CHK-PLT-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-002)에서는 엔진·worker의 실행 권한과 내부 통신 접근권을 확인한다. API별로 사용한 자격, 변환 전후 경로, 최종 처리 함수와 실제 작업 수행 여부를 기록하고, 내부 통신은 프로세스·UID·socket·공유 메모리의 접근 시험 결과를 남긴다. API 인증과 내부 IPC 접근 제한은 각각의 통제 위치에서 확인한다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.30.0 — 기본 모델과 같은 LoRA 이름



| 코드에서 확인한 차이 | v0.30.0의 LoRA 적재 요청 검사에는 기준판의 base model 이름 충돌 거부가 없다. |
| --- | --- |
| 수행 방법 | 격리된 관리 접점에서 base model과 같은 이름·별도 이름의 무해한 LoRA를 비교하고 실제 선택 모델·LoRA·해제 후 결과를 기록한다. 관리 경로와 모델별 권한도 함께 확인한다. |
| 확인할 결과·남길 자료 | 등록·거부 결과, alias→실제 모델 대응, LoRA 해제·원복과 정상 요청. |



확인할 체크리스트: [CHK-REQ-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-005)



### v0.32.0 — HTTP와 별도로 열리는 gRPC 포트



| 코드에서 확인한 차이 | Rust frontend의 --grpc-port는 HTTP와 별도 Inference·Control listener를 연다. HTTP key middleware와 gRPC 서비스 등록 경로가 분리된다. Python --grpc도 별도 서버이며 add_insecure_port와 외부 servicer를 사용한다. |
| --- | --- |
| 수행 방법 | 선정 frontend와 --grpc·--grpc-port 사용 여부를 기록한다. 사용하는 각 포트에서 무자격·잘못된 자격·허용 자격을 비교하고 관리 RPC를 별도 제한한다. gRPC를 쓰지 않으면 포트 비개방을 확인한다. |
| 확인할 결과·남길 자료 | 실제 listener·등록 서비스·TLS·접근 제한·관리 RPC 거부. HTTP API key 시험 결과를 다른 서버의 인증 결과로 재사용하지 않는다. |



확인할 체크리스트: [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001) · [CHK-REQ-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002) · [CHK-REQ-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-003)



### v0.32.0 — PP 구성의 공유 가중치 준비·종료



| 코드에서 확인한 차이 | 가중치 daemon의 rank 배치가 DP·TP에서 DP·PP·TP로 확장된다. 기준판이 거부하던 PP 구성을 v0.32.0은 rank 배치에 포함한다. |
| --- | --- |
| 수행 방법 | 공유 가중치를 PP와 함께 사용하면 dp_rank·pp_rank·tp_rank·장치·daemon socket을 대응시킨다. 한 rank 준비 실패와 daemon 종료 후 기존 소비자·새 취득을 분리해 확인한다. |
| 확인할 결과·남길 자료 | rank별 모델·layout·IPC payload·준비, 종료·참조 반환과 후속 정상 취득. release 응답만으로 소비자 참조 반환을 완료하지 않는다. |



확인할 체크리스트: [CHK-REQ-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-005)



### v0.32.0 — 브라우저 호출을 허용할 출처



| 코드에서 확인한 차이 | allowed_origins의 기본값이 ["*"]에서 []로 바뀐다. |
| --- | --- |
| 수행 방법 | 브라우저 호출이 필요하면 승인한 Origin만 명시한다. 허용·비허용 Origin의 preflight와 실제 요청을 각각 확인하고, 인증 키 없는 직통 요청도 별도로 확인한다. |
| 확인할 결과·남길 자료 | 실행 인자, Access-Control-Allow-Origin 응답, 정상·거부 요청. CORS 결과와 API 인증 결과를 구분한다. |



확인할 체크리스트: [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001) · [CHK-REQ-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002)



### v0.32.0 — 추가·이동한 추론·관리 API



| 코드에서 확인한 차이 | /v1/systemone이 새로 등록되고 개발 모드의 RL 관리 라우터가 entrypoints/rl/online으로 이동한다. /abort_requests는 request_ids를 생략하면 모든 진행 요청을 대상으로 한다. |
| --- | --- |
| 수행 방법 | 실제 라우트 목록에서 /v1/systemone과 활성 관리 API를 확인한다. 공개 경로에서는 관리 기능을 제한하고, 중단 시험은 격리된 인스턴스의 지정 요청으로 수행한다. 경로 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | 등록 조건, 호출자별 거부 결과, 지정 요청·전체 요청 구분, 실제 중단과 모델 변경 기록. |



확인할 체크리스트: [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001) · [CHK-REQ-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002) · [CHK-REQ-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-003) · [CHK-REQ-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-005)

