# CHK-SUP-005 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-005.md) · [기준판 상세 구현](../baseline/CHK-SUP-005.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/config/model.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/model.py) · [vllm/transformers_utils/utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/transformers_utils/utils.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | weights 재적재가 공통 reload.inplace로 이동한다. 새 weights_path를 지정하면 이전 revision뿐 아니라 model_weights 객체 저장소 공급원도 비운다. |
| --- | --- |
| 수행 방법 | 객체 저장소 공급원을 설정했던 모델에서 승인한 새 경로로 바꾸고 최종 읽기 파일·저장소를 확인한다. V1·V2 caller의 LoRA·encoder·MM 캐시 초기화도 함께 관측한다. |
| 확인할 결과·남길 자료 | 변경 전후 model·model_weights·revision, 실제 파일·적재 tensor와 새 요청 결과. 누락 경고가 났다면 필수 weights 준비 여부를 별도로 판정한다. |



### 고정 소스와 확인 범위



[vllm/config/model.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/model.py) · [vllm/model_executor/model_loader/reload/inplace.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/reload/inplace.py) · [vllm/transformers_utils/utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/utils.py) · [vllm/v1/worker/gpu/model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu/model_runner.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu_model_runner.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



