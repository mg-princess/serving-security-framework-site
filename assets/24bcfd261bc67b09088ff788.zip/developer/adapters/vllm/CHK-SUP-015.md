# CHK-SUP-015 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-015.md) · [기준판 상세 구현](../baseline/CHK-SUP-015.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0의 멀티모달 hash 직렬화는 v0.31.0의 길이 framing과 다르다. KV 추가 키도 cache_salt·LoRA·MM 종류를 붙이는 형태가 다르다. |
| --- | --- |
| 수행 방법 | 멀티모달 원문·분할 경계·옵션·LoRA·salt를 한 조건씩 바꿔 재사용 여부와 최종 결과를 확인한다. 판본을 넘겨 이전 캐시를 재사용하려면 호환 증거를 확보하거나 별도 경로에서 새로 생성한다. |
| 확인할 결과·남길 자료 | 판본별 hash 입력·키, 적중 여부, 실제 사용 자료·정상 결과. 새 캐시 경로와 이전 경로를 기록한다. |



### 고정 소스와 확인 범위



[vllm/compilation/backends.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/compilation/backends.py) · [vllm/compilation/caching.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/compilation/caching.py) · [vllm/compilation/compiler_interface.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/compilation/compiler_interface.py) · [vllm/compilation/decorators.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/compilation/decorators.py) · [vllm/multimodal/hasher.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/hasher.py) · [vllm/v1/core/kv_cache_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/core/kv_cache_utils.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



### 고정 소스와 확인 범위



[vllm/compilation/backends.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/compilation/backends.py) · [vllm/compilation/caching.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/compilation/caching.py) · [vllm/compilation/compiler_interface.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/compilation/compiler_interface.py) · [vllm/compilation/decorators.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/compilation/decorators.py) · [vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/multimodal.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/processor.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



