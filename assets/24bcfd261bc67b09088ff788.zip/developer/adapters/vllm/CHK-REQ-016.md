# CHK-REQ-016 — vLLM

[공통 시험 명세](../../checks/CHK-REQ-016.md) · [기준판 상세 구현](../baseline/CHK-REQ-016.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0의 멀티모달 hash 직렬화는 v0.31.0의 길이 framing과 다르다. KV 추가 키도 cache_salt·LoRA·MM 종류를 붙이는 형태가 다르다. |
| --- | --- |
| 수행 방법 | 멀티모달 원문·분할 경계·옵션·LoRA·salt를 한 조건씩 바꿔 재사용 여부와 최종 결과를 확인한다. 판본을 넘겨 이전 캐시를 재사용하려면 호환 증거를 확보하거나 별도 경로에서 새로 생성한다. |
| 확인할 결과·남길 자료 | 판본별 hash 입력·키, 적중 여부, 실제 사용 자료·정상 결과. 새 캐시 경로와 이전 경로를 기록한다. |



### 고정 소스와 확인 범위



[vllm/entrypoints/openai/models/serving.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/openai/models/serving.py) · [vllm/multimodal/hasher.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/hasher.py) · [vllm/multimodal/processing/inputs.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/processing/inputs.py) · [vllm/v1/core/kv_cache_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/core/kv_cache_utils.py) · [vllm/v1/engine/async_llm.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/async_llm.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 3건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



| 코드에서 확인한 차이 | 기존 return_mm_kwargs=False를 mm_payload="none"으로 옮기는 alias와 mm_payload 선택이 추가되고, 미디어가 있는 chat의 forwarded prompt_token_ids는 제거한 뒤 messages를 렌더한다. 존재하지 않는 모델 오류에는 유효 alias 이름이 추가된다. |
| --- | --- |
| 수행 방법 | 원래 옵션과 alias 모두에서 미디어 tensor·metadata·token ID 반환을 확인한다. 미디어+forwarded ID 조합의 실제 입력을 대조하고 모델 오류의 alias 노출도 허용 필드 정책에 포함한다. |
| 확인할 결과·남길 자료 | 최종 입력·반환 필드·alias 처리·오류 응답, 일반·stream의 정상 대조. |



### 고정 소스와 확인 범위



[vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/multimodal.py) · [vllm/distributed/device_communicators/shm_object_storage.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_object_storage.py) · [vllm/entrypoints/openai/chat_completion/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/chat_completion/protocol.py) · [vllm/entrypoints/openai/models/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/models/serving.py) · [vllm/entrypoints/openai/responses/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/responses/protocol.py) · [vllm/entrypoints/scale_out/token_in_token_out/mm_features.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/scale_out/token_in_token_out/mm_features.py) · [vllm/entrypoints/serve/engine/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/engine/serving.py) · [vllm/multimodal/cache/lru.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/cache/lru.py) · [vllm/multimodal/cache/shm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/cache/shm.py) · [vllm/multimodal/hasher.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/hasher.py) · [vllm/multimodal/processing/inputs.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/processing/inputs.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/processor.py) · [vllm/v1/core/kv_cache_utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/core/kv_cache_utils.py) · [vllm/v1/engine/async_llm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/async_llm.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



