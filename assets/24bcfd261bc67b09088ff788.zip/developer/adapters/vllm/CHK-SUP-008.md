# CHK-SUP-008 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-008.md) · [기준판 상세 구현](../baseline/CHK-SUP-008.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



### 고정 소스와 확인 범위



[vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/multimodal.py) · [vllm/entrypoints/generate/base/protocol.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/generate/base/protocol.py) · [vllm/entrypoints/launchers/cli_args.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/cli_args.py) · [vllm/entrypoints/pooling/base/serving.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/pooling/base/serving.py) · [vllm/multimodal/processing/context.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/processing/context.py) · [vllm/multimodal/processing/inputs.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/processing/inputs.py) · [vllm/plugins/lora_resolvers/hf_hub_resolver.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/plugins/lora_resolvers/hf_hub_resolver.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/transformers_utils/processor.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



### 고정 소스와 확인 범위



[vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/multimodal.py) · [vllm/entrypoints/generate/base/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/generate/base/protocol.py) · [vllm/entrypoints/pooling/base/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/pooling/base/serving.py) · [vllm/multimodal/processing/context.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/processing/context.py) · [vllm/multimodal/processing/inputs.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/processing/inputs.py) · [vllm/plugins/lora_resolvers/hf_hub_resolver.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/plugins/lora_resolvers/hf_hub_resolver.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/processor.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



