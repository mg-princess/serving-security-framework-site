

### vLLM · 8. 감사 기록·관측 신뢰성

 

<a id="f-vllm-field-8-content"></a>

 

<a id="log-dump-evidence"></a>

 

##### 로그·예외 dump 생성 조건

 

실행 예외의 dump 호출과 선택 debug/output 로그는 각각 확인해야 한다. NewRequestData의 prompt token 길이·req_id·sampling_params·lora_request와 실제 수집 필드를 대조해야 한다. 비스트리밍 response INFO 기록의 VLLM_DEBUG_LOG_API_SERVER_RESPONSE, 일반 output INFO의 enable_log_outputs·request_logger 조건을 유효 설정과 실제 정상/안전한 오류 사본에서 확인해야 한다. 수집 필드와 각 사본의 조회·저장 보호는 해당 CHK에서 따로 판정해야 한다.

 

공식 고정 소스: [vllm/v1/engine/core.py:540-553](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/v1/engine/core.py#L540-L553) · [vllm/logging_utils/dump_input.py:56-81](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/logging_utils/dump_input.py#L56-L81) · [vllm/v1/core/sched/output.py:112-133](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/v1/core/sched/output.py#L112-L133) · [vllm/entrypoints/serve/middleware/register.py:57-63](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/serve/middleware/register.py#L57-L63) · [vllm/entrypoints/serve/middleware/log_response.py:137-143](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/serve/middleware/log_response.py#L137-L143) · [vllm/entrypoints/serve/utils/request_logger.py:81-115](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/serve/utils/request_logger.py#L81-L115) · [vllm/entrypoints/openai/chat_completion/serving.py:907](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/openai/chat_completion/serving.py#L907) · [vllm/entrypoints/launchers/cli_args.py:163](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/launchers/cli_args.py#L163)

 

응답과 별도로 남는 로그 사본을 조사하고, 실제 실행 상태와 기록을 대조한다. 내보내기·수집 구간의 보호는 [CHK-PLT-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-009)와 앞의 정보·통신 보호 분야에서 확인한다.

 

**연결할 점검과 구현 위치** [CHK-OBS-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-001)·[CHK-OBS-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-002)에서 요청·승인·배포·관리 기록을 실제 준비·실패·종료 상태와 대조한다. UniProc의 check_health 호출 결과와 정상 추론 결과는 각각 기록하고, [CHK-OBS-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-011)에서는 필수 기록의 수집 중단·누락과 복구 후 재개를 확인한다. 기록·진단에 포함되는 정보, 저장 사본의 접근·보존은 [CHK-OBS-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-003)·[CHK-OBS-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-006)·[CHK-OBS-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-012)에 연결한다.

 

내장 사용·환경 정보 보고는 [CHK-OBS-004](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-004)·[CHK-OBS-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-005)에서 확인한다. 비활성 설정의 최초 판단과 초기·주기 보고를 관측하고, 설정 조합마다 새 프로세스로 시험한다. 정확한 환경변수 판정식과 우선순위는 CHK-OBS-004의 엔진별 확인 사항을 따른다. 보고를 허용한 경우에는 승인한 항목·수신지·주기와 실제 전송 내용을 비교한다.

 

**남길 증거** 동일 실행의 요청 ID·대상·행위자·정책 판본, 상태 기록과 별도 계측한 준비·종료 결과를 연결한다. 수집 장애의 발생·탐지·알림·복구·수집 재개 시각과 실제 저장 자료를 남긴다. 사용·환경 정보 보고에서는 새 실행의 유효 설정과 초기·주기 자료의 생성·파일 기록·송신을 관측한 결과를 남긴다. 이전 사본과 구분할 근거도 기록한다. 수집 장애 때문에 증거가 부족한 시험은 프레임워크 6장 「검증과 결과 평가」의 판정 규칙을 따른다. 실제 상태·기록·수집 장애의 구현 위치는 [CHK-OBS-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-001)·[CHK-OBS-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-002)·[CHK-OBS-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-011)의 공식 고정 소스에서 확인한다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.32.0 — 대기열 거부 기록과 진단 종료



| 코드에서 확인한 차이 | 대기열 거부 로그가 INFO에서 DEBUG로 바뀌고 거부 원인별 계측이 추가된다. profiler 시작·정지는 lock과 session 상태를 사용한다. |
| --- | --- |
| 수행 방법 | 대기열 초과 사건은 기본 INFO 로그 존재만으로 판단하지 말고 실제 거부·관련 지표를 수집한다. profiler 동시 시작·정지와 실패 뒤 수집 종료·자원 반환도 비교한다. |
| 확인할 결과·남길 자료 | 거부 원인·요청 결과·지표 수집, profiler session·실제 backend 종료·후속 정상 요청. |



확인할 체크리스트: [CHK-LIF-014](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-014) · [CHK-OBS-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-001) · [CHK-OBS-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-002) · [CHK-OBS-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-011)

