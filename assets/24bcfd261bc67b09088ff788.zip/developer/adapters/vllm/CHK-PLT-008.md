# CHK-PLT-008 — vLLM

[공통 시험 명세](../../checks/CHK-PLT-008.md) · [기준판 상세 구현](../baseline/CHK-PLT-008.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/distributed/device_communicators/shm_broadcast.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/distributed/device_communicators/shm_broadcast.py) · [vllm/utils/network_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/utils/network_utils.py) · [vllm/v1/engine/core.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/core.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | Rust frontend의 --grpc-port는 HTTP와 별도 Inference·Control listener를 연다. HTTP key middleware와 gRPC 서비스 등록 경로가 분리된다. Python --grpc도 별도 서버이며 add_insecure_port와 외부 servicer를 사용한다. |
| --- | --- |
| 수행 방법 | 선정 frontend와 --grpc·--grpc-port 사용 여부를 기록한다. 사용하는 각 포트에서 무자격·잘못된 자격·허용 자격을 비교하고 관리 RPC를 별도 제한한다. gRPC를 쓰지 않으면 포트 비개방을 확인한다. |
| 확인할 결과·남길 자료 | 실제 listener·등록 서비스·TLS·접근 제한·관리 RPC 거부. HTTP API key 시험 결과를 다른 서버의 인증 결과로 재사용하지 않는다. |



### 고정 소스와 확인 범위



[rust/src/server/src/lib.rs](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/rust/src/server/src/lib.rs) · [rust/src/server/src/middleware/auth.rs](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/rust/src/server/src/middleware/auth.rs) · [vllm/distributed/device_communicators/shm_broadcast.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_broadcast.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/cli/serve.py) · [vllm/entrypoints/launchers/cli_args.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/cli_args.py) · [vllm/entrypoints/launchers/grpc_server.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/grpc_server.py) · [vllm/utils/network_utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/utils/network_utils.py) · [vllm/v1/engine/core.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/core.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



