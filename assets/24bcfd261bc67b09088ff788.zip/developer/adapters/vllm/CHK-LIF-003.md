# CHK-LIF-003 — vLLM

[공통 시험 명세](../../checks/CHK-LIF-003.md) · [기준판 상세 구현](../baseline/CHK-LIF-003.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



### 고정 소스와 확인 범위



[vllm/config/scheduler.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/scheduler.py) · [vllm/entrypoints/generate/base/protocol.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/generate/base/protocol.py) · [vllm/entrypoints/generate/base/serving.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/generate/base/serving.py) · [vllm/entrypoints/launchers/cli_args.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/cli_args.py) · [vllm/envs.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/envs.py) · [vllm/multimodal/media/audio.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/media/audio.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/renderers/online_renderer.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 6건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | 토큰 범위 검사가 renderer.validate_token_ids로 이동하고, 구조화 출력에는 JSON 중첩 깊이 검사와 Guidance tokenizer 적합성 검사가 추가된다. |
| --- | --- |
| 수행 방법 | 음수·상한 밖 token ID와 깊이가 다른 무해한 schema를 정상 요청과 비교한다. 선택한 tokenizer와 구조화 출력 backend를 기록하고 API 오류뿐 아니라 worker 생존과 후속 정상 요청을 확인한다. |
| 확인할 결과·남길 자료 | 실제 validator·backend, 오류 응답, worker 상태·메모리·후속 정상 요청. 소스의 제한값을 조직 공통 정책값으로 옮기지 않는다. |



| 코드에서 확인한 차이 | Rust frontend의 --grpc-port는 HTTP와 별도 Inference·Control listener를 연다. HTTP key middleware와 gRPC 서비스 등록 경로가 분리된다. Python --grpc도 별도 서버이며 add_insecure_port와 외부 servicer를 사용한다. |
| --- | --- |
| 수행 방법 | 선정 frontend와 --grpc·--grpc-port 사용 여부를 기록한다. 사용하는 각 포트에서 무자격·잘못된 자격·허용 자격을 비교하고 관리 RPC를 별도 제한한다. gRPC를 쓰지 않으면 포트 비개방을 확인한다. |
| 확인할 결과·남길 자료 | 실제 listener·등록 서비스·TLS·접근 제한·관리 RPC 거부. HTTP API key 시험 결과를 다른 서버의 인증 결과로 재사용하지 않는다. |



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



| 코드에서 확인한 차이 | 대기열 거부 로그가 INFO에서 DEBUG로 바뀌고 거부 원인별 계측이 추가된다. profiler 시작·정지는 lock과 session 상태를 사용한다. |
| --- | --- |
| 수행 방법 | 대기열 초과 사건은 기본 INFO 로그 존재만으로 판단하지 말고 실제 거부·관련 지표를 수집한다. profiler 동시 시작·정지와 실패 뒤 수집 종료·자원 반환도 비교한다. |
| 확인할 결과·남길 자료 | 거부 원인·요청 결과·지표 수집, profiler session·실제 backend 종료·후속 정상 요청. |



| 코드에서 확인한 차이 | 비동기 template 렌더에 VLLM_CHAT_TEMPLATE_RENDER_TIMEOUT 제한과 executor 교체가 추가된다. timeout 뒤 기존 Python thread의 CPU 작업은 계속될 수 있다. |
| --- | --- |
| 수행 방법 | 승인한 무해한 지연 template로 timeout·후속 정상 요청을 비교하고 기존 thread의 CPU·메모리도 관측한다. 제한을 시험 때문에 바꿨다면 승인값으로 복원하고 필요하면 프로세스를 다시 기동한다. |
| 확인할 결과·남길 자료 | 유효 timeout, API 오류·후속 요청, 이전 thread·CPU·메모리의 종결. 응답 timeout을 실제 연산 종료로 판정하지 않는다. |



| 코드에서 확인한 차이 | prompt_logprob_token_ids가 기준판의 1차원 목록에서 행별 2차원 정수 배열로 바뀐다. 행·열 수를 제한한 뒤 padding하며 -1은 padding 값이다. |
| --- | --- |
| 수행 방법 | 실제 지원 API에서 행 수·행별 ID 수·범위·padding·prompt_logprob_start를 정상·경계 입력으로 비교한다. 기준판의 1차원 시험 파일을 그대로 재사용하지 말고 반환할 점수 필드도 허용 정책과 대조한다. |
| 확인할 결과·남길 자료 | 지원 schema·정규화 뒤 배열·선택 runner·거부 위치·실제 반환 필드와 비용. |



### 고정 소스와 확인 범위



[rust/src/server/src/lib.rs](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/rust/src/server/src/lib.rs) · [rust/src/server/src/middleware/auth.rs](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/rust/src/server/src/middleware/auth.rs) · [vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/multimodal.py) · [vllm/config/scheduler.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/scheduler.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/cli/serve.py) · [vllm/entrypoints/generate/base/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/generate/base/serving.py) · [vllm/entrypoints/launchers/cli_args.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/cli_args.py) · [vllm/entrypoints/launchers/grpc_server.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/grpc_server.py) · [vllm/envs.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/envs.py) · [vllm/multimodal/media/audio.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/media/audio.py) · [vllm/renderers/hf.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/hf.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/online_renderer.py) · [vllm/sampling_params.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/sampling_params.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/processor.py) · [vllm/v1/engine/async_llm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/async_llm.py) · [vllm/v1/engine/input_processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/input_processor.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



