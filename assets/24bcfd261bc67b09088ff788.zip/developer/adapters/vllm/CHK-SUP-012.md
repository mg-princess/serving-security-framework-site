# CHK-SUP-012 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-012.md) · [기준판 상세 구현](../baseline/CHK-SUP-012.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.32.0은 Python 최소 버전을 3.11로 올리고 requests·transformers·tokenizers·aiohttp·Pillow·filelock 등의 의존 범위를 바꾼다. v0.30.0은 tokenizer·grammar·GPU 라이브러리와 harmony 패키지 선택이 기준판과 다르다. |
| --- | --- |
| 수행 방법 | 실제 이미지에서 Python·패키지·decoder·GPU 라이브러리 목록과 digest를 수집하고 해당 판본의 설치 선언과 대조한다. 공지의 영향 조건·백포트·실제 활성 기능을 따로 평가한다. |
| 확인할 결과·남길 자료 | 실제 설치 목록·wheel/이미지 식별과 선언 차이·공지 적용 근거·재발 시험. 의존성 하한 변경만으로 모든 취약점 조치 완료를 판정하지 않는다. |



### 고정 소스와 확인 범위



[pyproject.toml](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/pyproject.toml) · [requirements/common.txt](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/requirements/common.txt) · [requirements/cuda.txt](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/requirements/cuda.txt) · [setup.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/setup.py) · [vllm/config/load.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/load.py) · [vllm/distributed/device_communicators/shm_object_storage.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/distributed/device_communicators/shm_object_storage.py) · [vllm/entrypoints/scale_out/token_in_token_out/mm_features.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/scale_out/token_in_token_out/mm_features.py) · [vllm/model_executor/model_loader/default_loader.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/model_executor/model_loader/default_loader.py) · [vllm/model_executor/model_loader/weight_cache/daemon.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/model_executor/model_loader/weight_cache/daemon.py) · [vllm/model_executor/model_loader/weight_cache/ipc_loader.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/model_executor/model_loader/weight_cache/ipc_loader.py) · [vllm/model_executor/model_loader/weight_cache/protocol.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/model_executor/model_loader/weight_cache/protocol.py) · [vllm/multimodal/media/audio.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/media/audio.py) · [vllm/multimodal/media/image.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/multimodal/media/image.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 3건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



| 코드에서 확인한 차이 | worker queue는 큰 out-of-band buffer를 재사용 ring에서 복사하고, 선택한 tensor arena는 storage 해제와 H2D 완료 event 뒤 slot을 반환한다. 일반 pickle 경로도 남는다. |
| --- | --- |
| 수행 방법 | tensor arena 활성 여부와 실제 fallback을 기록한다. 느린 소비·비동기 H2D·취소·worker 종료에서 tensor storage·CUDA event·slot 반환과 다음 요청 결과를 관측한다. |
| 확인할 결과·남길 자료 | queue 선택·arena slot·reader별 반환·GPU 완료·다음 재사용 순서. 새 arena를 별도 사용자 인가 경계로 간주하지 않는다. |



| 코드에서 확인한 차이 | v0.32.0은 Python 최소 버전을 3.11로 올리고 requests·transformers·tokenizers·aiohttp·Pillow·filelock 등의 의존 범위를 바꾼다. v0.30.0은 tokenizer·grammar·GPU 라이브러리와 harmony 패키지 선택이 기준판과 다르다. |
| --- | --- |
| 수행 방법 | 실제 이미지에서 Python·패키지·decoder·GPU 라이브러리 목록과 digest를 수집하고 해당 판본의 설치 선언과 대조한다. 공지의 영향 조건·백포트·실제 활성 기능을 따로 평가한다. |
| 확인할 결과·남길 자료 | 실제 설치 목록·wheel/이미지 식별과 선언 차이·공지 적용 근거·재발 시험. 의존성 하한 변경만으로 모든 취약점 조치 완료를 판정하지 않는다. |



### 고정 소스와 확인 범위



[pyproject.toml](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/pyproject.toml) · [requirements/common.txt](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/requirements/common.txt) · [requirements/cuda.txt](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/requirements/cuda.txt) · [setup.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/setup.py) · [vllm/config/load.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/load.py) · [vllm/distributed/device_communicators/shm_broadcast.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_broadcast.py) · [vllm/distributed/device_communicators/shm_object_storage.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_object_storage.py) · [vllm/distributed/device_communicators/shm_tensor_arena.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_tensor_arena.py) · [vllm/entrypoints/scale_out/token_in_token_out/mm_features.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/scale_out/token_in_token_out/mm_features.py) · [vllm/model_executor/model_loader/default_loader.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/default_loader.py) · [vllm/model_executor/model_loader/weight_cache/daemon.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/daemon.py) · [vllm/model_executor/model_loader/weight_cache/ipc_loader.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/ipc_loader.py) · [vllm/model_executor/model_loader/weight_cache/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/protocol.py) · [vllm/multimodal/cache/shm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/cache/shm.py) · [vllm/multimodal/media/audio.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/media/audio.py) · [vllm/multimodal/media/image.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/media/image.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



