# CHK-REQ-013 — vLLM

[공통 시험 명세](../../checks/CHK-REQ-013.md) · [기준판 상세 구현](../baseline/CHK-REQ-013.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/entrypoints/openai/chat_completion/protocol.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/openai/chat_completion/protocol.py) · [vllm/entrypoints/serve/exception_handling/utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/serve/exception_handling/utils.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 2건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | prompt_logprob_token_ids가 기준판의 1차원 목록에서 행별 2차원 정수 배열로 바뀐다. 행·열 수를 제한한 뒤 padding하며 -1은 padding 값이다. |
| --- | --- |
| 수행 방법 | 실제 지원 API에서 행 수·행별 ID 수·범위·padding·prompt_logprob_start를 정상·경계 입력으로 비교한다. 기준판의 1차원 시험 파일을 그대로 재사용하지 말고 반환할 점수 필드도 허용 정책과 대조한다. |
| 확인할 결과·남길 자료 | 지원 schema·정규화 뒤 배열·선택 runner·거부 위치·실제 반환 필드와 비용. |



| 코드에서 확인한 차이 | 기존 return_mm_kwargs=False를 mm_payload="none"으로 옮기는 alias와 mm_payload 선택이 추가되고, 미디어가 있는 chat의 forwarded prompt_token_ids는 제거한 뒤 messages를 렌더한다. 존재하지 않는 모델 오류에는 유효 alias 이름이 추가된다. |
| --- | --- |
| 수행 방법 | 원래 옵션과 alias 모두에서 미디어 tensor·metadata·token ID 반환을 확인한다. 미디어+forwarded ID 조합의 실제 입력을 대조하고 모델 오류의 alias 노출도 허용 필드 정책에 포함한다. |
| 확인할 결과·남길 자료 | 최종 입력·반환 필드·alias 처리·오류 응답, 일반·stream의 정상 대조. |



### 고정 소스와 확인 범위



[vllm/entrypoints/openai/chat_completion/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/chat_completion/protocol.py) · [vllm/entrypoints/openai/responses/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/openai/responses/protocol.py) · [vllm/entrypoints/scale_out/token_in_token_out/mm_features.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/scale_out/token_in_token_out/mm_features.py) · [vllm/entrypoints/serve/engine/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/engine/serving.py) · [vllm/entrypoints/serve/exception_handling/utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/exception_handling/utils.py) · [vllm/sampling_params.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/sampling_params.py) · [vllm/v1/engine/input_processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/input_processor.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



