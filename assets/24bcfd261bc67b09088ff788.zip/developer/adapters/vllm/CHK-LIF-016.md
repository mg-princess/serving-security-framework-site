# CHK-LIF-016 — vLLM

[공통 시험 명세](../../checks/CHK-LIF-016.md) · [기준판 상세 구현](../baseline/CHK-LIF-016.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0 소스에는 기준판의 vllm.snapshot 구현이 없다. 일반 배포 자료·모델·cache 복원 점검은 그대로 적용된다. |
| --- | --- |
| 수행 방법 | 이 판본에 기준판 snapshot 명령을 복사하지 않는다. 현재 승인된 이미지·모델·설정의 새 기동으로 복원하고 실제 배치한 외부 snapshot 도구가 있으면 그 지원 조건·검증·접수 제한을 따로 확인한다. |
| 확인할 결과·남길 자료 | 복원 도구·지원 환경, 현재 승인 자료와 실제 실행 식별, 필수 준비·보호·canary와 재개 결정. |



### 고정 소스와 확인 범위



[vllm/benchmarks/sweep/server.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/benchmarks/sweep/server.py) · [vllm/entrypoints/cli/serve.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/cli/serve.py) · [vllm/v1/hisparse/runtime.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/hisparse/runtime.py) · [vllm/v1/kv_offload/tiering/p2p/session/server.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/kv_offload/tiering/p2p/session/server.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



### 고정 소스와 확인 범위



[vllm/benchmarks/sweep/server.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/benchmarks/sweep/server.py) · [vllm/distributed/device_communicators/shm_object_storage.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_object_storage.py) · [vllm/multimodal/cache/shm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/cache/shm.py) · [vllm/snapshot/controller.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/snapshot/controller.py) · [vllm/snapshot/manifest.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/snapshot/manifest.py) · [vllm/snapshot/runtime.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/snapshot/runtime.py) · [vllm/snapshot/server.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/snapshot/server.py) · [vllm/v1/hisparse/runtime.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/hisparse/runtime.py) · [vllm/v1/kv_offload/tiering/p2p/session/server.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/kv_offload/tiering/p2p/session/server.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



