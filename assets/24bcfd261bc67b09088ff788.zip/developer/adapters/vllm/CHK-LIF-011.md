# CHK-LIF-011 — vLLM

[공통 시험 명세](../../checks/CHK-LIF-011.md) · [기준판 상세 구현](../baseline/CHK-LIF-011.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/entrypoints/launchers/api_server/entry.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/api_server/entry.py) · [vllm/entrypoints/launchers/api_server/routers.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/api_server/routers.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/launcher.py) · [vllm/entrypoints/serve/dev/rlhf/api_router.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/serve/dev/rlhf/api_router.py) · [vllm/entrypoints/serve/dev/rpc/api_router.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/serve/dev/rpc/api_router.py) · [vllm/v1/engine/utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/utils.py) · [vllm/v1/metrics/loggers.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/metrics/loggers.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 3건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | 가중치 daemon의 rank 배치가 DP·TP에서 DP·PP·TP로 확장된다. 기준판이 거부하던 PP 구성을 v0.32.0은 rank 배치에 포함한다. |
| --- | --- |
| 수행 방법 | 공유 가중치를 PP와 함께 사용하면 dp_rank·pp_rank·tp_rank·장치·daemon socket을 대응시킨다. 한 rank 준비 실패와 daemon 종료 후 기존 소비자·새 취득을 분리해 확인한다. |
| 확인할 결과·남길 자료 | rank별 모델·layout·IPC payload·준비, 종료·참조 반환과 후속 정상 취득. release 응답만으로 소비자 참조 반환을 완료하지 않는다. |



| 코드에서 확인한 차이 | worker queue는 큰 out-of-band buffer를 재사용 ring에서 복사하고, 선택한 tensor arena는 storage 해제와 H2D 완료 event 뒤 slot을 반환한다. 일반 pickle 경로도 남는다. |
| --- | --- |
| 수행 방법 | tensor arena 활성 여부와 실제 fallback을 기록한다. 느린 소비·비동기 H2D·취소·worker 종료에서 tensor storage·CUDA event·slot 반환과 다음 요청 결과를 관측한다. |
| 확인할 결과·남길 자료 | queue 선택·arena slot·reader별 반환·GPU 완료·다음 재사용 순서. 새 arena를 별도 사용자 인가 경계로 간주하지 않는다. |



| 코드에서 확인한 차이 | CUDA Graph capture pool 관리가 공통 capture_pool로 이동하고 custom all-reduce는 graph buffer 등록 여부와 batch invariant의 큰 입력 chunk 처리를 추가한다. native custom_all_reduce.cu는 libtorch_stable 경로에서 csrc로 이동한다. |
| --- | --- |
| 수행 방법 | 선정 runner·capture pool·custom AR 설정을 기록하고 큰 입력 반복·graph 종료·통신기 해제·재등록을 관측한다. 파일 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | backend·pool·rank·buffer 범위와 GPU 완료·해제·재등록, 다음 정상 실행. 해당 kernel·설치 바이너리의 계측 없이는 메모리 안전 결과를 미확인으로 남긴다. |



### 고정 소스와 확인 범위



[csrc/custom_all_reduce.cu](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/csrc/custom_all_reduce.cu) · [csrc/custom_all_reduce.cuh](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/csrc/custom_all_reduce.cuh) · [vllm/compilation/cuda_graph.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/compilation/cuda_graph.py) · [vllm/distributed/device_communicators/custom_all_reduce.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/custom_all_reduce.py) · [vllm/distributed/device_communicators/shm_broadcast.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_broadcast.py) · [vllm/distributed/device_communicators/shm_tensor_arena.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_tensor_arena.py) · [vllm/entrypoints/launchers/api_server/entry.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/api_server/entry.py) · [vllm/entrypoints/launchers/api_server/routers.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/api_server/routers.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/launcher.py) · [vllm/entrypoints/rl/online/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/rl/online/api_router.py) · [vllm/entrypoints/serve/dev/rpc/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/dev/rpc/api_router.py) · [vllm/model_executor/model_loader/weight_cache/daemon.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/daemon.py) · [vllm/model_executor/model_loader/weight_cache/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/protocol.py) · [vllm/v1/engine/utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/utils.py) · [vllm/v1/metrics/loggers.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/metrics/loggers.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



