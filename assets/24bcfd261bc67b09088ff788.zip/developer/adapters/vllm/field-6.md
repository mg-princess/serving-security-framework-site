

### vLLM · 6. 자원 관리·서비스 가용성

 

<a id="f-vllm-field-6-content"></a>

 

실제 취소·GPU 작업 완료·자원 회수를 확인한다. 요청·시도·worker 상태·출력 대상을 연결하고 늦은 결과의 처리 규칙을 점검한다. 공유 가중치는 release 동작과 수명, 기존 참조의 상태를 확인한다. 같은 실행에서 확보한 증거는 관련 항목에서 함께 참조할 수 있다.

 

[CHK-LIF-014](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-014)는 선택한 성능 진단 기능의 종료 동작과 실제 수집·자원 사용 종료를 확인한다. 진단 결과는 실제 사용하는 파일·스트림·원격 수신 방식으로 조사한다.

 

**연결할 점검과 구현 위치** [CHK-LIF-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-001)은 모델 로딩 뒤 메모리 측정·KV 할당·컴파일·예열·graph capture까지 준비 단계의 비용과 실패를 확인한다. [CHK-LIF-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-008)·[CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011)에서는 프로세스 사망, 처리 중 발생한 메서드 예외, 응답 시간 초과와 collective 정지를 나눠 감지·통지·정리·재기동을 확인한다. [CHK-LIF-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010)은 HTTP 연결 종료에서 AsyncLLM·EngineCore의 abort, scheduler 종료, worker 상태·KV 참조 반환과 GPU 작업 완료까지 따라간다.

 

**남길 증거** 단계별 시간·CPU·RAM·GPU 사용량과 실패 위치, rank별 감지·통지 시각, 정리 후 정상 기동 결과를 남긴다. 취소 시험에서는 대기·계산·출력 단계별로 취소를 발생시키고, 취소 전달·논리적 요청 종료·실행 중 GPU 작업 완료·상태와 자원 반환 시각을 기록한다. 요청이 끝난 뒤 보존하도록 정한 graph·cache와 정리할 요청별 상태를 구분한다. 이후 요청의 정상 처리도 확인한다. 실제 종결·자원 반환의 구현 위치는 [CHK-LIF-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010)·[CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011)의 엔진별 확인 사항과 공식 고정 소스를 따른다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.30.0 · v0.32.0 — Python·처리 라이브러리의 지원 조건



| 코드에서 확인한 차이 | v0.32.0은 Python 최소 버전을 3.11로 올리고 requests·transformers·tokenizers·aiohttp·Pillow·filelock 등의 의존 범위를 바꾼다. v0.30.0은 tokenizer·grammar·GPU 라이브러리와 harmony 패키지 선택이 기준판과 다르다. |
| --- | --- |
| 수행 방법 | 실제 이미지에서 Python·패키지·decoder·GPU 라이브러리 목록과 digest를 수집하고 해당 판본의 설치 선언과 대조한다. 공지의 영향 조건·백포트·실제 활성 기능을 따로 평가한다. |
| 확인할 결과·남길 자료 | 실제 설치 목록·wheel/이미지 식별과 선언 차이·공지 적용 근거·재발 시험. 의존성 하한 변경만으로 모든 취약점 조치 완료를 판정하지 않는다. |



확인할 체크리스트: [CHK-LIF-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-001)



### v0.30.0 — 요청별 미디어 처리 옵션 제한



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.32.0 — HTTP와 별도로 열리는 gRPC 포트



| 코드에서 확인한 차이 | Rust frontend의 --grpc-port는 HTTP와 별도 Inference·Control listener를 연다. HTTP key middleware와 gRPC 서비스 등록 경로가 분리된다. Python --grpc도 별도 서버이며 add_insecure_port와 외부 servicer를 사용한다. |
| --- | --- |
| 수행 방법 | 선정 frontend와 --grpc·--grpc-port 사용 여부를 기록한다. 사용하는 각 포트에서 무자격·잘못된 자격·허용 자격을 비교하고 관리 RPC를 별도 제한한다. gRPC를 쓰지 않으면 포트 비개방을 확인한다. |
| 확인할 결과·남길 자료 | 실제 listener·등록 서비스·TLS·접근 제한·관리 RPC 거부. HTTP API key 시험 결과를 다른 서버의 인증 결과로 재사용하지 않는다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.32.0 — 대기열 거부 기록과 진단 종료



| 코드에서 확인한 차이 | 대기열 거부 로그가 INFO에서 DEBUG로 바뀌고 거부 원인별 계측이 추가된다. profiler 시작·정지는 lock과 session 상태를 사용한다. |
| --- | --- |
| 수행 방법 | 대기열 초과 사건은 기본 INFO 로그 존재만으로 판단하지 말고 실제 거부·관련 지표를 수집한다. profiler 동시 시작·정지와 실패 뒤 수집 종료·자원 반환도 비교한다. |
| 확인할 결과·남길 자료 | 거부 원인·요청 결과·지표 수집, profiler session·실제 backend 종료·후속 정상 요청. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.32.0 — 미디어 옵션 병합과 처리 코드 선택



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.32.0 — 입력 토큰 점수 요청의 배열 형식



| 코드에서 확인한 차이 | prompt_logprob_token_ids가 기준판의 1차원 목록에서 행별 2차원 정수 배열로 바뀐다. 행·열 수를 제한한 뒤 padding하며 -1은 padding 값이다. |
| --- | --- |
| 수행 방법 | 실제 지원 API에서 행 수·행별 ID 수·범위·padding·prompt_logprob_start를 정상·경계 입력으로 비교한다. 기준판의 1차원 시험 파일을 그대로 재사용하지 말고 반환할 점수 필드도 허용 정책과 대조한다. |
| 확인할 결과·남길 자료 | 지원 schema·정규화 뒤 배열·선택 runner·거부 위치·실제 반환 필드와 비용. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.32.0 — 템플릿 처리 시간 제한과 작업 종료



| 코드에서 확인한 차이 | 비동기 template 렌더에 VLLM_CHAT_TEMPLATE_RENDER_TIMEOUT 제한과 executor 교체가 추가된다. timeout 뒤 기존 Python thread의 CPU 작업은 계속될 수 있다. |
| --- | --- |
| 수행 방법 | 승인한 무해한 지연 template로 timeout·후속 정상 요청을 비교하고 기존 thread의 CPU·메모리도 관측한다. 제한을 시험 때문에 바꿨다면 승인값으로 복원하고 필요하면 프로세스를 다시 기동한다. |
| 확인할 결과·남길 자료 | 유효 timeout, API 오류·후속 요청, 이전 thread·CPU·메모리의 종결. 응답 timeout을 실제 연산 종료로 판정하지 않는다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003) · [CHK-LIF-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010)



### v0.32.0 — 토큰 범위와 구조화 출력 검사



| 코드에서 확인한 차이 | 토큰 범위 검사가 renderer.validate_token_ids로 이동하고, 구조화 출력에는 JSON 중첩 깊이 검사와 Guidance tokenizer 적합성 검사가 추가된다. |
| --- | --- |
| 수행 방법 | 음수·상한 밖 token ID와 깊이가 다른 무해한 schema를 정상 요청과 비교한다. 선택한 tokenizer와 구조화 출력 backend를 기록하고 API 오류뿐 아니라 worker 생존과 후속 정상 요청을 확인한다. |
| 확인할 결과·남길 자료 | 실제 validator·backend, 오류 응답, worker 상태·메모리·후속 정상 요청. 소스의 제한값을 조직 공통 정책값으로 옮기지 않는다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.32.0 — 프로세스 사이 버퍼의 사용·반환



| 코드에서 확인한 차이 | worker queue는 큰 out-of-band buffer를 재사용 ring에서 복사하고, 선택한 tensor arena는 storage 해제와 H2D 완료 event 뒤 slot을 반환한다. 일반 pickle 경로도 남는다. |
| --- | --- |
| 수행 방법 | tensor arena 활성 여부와 실제 fallback을 기록한다. 느린 소비·비동기 H2D·취소·worker 종료에서 tensor storage·CUDA event·slot 반환과 다음 요청 결과를 관측한다. |
| 확인할 결과·남길 자료 | queue 선택·arena slot·reader별 반환·GPU 완료·다음 재사용 순서. 새 arena를 별도 사용자 인가 경계로 간주하지 않는다. |



확인할 체크리스트: [CHK-LIF-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010)

