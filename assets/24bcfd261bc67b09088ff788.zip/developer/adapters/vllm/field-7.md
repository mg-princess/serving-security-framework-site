

### vLLM · 7. 구성·변경 관리

 

<a id="f-vllm-field-7-content"></a>

 

공유 weights와 실행 중 변경(live 변경)을 사용하면 C13/SC-16과 C09/SC-17-03에 따라 접근 권한, 자료가 속한 요청·모델과 메모리 상태를 추가 확인한다. SC-17-03의 runtime LoRA, transfer 세션과 runner reload는 별도 시험으로 기록한다. 세션 중복 거부 외에 실제 추론의 상호 배제를 확인하고, update 중 예외가 발생하면 active가 해제되는지, target이 초기화되는지, tensor가 복원되는지 각각 확인한다.

 

reload는 model 경로와 revision=None을 먼저 설정한다. 실패 후에는 설정·부분 weights·cache와 호출자의 복구 처리를 조사한다. 부분 갱신이 발생하는지는 backend별로 시험한다. [고정 코드](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/v1/worker/gpu_model_runner.py#L5492-L5584)

 

**연결할 점검과 증거** [CHK-LIF-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005)·[CHK-LIF-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006)에서 중단 배포와 실행 중 변경을 구분하고, 요청별 모델 세대와 변경 실패 후 상태를 남긴다. [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007)·[CHK-LIF-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009)에서는 모델 로딩, KV 준비, 컴파일·graph 준비, 필요한 모든 rank의 준비와 정상 추론을 확인한 뒤 요청 접수를 재개하는지 시험한다. 중간 READY 기록과 최종 접수 허용 시각을 각각 남기고, 준비 단계별 실패에서 접수 제한·부분 상태 정리·다음 정상 기동을 확인한다. 단계별 준비·부분 실패의 구현 위치는 [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007)·[CHK-LIF-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009)의 엔진별 확인 사항과 공식 고정 소스를 따른다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.30.0 — 기본 모델과 같은 LoRA 이름



| 코드에서 확인한 차이 | v0.30.0의 LoRA 적재 요청 검사에는 기준판의 base model 이름 충돌 거부가 없다. |
| --- | --- |
| 수행 방법 | 격리된 관리 접점에서 base model과 같은 이름·별도 이름의 무해한 LoRA를 비교하고 실제 선택 모델·LoRA·해제 후 결과를 기록한다. 관리 경로와 모델별 권한도 함께 확인한다. |
| 확인할 결과·남길 자료 | 등록·거부 결과, alias→실제 모델 대응, LoRA 해제·원복과 정상 요청. |



확인할 체크리스트: [CHK-LIF-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006)



### v0.30.0 — 백업 복원과 snapshot 지원 여부



| 코드에서 확인한 차이 | v0.30.0 소스에는 기준판의 vllm.snapshot 구현이 없다. 일반 배포 자료·모델·cache 복원 점검은 그대로 적용된다. |
| --- | --- |
| 수행 방법 | 이 판본에 기준판 snapshot 명령을 복사하지 않는다. 현재 승인된 이미지·모델·설정의 새 기동으로 복원하고 실제 배치한 외부 snapshot 도구가 있으면 그 지원 조건·검증·접수 제한을 따로 확인한다. |
| 확인할 결과·남길 자료 | 복원 도구·지원 환경, 현재 승인 자료와 실제 실행 식별, 필수 준비·보호·canary와 재개 결정. |



확인할 체크리스트: [CHK-LIF-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-016)



### v0.32.0 — GPU 그래프와 통신 버퍼 수명



| 코드에서 확인한 차이 | CUDA Graph capture pool 관리가 공통 capture_pool로 이동하고 custom all-reduce는 graph buffer 등록 여부와 batch invariant의 큰 입력 chunk 처리를 추가한다. native custom_all_reduce.cu는 libtorch_stable 경로에서 csrc로 이동한다. |
| --- | --- |
| 수행 방법 | 선정 runner·capture pool·custom AR 설정을 기록하고 큰 입력 반복·graph 종료·통신기 해제·재등록을 관측한다. 파일 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | backend·pool·rank·buffer 범위와 GPU 완료·해제·재등록, 다음 정상 실행. 해당 kernel·설치 바이너리의 계측 없이는 메모리 안전 결과를 미확인으로 남긴다. |



확인할 체크리스트: [CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011)



### v0.32.0 — HTTP와 별도로 열리는 gRPC 포트



| 코드에서 확인한 차이 | Rust frontend의 --grpc-port는 HTTP와 별도 Inference·Control listener를 연다. HTTP key middleware와 gRPC 서비스 등록 경로가 분리된다. Python --grpc도 별도 서버이며 add_insecure_port와 외부 servicer를 사용한다. |
| --- | --- |
| 수행 방법 | 선정 frontend와 --grpc·--grpc-port 사용 여부를 기록한다. 사용하는 각 포트에서 무자격·잘못된 자격·허용 자격을 비교하고 관리 RPC를 별도 제한한다. gRPC를 쓰지 않으면 포트 비개방을 확인한다. |
| 확인할 결과·남길 자료 | 실제 listener·등록 서비스·TLS·접근 제한·관리 RPC 거부. HTTP API key 시험 결과를 다른 서버의 인증 결과로 재사용하지 않는다. |



확인할 체크리스트: [CHK-LIF-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005) · [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007)



### v0.32.0 — PP 구성의 공유 가중치 준비·종료



| 코드에서 확인한 차이 | 가중치 daemon의 rank 배치가 DP·TP에서 DP·PP·TP로 확장된다. 기준판이 거부하던 PP 구성을 v0.32.0은 rank 배치에 포함한다. |
| --- | --- |
| 수행 방법 | 공유 가중치를 PP와 함께 사용하면 dp_rank·pp_rank·tp_rank·장치·daemon socket을 대응시킨다. 한 rank 준비 실패와 daemon 종료 후 기존 소비자·새 취득을 분리해 확인한다. |
| 확인할 결과·남길 자료 | rank별 모델·layout·IPC payload·준비, 종료·참조 반환과 후속 정상 취득. release 응답만으로 소비자 참조 반환을 완료하지 않는다. |



확인할 체크리스트: [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007) · [CHK-LIF-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009) · [CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011) · [CHK-LIF-013](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-013)



### v0.32.0 — 공유 메모리 참조의 서명 검사



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



확인할 체크리스트: [CHK-LIF-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-016)



### v0.32.0 — 모델 교체 때 실제로 읽는 가중치



| 코드에서 확인한 차이 | weights 재적재가 공통 reload.inplace로 이동한다. 새 weights_path를 지정하면 이전 revision뿐 아니라 model_weights 객체 저장소 공급원도 비운다. |
| --- | --- |
| 수행 방법 | 객체 저장소 공급원을 설정했던 모델에서 승인한 새 경로로 바꾸고 최종 읽기 파일·저장소를 확인한다. V1·V2 caller의 LoRA·encoder·MM 캐시 초기화도 함께 관측한다. |
| 확인할 결과·남길 자료 | 변경 전후 model·model_weights·revision, 실제 파일·적재 tensor와 새 요청 결과. 누락 경고가 났다면 필수 weights 준비 여부를 별도로 판정한다. |



확인할 체크리스트: [CHK-LIF-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006) · [CHK-LIF-015](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-015)



### v0.32.0 — 추가·이동한 추론·관리 API



| 코드에서 확인한 차이 | /v1/systemone이 새로 등록되고 개발 모드의 RL 관리 라우터가 entrypoints/rl/online으로 이동한다. /abort_requests는 request_ids를 생략하면 모든 진행 요청을 대상으로 한다. |
| --- | --- |
| 수행 방법 | 실제 라우트 목록에서 /v1/systemone과 활성 관리 API를 확인한다. 공개 경로에서는 관리 기능을 제한하고, 중단 시험은 격리된 인스턴스의 지정 요청으로 수행한다. 경로 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | 등록 조건, 호출자별 거부 결과, 지정 요청·전체 요청 구분, 실제 중단과 모델 변경 기록. |



확인할 체크리스트: [CHK-LIF-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005) · [CHK-LIF-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006)



### v0.32.0 — 프로세스 사이 버퍼의 사용·반환



| 코드에서 확인한 차이 | worker queue는 큰 out-of-band buffer를 재사용 ring에서 복사하고, 선택한 tensor arena는 storage 해제와 H2D 완료 event 뒤 slot을 반환한다. 일반 pickle 경로도 남는다. |
| --- | --- |
| 수행 방법 | tensor arena 활성 여부와 실제 fallback을 기록한다. 느린 소비·비동기 H2D·취소·worker 종료에서 tensor storage·CUDA event·slot 반환과 다음 요청 결과를 관측한다. |
| 확인할 결과·남길 자료 | queue 선택·arena slot·reader별 반환·GPU 완료·다음 재사용 순서. 새 arena를 별도 사용자 인가 경계로 간주하지 않는다. |



확인할 체크리스트: [CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011)

