

### vLLM · 5. 정보·통신 보호

 

<a id="f-vllm-field-5-content"></a>

 

실제 내부 통신의 접근·암호화와 실행 자격을 확인한다. 요청·모델 자료를 사용할 권한과 통신에 접근할 권한을 구분하고, 선택 기능의 공유 weights daemon과 실제 사용하는 다중 프로세스·분산 실행의 경계를 각각 조사한다. 외부 통신과 관측 자료 전송은 사용하는 목적지·구간별로 증거를 확보한다.

 

**연결할 점검과 구현 위치** [CHK-PLT-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-008)에서는 frontend↔EngineCore의 ZMQ 통신과 활성 executor의 worker 통신을 구분한다. 단일 worker의 직접 호출, TP의 공유 메모리 제어 전달·큰 자료의 socket 전송, Ray 제어·노드 연결·TP collective·PP tensor 전달은 실제 사용하는 구성에서 각각 확인한다. [CHK-PLT-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-009)에서는 OTLP exporter나 pull 수집의 연결 주체와 TLS 종료점, 수집기 이후 저장소 구간을 확인한다. 외부 목적지 허용 여부는 [CHK-PLT-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-007)과 연결한다.

 

**남길 증거** 구간별 송수신 프로세스·상대 주소·선정 transport·접근 권한과 인증·암호화 적용 결과를 남긴다. 필요한 구간에서 허용되지 않은 상대·인증서의 거부와 정상 전송을 비교한다. 로컬 IPC를 OS 권한으로 보호하면 해당 권한과 실제 접속 제한을 기록한다. OTLP는 SDK 판본·유효 설정·실제 연결과 수신 결과를 함께 확인한다. 구현 위치와 구간별 판정은 [CHK-PLT-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-008)·[CHK-PLT-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-009)의 엔진별 확인 사항과 공식 고정 소스를 따른다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.32.0 — HTTP와 별도로 열리는 gRPC 포트



| 코드에서 확인한 차이 | Rust frontend의 --grpc-port는 HTTP와 별도 Inference·Control listener를 연다. HTTP key middleware와 gRPC 서비스 등록 경로가 분리된다. Python --grpc도 별도 서버이며 add_insecure_port와 외부 servicer를 사용한다. |
| --- | --- |
| 수행 방법 | 선정 frontend와 --grpc·--grpc-port 사용 여부를 기록한다. 사용하는 각 포트에서 무자격·잘못된 자격·허용 자격을 비교하고 관리 RPC를 별도 제한한다. gRPC를 쓰지 않으면 포트 비개방을 확인한다. |
| 확인할 결과·남길 자료 | 실제 listener·등록 서비스·TLS·접근 제한·관리 RPC 거부. HTTP API key 시험 결과를 다른 서버의 인증 결과로 재사용하지 않는다. |



확인할 체크리스트: [CHK-PLT-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-007) · [CHK-PLT-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-008)



### v0.32.0 — 공유 메모리 참조의 서명 검사



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



확인할 체크리스트: [CHK-PLT-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-002)

