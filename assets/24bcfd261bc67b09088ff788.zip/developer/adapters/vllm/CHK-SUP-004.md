# CHK-SUP-004 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-004.md) · [기준판 상세 구현](../baseline/CHK-SUP-004.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.32.0은 Python 최소 버전을 3.11로 올리고 requests·transformers·tokenizers·aiohttp·Pillow·filelock 등의 의존 범위를 바꾼다. v0.30.0은 tokenizer·grammar·GPU 라이브러리와 harmony 패키지 선택이 기준판과 다르다. |
| --- | --- |
| 수행 방법 | 실제 이미지에서 Python·패키지·decoder·GPU 라이브러리 목록과 digest를 수집하고 해당 판본의 설치 선언과 대조한다. 공지의 영향 조건·백포트·실제 활성 기능을 따로 평가한다. |
| 확인할 결과·남길 자료 | 실제 설치 목록·wheel/이미지 식별과 선언 차이·공지 적용 근거·재발 시험. 의존성 하한 변경만으로 모든 취약점 조치 완료를 판정하지 않는다. |



### 고정 소스와 확인 범위



[pyproject.toml](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/pyproject.toml) · [requirements/common.txt](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/requirements/common.txt) · [requirements/cuda.txt](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/requirements/cuda.txt) · [setup.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/setup.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.32.0은 Python 최소 버전을 3.11로 올리고 requests·transformers·tokenizers·aiohttp·Pillow·filelock 등의 의존 범위를 바꾼다. v0.30.0은 tokenizer·grammar·GPU 라이브러리와 harmony 패키지 선택이 기준판과 다르다. |
| --- | --- |
| 수행 방법 | 실제 이미지에서 Python·패키지·decoder·GPU 라이브러리 목록과 digest를 수집하고 해당 판본의 설치 선언과 대조한다. 공지의 영향 조건·백포트·실제 활성 기능을 따로 평가한다. |
| 확인할 결과·남길 자료 | 실제 설치 목록·wheel/이미지 식별과 선언 차이·공지 적용 근거·재발 시험. 의존성 하한 변경만으로 모든 취약점 조치 완료를 판정하지 않는다. |



### 고정 소스와 확인 범위



[pyproject.toml](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/pyproject.toml) · [requirements/common.txt](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/requirements/common.txt) · [requirements/cuda.txt](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/requirements/cuda.txt) · [setup.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/setup.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



