# CHK-SUP-006 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-006.md) · [기준판 상세 구현](../baseline/CHK-SUP-006.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/config/model.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/model.py) · [vllm/model_executor/model_loader/default_loader.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/model_executor/model_loader/default_loader.py) · [vllm/transformers_utils/utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/transformers_utils/utils.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 2건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | weights 재적재가 공통 reload.inplace로 이동한다. 새 weights_path를 지정하면 이전 revision뿐 아니라 model_weights 객체 저장소 공급원도 비운다. |
| --- | --- |
| 수행 방법 | 객체 저장소 공급원을 설정했던 모델에서 승인한 새 경로로 바꾸고 최종 읽기 파일·저장소를 확인한다. V1·V2 caller의 LoRA·encoder·MM 캐시 초기화도 함께 관측한다. |
| 확인할 결과·남길 자료 | 변경 전후 model·model_weights·revision, 실제 파일·적재 tensor와 새 요청 결과. 누락 경고가 났다면 필수 weights 준비 여부를 별도로 판정한다. |



| 코드에서 확인한 차이 | 가중치 daemon의 rank 배치가 DP·TP에서 DP·PP·TP로 확장된다. 기준판이 거부하던 PP 구성을 v0.32.0은 rank 배치에 포함한다. |
| --- | --- |
| 수행 방법 | 공유 가중치를 PP와 함께 사용하면 dp_rank·pp_rank·tp_rank·장치·daemon socket을 대응시킨다. 한 rank 준비 실패와 daemon 종료 후 기존 소비자·새 취득을 분리해 확인한다. |
| 확인할 결과·남길 자료 | rank별 모델·layout·IPC payload·준비, 종료·참조 반환과 후속 정상 취득. release 응답만으로 소비자 참조 반환을 완료하지 않는다. |



### 고정 소스와 확인 범위



[vllm/config/model.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/model.py) · [vllm/model_executor/model_loader/default_loader.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/default_loader.py) · [vllm/model_executor/model_loader/reload/inplace.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/reload/inplace.py) · [vllm/model_executor/model_loader/weight_cache/daemon.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/daemon.py) · [vllm/model_executor/model_loader/weight_cache/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/weight_cache/protocol.py) · [vllm/transformers_utils/utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/utils.py) · [vllm/v1/worker/gpu/model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu/model_runner.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



