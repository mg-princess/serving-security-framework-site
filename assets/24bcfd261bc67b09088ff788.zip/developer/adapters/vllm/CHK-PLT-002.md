# CHK-PLT-002 — vLLM

[공통 시험 명세](../../checks/CHK-PLT-002.md) · [기준판 상세 구현](../baseline/CHK-PLT-002.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/distributed/device_communicators/shm_broadcast.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/distributed/device_communicators/shm_broadcast.py) · [vllm/utils/network_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/utils/network_utils.py) · [vllm/v1/engine/core.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/core.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



### 고정 소스와 확인 범위



[vllm/distributed/device_communicators/shm_broadcast.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_broadcast.py) · [vllm/distributed/device_communicators/shm_object_storage.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/distributed/device_communicators/shm_object_storage.py) · [vllm/multimodal/cache/shm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/multimodal/cache/shm.py) · [vllm/utils/network_utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/utils/network_utils.py) · [vllm/v1/engine/core.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/core.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



