

### vLLM · 3. 입력 처리·코드 실행 안전성

 

<a id="f-vllm-field-3-content"></a>

 

<a id="현재-비교-근거의-한계"></a>
 기본값과 템플릿을 적용하고 token으로 변환한 뒤, 모델에 실제 전달하는 입력에도 검사가 적용되는지 확인한다. 템플릿의 승인과 해석 기능은 모델·소프트웨어 자료 점검에, 변환 후 요청 제한은 해당 입력 점검에 기록한다.

 

[CHK-SUP-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-008)은 코드 선택 경로에 전달되는 인수와 실제 사용 결과를 확인한다. MM processor 외의 경로도 조사한다. [CHK-SUP-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-010)은 설치한 확장 그룹과 허용 검사가 실행 전에 적용되는지, [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)는 허용한 형식의 정상 처리와 금지 객체·동작의 거부를 확인한다. [CHK-REQ-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-008)은 재사용 입력의 전달·변환 경로와 금지 구성의 거부를 확인한다.

 

추가 코드(custom code)를 사용하면 auto_map, 실제 선택한 class, 코드 출처와 의존 파일을 확인한다. 코드 실행 허용 여부를 검사하는 시점과 import 순서도 조사한다. npcache의 생성·재사용, 컴파일 목록의 해석·실제 코드 사용도 각각 확인한다. torch 등 의존성의 과거 취약점은 실제 설치 버전·수정 근거와 대조한다. 생성 코드는 허용한 입력·도구·옵션과 결과를 연결해 기록하며, 컴파일러 내부 동작 전반과 생성 코드·캐시 구현은 추가로 조사할 범위다.

 

**남길 증거** 입력 변환 전후의 값, 실제 선택한 코드·플러그인·자료 해석기와 의존성 판본을 기록한다. 금지한 입력·코드·객체의 처리 결과와 승인한 자료의 정상 처리 결과를 함께 남긴다. 코드 사용을 허용하는 설정이 실제 import·역직렬화보다 먼저 검사되는지 해당 경로에서 확인한다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.30.0 — 요청별 미디어 처리 옵션 제한



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



확인할 체크리스트: [CHK-REQ-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-007) · [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009)



### v0.30.0 — 입력 길이와 생성 옵션 검사



| 코드에서 확인한 차이 | v0.30.0에는 기준판의 prompt_is_token_ids 길이 검사와 max_tokens 자동 산정 후 min_tokens 재검사가 없다. |
| --- | --- |
| 수행 방법 | 실제 지원 입력에 한해 embedding 길이 불일치와 max_tokens 생략·min_tokens 초과를 정상 요청과 비교한다. API와 renderer·worker 중 어디에서 거부하는지 기록한다. |
| 확인할 결과·남길 자료 | 지원 스키마, 오류·작업 생성 여부, 후속 정상 요청. 지원하지 않는 필드는 기능 부재로 구분한다. |



확인할 체크리스트: [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009) · [CHK-REQ-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-010)



### v0.32.0 — 공유 메모리 참조의 서명 검사



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



확인할 체크리스트: [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009)



### v0.32.0 — 미디어 옵션 병합과 처리 코드 선택



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



확인할 체크리스트: [CHK-REQ-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-007) · [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009)



### v0.32.0 — 미디어·토큰 반환 옵션과 오류 정보



| 코드에서 확인한 차이 | 기존 return_mm_kwargs=False를 mm_payload="none"으로 옮기는 alias와 mm_payload 선택이 추가되고, 미디어가 있는 chat의 forwarded prompt_token_ids는 제거한 뒤 messages를 렌더한다. 존재하지 않는 모델 오류에는 유효 alias 이름이 추가된다. |
| --- | --- |
| 수행 방법 | 원래 옵션과 alias 모두에서 미디어 tensor·metadata·token ID 반환을 확인한다. 미디어+forwarded ID 조합의 실제 입력을 대조하고 모델 오류의 alias 노출도 허용 필드 정책에 포함한다. |
| 확인할 결과·남길 자료 | 최종 입력·반환 필드·alias 처리·오류 응답, 일반·stream의 정상 대조. |



확인할 체크리스트: [CHK-REQ-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-007) · [CHK-REQ-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-008) · [CHK-REQ-013](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-013)



### v0.32.0 — 입력 토큰 점수 요청의 배열 형식



| 코드에서 확인한 차이 | prompt_logprob_token_ids가 기준판의 1차원 목록에서 행별 2차원 정수 배열로 바뀐다. 행·열 수를 제한한 뒤 padding하며 -1은 padding 값이다. |
| --- | --- |
| 수행 방법 | 실제 지원 API에서 행 수·행별 ID 수·범위·padding·prompt_logprob_start를 정상·경계 입력으로 비교한다. 기준판의 1차원 시험 파일을 그대로 재사용하지 말고 반환할 점수 필드도 허용 정책과 대조한다. |
| 확인할 결과·남길 자료 | 지원 schema·정규화 뒤 배열·선택 runner·거부 위치·실제 반환 필드와 비용. |



확인할 체크리스트: [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009) · [CHK-REQ-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-010) · [CHK-REQ-013](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-013)



### v0.32.0 — 추가·이동한 추론·관리 API



| 코드에서 확인한 차이 | /v1/systemone이 새로 등록되고 개발 모드의 RL 관리 라우터가 entrypoints/rl/online으로 이동한다. /abort_requests는 request_ids를 생략하면 모든 진행 요청을 대상으로 한다. |
| --- | --- |
| 수행 방법 | 실제 라우트 목록에서 /v1/systemone과 활성 관리 API를 확인한다. 공개 경로에서는 관리 기능을 제한하고, 중단 시험은 격리된 인스턴스의 지정 요청으로 수행한다. 경로 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | 등록 조건, 호출자별 거부 결과, 지정 요청·전체 요청 구분, 실제 중단과 모델 변경 기록. |



확인할 체크리스트: [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009) · [CHK-REQ-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-010)



### v0.32.0 — 템플릿 처리 시간 제한과 작업 종료



| 코드에서 확인한 차이 | 비동기 template 렌더에 VLLM_CHAT_TEMPLATE_RENDER_TIMEOUT 제한과 executor 교체가 추가된다. timeout 뒤 기존 Python thread의 CPU 작업은 계속될 수 있다. |
| --- | --- |
| 수행 방법 | 승인한 무해한 지연 template로 timeout·후속 정상 요청을 비교하고 기존 thread의 CPU·메모리도 관측한다. 제한을 시험 때문에 바꿨다면 승인값으로 복원하고 필요하면 프로세스를 다시 기동한다. |
| 확인할 결과·남길 자료 | 유효 timeout, API 오류·후속 요청, 이전 thread·CPU·메모리의 종결. 응답 timeout을 실제 연산 종료로 판정하지 않는다. |



확인할 체크리스트: [CHK-REQ-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-007)



### v0.32.0 — 토큰 범위와 구조화 출력 검사



| 코드에서 확인한 차이 | 토큰 범위 검사가 renderer.validate_token_ids로 이동하고, 구조화 출력에는 JSON 중첩 깊이 검사와 Guidance tokenizer 적합성 검사가 추가된다. |
| --- | --- |
| 수행 방법 | 음수·상한 밖 token ID와 깊이가 다른 무해한 schema를 정상 요청과 비교한다. 선택한 tokenizer와 구조화 출력 backend를 기록하고 API 오류뿐 아니라 worker 생존과 후속 정상 요청을 확인한다. |
| 확인할 결과·남길 자료 | 실제 validator·backend, 오류 응답, worker 상태·메모리·후속 정상 요청. 소스의 제한값을 조직 공통 정책값으로 옮기지 않는다. |



확인할 체크리스트: [CHK-REQ-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-008) · [CHK-REQ-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009) · [CHK-REQ-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-010)

