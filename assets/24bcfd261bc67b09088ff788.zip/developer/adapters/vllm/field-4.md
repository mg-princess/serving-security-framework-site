

### vLLM · 4. 상태 격리·재사용 안전성

 

<a id="f-vllm-field-4-content"></a>

 

검증된 신원에서 허용된 공유 집단을 정하고, 실제 cache key와 재사용 결과를 대조한다. [CHK-REQ-015](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-015)의 salt·namespace·별도 실행 영역 등 실제 공유 제어를 확인한다. 캐시 시간 차이를 통한 추론은 공격자가 관측할 수 있는 조건과 성능 영향을 함께 평가한다.

 

<a id="sc-16-01-공유-consumer-권한"></a>
 
<a id="sc-16-02-client-메시지-신뢰"></a>
 
<a id="sc-16-03-공유-실물세대-불일치"></a>
 **공유 서비스의 권한과 자료(SC-16-01·SC-16-02·SC-16-03).** 공유 daemon을 사용하면 peer 접근권과 모델 사용권을 [Q-C13](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C13)·[Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10)에 따라 각각 확인한다. 접근이 허용된 client의 입력도 사용하는 protocol·serializer가 허용하는 형식·동작 범위에서 처리되는지 [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07)로 시험하고, 실제 처리 경로에 도달한 증거를 확보한다.

 

자료를 제공하는 publisher와 사용하는 consumer에서 실제 자료·세대·layout을 비교한다. SC-16-03의 key에는 architecture·quantization 관련 값이 있지만 config 전체·토크나이저·대화 템플릿·tensor payload의 승인을 검사하는 것은 아니다. key/header hash와 함께 실제 payload 승인 근거를 확보하고, revision의 값과 직렬화도 확인한다. [고정 코드](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/model_executor/model_loader/weight_cache/protocol.py#L251-L340)

 

공유 모델 자료는 [2.2 실제 사용의 무결성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-2-2), [4.3 재사용 문맥의 호환성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-3), [1.2 작업·대상 인가](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-2), [1.4 실행 최소 권한](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-4), [6.4 종결·자원 회수](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-6-4)를 함께 참조한다. 자료의 승인 여부, 접근 권한, 공유 해제(release)와 기존 참조의 사용 종료를 각각 확인한다.

 

[CHK-REQ-018](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-018)은 실제 runner가 배치 상태를 이동·재사용할 때 현재 요청의 제한 상태가 유지되는지 확인한다. V1/V2 graph 경로, finished 배치·출력 수명과 rank의 회신 역할·계산 참여를 실제 실행 방식에 맞춰 조사한다. GPU 커널·CUDA Graph의 기술별 확인 범위는 아래 상세 설명을 참조한다.

 

### 모델 구현·컴파일·GPU 커널·CUDA Graph의 확인 범위

 

<a id="이번-근거로-아직-확정할-수-없는-것"></a>
 
<a id="다른-환경에-적용할-때-남는-확인"></a>
 
<a id="source-01-00666"></a>
 모델 구현·컴파일·커널·CUDA Graph는 같은 실행에서 함께 쓰이는 기술이다. 사용 설정·backend·지연 초기화에 따라 실행 시점이 달라진다.

 

| 기술 | 확인할 내용과 현재 근거 |
| --- | --- |
| 모델 구현 | 승인한 코드와 허용된 실행은 추가 코드의 선택·로딩·해석·실행 경로에서 확인한다. 모델·소프트웨어 무결성과 입력 처리·코드 실행 안전성에 관련된다. 실제 코드·plugin·자료 해석 경로를 조사하며, 사용하는 모델이 Transformers 구현을 실행하는지는 해당 구성에서 확인한다. |
| 컴파일러·생성 코드·컴파일 캐시 | 생성물의 출처·writer와 원본·설정·도구 판본, 재사용 조건은 승인 자료와 실제 코드 사용·로딩 경로를 대조해 확인한다. 모델·소프트웨어 무결성과 상태 격리·재사용에 관련되고, 생성·로딩 비용은 자원 관리·서비스 가용성 분야에서 확인한다. 선정 compiler의 실제 생성·로딩·재사용 경로에 필요한 관측을 확보한다. |
| GPU 커널 | 선택 kernel/backend와 패치 조건에 따라 입력 범위·메모리 접근·초기화를 C04·06에서, 장치 권한은 C10에서 확인한다. 여기서 Triton은 커널 작성·컴파일 기술이며 NVIDIA Triton Inference Server와 구분한다. 문제가 확인되면 수정판이나 근거 있는 입력 제한을 적용한다. |
| CUDA Graph | 입력 갱신·그래프 선택·버퍼 수명·출력 귀속은 C02·06, 작업 종료는 C08에서 확인한다. SC-06-02의 활성 기능별 시험을 사용하고 wrapper 조사와 실제 runner·실행 검증을 각각 기록한다. |

 

CUDA Graph의 주소·버퍼 재사용을 점검할 때는 입력 갱신 누락·유효 범위 오류·수명 위반·다른 요청 상태 혼입을 확인한다. 고정 buffer에 새 입력을 복사하는 방식은 구현 예시 중 하나이므로 실제 graph 경로의 방식을 조사한다.

 

조사한 vLLM wrapper에서는 호출하는 쪽이 재실행에 사용할 persistent buffer를 보관하고 입력을 복사한다. 재실행 시 입력 tensor 주소 검사는 debug 조건에서 수행한다. 내용·소유권은 주소 일치 외의 근거와 함께 확인한다. [wrapper 설명](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/compilation/cuda_graph.py#L146-L169) · [재실행 처리](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/compilation/cuda_graph.py#L347-L363)

 

**남길 증거** 요청 ID와 실제 배치 위치·공유 키·모델 세대·출력 수신자를 연결한다. 서로 다른 공유 집단, 배치 위치 이동, 요청 종료·취소 뒤 재사용을 시험하고 독립 실행한 정상 결과와 비교한다. [CHK-REQ-020](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-020)·[CHK-REQ-021](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-021)에서는 실제 graph 실행의 입력 갱신, 출력 사용 완료, 다음 버퍼 재사용과 TP 참조 해제의 순서를 기록한다. GPU 실행·종료 시점은 실제 선택한 runner와 통신 구현에서 계측한다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.30.0 — 미디어 캐시 식별값과 재사용



| 코드에서 확인한 차이 | v0.30.0의 멀티모달 hash 직렬화는 v0.31.0의 길이 framing과 다르다. KV 추가 키도 cache_salt·LoRA·MM 종류를 붙이는 형태가 다르다. |
| --- | --- |
| 수행 방법 | 멀티모달 원문·분할 경계·옵션·LoRA·salt를 한 조건씩 바꿔 재사용 여부와 최종 결과를 확인한다. 판본을 넘겨 이전 캐시를 재사용하려면 호환 증거를 확보하거나 별도 경로에서 새로 생성한다. |
| 확인할 결과·남길 자료 | 판본별 hash 입력·키, 적중 여부, 실제 사용 자료·정상 결과. 새 캐시 경로와 이전 경로를 기록한다. |



확인할 체크리스트: [CHK-REQ-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-016)



### v0.30.0 — 요청 자리 이동 뒤 남는 제한 상태



| 코드에서 확인한 차이 | V1 InputBatch의 mask 교환 방식과 condense 뒤 이전 슬롯 초기화가 기준판과 다르다. v0.30.0에는 remove_request에서 prompt embedding 참조를 제거하는 처리도 없다. |
| --- | --- |
| 수행 방법 | V1 runner에서 서로 다른 허용 토큰 mask·embedding을 쓰는 요청을 종료·교환·압축·다음 슬롯 재사용 순서로 시험한다. V2 runner는 별도 상태 경로로 확인한다. |
| 확인할 결과·남길 자료 | 이동 전후 mask·요청 ID·slot·embedding 참조와 실제 출력. Python 단위 결과와 GPU 실행 결과를 구분한다. |



확인할 체크리스트: [CHK-REQ-018](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-018)



### v0.32.0 — GPU 그래프와 통신 버퍼 수명



| 코드에서 확인한 차이 | CUDA Graph capture pool 관리가 공통 capture_pool로 이동하고 custom all-reduce는 graph buffer 등록 여부와 batch invariant의 큰 입력 chunk 처리를 추가한다. native custom_all_reduce.cu는 libtorch_stable 경로에서 csrc로 이동한다. |
| --- | --- |
| 수행 방법 | 선정 runner·capture pool·custom AR 설정을 기록하고 큰 입력 반복·graph 종료·통신기 해제·재등록을 관측한다. 파일 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | backend·pool·rank·buffer 범위와 GPU 완료·해제·재등록, 다음 정상 실행. 해당 kernel·설치 바이너리의 계측 없이는 메모리 안전 결과를 미확인으로 남긴다. |



확인할 체크리스트: [CHK-REQ-019](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-019) · [CHK-REQ-020](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-020) · [CHK-REQ-021](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-021)



### v0.32.0 — 공유 메모리 참조의 서명 검사



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



확인할 체크리스트: [CHK-REQ-014](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-014) · [CHK-REQ-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-016)



### v0.32.0 — 미디어 옵션 병합과 처리 코드 선택



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



확인할 체크리스트: [CHK-REQ-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-016)



### v0.32.0 — 미디어·토큰 반환 옵션과 오류 정보



| 코드에서 확인한 차이 | 기존 return_mm_kwargs=False를 mm_payload="none"으로 옮기는 alias와 mm_payload 선택이 추가되고, 미디어가 있는 chat의 forwarded prompt_token_ids는 제거한 뒤 messages를 렌더한다. 존재하지 않는 모델 오류에는 유효 alias 이름이 추가된다. |
| --- | --- |
| 수행 방법 | 원래 옵션과 alias 모두에서 미디어 tensor·metadata·token ID 반환을 확인한다. 미디어+forwarded ID 조합의 실제 입력을 대조하고 모델 오류의 alias 노출도 허용 필드 정책에 포함한다. |
| 확인할 결과·남길 자료 | 최종 입력·반환 필드·alias 처리·오류 응답, 일반·stream의 정상 대조. |



확인할 체크리스트: [CHK-REQ-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-016)



### v0.32.0 — 프로세스 사이 버퍼의 사용·반환



| 코드에서 확인한 차이 | worker queue는 큰 out-of-band buffer를 재사용 ring에서 복사하고, 선택한 tensor arena는 storage 해제와 H2D 완료 event 뒤 slot을 반환한다. 일반 pickle 경로도 남는다. |
| --- | --- |
| 수행 방법 | tensor arena 활성 여부와 실제 fallback을 기록한다. 느린 소비·비동기 H2D·취소·worker 종료에서 tensor storage·CUDA event·slot 반환과 다음 요청 결과를 관측한다. |
| 확인할 결과·남길 자료 | queue 선택·arena slot·reader별 반환·GPU 완료·다음 재사용 순서. 새 arena를 별도 사용자 인가 경계로 간주하지 않는다. |



확인할 체크리스트: [CHK-REQ-014](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-014) · [CHK-REQ-020](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-020)

