

### vLLM · 2. 모델·소프트웨어 무결성

 

<a id="f-vllm-field-2-content"></a>

 

<a id="이번-r05r08r09-보완의-재사용-범위"></a>
 
<a id="공급공유-가중치변경-경로의-구현-근거"></a>
 모델 사용권과 실제 모델·소프트웨어 자료의 승인을 각각 확인한다. config·tokenizer·generation config의 실제 사용, 공급원별 revision 해석과 worker별 모델 부분을 조사하고, 승인한 자료가 실제 적재 내용과 일치하는지 확인한다. 경로·로컬 revision 문자열·파일 hash는 승인 자료와 실제 적재 내용을 연결하는 근거와 함께 사용한다.

 

**승인 이후 파일 교체(SC-10-01).** 로컬 반입 시 검수 전후 staging, 배치한 서빙 디렉터리·symlink·마운트의 쓰기 권한을 각각 확인한다. 검수→복사→로딩 사이에 파일을 바꾸는 시험으로 실제 사용 대상을 확인한다. [고정 코드](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/transformers_utils/repo_utils.py#L52-L93)

 

<a id="위협-해설"></a>
 
<a id="source-03-05963"></a>
 
<a id="조건부-경로와-증거의-한계"></a>
 
<a id="실행-기반자격통신--상세"></a>
 
<a id="source-03-06016"></a>
 
<a id="sc-13-02-대체-파일-선택"></a>
 **대체 파일 선택(SC-13-02).** auto/hf 등 실제 선택한 loader의 후보 파일과 형식을 조사하고 [Q-R05-11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-11)에 따라 승인·형식 제한을 재확인한다. 후보 선택과 파싱 오류 후 retry는 별도로 확인한다. 고정 v0.31.0의 PT iterator는 weights_only=True와 실제 의존성을 함께 조사한다. PT 형식을 선택했다는 사실만으로 임의 코드 실행이 발생했다고 판정하지 않는다. [고정 코드](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/model_executor/model_loader/default_loader.py#L154-L252)

 

<a id="sc-13-03-daemon-fallback"></a>
 **공유 서비스의 대체 로딩(SC-13-03).** IPC fallback은 load_format=auto, model_loader_extra_config={}로 DefaultModelLoader를 생성한다. 실제 대체 source·형식·승인을 [Q-R05-11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-11)과 [Q-C13](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C13)에 따라 확인하고, 대체 로딩에 설정을 다시 적용했을 때의 효과는 실행 시험으로 확인한다. [고정 코드](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/model_executor/model_loader/weight_cache/ipc_loader.py#L401-L416)

 

모델의 실제 적재 일치([Q-R05-14](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-14))와 전체 실행 준비·접수 재개([Q-C09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C09))는 각각 증거를 남긴다. 한 rank의 READY나 정상 canary 결과에 더해 필수 모델 부분·worker와 전체 준비 상태를 확인한다.

 

**연결할 점검과 증거** [CHK-SUP-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-003)·[CHK-SUP-004](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-004)·[CHK-SUP-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-005)·[CHK-SUP-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-006)에 따라 승인한 모델·소프트웨어 목록을 실제 읽은 자료와 대조한다. 모델·tokenizer·설정·이미지의 판본과 digest, 파일 교체 시도 결과, 각 worker가 적재한 모델 부분을 남긴다. 컴파일 결과를 사용하면 [CHK-SUP-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-007)·[CHK-SUP-015](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-015)·[CHK-SUP-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-016)에서 생성 경로·쓰기 권한·재사용 조건과 생성 중단 후 부분 파일의 처리도 확인한다.

 

### vLLM · 다른 버전에서 적용할 때



### v0.30.0 · v0.32.0 — Python·처리 라이브러리의 지원 조건



| 코드에서 확인한 차이 | v0.32.0은 Python 최소 버전을 3.11로 올리고 requests·transformers·tokenizers·aiohttp·Pillow·filelock 등의 의존 범위를 바꾼다. v0.30.0은 tokenizer·grammar·GPU 라이브러리와 harmony 패키지 선택이 기준판과 다르다. |
| --- | --- |
| 수행 방법 | 실제 이미지에서 Python·패키지·decoder·GPU 라이브러리 목록과 digest를 수집하고 해당 판본의 설치 선언과 대조한다. 공지의 영향 조건·백포트·실제 활성 기능을 따로 평가한다. |
| 확인할 결과·남길 자료 | 실제 설치 목록·wheel/이미지 식별과 선언 차이·공지 적용 근거·재발 시험. 의존성 하한 변경만으로 모든 취약점 조치 완료를 판정하지 않는다. |



확인할 체크리스트: [CHK-SUP-004](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-004) · [CHK-SUP-017](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-017) · [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)



### v0.30.0 — 미디어 캐시 식별값과 재사용



| 코드에서 확인한 차이 | v0.30.0의 멀티모달 hash 직렬화는 v0.31.0의 길이 framing과 다르다. KV 추가 키도 cache_salt·LoRA·MM 종류를 붙이는 형태가 다르다. |
| --- | --- |
| 수행 방법 | 멀티모달 원문·분할 경계·옵션·LoRA·salt를 한 조건씩 바꿔 재사용 여부와 최종 결과를 확인한다. 판본을 넘겨 이전 캐시를 재사용하려면 호환 증거를 확보하거나 별도 경로에서 새로 생성한다. |
| 확인할 결과·남길 자료 | 판본별 hash 입력·키, 적중 여부, 실제 사용 자료·정상 결과. 새 캐시 경로와 이전 경로를 기록한다. |



확인할 체크리스트: [CHK-SUP-015](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-015)



### v0.30.0 — 요청별 미디어 처리 옵션 제한



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



확인할 체크리스트: [CHK-SUP-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-003) · [CHK-SUP-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-008)



### v0.32.0 — PP 구성의 공유 가중치 준비·종료



| 코드에서 확인한 차이 | 가중치 daemon의 rank 배치가 DP·TP에서 DP·PP·TP로 확장된다. 기준판이 거부하던 PP 구성을 v0.32.0은 rank 배치에 포함한다. |
| --- | --- |
| 수행 방법 | 공유 가중치를 PP와 함께 사용하면 dp_rank·pp_rank·tp_rank·장치·daemon socket을 대응시킨다. 한 rank 준비 실패와 daemon 종료 후 기존 소비자·새 취득을 분리해 확인한다. |
| 확인할 결과·남길 자료 | rank별 모델·layout·IPC payload·준비, 종료·참조 반환과 후속 정상 취득. release 응답만으로 소비자 참조 반환을 완료하지 않는다. |



확인할 체크리스트: [CHK-SUP-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-006)



### v0.32.0 — 공유 메모리 참조의 서명 검사



| 코드에서 확인한 차이 | SHM handle에 key·address·monotonic_id를 묶은 HMAC 서명이 추가된다. reader는 주소를 읽기 전에 검증하고 sender는 현재 key의 항목인지도 확인한다. |
| --- | --- |
| 수행 방법 | SHM 캐시 사용 구성에서 정상 handle과 key 변경·주소 변경·서명 누락·오래된 세대 참조를 무해하게 대조한다. 수신 시점에서 거부하고 역직렬화에 도달하지 않는지 확인한다. |
| 확인할 결과·남길 자료 | 서버 발급 handle, 수신 검증·거부 위치, 최종 reader, 정상 캐시 사용과 재기동 뒤 이전 참조 처리. 같은 UID의 SHM 접근 제한은 별도로 확인한다. |



확인할 체크리스트: [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)



### v0.32.0 — 모델 교체 때 실제로 읽는 가중치



| 코드에서 확인한 차이 | weights 재적재가 공통 reload.inplace로 이동한다. 새 weights_path를 지정하면 이전 revision뿐 아니라 model_weights 객체 저장소 공급원도 비운다. |
| --- | --- |
| 수행 방법 | 객체 저장소 공급원을 설정했던 모델에서 승인한 새 경로로 바꾸고 최종 읽기 파일·저장소를 확인한다. V1·V2 caller의 LoRA·encoder·MM 캐시 초기화도 함께 관측한다. |
| 확인할 결과·남길 자료 | 변경 전후 model·model_weights·revision, 실제 파일·적재 tensor와 새 요청 결과. 누락 경고가 났다면 필수 weights 준비 여부를 별도로 판정한다. |



확인할 체크리스트: [CHK-SUP-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-003) · [CHK-SUP-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-005) · [CHK-SUP-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-006)



### v0.32.0 — 미디어 옵션 병합과 처리 코드 선택



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



확인할 체크리스트: [CHK-SUP-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-003) · [CHK-SUP-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-008) · [CHK-SUP-015](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-015)



### v0.32.0 — 템플릿 처리 시간 제한과 작업 종료



| 코드에서 확인한 차이 | 비동기 template 렌더에 VLLM_CHAT_TEMPLATE_RENDER_TIMEOUT 제한과 executor 교체가 추가된다. timeout 뒤 기존 Python thread의 CPU 작업은 계속될 수 있다. |
| --- | --- |
| 수행 방법 | 승인한 무해한 지연 template로 timeout·후속 정상 요청을 비교하고 기존 thread의 CPU·메모리도 관측한다. 제한을 시험 때문에 바꿨다면 승인값으로 복원하고 필요하면 프로세스를 다시 기동한다. |
| 확인할 결과·남길 자료 | 유효 timeout, API 오류·후속 요청, 이전 thread·CPU·메모리의 종결. 응답 timeout을 실제 연산 종료로 판정하지 않는다. |



확인할 체크리스트: [CHK-SUP-013](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-013)



### v0.32.0 — 프로세스 사이 버퍼의 사용·반환



| 코드에서 확인한 차이 | worker queue는 큰 out-of-band buffer를 재사용 ring에서 복사하고, 선택한 tensor arena는 storage 해제와 H2D 완료 event 뒤 slot을 반환한다. 일반 pickle 경로도 남는다. |
| --- | --- |
| 수행 방법 | tensor arena 활성 여부와 실제 fallback을 기록한다. 느린 소비·비동기 H2D·취소·worker 종료에서 tensor storage·CUDA event·slot 반환과 다음 요청 결과를 관측한다. |
| 확인할 결과·남길 자료 | queue 선택·arena slot·reader별 반환·GPU 완료·다음 재사용 순서. 새 arena를 별도 사용자 인가 경계로 간주하지 않는다. |



확인할 체크리스트: [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)

