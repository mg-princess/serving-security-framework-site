# CHK-SUP-003 — vLLM

[공통 시험 명세](../../checks/CHK-SUP-003.md) · [기준판 상세 구현](../baseline/CHK-SUP-003.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0에는 validate_request_mm_kwargs와 --trust-request-mm-kwargs가 없다. v0.31.0·v0.32.0은 기본 false인 trust_request_mm_kwargs에 따라 요청별 mm_processor_kwargs·media_io_kwargs를 거부한다. |
| --- | --- |
| 수행 방법 | v0.30.0에서는 지원하지 않는 플래그를 추가하지 말고, 공개 진입점에서 두 필드를 허용할지 정한다. 정상 요청과 두 필드를 각각 넣은 요청을 비교하고 processor가 실제 받은 값을 확인한다. |
| 확인할 결과·남길 자료 | API 거부·제거 결과, 실제 processor와 입력 옵션, 전처리 자원 사용. 허용 시험에 사용한 우회 정책은 시험 후 회수한다. |



### 고정 소스와 확인 범위



[vllm/config/model.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/model.py) · [vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/config/multimodal.py) · [vllm/engine/arg_utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/engine/arg_utils.py) · [vllm/entrypoints/generate/base/protocol.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/generate/base/protocol.py) · [vllm/entrypoints/launchers/cli_args.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/cli_args.py) · [vllm/entrypoints/pooling/base/serving.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/pooling/base/serving.py) · [vllm/model_executor/models/ultravox.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/model_executor/models/ultravox.py) · [vllm/plugins/lora_resolvers/hf_hub_resolver.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/plugins/lora_resolvers/hf_hub_resolver.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/config.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/transformers_utils/config.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/transformers_utils/processor.py) · [vllm/transformers_utils/utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/transformers_utils/utils.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 2건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | MM processor 옵션은 중첩 scope를 재귀 병합한다. processor 로딩에는 고정 revision의 비가중치 snapshot 선택이 추가되며 code_revision이 다르면 별도 경로를 사용한다. |
| --- | --- |
| 수행 방법 | 요청별 옵션 허용 구성에서 flat·images_kwargs·videos_kwargs·audio_kwargs를 한 조건씩 바꾸고 processor에 최종 전달된 값과 캐시 식별값을 확인한다. 실제 config·processor·코드 파일의 commit·경로도 기록한다. |
| 확인할 결과·남길 자료 | 최종 병합 옵션, 선택 파일·코드 판본, 자원 비용·캐시 적중과 정상 결과. 금지 구성의 기본 거부 시험은 그대로 유지한다. |



| 코드에서 확인한 차이 | weights 재적재가 공통 reload.inplace로 이동한다. 새 weights_path를 지정하면 이전 revision뿐 아니라 model_weights 객체 저장소 공급원도 비운다. |
| --- | --- |
| 수행 방법 | 객체 저장소 공급원을 설정했던 모델에서 승인한 새 경로로 바꾸고 최종 읽기 파일·저장소를 확인한다. V1·V2 caller의 LoRA·encoder·MM 캐시 초기화도 함께 관측한다. |
| 확인할 결과·남길 자료 | 변경 전후 model·model_weights·revision, 실제 파일·적재 tensor와 새 요청 결과. 누락 경고가 났다면 필수 weights 준비 여부를 별도로 판정한다. |



### 고정 소스와 확인 범위



[vllm/config/model.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/model.py) · [vllm/config/multimodal.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/config/multimodal.py) · [vllm/engine/arg_utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/engine/arg_utils.py) · [vllm/entrypoints/generate/base/protocol.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/generate/base/protocol.py) · [vllm/entrypoints/pooling/base/serving.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/pooling/base/serving.py) · [vllm/model_executor/model_loader/reload/inplace.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/reload/inplace.py) · [vllm/model_executor/models/ultravox.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/models/ultravox.py) · [vllm/plugins/lora_resolvers/hf_hub_resolver.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/plugins/lora_resolvers/hf_hub_resolver.py) · [vllm/renderers/online_renderer.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/renderers/online_renderer.py) · [vllm/transformers_utils/config.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/config.py) · [vllm/transformers_utils/processor.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/processor.py) · [vllm/transformers_utils/utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/transformers_utils/utils.py) · [vllm/v1/worker/gpu/model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu/model_runner.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



