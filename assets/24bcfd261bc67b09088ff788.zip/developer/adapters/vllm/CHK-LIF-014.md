# CHK-LIF-014 — vLLM

[공통 시험 명세](../../checks/CHK-LIF-014.md) · [기준판 상세 구현](../baseline/CHK-LIF-014.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 공통 절차 적용



비교 기준: v0.31.0



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[vllm/entrypoints/serve/profile/api_router.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/serve/profile/api_router.py) · [vllm/profiler/wrapper.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/profiler/wrapper.py) · [vllm/v1/engine/async_llm.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/async_llm.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | 대기열 거부 로그가 INFO에서 DEBUG로 바뀌고 거부 원인별 계측이 추가된다. profiler 시작·정지는 lock과 session 상태를 사용한다. |
| --- | --- |
| 수행 방법 | 대기열 초과 사건은 기본 INFO 로그 존재만으로 판단하지 말고 실제 거부·관련 지표를 수집한다. profiler 동시 시작·정지와 실패 뒤 수집 종료·자원 반환도 비교한다. |
| 확인할 결과·남길 자료 | 거부 원인·요청 결과·지표 수집, profiler session·실제 backend 종료·후속 정상 요청. |



### 고정 소스와 확인 범위



[vllm/entrypoints/serve/profile/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/profile/api_router.py) · [vllm/profiler/wrapper.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/profiler/wrapper.py) · [vllm/v1/engine/async_llm.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/async_llm.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



