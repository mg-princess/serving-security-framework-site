# CHK-LIF-006 — vLLM

[공통 시험 명세](../../checks/CHK-LIF-006.md) · [기준판 상세 구현](../baseline/CHK-LIF-006.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.30.0



### vLLM v0.30.0 · 시험 보완 1건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | v0.30.0의 LoRA 적재 요청 검사에는 기준판의 base model 이름 충돌 거부가 없다. |
| --- | --- |
| 수행 방법 | 격리된 관리 접점에서 base model과 같은 이름·별도 이름의 무해한 LoRA를 비교하고 실제 선택 모델·LoRA·해제 후 결과를 기록한다. 관리 경로와 모델별 권한도 함께 확인한다. |
| 확인할 결과·남길 자료 | 등록·거부 결과, alias→실제 모델 대응, LoRA 해제·원복과 정상 요청. |



### 고정 소스와 확인 범위



[vllm/entrypoints/launchers/api_server/entry.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/api_server/entry.py) · [vllm/entrypoints/launchers/api_server/routers.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/api_server/routers.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/launchers/launcher.py) · [vllm/entrypoints/openai/models/serving.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/openai/models/serving.py) · [vllm/entrypoints/serve/dev/rlhf/api_router.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/serve/dev/rlhf/api_router.py) · [vllm/entrypoints/serve/dev/rpc/api_router.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/serve/dev/rpc/api_router.py) · [vllm/v1/engine/utils.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/engine/utils.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.32.0



### vLLM v0.32.0 · 시험 보완 2건



비교 기준: v0.31.0



| 코드에서 확인한 차이 | /v1/systemone이 새로 등록되고 개발 모드의 RL 관리 라우터가 entrypoints/rl/online으로 이동한다. /abort_requests는 request_ids를 생략하면 모든 진행 요청을 대상으로 한다. |
| --- | --- |
| 수행 방법 | 실제 라우트 목록에서 /v1/systemone과 활성 관리 API를 확인한다. 공개 경로에서는 관리 기능을 제한하고, 중단 시험은 격리된 인스턴스의 지정 요청으로 수행한다. 경로 이동을 기능 제거로 처리하지 않는다. |
| 확인할 결과·남길 자료 | 등록 조건, 호출자별 거부 결과, 지정 요청·전체 요청 구분, 실제 중단과 모델 변경 기록. |



| 코드에서 확인한 차이 | weights 재적재가 공통 reload.inplace로 이동한다. 새 weights_path를 지정하면 이전 revision뿐 아니라 model_weights 객체 저장소 공급원도 비운다. |
| --- | --- |
| 수행 방법 | 객체 저장소 공급원을 설정했던 모델에서 승인한 새 경로로 바꾸고 최종 읽기 파일·저장소를 확인한다. V1·V2 caller의 LoRA·encoder·MM 캐시 초기화도 함께 관측한다. |
| 확인할 결과·남길 자료 | 변경 전후 model·model_weights·revision, 실제 파일·적재 tensor와 새 요청 결과. 누락 경고가 났다면 필수 weights 준비 여부를 별도로 판정한다. |



### 고정 소스와 확인 범위



[vllm/entrypoints/generate/structured_decisions/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/generate/structured_decisions/api_router.py) · [vllm/entrypoints/launchers/api_server/entry.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/api_server/entry.py) · [vllm/entrypoints/launchers/api_server/routers.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/api_server/routers.py) · [vllm/entrypoints/launchers/launcher.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/launchers/launcher.py) · [vllm/entrypoints/rl/online/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/rl/online/api_router.py) · [vllm/entrypoints/rl/online/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/rl/online/api_router.py) · [vllm/entrypoints/serve/dev/rpc/api_router.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/dev/rpc/api_router.py) · [vllm/entrypoints/serve/middleware/authenticate.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/entrypoints/serve/middleware/authenticate.py) · [vllm/model_executor/model_loader/reload/inplace.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/model_executor/model_loader/reload/inplace.py) · [vllm/v1/engine/utils.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/engine/utils.py) · [vllm/v1/worker/gpu/model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu/model_runner.py) · [vllm/v1/worker/gpu_model_runner.py](https://github.com/vllm-project/vllm/blob/5df63a7203cdb9328d824a27b682e77c7b9928be/vllm/v1/worker/gpu_model_runner.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



