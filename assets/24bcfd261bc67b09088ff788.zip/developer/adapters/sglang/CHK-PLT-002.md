# CHK-PLT-002 — SGLang

[공통 시험 명세](../../checks/CHK-PLT-002.md) · [기준판 상세 구현](../baseline/CHK-PLT-002.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/managers/scheduler_components/ipc_channels.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler_components/ipc_channels.py) · [python/sglang/srt/utils/network.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/network.py) · [python/sglang/srt/weight_cache/daemon.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/daemon.py) · [python/sglang/srt/weight_cache/ipc_loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/ipc_loader.py) · [python/sglang/srt/weight_cache/protocol.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/protocol.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | SGLANG_ZMQ_ALLOWED_PEERS를 사용하는 TCP peer 제한과 SGLANG_ZMQ_SOURCE_IP를 사용하는 송신 출발 주소 지정이 추가된다. allowlist가 비어 있으면 제한하지 않으며 get_zmq_socket_on_host는 호출자가 restrict_peers=True를 전달해야 적용된다. |
| --- | --- |
| 수행 방법 | 실제 내부 TCP socket의 생성 함수와 bind 전에 제한이 적용되는지 확인한다. 허용·비허용 출발 주소에서 정상·거부를 비교하고 컨테이너·다중 NIC의 실제 출발 주소를 기록한다. |
| 확인할 결과·남길 자료 | 환경값, 호출자별 restrict_peers 적용, 실제 source IP와 연결·메시지 소비 결과. IP 제한과 암호화·프로세스별 신원 확인을 각각 평가한다. |



### 고정 소스와 확인 범위



[python/sglang/srt/environ.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/environ.py) · [python/sglang/srt/managers/data_parallel_controller.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/data_parallel_controller.py) · [python/sglang/srt/managers/scheduler_components/ipc_channels.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/scheduler_components/ipc_channels.py) · [python/sglang/srt/ray/data_parallel_controller.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/ray/data_parallel_controller.py) · [python/sglang/srt/utils/network.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/utils/network.py) · [python/sglang/srt/weight_cache/daemon.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/weight_cache/daemon.py) · [python/sglang/srt/weight_cache/ipc_loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/weight_cache/ipc_loader.py) · [python/sglang/srt/weight_cache/protocol.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/weight_cache/protocol.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



