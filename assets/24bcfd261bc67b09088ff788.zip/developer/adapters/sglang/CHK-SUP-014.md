# CHK-SUP-014 — SGLang

[공통 시험 명세](../../checks/CHK-SUP-014.md) · [기준판 상세 구현](../baseline/CHK-SUP-014.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | HiCache backend에 시험용 지연·실패 주입 wrapper가 추가된다. SGLANG_TEST_HICACHE_BACKEND_RANDOM_DELAY·SGLANG_TEST_HICACHE_BACKEND_RANDOM_FAILURE가 설정된 경우에만 적용된다. |
| --- | --- |
| 수행 방법 | 격리 시험에서 필요할 때만 두 시험용 환경값을 사용한다. 실패 시 준비·복원 결과가 보류되는지 확인한 뒤 환경값을 제거하고 프로세스를 다시 기동해 정상 구성을 확인한다. |
| 확인할 결과·남길 자료 | 시험 설정·주입 로그·실패 전달·재기동 뒤 환경값 부재와 정상 요청. 확률값은 운영 권장값으로 제공하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/mem_cache/storage/backend_factory.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/storage/backend_factory.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



