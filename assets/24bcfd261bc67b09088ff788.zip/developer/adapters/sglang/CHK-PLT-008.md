# CHK-PLT-008 — SGLang

[공통 시험 명세](../../checks/CHK-PLT-008.md) · [기준판 상세 구현](../baseline/CHK-PLT-008.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/distributed/device_communicators/custom_all_reduce.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py) · [python/sglang/srt/entrypoints/grpc_bridge.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/grpc_bridge.py) · [python/sglang/srt/entrypoints/grpc_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/grpc_server.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/managers/scheduler_components/ipc_channels.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler_components/ipc_channels.py) · [rust/sglang-grpc/src/server.rs](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/rust/sglang-grpc/src/server.rs) · [rust/sglang-server/src/api_server/app.rs](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/rust/sglang-server/src/api_server/app.rs)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 2건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | SGLANG_ZMQ_ALLOWED_PEERS를 사용하는 TCP peer 제한과 SGLANG_ZMQ_SOURCE_IP를 사용하는 송신 출발 주소 지정이 추가된다. allowlist가 비어 있으면 제한하지 않으며 get_zmq_socket_on_host는 호출자가 restrict_peers=True를 전달해야 적용된다. |
| --- | --- |
| 수행 방법 | 실제 내부 TCP socket의 생성 함수와 bind 전에 제한이 적용되는지 확인한다. 허용·비허용 출발 주소에서 정상·거부를 비교하고 컨테이너·다중 NIC의 실제 출발 주소를 기록한다. |
| 확인할 결과·남길 자료 | 환경값, 호출자별 restrict_peers 적용, 실제 source IP와 연결·메시지 소비 결과. IP 제한과 암호화·프로세스별 신원 확인을 각각 평가한다. |



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/distributed/device_communicators/custom_all_reduce.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py) · [python/sglang/srt/entrypoints/grpc_bridge.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/grpc_bridge.py) · [python/sglang/srt/entrypoints/grpc_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/grpc_server.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/environ.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/environ.py) · [python/sglang/srt/managers/data_parallel_controller.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/data_parallel_controller.py) · [python/sglang/srt/managers/scheduler_components/ipc_channels.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/scheduler_components/ipc_channels.py) · [python/sglang/srt/ray/data_parallel_controller.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/ray/data_parallel_controller.py) · [python/sglang/srt/utils/network.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/utils/network.py) · [rust/sglang-grpc/src/server.rs](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/rust/sglang-grpc/src/server.rs) · [rust/sglang-server/src/api_server/http/app.rs](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/rust/sglang-server/src/api_server/http/app.rs)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



