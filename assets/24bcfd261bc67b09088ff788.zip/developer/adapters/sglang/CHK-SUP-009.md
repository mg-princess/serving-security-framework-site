# CHK-SUP-009 — SGLang

[공통 시험 명세](../../checks/CHK-SUP-009.md) · [기준판 상세 구현](../baseline/CHK-SUP-009.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



**추가 reader·실행 경로 확인.** 확인한 tokenizer helper는 trust 값을 재호출에 전달하고 선언 class의 동적 해석을 그 값으로 제한한다. 설치 SDK·선택 모델의 최종 거부는 정상 대조와 함께 확인해야 한다.



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/model.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/model.py) · [python/sglang/srt/configs/model_config.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/configs/model_config.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 공통 절차 적용



**추가 reader·실행 경로 확인.** 확인한 tokenizer helper는 trust 값을 재호출에 전달하고 선언 class의 동적 해석을 그 값으로 제한한다. 설치 SDK·선택 모델의 최종 거부는 정상 대조와 함께 확인해야 한다.



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/model.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/model.py) · [python/sglang/srt/configs/model_config.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/configs/model_config.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



