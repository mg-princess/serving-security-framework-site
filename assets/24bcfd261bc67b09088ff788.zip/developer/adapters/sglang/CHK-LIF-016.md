# CHK-LIF-016 — SGLang

[공통 시험 명세](../../checks/CHK-LIF-016.md) · [기준판 상세 구현](../baseline/CHK-LIF-016.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | 기준판의 PD decode 대기 요청 중 기존 KV를 가진 요청을 retract 대상으로 옮기는 처리가 v0.5.21에 없다. prefill overlap의 전송 경계와 abort의 KV·host backup 회수 조건도 다르다. |
| --- | --- |
| 수행 방법 | PD에서 전송 완료 후 실행 대기 중인 요청을 포함해 pause·모델 변경·resume·abort를 시험한다. 요청별 weights·KV 세대와 전송·반환을 기록한다. 해당 흐름을 확인하지 못하면 중단 후 그룹 전체 교체 절차를 적용한다. |
| 확인할 결과·남길 자료 | prefill·decode 양쪽의 요청·모델 세대, 대기 KV·backup 반환과 후속 정상 요청. 단일 프로세스의 pause 응답으로 분산 전환을 완료하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/managers/scheduler.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/weight_cache/daemon.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/daemon.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 2건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | HiCacheFile은 TP별 Mamba 상태와 공유 MLA KV의 파일 suffix·삭제 소유 범위를 나누고 DCP shard·page 크기를 키에 추가한다. raw payload에는 dtype·layout을 담지 않는 경로도 남는다. |
| --- | --- |
| 수행 방법 | 선정 모델의 TP·PP·CP·DCP·Mamba와 실제 생성 파일 이름을 확인한다. 구성 변경 전후 캐시를 분리해 읽기·회수·복원을 시험하고 layout·dtype 호환 증거 없이 이전 파일을 재사용하지 않는다. |
| 확인할 결과·남길 자료 | 실제 파일·저장 경로·키·writer·삭제 대상, 복원 자료의 호환 조건과 새 생성 결과. LRU 회수를 보존 기한에 따른 전체 사본 삭제로 대신하지 않는다. |



| 코드에서 확인한 차이 | HiCache backend에 시험용 지연·실패 주입 wrapper가 추가된다. SGLANG_TEST_HICACHE_BACKEND_RANDOM_DELAY·SGLANG_TEST_HICACHE_BACKEND_RANDOM_FAILURE가 설정된 경우에만 적용된다. |
| --- | --- |
| 수행 방법 | 격리 시험에서 필요할 때만 두 시험용 환경값을 사용한다. 실패 시 준비·복원 결과가 보류되는지 확인한 뒤 환경값을 제거하고 프로세스를 다시 기동해 정상 구성을 확인한다. |
| 확인할 결과·남길 자료 | 시험 설정·주입 로그·실패 전달·재기동 뒤 환경값 부재와 정상 요청. 확률값은 운영 권장값으로 제공하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/mem_cache/storage/backend_factory.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/storage/backend_factory.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/weight_cache/daemon.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/weight_cache/daemon.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



