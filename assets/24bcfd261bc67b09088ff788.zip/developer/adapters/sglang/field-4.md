

### SGLang · 4. 상태 격리·재사용 안전성

 

<a id="f-sglang-field-4"></a>
 
<a id="f-sglang-CHK-REQ-011"></a>

 

##### CHK-REQ-011 · 응답의 요청별 귀속

 

**확인할 내용** OpenAI 요청 변환과 stream 분기, tokenizer 응답 대기 과정에서 각 결과가 원래 요청에 돌아가는지 확인한다.

 

**남길 증거** 사용자 A와 B의 동시 요청에 대해 내부·외부 ID와 stream chunk, 실제 수신자와 결과를 대조한다. native API도 같은 범위로 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-011) · 소스: [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135) · [tokenizer_manager.py:1950](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1950-L1978)

 

<a id="f-sglang-CHK-REQ-012"></a>

 

##### CHK-REQ-012 · 취소 후 늦은 결과 처리

 

**확인할 내용** 연결 종료 후 abort가 전달되고 scheduler가 후처리하는 과정을 확인한다. 늦게 도착한 결과가 어느 요청으로 전달되는지도 추적한다.

 

**남길 증거** 취소 대상과 시도 ID, 늦은 출력, 새 요청이 수신한 결과를 기록한다. 자원 회수는 LIF-010에서 별도로 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-012) · 소스: [tokenizer_manager.py:1950](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1950-L1978) · [tokenizer_manager.py:2240](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L2240-L2260) · [scheduler.py:5458](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler.py#L5458-L5523)

 

<a id="f-sglang-CHK-REQ-014"></a>

 

##### CHK-REQ-014 · TP 자료·출력의 요청별 귀속

 

**확인할 내용** scheduler IPC와 TP communicator에서 중간 자료가 전달되는 과정을 따라가며 최종 출력이 어느 요청에 속하는지 확인한다.

 

**남길 증거** 실제 TP rank와 요청, 세대, 전달 payload를 최종 출력과 대조한다. PD나 PP를 선택한 경우에는 해당 경로도 별도로 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-014) · 소스: [ipc_channels.py:25](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/ipc_channels.py#L25-L88) · [custom_all_reduce.py:230](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py#L230-L258)

 

<a id="f-sglang-CHK-REQ-015"></a>

 

##### CHK-REQ-015 · 캐시 공유 집단의 구분

 

**확인할 내용** 요청의 cache_salt가 Radix key에 반영되는지 확인한다. 인증 신원에 따라 캐시 공유 집단을 정하는 방식은 Gateway와 실제 환경의 증거로 확인한다.

 

**남길 증거** 검증된 신원과 신뢰 집단, salt 주입 규칙을 기록한다. client salt를 위조하거나 누락한 경우를 시험하고, 실제로 집단을 넘나드는 cache hit나 자료 사용이 일어나는지 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-015) · 소스: [tokenizer_manager.py:1535](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1535-L1625) · [radix_cache.py:59](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L59-L77) · [radix_cache.py:166](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L166-L175) · [radix_cache.py:364](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L364-L508)

 

<a id="f-sglang-CHK-SUP-015"></a>

 

##### CHK-SUP-015 · 변경 후 캐시 재사용

 

**확인할 내용** 다운로드 캐시와 compile cache를 어떤 값으로 구별해 재사용하는지 확인한다. 관련 조건을 변경한 뒤 캐시를 재생성하는지도 조사한다.

 

**남길 증거** 변경 전후의 모델과 도구, 옵션, cache 식별값을 기록하고 실제 재사용·재생성 결과를 비교한다. 하위 compiler가 사용하는 캐시도 포함한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-015) · 소스: [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [backend.py:94](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L94-L143) · [backend.py:407](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L407-L474)

 

<a id="f-sglang-CHK-REQ-016"></a>

 

##### CHK-REQ-016 · 캐시 재사용의 호환 조건

 

**확인할 내용** Radix key와 extra_key, salt를 확인하고 모델·adapter 변경 시 캐시 재사용에 어떤 조건이 적용되는지 대조한다.

 

**남길 증거** 실제 cache 종류별 key와 모델·판본·설정·adapter 정보를 기록한다. 호환되는 경우와 호환되지 않는 경우의 재사용 결과를 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-016) · 소스: [radix_cache.py:59](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L59-L77) · [radix_cache.py:166](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L166-L175) · [radix_cache.py:364](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L364-L508) · [hicache_storage.py:386](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/hicache_storage.py#L386-L420)

 

<a id="f-sglang-CHK-REQ-018"></a>

 

##### CHK-REQ-018 · 배치 변경 후 요청 상태

 

**확인할 내용** SGLang이 batch를 filter하거나 merge할 때 sampling 상태가 어떻게 이동하는지 확인한다.

 

**남길 증거** 요청이 slot 사이를 이동한 기록을 grammar·mask·logit 상태와 대조한다. 각 요청을 독립적으로 실행한 정상 결과와 비교하고, 선택한 runner별 관측 결과를 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-018) · 소스: [sampling_batch_info.py:466](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/sampling/sampling_batch_info.py#L466-L646)

 

<a id="f-sglang-CHK-REQ-020"></a>

 

##### CHK-REQ-020 · CUDA Graph 버퍼 사용 순서

 

**확인할 내용** decode CUDA Graph의 capture 과정과 input buffer copy 과정을 확인한다.

 

**남길 증거** graph의 실제 활성 여부와 mode, 현재 입력(current input)과 유효 길이를 기록한다. 출력을 사용하는 시점과 buffer 재사용 시점, GPU 완료 시점을 대조한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-020) · 소스: [decode_cuda_graph_runner.py:1117](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py#L1117-L1240) · [decode_cuda_graph_runner.py:1404](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py#L1404-L1450)

 

<a id="f-sglang-CHK-REQ-021"></a>

 

##### CHK-REQ-021 · TP 통신 버퍼의 수명

 

**확인할 내용** custom all-reduce에서 graph buffer를 등록하고 dispose하는 과정을 확인한다.

 

**남길 증거** 선택한 communicator와 등록·실행·종료·재기동 시점의 handle, 세대, owner를 기록한다. GPU 완료 시점과 최종 참조 해제 시점도 함께 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-021) · 소스: [custom_all_reduce.py:230](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py#L230-L258) · [custom_all_reduce.py:332](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py#L332-L340)

 

<a id="f-sglang-CHK-LIF-013"></a>

 

##### CHK-LIF-013 · 공유 가중치의 해제와 재취득

 

**확인할 내용** 공유 가중치를 제공하는 daemon은 있으나, 조사한 socket 프로토콜의 메시지는 `query_config/fetch_state/ping`이며, 전체 release 요청은 확인하지 못했다. daemon 종료, 자료를 사용하는 프로세스(consumer)의 종료 감시와 client fallback을 각각 확인한다. 전체 해제는 별도 경로에서 확인한다.

 

**남길 증거** 실제 설치판과 확장 기능에서 전체 release를 호출할 경로가 있는지 확인해 적용 여부를 정한다. daemon 종료 권한과 다른 consumer에 미치는 영향, 재취득·fallback 승인, 현재 참조·GPU 자원의 수명을 각각 시험한다. 증거를 얻지 못한 범위는 미확인으로 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-013) · 소스: [model.py:371](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/model.py#L371-L397) · [daemon.py:556](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/daemon.py#L556-L624) · [ipc_loader.py:85](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L85-L124) · [ipc_loader.py:451](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L451-L500) · [ipc_loader.py:183](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L183-L228)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 · v0.5.23 — Python·GPU 라이브러리의 지원 조건



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



확인할 체크리스트: [CHK-REQ-019](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-019)



### v0.5.21 — 실패한 요청과 재사용한 ID 정리



| 코드에서 확인한 차이 | 요청 상태를 만든 뒤 실패했을 때 기준판은 해당 state 객체와 현재 state가 같은지 확인해 정리한다. v0.5.21은 rid로 현재 상태를 찾아 정리하며 LoRA 참조 반환 처리에도 차이가 있다. |
| --- | --- |
| 수행 방법 | 같은 rid를 다시 사용하는 요청, 묶음 내부 중복 rid, dispatch 전 실패·취소와 LoRA 사용을 구분해 시험한다. 이전 요청의 늦은 정리가 새 요청 상태에 영향을 주는지 관측한다. |
| 확인할 결과·남길 자료 | attempt별 rid·state 식별, dispatch·abort·종결·LoRA 참조 반환과 후속 정상 요청. 공개 요청의 rid 정책도 함께 확인한다. |



확인할 체크리스트: [CHK-REQ-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-011) · [CHK-REQ-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-012)



### v0.5.23 — GPU 입력 갱신과 큰 통신 작업



| 코드에서 확인한 차이 | decode graph에는 미리 채운 입력의 tensor 동일성 확인과 복사 경로가 추가된다. deterministic all-reduce의 큰 입력은 등록 slot을 계속 추가하는 대신 기존 buffer 크기로 나누어 처리한다. |
| --- | --- |
| 수행 방법 | 선정 graph·speculative 모드에서 입력 갱신·유효 길이·출력 소비를 관측한다. deterministic custom AR의 큰 입력을 반복하고 chunk별 범위·rank 등록 수·종료 후 재기동을 확인한다. |
| 확인할 결과·남길 자료 | 실제 backend·dtype·shape·복사·event·등록 수·GPU 완료·정상 결과. 외부 sglang-kernel의 설치 바이너리와 별도 소스 대응도 확보해야 한다. |



확인할 체크리스트: [CHK-REQ-019](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-019) · [CHK-REQ-020](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-020) · [CHK-REQ-021](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-021)



### v0.5.23 — 분산 캐시 파일의 구분·회수



| 코드에서 확인한 차이 | HiCacheFile은 TP별 Mamba 상태와 공유 MLA KV의 파일 suffix·삭제 소유 범위를 나누고 DCP shard·page 크기를 키에 추가한다. raw payload에는 dtype·layout을 담지 않는 경로도 남는다. |
| --- | --- |
| 수행 방법 | 선정 모델의 TP·PP·CP·DCP·Mamba와 실제 생성 파일 이름을 확인한다. 구성 변경 전후 캐시를 분리해 읽기·회수·복원을 시험하고 layout·dtype 호환 증거 없이 이전 파일을 재사용하지 않는다. |
| 확인할 결과·남길 자료 | 실제 파일·저장 경로·키·writer·삭제 대상, 복원 자료의 호환 조건과 새 생성 결과. LRU 회수를 보존 기한에 따른 전체 사본 삭제로 대신하지 않는다. |



확인할 체크리스트: [CHK-REQ-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-016)

