# CHK-SUP-004 — SGLang

[공통 시험 명세](../../checks/CHK-SUP-004.md) · [기준판 상세 구현](../baseline/CHK-SUP-004.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/pyproject.toml) · [python/sglang/srt/arg_groups/fields/model.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/model.py) · [python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/layers/attention/flashinfer_backend.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/layers/attention/flashinfer_backend.py) · [python/sglang/srt/parser/jinja_template_utils.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/parser/jinja_template_utils.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/pyproject.toml) · [python/sglang/srt/arg_groups/fields/model.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/model.py) · [python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/layers/attention/flashinfer_backend.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/layers/attention/flashinfer_backend.py) · [python/sglang/srt/parser/jinja_template_utils.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/parser/jinja_template_utils.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



