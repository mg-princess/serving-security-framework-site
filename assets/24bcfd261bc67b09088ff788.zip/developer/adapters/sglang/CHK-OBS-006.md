# CHK-OBS-006 — SGLang

[공통 시험 명세](../../checks/CHK-OBS-006.md) · [기준판 상세 구현](../baseline/CHK-OBS-006.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/managers/scheduler_components/profiler_manager.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler_components/profiler_manager.py) · [python/sglang/srt/utils/request_logger.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/request_logger.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | watermark 비밀값 마스킹이 enable_watermark 설정과 연결되고, 긴 list·tuple 안의 값도 재귀적으로 처리한다. |
| --- | --- |
| 수행 방법 | watermark 활성·비활성 구성과 중첩 list·dict의 무해 표식으로 실제 요청 로그를 확인한다. 단순 문자열·길이 제한만으로 비밀값 제거를 판정하지 않는다. |
| 확인할 결과·남길 자료 | 로그 설정, 중첩 표식의 저장 여부, 출력 파일·수집기·보관본. 시험 표식과 추가 로그 설정은 회수한다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/managers/scheduler_components/profiler_manager.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/scheduler_components/profiler_manager.py) · [python/sglang/srt/utils/request_logger.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/utils/request_logger.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



