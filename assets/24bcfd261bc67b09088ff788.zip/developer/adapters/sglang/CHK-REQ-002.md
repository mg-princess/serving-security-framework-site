# CHK-REQ-002 — SGLang

[공통 시험 명세](../../checks/CHK-REQ-002.md) · [기준판 상세 구현](../baseline/CHK-REQ-002.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/grpc_bridge.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/grpc_bridge.py) · [python/sglang/srt/entrypoints/grpc_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/grpc_server.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/utils/auth.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/auth.py) · [rust/sglang-grpc/src/server.rs](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/rust/sglang-grpc/src/server.rs) · [rust/sglang-server/src/api_server/app.rs](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/rust/sglang-server/src/api_server/app.rs)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/grpc_bridge.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/grpc_bridge.py) · [python/sglang/srt/entrypoints/grpc_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/grpc_server.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/utils/auth.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/utils/auth.py) · [rust/sglang-grpc/src/server.rs](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/rust/sglang-grpc/src/server.rs) · [rust/sglang-server/src/api_server/http/app.rs](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/rust/sglang-server/src/api_server/http/app.rs)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



