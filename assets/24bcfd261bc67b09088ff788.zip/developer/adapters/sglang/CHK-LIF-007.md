# CHK-LIF-007 — SGLang

[공통 시험 명세](../../checks/CHK-LIF-007.md) · [기준판 상세 구현](../baseline/CHK-LIF-007.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/http_server.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 3건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | /ping은 이전판의 고정 200에서 is_healthy 기반 200/503으로 바뀐다. 일시정지 중에도 healthy이면 /ping은 200이고 /ready는 접수 준비 여부를 별도로 표시한다. |
| --- | --- |
| 수행 방법 | 기동 중·정상·일시정지·종료·실패에서 /ping과 /ready를 대조한다. 운영 접수 gate는 준비 상태와 실제 정상 요청·필수 rank를 함께 사용한다. |
| 확인할 결과·남길 자료 | 상태별 응답, 필수 worker·모델 준비와 canary, 접수·종료 기록. /ping 성공만으로 접수를 재개하지 않는다. |



| 코드에서 확인한 차이 | HiCache backend에 시험용 지연·실패 주입 wrapper가 추가된다. SGLANG_TEST_HICACHE_BACKEND_RANDOM_DELAY·SGLANG_TEST_HICACHE_BACKEND_RANDOM_FAILURE가 설정된 경우에만 적용된다. |
| --- | --- |
| 수행 방법 | 격리 시험에서 필요할 때만 두 시험용 환경값을 사용한다. 실패 시 준비·복원 결과가 보류되는지 확인한 뒤 환경값을 제거하고 프로세스를 다시 기동해 정상 구성을 확인한다. |
| 확인할 결과·남길 자료 | 시험 설정·주입 로그·실패 전달·재기동 뒤 환경값 부재와 정상 요청. 확률값은 운영 권장값으로 제공하지 않는다. |



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/serving.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/serving.py) · [python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/managers/tokenizer_manager.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/tokenizer_manager.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/mem_cache/storage/backend_factory.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/storage/backend_factory.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



