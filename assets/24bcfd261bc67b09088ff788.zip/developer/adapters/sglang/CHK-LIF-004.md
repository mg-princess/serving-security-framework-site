# CHK-LIF-004 — SGLang

[공통 시험 명세](../../checks/CHK-LIF-004.md) · [기준판 상세 구현](../baseline/CHK-LIF-004.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | OpenAI 요청을 내부 요청으로 바꾸는 작업은 v0.5.21에서는 호출 흐름에서 수행하고, 기준판부터 executor로 넘긴다. |
| --- | --- |
| 수행 방법 | 긴 입력·멀티모달 전처리와 가벼운 정상 요청을 함께 보내 처리 기회와 취소 반응을 관측한다. HTTP 동시 요청 수만으로 전처리 비용이 제한됐다고 판단하지 않는다. |
| 확인할 결과·남길 자료 | API 지연, 전처리 대기·메모리, 취소·정상 요청 완료. 부하 상한은 조직이 승인한 예산에서 정한다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/entrypoints/openai/serving_base.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/openai/serving_base.py) · [python/sglang/srt/managers/tokenizer_manager.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/tokenizer_manager.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/arg_groups/fields/serving.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/serving.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/entrypoints/openai/serving_base.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/openai/serving_base.py) · [python/sglang/srt/managers/tokenizer_manager.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/tokenizer_manager.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



