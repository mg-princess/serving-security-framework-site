# CHK-OBS-003 — SGLang

[공통 시험 명세](../../checks/CHK-OBS-003.md) · [기준판 상세 구현](../baseline/CHK-OBS-003.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21의 POST /load_lora_adapter_from_tensors와 GET·POST /set_trace_level에는 기준판의 ADMIN_OPTIONAL 지정이 없다. 기본 NORMAL 인증으로 처리된다. |
| --- | --- |
| 수행 방법 | 일반 API key와 관리 key를 분리한 구성에서 두 경로를 각각 호출한다. v0.5.21은 앞단의 관리 경로 허용 목록과 직통 차단을 확인한다. 무해한 LoRA·trace 설정을 쓰고 시험 뒤 이전 상태로 복원한다. |
| 확인할 결과·남길 자료 | 경로별 실제 auth level·허용 작업과 변경 결과, 직통 거부·복원. API key가 있다는 사실만으로 관리 권한 분리를 판정하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/managers/scheduler_components/profiler_manager.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler_components/profiler_manager.py) · [python/sglang/srt/observability/trace.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/observability/trace.py) · [python/sglang/srt/utils/auth.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/auth.py) · [python/sglang/srt/utils/request_logger.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/request_logger.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | watermark 비밀값 마스킹이 enable_watermark 설정과 연결되고, 긴 list·tuple 안의 값도 재귀적으로 처리한다. |
| --- | --- |
| 수행 방법 | watermark 활성·비활성 구성과 중첩 list·dict의 무해 표식으로 실제 요청 로그를 확인한다. 단순 문자열·길이 제한만으로 비밀값 제거를 판정하지 않는다. |
| 확인할 결과·남길 자료 | 로그 설정, 중첩 표식의 저장 여부, 출력 파일·수집기·보관본. 시험 표식과 추가 로그 설정은 회수한다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/managers/scheduler_components/profiler_manager.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/scheduler_components/profiler_manager.py) · [python/sglang/srt/observability/trace.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/observability/trace.py) · [python/sglang/srt/utils/request_logger.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/utils/request_logger.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



