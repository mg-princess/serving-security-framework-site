

### SGLang · 6. 자원 관리·서비스 가용성

 

<a id="f-sglang-field-6"></a>
 
<a id="f-sglang-CHK-LIF-001"></a>

 

##### CHK-LIF-001 · 모델 준비 과정의 자원 예산

 

**확인할 내용** 다운로드·모델 적재(loader)·선택한 컴파일(compile)의 단계별 비용과 누적 비용을 확인한다. 실제로 모델을 준비하는 과정과 자원이 반환되는 결과를 예산에 대조한다.

 

**남길 증거** 사용한 모델·설정, 단계별 시간·CPU·RAM·GPU·디스크 사용량과 전체 비용을 남긴다. 정상 준비와 자원 반환 결과를 예산과 대조하고, 기준을 정하지 못한 값은 미정으로 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-001) · 소스: [weight_utils.py:621](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L621-L714) · [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [backend.py:407](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L407-L474) · [http_server.py:2412](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2412-L2501)

 

<a id="f-sglang-CHK-LIF-003"></a>

 

##### CHK-LIF-003 · 요청 부하와 정상 서비스의 유지

 

**확인할 내용** 동시 처리(concurrency), 대기열(queue), 토큰 풀(token pool)과 분할 처리(chunking)의 설정을 실제 자원 비용과 대조한다. native API와 추가 반환 기능에서 발생하는 비용도 포함한다.

 

**남길 증거** 설정을 해석한 뒤 실제로 적용된 예산을 확인하고, 요청별·전체 자원 사용량과 대기·공정성, 정상 요청 성능을 남긴다. 비용 한도와 처리 기한은 적용 환경에서 채택한 기준을 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003) · 소스: [schedule.py:27](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/schedule.py#L27-L94) · [io_struct.py:180](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/io_struct.py#L180-L300) · [sampling_params.py:229](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/sampling/sampling_params.py#L229-L305)

 

<a id="f-sglang-CHK-LIF-004"></a>

 

##### CHK-LIF-004 · 느린 응답 수신과 버퍼 비용

 

**확인할 내용** 스트리밍(stream) 대기·출력 생성·연결 종료에 따라 자원이 어떻게 사용되는지 확인한다. 진단 버퍼(buffer)를 사용하는 경우에는 그 비용도 함께 대조한다.

 

**남길 증거** 응답을 느리게 수신하거나 연결을 종료하기 전후의 queue·buffer·RAM·GPU 사용량을 남긴다. 정리 조건과 동시에 처리하는 정상 요청에 미친 영향도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-004) · 소스: [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135) · [tokenizer_manager.py:1950](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1950-L1978) · [observability.py:30](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/observability.py#L30-L70)

 

<a id="f-sglang-CHK-LIF-002"></a>

 

##### CHK-LIF-002 · 모델 취득 실패와 재시도 비용

 

**확인할 내용** HF 등 실제 모델 취득에 사용하는 SDK·도구의 재시도 경로와 예산을 확인한다. 취득이 실패한 조건별로 재시도가 어떻게 발생하는지 관측한다.

 

**남길 증거** 사용한 SDK·환경과 실패 조건별 재시도 횟수·시간·누적 비용을 남긴다. 부분 파일이 정리된 결과와 정상 재취득 결과도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-002) · 소스: [weight_utils.py:621](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L621-L714)

 

<a id="f-sglang-CHK-LIF-012"></a>

 

##### CHK-LIF-012 · 추론 재시도와 잔존 작업

 

**확인할 내용** Gateway·앱·엔진에서 추론 재시도(retry)를 실제로 사용하는지 확인한다. 재시도가 발생하면 이전 작업이 남아 있는지와 새 시도의 결과·비용을 함께 대조한다.

 

**남길 증거** retry를 금지했다면 실제 적용된 설정·경로와 재시도가 발생하지 않은 결과를 남긴다. 허용했다면 이전·새 시도, 중복 결과·비용과 작업·자원의 회수 결과를 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-012) · 소스: [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135) · [tokenizer_manager.py:2240](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L2240-L2260)

 

<a id="f-sglang-CHK-LIF-008"></a>

 

##### CHK-LIF-008 · worker 장애의 감지와 통지

 

**확인할 내용** forward watchdog과 하위 프로세스(subprocess)의 종료 감지가 실제로 동작하는지 확인한다. 예외·프로세스 종료·지연·통신 정지별로 상위 제어 프로세스에 통지가 전달되는지 대조한다.

 

**남길 증거** rank별 예외·종료·지연·통신 정지 시험에서 실제 상위 통지와 처리 기한을 남긴다. 불완전한 결과를 어떻게 처리했는지도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-008) · 소스: [watchdog.py:103](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/watchdog.py#L103-L223) · [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

<a id="f-sglang-CHK-LIF-010"></a>

 

##### CHK-LIF-010 · 취소 후 작업 중단과 자원 회수

 

**확인할 내용** tokenizer의 연결 종료(disconnect)·abort 처리와 scheduler의 단계별 자원 반환을 따라 확인한다. 요청 대기·계산·출력 중 취소했을 때 실제 GPU 작업과 관련 상태가 어떻게 끝나는지 대조한다.

 

**남길 증거** 각 단계의 abort와 실제 GPU 작업 중단 결과를 남긴다. req·KV·session 참조와 자원이 회수된 시각·결과를 정한 처리 기한에 대조해 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010) · 소스: [tokenizer_manager.py:1950](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1950-L1978) · [tokenizer_manager.py:2240](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L2240-L2260) · [scheduler.py:5458](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler.py#L5458-L5523) · [session_controller.py:370](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/session/session_controller.py#L370-L455)

 

<a id="f-sglang-CHK-LIF-011"></a>

 

##### CHK-LIF-011 · 실패한 실행의 정리와 재기동

 

**확인할 내용** 엔진·worker·통신 구성요소(communicator)의 종료와 재기동을 확인한다. daemon을 사용하는 경우에는 해당 프로세스와 공유 자원도 함께 점검한다.

 

**남길 증거** PID·socket·SHM·GPU·handle별 실제 반환 결과와 최종 참조가 해제된 근거를 남긴다. 실패를 정리한 뒤 정상 재기동한 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011) · 소스: [engine.py:1438](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1438-L1477) · [custom_all_reduce.py:332](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py#L332-L340) · [ipc_loader.py:183](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L183-L228)

 

<a id="f-sglang-CHK-LIF-014"></a>

 

##### CHK-LIF-014 · 성능 진단의 실제 종료

 

**확인할 내용** profiler stop이 backend별로 어떻게 처리되는지와 적용할 종료 조건을 확인한다. 종료 응답을 받은 시점과 실제 수집·관련 자원 사용이 끝난 시점·결과를 대조한다.

 

**남길 증거** 선택한 backend, stop 응답과 실제 수집 중단 결과를 남긴다. 자료 저장·전송과 자원 반환, 이후 정상 서비스의 결과도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-014) · 소스: [http_server.py:1009](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L1009-L1219) · [profiler_manager.py:318](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/profiler_manager.py#L318-L395)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 · v0.5.23 — Python·GPU 라이브러리의 지원 조건



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



확인할 체크리스트: [CHK-LIF-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-001)



### v0.5.21 — 분리형 배포의 중단·변경·취소



| 코드에서 확인한 차이 | 기준판의 PD decode 대기 요청 중 기존 KV를 가진 요청을 retract 대상으로 옮기는 처리가 v0.5.21에 없다. prefill overlap의 전송 경계와 abort의 KV·host backup 회수 조건도 다르다. |
| --- | --- |
| 수행 방법 | PD에서 전송 완료 후 실행 대기 중인 요청을 포함해 pause·모델 변경·resume·abort를 시험한다. 요청별 weights·KV 세대와 전송·반환을 기록한다. 해당 흐름을 확인하지 못하면 중단 후 그룹 전체 교체 절차를 적용한다. |
| 확인할 결과·남길 자료 | prefill·decode 양쪽의 요청·모델 세대, 대기 KV·backup 반환과 후속 정상 요청. 단일 프로세스의 pause 응답으로 분산 전환을 완료하지 않는다. |



확인할 체크리스트: [CHK-LIF-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010)



### v0.5.21 · v0.5.23 — 서버 종류별 인증 적용 범위



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003)



### v0.5.21 — 실패한 요청과 재사용한 ID 정리



| 코드에서 확인한 차이 | 요청 상태를 만든 뒤 실패했을 때 기준판은 해당 state 객체와 현재 state가 같은지 확인해 정리한다. v0.5.21은 rid로 현재 상태를 찾아 정리하며 LoRA 참조 반환 처리에도 차이가 있다. |
| --- | --- |
| 수행 방법 | 같은 rid를 다시 사용하는 요청, 묶음 내부 중복 rid, dispatch 전 실패·취소와 LoRA 사용을 구분해 시험한다. 이전 요청의 늦은 정리가 새 요청 상태에 영향을 주는지 관측한다. |
| 확인할 결과·남길 자료 | attempt별 rid·state 식별, dispatch·abort·종결·LoRA 참조 반환과 후속 정상 요청. 공개 요청의 rid 정책도 함께 확인한다. |



확인할 체크리스트: [CHK-LIF-010](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-010) · [CHK-LIF-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-012)



### v0.5.21 — 요청 변환 작업과 동시 처리



| 코드에서 확인한 차이 | OpenAI 요청을 내부 요청으로 바꾸는 작업은 v0.5.21에서는 호출 흐름에서 수행하고, 기준판부터 executor로 넘긴다. |
| --- | --- |
| 수행 방법 | 긴 입력·멀티모달 전처리와 가벼운 정상 요청을 함께 보내 처리 기회와 취소 반응을 관측한다. HTTP 동시 요청 수만으로 전처리 비용이 제한됐다고 판단하지 않는다. |
| 확인할 결과·남길 자료 | API 지연, 전처리 대기·메모리, 취소·정상 요청 완료. 부하 상한은 조직이 승인한 예산에서 정한다. |



확인할 체크리스트: [CHK-LIF-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-003) · [CHK-LIF-004](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-004)



### v0.5.23 — 여러 HTTP worker의 준비·종료



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



확인할 체크리스트: [CHK-LIF-004](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-004)



### v0.5.23 — 캐시 지연·실패 시험과 설정 회수



| 코드에서 확인한 차이 | HiCache backend에 시험용 지연·실패 주입 wrapper가 추가된다. SGLANG_TEST_HICACHE_BACKEND_RANDOM_DELAY·SGLANG_TEST_HICACHE_BACKEND_RANDOM_FAILURE가 설정된 경우에만 적용된다. |
| --- | --- |
| 수행 방법 | 격리 시험에서 필요할 때만 두 시험용 환경값을 사용한다. 실패 시 준비·복원 결과가 보류되는지 확인한 뒤 환경값을 제거하고 프로세스를 다시 기동해 정상 구성을 확인한다. |
| 확인할 결과·남길 자료 | 시험 설정·주입 로그·실패 전달·재기동 뒤 환경값 부재와 정상 요청. 확률값은 운영 권장값으로 제공하지 않는다. |



확인할 체크리스트: [CHK-LIF-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-001)

