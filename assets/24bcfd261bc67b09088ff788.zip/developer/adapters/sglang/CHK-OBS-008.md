# CHK-OBS-008 — SGLang

[공통 시험 명세](../../checks/CHK-OBS-008.md) · [기준판 상세 구현](../baseline/CHK-OBS-008.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/debug_utils/dump_loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/debug_utils/dump_loader.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/model_loader/weight_utils.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/weight_utils.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | _load_pt_file에서 구형 tar 오류 뒤 weights_only=False로 다시 읽던 처리가 제거됐다. v0.5.21·v0.5.22에는 해당 fallback이 있다. |
| --- | --- |
| 수행 방법 | 선택한 PT loader에 정상 자료·구형 tar·금지 객체를 나타내는 무해한 자료를 각각 제공한다. v0.5.23은 거부 위치를 확인하고 실패한 자료를 자동으로 제한 없는 reader로 다시 읽지 않는다. |
| 확인할 결과·남길 자료 | 최종 reader·weights_only, 선택 파일, 거부·정상 결과와 부수 동작. 호환되지 않는 자료는 승인 절차에 따라 변환·재검증한다. |



### 고정 소스와 확인 범위



[python/sglang/srt/debug_utils/dump_loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/debug_utils/dump_loader.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/model_loader/weight_utils.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/weight_utils.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



