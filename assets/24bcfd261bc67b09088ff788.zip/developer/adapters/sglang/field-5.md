

### SGLang · 5. 정보·통신 보호

 

<a id="f-sglang-field-5"></a>
 
<a id="f-sglang-CHK-REQ-013"></a>

 

##### CHK-REQ-013 · 응답에 포함되는 정보

 

**확인할 내용** endpoint별 prompt_token_ids, native API의 추가 반환값과 오류 응답(envelope)을 확인한다. 수신자에게 허용된 정보 범위와 실제 반환 내용을 대조한다.

 

**남길 증거** 정상·stream·오류 응답의 필드와 합성 내부 marker를 수신자별 허용 정책과 대조한다. 정상 답변에 포함된 인용과 추가로 반환된 입력은 구분해 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-013) · 소스: [serving_chat.py:2008](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L2008-L2235) · [serving_chat.py:2451](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L2451-L2492) · [io_struct.py:180](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/io_struct.py#L180-L300) · [http_server.py:2173](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2173-L2177) · [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135)

 

<a id="f-sglang-CHK-OBS-003"></a>

 

##### CHK-OBS-003 · 로그·진단 자료의 수집 정보

 

**확인할 내용** 요청 로그 수준(request log level), crash dump, trace와 profiler가 각각 어떤 필드를 수집하는지 확인한다.

 

**남길 증거** 실제로 적용된 설정과 저장 위치(sink)별 원본·사본을 남긴다. 합성한 민감정보 표식(marker)이 기록되는지 확인하고, 필요한 필수 사건 기록이 유지되는지도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-003) · 소스: [observability.py:30](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/observability.py#L30-L70) · [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173) · [trace.py:277](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/observability/trace.py#L277-L290) · [profiler_manager.py:318](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/profiler_manager.py#L318-L395)

 

<a id="f-sglang-CHK-OBS-004"></a>

 

##### CHK-OBS-004 · 제품 사용 통계의 비사용 확인

 

**확인할 내용** 검토한 srt 코드에서 usage_stats·telemetry·do_not_track과 관측 코드를 조사했지만, vLLM형 제품 사용 통계 reporter에 대응하는 경로는 확인하지 못했다. 설치한 패키지와 실행 진입점(entrypoint)에서 해당 기능을 추가로 확인하며, OTel 추적과 요청의 token usage는 각각 별도 기능으로 조사한다.

 

**남길 증거** 실제 설치 패키지·entrypoint, 내장 reporter와 외부 송신을 조사한 결과를 남긴다. 프로세스 시작 시점과 주기적인 보고 생성·송신을 관측한 뒤 해당 기능의 비사용 여부를 판단한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-004) · 소스: [observability.py:30](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/observability.py#L30-L70) · [trace.py:277](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/observability/trace.py#L277-L290)

 

<a id="f-sglang-CHK-OBS-005"></a>

 

##### CHK-OBS-005 · 허용한 제품 사용 통계의 범위

 

**확인할 내용** 사용 통계 보고를 허용하는 경우에도 먼저 실제 reporter를 확인한다. 보고를 금지한 참조 구성에서는 비사용을 확인하고, 조직이 보고를 허용한 경우에는 승인 범위를 대조한다.

 

**남길 증거** 기능 조사 결과를 남긴다. 조직이 보고를 허용했다면 허용한 필드·목적지·주기와 실제 전송 내용(payload)을 비교한 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-005) · 소스: [observability.py:30](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/observability.py#L30-L70) · [trace.py:277](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/observability/trace.py#L277-L290)

 

<a id="f-sglang-CHK-OBS-006"></a>

 

##### CHK-OBS-006 · 기록 사본의 조회·반출과 암호화

 

**확인할 내용** 요청·장애(crash)·profiler의 dump와 수집기(collector)에 저장한 사본을 확인한다. 각 사본을 누가 읽을 수 있는지와 필요한 암호화가 적용되는지를 실제 저장소의 접근 통제 위치에서 점검한다.

 

**남길 증거** 사본별 읽는 계정·프로그램(reader)과 ACL, 조회·반출 결과를 남긴다. 자료 등급에 따른 암호화·복호화 권한과 허용된 정상 조회 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-006) · 소스: [observability.py:30](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/observability.py#L30-L70) · [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173) · [profiler_manager.py:318](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/profiler_manager.py#L318-L395)

 

<a id="f-sglang-CHK-PLT-008"></a>

 

##### CHK-PLT-008 · API와 내부 통신의 구간별 보호

 

**확인할 내용** HTTP의 TLS 설정 인수와 로컬 IPC·TP 통신을 구간별로 나눠 확인한다. 호출자에서 Gateway·엔진으로 이어지는 경로와 내부 통신에서 각각 어떤 보호가 적용되는지 대조한다.

 

**남길 증거** 각 구간의 실제 통신 상대(peer), 보호 정책과 인증·암호화 적용 결과를 남긴다. OS의 접근 통제로 보호하는 구간은 해당 통제의 설정과 동작을 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-008) · 소스: [http_server.py:2726](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2726-L2747) · [ipc_channels.py:25](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/ipc_channels.py#L25-L88) · [custom_all_reduce.py:230](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py#L230-L258)

 

<a id="f-sglang-CHK-PLT-009"></a>

 

##### CHK-PLT-009 · 기록 수집·저장 경로의 전송 보호

 

**확인할 내용** OTLP gRPC·HTTP exporter가 기록을 수집기(collector)에 보내는 구간과 수집기에서 최종 저장소(sink)로 전달하는 구간을 따로 확인한다.

 

**남길 증거** 실제 exporter·SDK·endpoint와 gRPC의 insecure 설정을 남긴다. 네트워크 접근 제한·인증·암호화가 적용된 결과를 수집기 이후의 저장소 구간까지 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-009) · 소스: [trace.py:277](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/observability/trace.py#L277-L290)

 

<a id="f-sglang-CHK-REQ-017"></a>

 

##### CHK-REQ-017 · 캐시 시간 정보의 노출

 

**확인할 내용** 공유 Radix hit가 발생하는 경로에서 위협 조건에 맞춘 시간 관측 시험을 수행한다.

 

**남길 증거** 추론 대상인 비공개 prefix, 시간을 관측하는 사용자, 반복 시험 한도와 통계 기준을 기록한다. hit와 지연의 원인을 확인하고, 정책상 허용된 정보 추론과 금지된 정보 추론의 결과를 구분해 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-017) · 소스: [radix_cache.py:364](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/radix_cache.py#L364-L508)

 

<a id="f-sglang-CHK-OBS-012"></a>

 

##### CHK-OBS-012 · 자산 원본·사본의 보존과 삭제

 

**확인할 내용** 로그·진단·사용 통계(usage)와 함께 모델·입력 자료·임시 파일·캐시·백업 중 실제로 보존하는 자산을 확인한다. SGLang의 요청·진단 저장 경로, Responses 저장 기능과 HiCache·외부 KV 저장을 사용하는 경우 각 backend의 원본·사본 목록을 작성하고, 자산별 보존 기간과 삭제 조건을 시험한다.

 

**남길 증거** 자산·사본별 위치와 소유자, 보존 기간·예외·삭제 정책, 삭제 실행·조회·복구 결과를 남긴다. 임시 파일과 지속 KV 사본을 포함해 삭제 뒤에도 접근·복구할 수 있는지 확인하고, backend에 필요한 삭제 완료 근거를 기록한다. 각 자산의 결과를 OBS-012에 연결한다. 아래 소스 근거는 관측 자료의 생성·저장 경로를 설명하므로, 모델·입력·KV·백업의 실제 저장·삭제 구현은 선택한 backend와 외부 저장소에서 추가로 확인해 근거를 붙인다. 기록 자료의 접근 제한·암호화는 OBS-006에서 별도로 판정한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-012) · 소스: [observability.py:30](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/observability.py#L30-L70) · [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173) · [profiler_manager.py:318](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/profiler_manager.py#L318-L395)

 

<a id="f-sglang-CHK-PLT-013"></a>



##### CHK-PLT-013 · 모델·입력·결과·영속 캐시·백업의 저장 권한

 

저장소 담당자는 SGLang이 실제로 읽거나 기록하는 위치부터 찾아야 한다. 엔진 API의 인증과 별도로 파일·볼륨·저장소에 직접 접근하는 계정을 확인해야 한다. 다음 위치는 사용하는 기능에 따라 조사해야 한다.

 

| 대상 | SGLang v0.5.22에서 확인할 위치 | 적용 방법 |
| --- | --- | --- |
| 모델 원본·다운로드 사본 | `model_path`, 실제 로더가 사용하는 `load_config.download_dir`, 선택된 가중치 파일과 인덱스 | 실제로 연 경로·마운트와 승인 목록을 대조해야 한다. 운영 원본은 읽기 전용 사용을 우선하고, 다운로드·승인·배포의 쓰기 권한을 구분해야 한다. |
| 파일로 저장하는 HiCache | `HiCacheFile`을 선택했다면 `SGLANG_HICACHE_FILE_BACKEND_STORAGE_DIR`, `file_storage_path`, 최종 `file_path` | 이 소스의 기본 경로인 `/tmp/hicache`는 운영 권장 경로가 아니다. 실제 선택된 저장 위치·모델/분산 실행별 파일과 읽기·쓰기 주체를 조사하고, 승인한 전용 저장 위치와 접근 정책을 적용해야 한다. |
| 진단·재실행용 파일 | 사용하는 경우 `SGLANG_DUMP_LOADER_DIR`와 실제 진단 파일 | 이 경로의 읽기 함수는 `torch.load(..., weights_only=False)`를 사용한다. 파일 조회·변경 권한과 이를 읽어 실행하는 권한을 구분해야 한다. 파일 내용의 해석 안전성은 CHK-SUP-012·CHK-OBS-008에서도 확인해야 한다. |
| 저장 입력·결과·미디어 임시 파일 | 선택한 API·모델 처리기·연결 앱이 실제로 생성한 파일과 저장소 | 자료 종류·경로·소유자·보존 사본을 확인해야 한다. 모든 입력이나 결과가 파일로 저장된다고 전제하지 않고, 실제 저장 여부를 설정과 기록으로 확인해야 한다. |
| 외부 저장소·백업·복구 사본 | 선택한 외부 캐시 저장소, 객체 저장소, 볼륨 스냅샷과 백업 | 실제 서비스 계정과 저장소 정책·키 사용 권한을 대조해야 한다. 다른 계정으로 복구하거나 내려받는 경로에도 같은 보호 기준을 적용해야 한다. |

 

**수행과 확인:** 운영 담당자는 자료별 경로·계정·허용 작업을 정리해야 한다. 시험 담당자는 대상과 같은 소유권·ACL·암호화 정책을 적용한 무해한 시험 파일로 허용·비허용 계정의 직접 읽기·쓰기·다운로드를 비교해야 한다. 파일·볼륨·외부 저장소마다 실제 집행 위치를 확인하고, 암호화가 필수인 자료는 저장 설정과 복호화·키 사용 권한도 확인해야 한다.

 

**실패와 복원:** 비허용 접근이 성공하면 해당 경로를 제한하고 노출·변경 범위를 확인해야 한다. 권한을 수정한 뒤 같은 요청과 정상 모델 로딩·추론을 다시 확인해야 한다. 임시 권한·시험 파일을 회수하고, 복구 사본에도 현재 접근 정책이 적용되는지 확인해야 한다. 보존·삭제 결과는 CHK-OBS-012에 자료별로 남겨야 한다. 로그·진단 사본은 CHK-OBS-006의 결과와 증거를 재사용하되 각 항목의 판정은 구분해야 한다.

 

[CHK-PLT-013 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-013) · [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012) · [CHK-OBS-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-008) · [CHK-OBS-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-012) · 소스: [실제 모델 파일 선택](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [HiCache 파일 저장 위치](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/hicache_storage.py#L386-L420) · [선택 진단 파일 읽기](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/debug_utils/dump_loader.py#L32-L85)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 · v0.5.23 — 서버 종류별 인증 적용 범위



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



확인할 체크리스트: [CHK-PLT-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-008)



### v0.5.21 · v0.5.23 — 실제로 사용하는 캐시 저장 경로



| 코드에서 확인한 차이 | v0.5.21의 HiCacheFile은 SGLANG_HICACHE_FILE_BACKEND_STORAGE_DIR 또는 생성자 file_path를 사용한다. 기준판·v0.5.23은 그 사이에 extra_config.file_storage_path 선택을 추가한다. serving.file_storage_path의 선언값만으로 실제 저장 위치를 정할 수 없다. |
| --- | --- |
| 수행 방법 | HiCache file backend를 사용하는 경우 실제 소비 함수가 선택한 경로를 확인한다. 환경값·extra_config·생성자 인자의 우선순위와 실제 파일 생성·권한·사본을 대조한다. |
| 확인할 결과·남길 자료 | 최종 절대 경로, mount·소유자·읽기·반출 권한, 생성·보존·삭제 결과. 사용하지 않는 설정 이름을 저장 보호 근거로 쓰지 않는다. |



확인할 체크리스트: [CHK-OBS-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-012) · [CHK-PLT-013](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-013)



### v0.5.23 — 내부 통신의 접속 허용 주소



| 코드에서 확인한 차이 | SGLANG_ZMQ_ALLOWED_PEERS를 사용하는 TCP peer 제한과 SGLANG_ZMQ_SOURCE_IP를 사용하는 송신 출발 주소 지정이 추가된다. allowlist가 비어 있으면 제한하지 않으며 get_zmq_socket_on_host는 호출자가 restrict_peers=True를 전달해야 적용된다. |
| --- | --- |
| 수행 방법 | 실제 내부 TCP socket의 생성 함수와 bind 전에 제한이 적용되는지 확인한다. 허용·비허용 출발 주소에서 정상·거부를 비교하고 컨테이너·다중 NIC의 실제 출발 주소를 기록한다. |
| 확인할 결과·남길 자료 | 환경값, 호출자별 restrict_peers 적용, 실제 source IP와 연결·메시지 소비 결과. IP 제한과 암호화·프로세스별 신원 확인을 각각 평가한다. |



확인할 체크리스트: [CHK-PLT-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-002) · [CHK-PLT-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-006) · [CHK-PLT-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-008)



### v0.5.23 — 분산 캐시 파일의 구분·회수



| 코드에서 확인한 차이 | HiCacheFile은 TP별 Mamba 상태와 공유 MLA KV의 파일 suffix·삭제 소유 범위를 나누고 DCP shard·page 크기를 키에 추가한다. raw payload에는 dtype·layout을 담지 않는 경로도 남는다. |
| --- | --- |
| 수행 방법 | 선정 모델의 TP·PP·CP·DCP·Mamba와 실제 생성 파일 이름을 확인한다. 구성 변경 전후 캐시를 분리해 읽기·회수·복원을 시험하고 layout·dtype 호환 증거 없이 이전 파일을 재사용하지 않는다. |
| 확인할 결과·남길 자료 | 실제 파일·저장 경로·키·writer·삭제 대상, 복원 자료의 호환 조건과 새 생성 결과. LRU 회수를 보존 기한에 따른 전체 사본 삭제로 대신하지 않는다. |



확인할 체크리스트: [CHK-OBS-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-012) · [CHK-PLT-013](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-013)



### v0.5.23 — 중첩된 로그의 비밀값 가림



| 코드에서 확인한 차이 | watermark 비밀값 마스킹이 enable_watermark 설정과 연결되고, 긴 list·tuple 안의 값도 재귀적으로 처리한다. |
| --- | --- |
| 수행 방법 | watermark 활성·비활성 구성과 중첩 list·dict의 무해 표식으로 실제 요청 로그를 확인한다. 단순 문자열·길이 제한만으로 비밀값 제거를 판정하지 않는다. |
| 확인할 결과·남길 자료 | 로그 설정, 중첩 표식의 저장 여부, 출력 파일·수집기·보관본. 시험 표식과 추가 로그 설정은 회수한다. |



확인할 체크리스트: [CHK-OBS-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-006)

