# CHK-LIF-006 — SGLang

[공통 시험 명세](../../checks/CHK-LIF-006.md) · [기준판 상세 구현](../baseline/CHK-LIF-006.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 2건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21의 POST /load_lora_adapter_from_tensors와 GET·POST /set_trace_level에는 기준판의 ADMIN_OPTIONAL 지정이 없다. 기본 NORMAL 인증으로 처리된다. |
| --- | --- |
| 수행 방법 | 일반 API key와 관리 key를 분리한 구성에서 두 경로를 각각 호출한다. v0.5.21은 앞단의 관리 경로 허용 목록과 직통 차단을 확인한다. 무해한 LoRA·trace 설정을 쓰고 시험 뒤 이전 상태로 복원한다. |
| 확인할 결과·남길 자료 | 경로별 실제 auth level·허용 작업과 변경 결과, 직통 거부·복원. API key가 있다는 사실만으로 관리 권한 분리를 판정하지 않는다. |



| 코드에서 확인한 차이 | 기준판의 PD decode 대기 요청 중 기존 KV를 가진 요청을 retract 대상으로 옮기는 처리가 v0.5.21에 없다. prefill overlap의 전송 경계와 abort의 KV·host backup 회수 조건도 다르다. |
| --- | --- |
| 수행 방법 | PD에서 전송 완료 후 실행 대기 중인 요청을 포함해 pause·모델 변경·resume·abort를 시험한다. 요청별 weights·KV 세대와 전송·반환을 기록한다. 해당 흐름을 확인하지 못하면 중단 후 그룹 전체 교체 절차를 적용한다. |
| 확인할 결과·남길 자료 | prefill·decode 양쪽의 요청·모델 세대, 대기 KV·backup 반환과 후속 정상 요청. 단일 프로세스의 pause 응답으로 분산 전환을 완료하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/managers/scheduler.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/utils/auth.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/auth.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



