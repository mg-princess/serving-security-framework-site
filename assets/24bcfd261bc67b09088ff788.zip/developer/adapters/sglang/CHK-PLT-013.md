# CHK-PLT-013 — SGLang

[공통 시험 명세](../../checks/CHK-PLT-013.md) · [기준판 상세 구현](../baseline/CHK-PLT-013.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21의 HiCacheFile은 SGLANG_HICACHE_FILE_BACKEND_STORAGE_DIR 또는 생성자 file_path를 사용한다. 기준판·v0.5.23은 그 사이에 extra_config.file_storage_path 선택을 추가한다. serving.file_storage_path의 선언값만으로 실제 저장 위치를 정할 수 없다. |
| --- | --- |
| 수행 방법 | HiCache file backend를 사용하는 경우 실제 소비 함수가 선택한 경로를 확인한다. 환경값·extra_config·생성자 인자의 우선순위와 실제 파일 생성·권한·사본을 대조한다. |
| 확인할 결과·남길 자료 | 최종 절대 경로, mount·소유자·읽기·반출 권한, 생성·보존·삭제 결과. 사용하지 않는 설정 이름을 저장 보호 근거로 쓰지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/arg_groups/fields/serving.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/serving.py) · [python/sglang/srt/debug_utils/dump_loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/debug_utils/dump_loader.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/mem_cache/unified_radix_cache.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/mem_cache/unified_radix_cache.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 2건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | HiCacheFile은 TP별 Mamba 상태와 공유 MLA KV의 파일 suffix·삭제 소유 범위를 나누고 DCP shard·page 크기를 키에 추가한다. raw payload에는 dtype·layout을 담지 않는 경로도 남는다. |
| --- | --- |
| 수행 방법 | 선정 모델의 TP·PP·CP·DCP·Mamba와 실제 생성 파일 이름을 확인한다. 구성 변경 전후 캐시를 분리해 읽기·회수·복원을 시험하고 layout·dtype 호환 증거 없이 이전 파일을 재사용하지 않는다. |
| 확인할 결과·남길 자료 | 실제 파일·저장 경로·키·writer·삭제 대상, 복원 자료의 호환 조건과 새 생성 결과. LRU 회수를 보존 기한에 따른 전체 사본 삭제로 대신하지 않는다. |



| 코드에서 확인한 차이 | v0.5.21의 HiCacheFile은 SGLANG_HICACHE_FILE_BACKEND_STORAGE_DIR 또는 생성자 file_path를 사용한다. 기준판·v0.5.23은 그 사이에 extra_config.file_storage_path 선택을 추가한다. serving.file_storage_path의 선언값만으로 실제 저장 위치를 정할 수 없다. |
| --- | --- |
| 수행 방법 | HiCache file backend를 사용하는 경우 실제 소비 함수가 선택한 경로를 확인한다. 환경값·extra_config·생성자 인자의 우선순위와 실제 파일 생성·권한·사본을 대조한다. |
| 확인할 결과·남길 자료 | 최종 절대 경로, mount·소유자·읽기·반출 권한, 생성·보존·삭제 결과. 사용하지 않는 설정 이름을 저장 보호 근거로 쓰지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/arg_groups/fields/observability.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/observability.py) · [python/sglang/srt/arg_groups/fields/serving.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/serving.py) · [python/sglang/srt/debug_utils/dump_loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/debug_utils/dump_loader.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/mem_cache/unified_radix_cache.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/unified_radix_cache.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py)



조직의 IAM·승인·네트워크·저장소·수집 체계는 실제 환경에서 집행·증거를 확인해야 한다.



