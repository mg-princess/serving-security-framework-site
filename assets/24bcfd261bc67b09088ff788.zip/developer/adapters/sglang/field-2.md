

### SGLang · 2. 모델·소프트웨어 무결성

 

<a id="f-sglang-field-2"></a>
 
<a id="f-sglang-CHK-SUP-003"></a>

 

##### CHK-SUP-003 · 모델 구성 자료의 승인

 

**확인할 내용** 모델이 사용하는 자료 목록에 weights뿐 아니라 config, tokenizer, 템플릿과 추가 모델도 포함되는지 확인한다.

 

**남길 증거** 선정한 모델이 실제로 읽은 경로와 판본, digest를 승인 목록과 대조한다. draft나 LoRA를 사용하는 경우에는 해당 자료도 대조 대상에 추가한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-003) · 소스: [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [model_config.py:492](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/configs/model_config.py#L492-L600) · [serving_chat.py:1705](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L1705-L1759)

 

<a id="f-sglang-CHK-SUP-004"></a>

 

##### CHK-SUP-004 · 실행 소프트웨어의 승인

 

**확인할 내용** Python 환경과 kernel, transformers, torch, SDK가 실제 이미지와 설치 패키지에 어떻게 포함되어 있는지 확인한다.

 

**남길 증거** 실행 이미지의 image digest와 entrypoint, 설치된 의존성을 기록하고 승인 목록과 일치하는지 대조한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-004) · 소스: [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368) · [flashinfer_backend.py:77](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/layers/attention/flashinfer_backend.py#L77-L106) · [jinja_template_utils.py:73](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/parser/jinja_template_utils.py#L73-L80)

 

<a id="f-sglang-CHK-SUP-005"></a>

 

다운로드의 [파일 lock](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L165-L175)은 실제 취득 경로의 동시 사용 조건과 함께 확인해야 한다. 승인 저장소·manifest·원본 파일의 교체 권한은 별도로 대조해야 한다.

 

##### CHK-SUP-005 · 검사 후 파일 교체 방지

 

**확인할 내용** loader가 파일을 사용하는 과정에서 checksum 검사 전후로 파일, symlink 또는 mount를 교체할 수 있는지 확인한다. 각 교체를 막는 통제도 함께 살핀다.

 

**남길 증거** 실제 mount와 파일 권한을 기록하고, 무해한 자료로 교체를 시도한다. 사용 시점에 읽은 실제 bytes를 확인하거나 교체가 거부된 증거를 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-005) · 소스: [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [model_file_verifier.py:74](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/model_file_verifier.py#L74-L98)

 

<a id="f-sglang-CHK-SUP-006"></a>

 

##### CHK-SUP-006 · worker 적재 자료의 승인

 

**확인할 내용** 각 worker가 적재하는 모델 자료를 승인 대상과 대조한다. IPC로 weights를 전달하는 기능을 사용하면 실제 payload도 확인한다.

 

**남길 증거** rank별로 실제 모델과 shard, 적재 대상, 승인 식별자를 기록한다. daemon을 사용하면 config와 세대, transport로 전달한 payload도 함께 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-006) · 소스: [loader.py:845](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L845-L910) · [ipc_loader.py:85](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L85-L124)

 

<a id="f-sglang-CHK-SUP-007"></a>

 

##### CHK-SUP-007 · 컴파일 결과의 쓰기·재사용 권한

 

**확인할 내용** compile cache index, 하위 compiler의 캐시와 생성된 graph를 쓰는 계정·프로그램과 읽어 사용하는 계정·프로그램을 구분한다.

 

**남길 증거** compile의 실제 활성 여부와 저장 경로, 쓰고 읽어 사용하는 계정·프로그램(writer·reader)을 기록한다. 허용되지 않은 변조가 거부되는 경우와 정상적으로 재사용되는 경우를 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-007) · 소스: [backend.py:94](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L94-L143) · [backend.py:407](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L407-L474)

 

<a id="f-sglang-CHK-SUP-016"></a>

 

##### CHK-SUP-016 · 생성 중단 후 부분 파일 처리

 

**확인할 내용** 다운로드나 compile 결과 생성이 중단된 뒤 부분 파일을 읽어 사용하는지 조사한다.

 

**남길 증거** 생성 단계별 중단 기록과 완료 표지, 실제로 읽은 파일을 확인하고 정상 재시작 결과를 남긴다. 완료 여부는 파일의 존재만으로 판정하지 않는다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-016) · 소스: [weight_utils.py:621](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L621-L714) · [backend.py:94](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L94-L143) · [backend.py:407](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/compilation/backend.py#L407-L474)

 

<a id="f-sglang-CHK-SUP-017"></a>



##### CHK-SUP-017 · 설치한 엔진·라이브러리의 취약점 조치

 

SGLang v0.5.22의 소스에 선언된 의존성과 실제 서버에 설치한 패키지는 각각 확인해야 한다. 소스의 기본 의존성·선택 패키지는 조사 범위를 정하는 출발점이며, 판단에는 실행 중인 이미지와 실제 설치 목록을 사용해야 한다.

 

| 순서 | 담당자와 수행할 일 | 확인 결과 |
| --- | --- | --- |
| 설치 대상 확인 | 운영 담당자는 실행 이미지 digest, 실제 가상환경의 Python 경로와 설치 패키지 목록을 확보해야 한다. 소스에서 설치했거나 패치를 적용했다면 커밋·빌드·패치 식별정보도 기록해야 한다. 선택한 torch·Transformers·파일 읽기 라이브러리와 관리 범위의 GPU 드라이버·런타임을 포함해야 한다. | 실제 실행 대상과 설치 목록을 같은 이미지·배포 기록으로 식별할 수 있어야 한다. |
| 공지 적용 여부 판단 | 보안 담당자는 공식 공지의 영향 버전, 필요한 기능·권한·노출 경로를 실제 구성과 대조해야 한다. 예를 들어 모델의 `trust_remote_code`, 선택한 `load_format`, 추가 플러그인과 진단 파일 읽기 기능은 각각의 실행 조건을 확인해야 한다. | 공지별 적용·비적용 이유와 사용한 근거를 남겨야 한다. 설치되어 있다는 이유만으로 모든 취약 경로가 실행된다고 판단하지 않아야 한다. |
| 조치와 재확인 | 운영·시험 담당자는 수정 이미지·백포트 또는 접근·기능 제한을 격리 환경에서 확인해야 한다. 관련 경로가 실제로 수정·제한되고 정상 요청이 유지되는지 확인한 뒤, 운영 대상에도 같은 이미지·설정이 적용되었는지 대조해야 한다. | 공지에 대응하는 시험 또는 대체 확인 근거, 정상 요청 결과, 남은 위험·담당자·기한을 함께 기록해야 한다. |
| 시험 변경 회수 | 시험 담당자는 시험에 추가한 계정·자료·권한과 임시 진단 기능을 회수하고 정상 추론을 다시 확인해야 한다. 조치로 채택한 운영 보호 설정은 승인된 구성에 반영해야 한다. | 실제 적용된 조치와 시험용 변경의 회수를 구분해 남겨야 한다. |

 

설치 목록을 얻는 공통 방법은 아래의 [실제 Python 환경의 패키지 확인](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-package-inventory)을 따른다. 조치 기한과 예외는 조직 정책으로 정해야 하며, 스캐너 결과가 0건이거나 공지를 찾지 못했다는 사실만으로 충족을 판정하지 않아야 한다.

 

[CHK-SUP-017 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-017) · 소스: [기본·선택 의존성 선언](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/pyproject.toml) · [모델 로딩·추가 코드 설정](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/model.py#L45-L123) · [선택 PT 파일 읽기 경로](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L1398-L1415)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 · v0.5.23 — Python·GPU 라이브러리의 지원 조건



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



확인할 체크리스트: [CHK-SUP-004](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-004) · [CHK-SUP-017](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-017) · [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)



### v0.5.21 — 지원 로더와 분산 가중치 적재



| 코드에서 확인한 차이 | v0.5.21에는 기준판의 INSTANTTENSOR 분기와 해당 iterator가 없다. 양자화 RL 재적재 구현과 IPC 구성 지문도 달라진다. |
| --- | --- |
| 수행 방법 | 선정 loader의 지원 형식과 fallback을 먼저 확인한다. TP·PP·MoE 구성이 다른 캐시를 같은 것으로 취급하지 말고 rank별 실제 파일·양자화·IPC 지문과 준비 결과를 수집한다. |
| 확인할 결과·남길 자료 | 지원 load-format, 실제 reader와 shard, IPC 구성 대응·실패 결과. 기준판 옵션을 v0.5.21에 그대로 복사하지 않는다. |



확인할 체크리스트: [CHK-SUP-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-003) · [CHK-SUP-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-006) · [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)



### v0.5.23 — 구형 모델 파일을 읽는 방식



| 코드에서 확인한 차이 | _load_pt_file에서 구형 tar 오류 뒤 weights_only=False로 다시 읽던 처리가 제거됐다. v0.5.21·v0.5.22에는 해당 fallback이 있다. |
| --- | --- |
| 수행 방법 | 선택한 PT loader에 정상 자료·구형 tar·금지 객체를 나타내는 무해한 자료를 각각 제공한다. v0.5.23은 거부 위치를 확인하고 실패한 자료를 자동으로 제한 없는 reader로 다시 읽지 않는다. |
| 확인할 결과·남길 자료 | 최종 reader·weights_only, 선택 파일, 거부·정상 결과와 부수 동작. 호환되지 않는 자료는 승인 절차에 따라 변환·재검증한다. |



확인할 체크리스트: [CHK-SUP-012](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012)



### v0.5.23 — 분산 캐시 파일의 구분·회수



| 코드에서 확인한 차이 | HiCacheFile은 TP별 Mamba 상태와 공유 MLA KV의 파일 suffix·삭제 소유 범위를 나누고 DCP shard·page 크기를 키에 추가한다. raw payload에는 dtype·layout을 담지 않는 경로도 남는다. |
| --- | --- |
| 수행 방법 | 선정 모델의 TP·PP·CP·DCP·Mamba와 실제 생성 파일 이름을 확인한다. 구성 변경 전후 캐시를 분리해 읽기·회수·복원을 시험하고 layout·dtype 호환 증거 없이 이전 파일을 재사용하지 않는다. |
| 확인할 결과·남길 자료 | 실제 파일·저장 경로·키·writer·삭제 대상, 복원 자료의 호환 조건과 새 생성 결과. LRU 회수를 보존 기한에 따른 전체 사본 삭제로 대신하지 않는다. |



확인할 체크리스트: [CHK-SUP-015](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-015)



### v0.5.23 — 캐시 지연·실패 시험과 설정 회수



| 코드에서 확인한 차이 | HiCache backend에 시험용 지연·실패 주입 wrapper가 추가된다. SGLANG_TEST_HICACHE_BACKEND_RANDOM_DELAY·SGLANG_TEST_HICACHE_BACKEND_RANDOM_FAILURE가 설정된 경우에만 적용된다. |
| --- | --- |
| 수행 방법 | 격리 시험에서 필요할 때만 두 시험용 환경값을 사용한다. 실패 시 준비·복원 결과가 보류되는지 확인한 뒤 환경값을 제거하고 프로세스를 다시 기동해 정상 구성을 확인한다. |
| 확인할 결과·남길 자료 | 시험 설정·주입 로그·실패 전달·재기동 뒤 환경값 부재와 정상 요청. 확률값은 운영 권장값으로 제공하지 않는다. |



확인할 체크리스트: [CHK-SUP-014](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-014)

