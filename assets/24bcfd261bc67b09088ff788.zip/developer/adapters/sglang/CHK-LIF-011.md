# CHK-LIF-011 — SGLang

[공통 시험 명세](../../checks/CHK-LIF-011.md) · [기준판 상세 구현](../baseline/CHK-LIF-011.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | 기준판의 PD decode 대기 요청 중 기존 KV를 가진 요청을 retract 대상으로 옮기는 처리가 v0.5.21에 없다. prefill overlap의 전송 경계와 abort의 KV·host backup 회수 조건도 다르다. |
| --- | --- |
| 수행 방법 | PD에서 전송 완료 후 실행 대기 중인 요청을 포함해 pause·모델 변경·resume·abort를 시험한다. 요청별 weights·KV 세대와 전송·반환을 기록한다. 해당 흐름을 확인하지 못하면 중단 후 그룹 전체 교체 절차를 적용한다. |
| 확인할 결과·남길 자료 | prefill·decode 양쪽의 요청·모델 세대, 대기 KV·backup 반환과 후속 정상 요청. 단일 프로세스의 pause 응답으로 분산 전환을 완료하지 않는다. |



### 고정 소스와 확인 범위



[python/sglang/srt/distributed/device_communicators/custom_all_reduce.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py) · [python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/managers/scheduler.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/scheduler.py) · [python/sglang/srt/weight_cache/ipc_loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/ipc_loader.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 2건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | decode graph에는 미리 채운 입력의 tensor 동일성 확인과 복사 경로가 추가된다. deterministic all-reduce의 큰 입력은 등록 slot을 계속 추가하는 대신 기존 buffer 크기로 나누어 처리한다. |
| --- | --- |
| 수행 방법 | 선정 graph·speculative 모드에서 입력 갱신·유효 길이·출력 소비를 관측한다. deterministic custom AR의 큰 입력을 반복하고 chunk별 범위·rank 등록 수·종료 후 재기동을 확인한다. |
| 확인할 결과·남길 자료 | 실제 backend·dtype·shape·복사·event·등록 수·GPU 완료·정상 결과. 외부 sglang-kernel의 설치 바이너리와 별도 소스 대응도 확보해야 한다. |



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/pyproject.toml) · [python/sglang/srt/arg_groups/fields/serving.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/serving.py) · [python/sglang/srt/distributed/device_communicators/custom_all_reduce.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py) · [python/sglang/srt/entrypoints/engine.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/engine.py) · [python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py) · [python/sglang/srt/weight_cache/ipc_loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/weight_cache/ipc_loader.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



