# CHK-REQ-020 — SGLang

[공통 시험 명세](../../checks/CHK-REQ-020.md) · [기준판 상세 구현](../baseline/CHK-REQ-020.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py)



저장소의 caller·선정 native 경로 비교. 설치된 외부 native 패키지의 전문 검토·바이너리 대응과 GPU 계측은 수행하지 않았다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | decode graph에는 미리 채운 입력의 tensor 동일성 확인과 복사 경로가 추가된다. deterministic all-reduce의 큰 입력은 등록 slot을 계속 추가하는 대신 기존 buffer 크기로 나누어 처리한다. |
| --- | --- |
| 수행 방법 | 선정 graph·speculative 모드에서 입력 갱신·유효 길이·출력 소비를 관측한다. deterministic custom AR의 큰 입력을 반복하고 chunk별 범위·rank 등록 수·종료 후 재기동을 확인한다. |
| 확인할 결과·남길 자료 | 실제 backend·dtype·shape·복사·event·등록 수·GPU 완료·정상 결과. 외부 sglang-kernel의 설치 바이너리와 별도 소스 대응도 확보해야 한다. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/pyproject.toml) · [python/sglang/srt/distributed/device_communicators/custom_all_reduce.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py) · [python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py)



저장소의 caller·선정 native 경로 비교. 설치된 외부 native 패키지의 전문 검토·바이너리 대응과 GPU 계측은 수행하지 않았다.



