# CHK-SUP-012 — SGLang

[공통 시험 명세](../../checks/CHK-SUP-012.md) · [기준판 상세 구현](../baseline/CHK-SUP-012.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 2건



**추가 reader·실행 경로 확인.** 같은 고정 소스의 _maybe_unwrap_pickle에는 pickle.loads가, dumper의 _evaluate_filter에는 eval과 re.search/re.match 제공이 남아 있다. 가중치 파일 fallback의 수정과 다른 해석 경로의 보호를 각각 확인해야 한다.



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21에는 기준판의 INSTANTTENSOR 분기와 해당 iterator가 없다. 양자화 RL 재적재 구현과 IPC 구성 지문도 달라진다. |
| --- | --- |
| 수행 방법 | 선정 loader의 지원 형식과 fallback을 먼저 확인한다. TP·PP·MoE 구성이 다른 캐시를 같은 것으로 취급하지 말고 rank별 실제 파일·양자화·IPC 지문과 준비 결과를 수집한다. |
| 확인할 결과·남길 자료 | 지원 load-format, 실제 reader와 shard, IPC 구성 대응·실패 결과. 기준판 옵션을 v0.5.21에 그대로 복사하지 않는다. |



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/pyproject.toml) · [python/sglang/srt/arg_groups/fields/exec_.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/arg_groups/fields/exec_.py) · [python/sglang/srt/debug_utils/dump_loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/debug_utils/dump_loader.py) · [python/sglang/srt/managers/tokenizer_manager.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/managers/tokenizer_manager.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/model_loader/weight_utils.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/weight_utils.py) · [python/sglang/srt/multimodal/processors/base_processor.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/multimodal/processors/base_processor.py) · [python/sglang/srt/sampling/custom_logit_processor.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/sampling/custom_logit_processor.py) · [python/sglang/srt/utils/common.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/utils/common.py) · [python/sglang/srt/weight_cache/ipc_loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/ipc_loader.py) · [python/sglang/srt/weight_cache/protocol.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/weight_cache/protocol.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 2건



**추가 reader·실행 경로 확인.** 같은 고정 소스의 _maybe_unwrap_pickle에는 pickle.loads가, dumper의 _evaluate_filter에는 eval과 re.search/re.match 제공이 남아 있다. 가중치 파일 fallback의 수정과 다른 해석 경로의 보호를 각각 확인해야 한다.



비교 기준: v0.5.22



| 코드에서 확인한 차이 | _load_pt_file에서 구형 tar 오류 뒤 weights_only=False로 다시 읽던 처리가 제거됐다. v0.5.21·v0.5.22에는 해당 fallback이 있다. |
| --- | --- |
| 수행 방법 | 선택한 PT loader에 정상 자료·구형 tar·금지 객체를 나타내는 무해한 자료를 각각 제공한다. v0.5.23은 거부 위치를 확인하고 실패한 자료를 자동으로 제한 없는 reader로 다시 읽지 않는다. |
| 확인할 결과·남길 자료 | 최종 reader·weights_only, 선택 파일, 거부·정상 결과와 부수 동작. 호환되지 않는 자료는 승인 절차에 따라 변환·재검증한다. |



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/pyproject.toml) · [python/sglang/srt/arg_groups/fields/exec_.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/arg_groups/fields/exec_.py) · [python/sglang/srt/debug_utils/dump_loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/debug_utils/dump_loader.py) · [python/sglang/srt/managers/tokenizer_manager.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/managers/tokenizer_manager.py) · [python/sglang/srt/mem_cache/hicache_storage.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/mem_cache/hicache_storage.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py) · [python/sglang/srt/model_loader/weight_utils.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/weight_utils.py) · [python/sglang/srt/multimodal/processors/base_processor.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/multimodal/processors/base_processor.py) · [python/sglang/srt/sampling/custom_logit_processor.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/sampling/custom_logit_processor.py) · [python/sglang/srt/utils/common.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/utils/common.py) · [python/sglang/srt/weight_cache/protocol.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/weight_cache/protocol.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



