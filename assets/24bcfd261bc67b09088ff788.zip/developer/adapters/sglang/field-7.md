

### SGLang · 7. 구성·변경 관리

 

<a id="f-sglang-field-7"></a>
 
<a id="f-sglang-CHK-SUP-014"></a>

 

##### CHK-SUP-014 · 필수 검사와 사용 보류

 

**확인할 내용** 조직이 필수로 정한 검사와 보류 gate가 배포 또는 사용을 실제로 제한하는 위치를 확인한다.

 

**남길 증거** 채택한 필수 검사를 기록한다. 검사 실패, 오류, 생략이 있는 자료 묶음은 보류되고 정상 묶음은 허용되는지 시험한다. 승인 기록과 위험수용 기록은 구분해 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-014) · 소스: [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

<a id="f-sglang-CHK-LIF-007"></a>

 

##### CHK-LIF-007 · 모델 실행 준비와 요청 접수

 

**확인할 내용** scheduler가 준비된 상태와 HTTP warmup·status 전환을 실제 요청 접수 제한(gate)에 연결해 확인한다. 필요한 실행 준비가 끝나기 전과 후의 접수 동작을 대조한다.

 

**남길 증거** 필수 rank·모델·graph의 준비 상태와 준비를 생략하는 skip 설정의 유효값을 남긴다. 준비 전 요청의 거부·보류와 준비 후 정상 추론 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007) · 소스: [engine.py:989](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L989-L1025) · [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368) · [http_server.py:2412](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2412-L2501)

 

<a id="f-sglang-CHK-LIF-009"></a>

 

##### CHK-LIF-009 · 일부 실행 준비 실패의 처리

 

**확인할 내용** 하위 프로세스(subprocess) 초기화, scheduler ready와 warmup에서 일부 준비가 실패하는 상황을 각각 확인한다. 실제 실패와 상위 상태·요청 접수 동작을 대조한다.

 

**남길 증거** rank별 실패 주입과 상위 상태, 요청 접수 제한(gate)의 결과를 남긴다. 실패를 성공으로 잘못 기록했는지와 이후 정상 기동한 결과도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009) · 소스: [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368) · [engine.py:989](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L989-L1025) · [http_server.py:2412](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2412-L2501)

 

<a id="f-sglang-CHK-LIF-005"></a>

 

##### CHK-LIF-005 · 재배포 시 요청과 모델의 구분

 

**확인할 내용** Gateway에서 요청 접수를 중단한 뒤 엔진을 종료하고, 새 rank가 준비된 다음 접수를 재개하는 순서를 확인한다. 각 단계에서 진행 중 요청과 이전·새 모델을 어떻게 처리하는지 대조한다.

 

**남길 증거** 변경 전후의 image·model·세대와 진행 중 요청의 처리 방침을 남긴다. 실제 접수 제한(gate)과 모델·상태가 잘못 섞이지 않은 후속 정상 요청의 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005) · 소스: [engine.py:1438](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1438-L1477) · [engine.py:989](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L989-L1025) · [http_server.py:2412](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2412-L2501)

 

<a id="f-sglang-CHK-LIF-006"></a>

 

##### CHK-LIF-006 · 실행 중 변경의 일관성

 

**확인할 내용** 실행 중 가중치 교체(live weights), LoRA와 관리 update route를 사용하는 경우 각각의 변경을 따로 시험한다. 변경 도중의 부분 상태가 요청에 사용되는지와 각 요청의 모델 세대가 일관되는지 확인한다.

 

**남길 증거** 선택한 update·rolling 방식과 요청별 최종 model·세대를 남긴다. 변경 도중 실패한 결과, rollback 처리와 cache 상태도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006) · 소스: [http_server.py:1265](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L1265-L1649) · [loader.py:845](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L845-L910)

 

<a id="f-sglang-CHK-LIF-015"></a>

 

##### CHK-LIF-015 · 이전 구성 복귀와 현재 승인

 

**확인할 내용** 이전 배포 묶음으로 복귀할 때도 현재의 승인·철회 상태와 실제 적용할 설정을 확인한다. 엔진 외부에서 요청 접수·사용을 허용하거나 보류하는 통제(gate)가 검증 결과에 따라 동작하는지 확인한다.

 

**남길 증거** 복귀할 자료와 현재 승인·철회 기록, rollback 수행 주체를 남긴다. 검증 전 gate 동작과 이후 실제 모델·요청 처리 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-015) · 소스: [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

<a id="f-sglang-CHK-LIF-016"></a>

 

##### CHK-LIF-016 · 복원 자료와 잔존 상태의 검증

 

**확인할 내용** 일반 재배포로 복원하는 경우와 선택한 상태 복원 기능을 사용하는 경우를 나눠 확인한다. 각각의 복원 자료 출처와 이전 실행에서 남은 상태를 대조한다.

 

**남길 증거** 실제 backup·복원 범위, 무해하게 변조한 자료의 거부 결과와 이전 cache·session의 잔존 상태를 남긴다. 검증을 마치기 전 서비스 접수 제한(gate)의 동작도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-016) · 소스: [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [engine.py:1438](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1438-L1477) · [hicache_storage.py:484](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/hicache_storage.py#L484-L541)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 — LoRA 적재·trace 설정의 관리 권한



| 코드에서 확인한 차이 | v0.5.21의 POST /load_lora_adapter_from_tensors와 GET·POST /set_trace_level에는 기준판의 ADMIN_OPTIONAL 지정이 없다. 기본 NORMAL 인증으로 처리된다. |
| --- | --- |
| 수행 방법 | 일반 API key와 관리 key를 분리한 구성에서 두 경로를 각각 호출한다. v0.5.21은 앞단의 관리 경로 허용 목록과 직통 차단을 확인한다. 무해한 LoRA·trace 설정을 쓰고 시험 뒤 이전 상태로 복원한다. |
| 확인할 결과·남길 자료 | 경로별 실제 auth level·허용 작업과 변경 결과, 직통 거부·복원. API key가 있다는 사실만으로 관리 권한 분리를 판정하지 않는다. |



확인할 체크리스트: [CHK-LIF-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006)



### v0.5.21 — 분리형 배포의 중단·변경·취소



| 코드에서 확인한 차이 | 기준판의 PD decode 대기 요청 중 기존 KV를 가진 요청을 retract 대상으로 옮기는 처리가 v0.5.21에 없다. prefill overlap의 전송 경계와 abort의 KV·host backup 회수 조건도 다르다. |
| --- | --- |
| 수행 방법 | PD에서 전송 완료 후 실행 대기 중인 요청을 포함해 pause·모델 변경·resume·abort를 시험한다. 요청별 weights·KV 세대와 전송·반환을 기록한다. 해당 흐름을 확인하지 못하면 중단 후 그룹 전체 교체 절차를 적용한다. |
| 확인할 결과·남길 자료 | prefill·decode 양쪽의 요청·모델 세대, 대기 KV·backup 반환과 후속 정상 요청. 단일 프로세스의 pause 응답으로 분산 전환을 완료하지 않는다. |



확인할 체크리스트: [CHK-LIF-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005) · [CHK-LIF-006](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-006) · [CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011) · [CHK-LIF-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-016)



### v0.5.23 — GPU 입력 갱신과 큰 통신 작업



| 코드에서 확인한 차이 | decode graph에는 미리 채운 입력의 tensor 동일성 확인과 복사 경로가 추가된다. deterministic all-reduce의 큰 입력은 등록 slot을 계속 추가하는 대신 기존 buffer 크기로 나누어 처리한다. |
| --- | --- |
| 수행 방법 | 선정 graph·speculative 모드에서 입력 갱신·유효 길이·출력 소비를 관측한다. deterministic custom AR의 큰 입력을 반복하고 chunk별 범위·rank 등록 수·종료 후 재기동을 확인한다. |
| 확인할 결과·남길 자료 | 실제 backend·dtype·shape·복사·event·등록 수·GPU 완료·정상 결과. 외부 sglang-kernel의 설치 바이너리와 별도 소스 대응도 확보해야 한다. |



확인할 체크리스트: [CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011)



### v0.5.23 — 분산 캐시 파일의 구분·회수



| 코드에서 확인한 차이 | HiCacheFile은 TP별 Mamba 상태와 공유 MLA KV의 파일 suffix·삭제 소유 범위를 나누고 DCP shard·page 크기를 키에 추가한다. raw payload에는 dtype·layout을 담지 않는 경로도 남는다. |
| --- | --- |
| 수행 방법 | 선정 모델의 TP·PP·CP·DCP·Mamba와 실제 생성 파일 이름을 확인한다. 구성 변경 전후 캐시를 분리해 읽기·회수·복원을 시험하고 layout·dtype 호환 증거 없이 이전 파일을 재사용하지 않는다. |
| 확인할 결과·남길 자료 | 실제 파일·저장 경로·키·writer·삭제 대상, 복원 자료의 호환 조건과 새 생성 결과. LRU 회수를 보존 기한에 따른 전체 사본 삭제로 대신하지 않는다. |



확인할 체크리스트: [CHK-LIF-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-016)



### v0.5.23 — 서비스 상태와 요청 접수 준비



| 코드에서 확인한 차이 | /ping은 이전판의 고정 200에서 is_healthy 기반 200/503으로 바뀐다. 일시정지 중에도 healthy이면 /ping은 200이고 /ready는 접수 준비 여부를 별도로 표시한다. |
| --- | --- |
| 수행 방법 | 기동 중·정상·일시정지·종료·실패에서 /ping과 /ready를 대조한다. 운영 접수 gate는 준비 상태와 실제 정상 요청·필수 rank를 함께 사용한다. |
| 확인할 결과·남길 자료 | 상태별 응답, 필수 worker·모델 준비와 canary, 접수·종료 기록. /ping 성공만으로 접수를 재개하지 않는다. |



확인할 체크리스트: [CHK-LIF-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005) · [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007) · [CHK-LIF-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009)



### v0.5.23 — 여러 HTTP worker의 준비·종료



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



확인할 체크리스트: [CHK-LIF-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-005) · [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007) · [CHK-LIF-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009) · [CHK-LIF-011](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-011)



### v0.5.23 — 캐시 지연·실패 시험과 설정 회수



| 코드에서 확인한 차이 | HiCache backend에 시험용 지연·실패 주입 wrapper가 추가된다. SGLANG_TEST_HICACHE_BACKEND_RANDOM_DELAY·SGLANG_TEST_HICACHE_BACKEND_RANDOM_FAILURE가 설정된 경우에만 적용된다. |
| --- | --- |
| 수행 방법 | 격리 시험에서 필요할 때만 두 시험용 환경값을 사용한다. 실패 시 준비·복원 결과가 보류되는지 확인한 뒤 환경값을 제거하고 프로세스를 다시 기동해 정상 구성을 확인한다. |
| 확인할 결과·남길 자료 | 시험 설정·주입 로그·실패 전달·재기동 뒤 환경값 부재와 정상 요청. 확률값은 운영 권장값으로 제공하지 않는다. |



확인할 체크리스트: [CHK-LIF-007](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-007) · [CHK-LIF-009](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-009) · [CHK-LIF-016](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-LIF-016)

