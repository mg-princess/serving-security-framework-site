# CHK-REQ-019 — SGLang

[공통 시험 명세](../../checks/CHK-REQ-019.md) · [기준판 상세 구현](../baseline/CHK-REQ-019.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/pyproject.toml) · [python/sglang/srt/layers/attention/flashinfer_backend.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/layers/attention/flashinfer_backend.py)



저장소의 caller·선정 native 경로 비교. 설치된 외부 native 패키지의 전문 검토·바이너리 대응과 GPU 계측은 수행하지 않았다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 2건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | decode graph에는 미리 채운 입력의 tensor 동일성 확인과 복사 경로가 추가된다. deterministic all-reduce의 큰 입력은 등록 slot을 계속 추가하는 대신 기존 buffer 크기로 나누어 처리한다. |
| --- | --- |
| 수행 방법 | 선정 graph·speculative 모드에서 입력 갱신·유효 길이·출력 소비를 관측한다. deterministic custom AR의 큰 입력을 반복하고 chunk별 범위·rank 등록 수·종료 후 재기동을 확인한다. |
| 확인할 결과·남길 자료 | 실제 backend·dtype·shape·복사·event·등록 수·GPU 완료·정상 결과. 외부 sglang-kernel의 설치 바이너리와 별도 소스 대응도 확보해야 한다. |



| 코드에서 확인한 차이 | v0.5.21은 Python>=3.10·torch2.13.0·sglang-kernel0.4.7을 선언하고 기준판은 Python>=3.11·torch2.14.1·kernel0.4.9를 선언한다. v0.5.23은 kernel0.4.10·FlashInfer0.7.2 등 선택 의존성을 바꾼다. |
| --- | --- |
| 수행 방법 | 실제 설치한 Python·torch·sglang-kernel·FlashInfer·decoder와 이미지 digest를 기록한다. Python 소스 비교와 설치 native kernel의 검토·실행을 구분하고 각 구성의 공식 공지 적용 여부를 평가한다. |
| 확인할 결과·남길 자료 | 설치 패키지·native binary·CUDA·driver 대응, 공지 평가·조치·정상 요청·선정 kernel 시험. |



### 고정 소스와 확인 범위



[python/pyproject.toml](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/pyproject.toml) · [python/sglang/srt/distributed/device_communicators/custom_all_reduce.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/distributed/device_communicators/custom_all_reduce.py) · [python/sglang/srt/layers/attention/flashinfer_backend.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/layers/attention/flashinfer_backend.py) · [python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py)



저장소의 caller·선정 native 경로 비교. 설치된 외부 native 패키지의 전문 검토·바이너리 대응과 GPU 계측은 수행하지 않았다.



