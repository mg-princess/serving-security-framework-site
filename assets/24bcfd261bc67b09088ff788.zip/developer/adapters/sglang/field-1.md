

### SGLang · 1. 인증·접근 통제

 

<a id="f-sglang-field-1"></a>
 
<a id="f-sglang-CHK-REQ-004"></a>

 

##### CHK-REQ-004 · 최종 사용자 신원

 

**확인할 내용** SGLang의 공용 키와 Gateway가 검증한 최종 사용자 신원을 구분한다.

 

**남길 증거** 외부에서 받은 신원 header가 제거·재생성되는 과정과 최종 인가에 사용한 신원을 기록한다. 임의로 넣은 사용자 값과 검증된 신원을 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-004) · 소스: [auth.py:38](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/auth.py#L38-L213) · [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135)

 

<a id="f-sglang-CHK-REQ-001"></a>

 

##### CHK-REQ-001 · API 인증 경로

 

**확인할 내용** Gateway를 거치는 경로와 엔진에 직접 접근하는 경로를 함께 확인한다. SGLang 인증 middleware가 실제로 설치되어 적용되는 위치와 API 노출 범위도 살핀다.

 

**남길 증거** 외부 진입점(ingress)과 엔진 직통 경로, 키 정책을 기록한다. 허용·비허용 요청을 각각 보내 실제 처리 함수(handler)의 수행 여부를 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001) · 소스: [auth.py:38](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/auth.py#L38-L213) · [http_server.py:2670](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2670-L2685)

 

<a id="f-sglang-CHK-REQ-002"></a>

 

##### CHK-REQ-002 · 경로 변환과 인증

 

**확인할 내용** 요청 경로(Request path)와 root_path가 변환되고 처리 경로가 선택되는 과정(route match)을 확인한다. 최종 경로에 알맞은 권한 등급이 적용되는지도 대조한다.

 

**남길 증거** 프록시 재작성 전후의 경로와 최종 route, 정규화 결과, 인증 결과를 기록한다. 허용되지 않은 처리 함수(handler)가 수행되지 않는지 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002) · 소스: [auth.py:38](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/auth.py#L38-L213) · [http_server.py:2726](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2726-L2747)

 

<a id="f-sglang-CHK-REQ-003"></a>

 

##### CHK-REQ-003 · 관리 API 권한

 

**확인할 내용** ADMIN_OPTIONAL 설정과 일반·관리 키의 조합에 따른 동작을 역할별 허용 정책과 대조한다. health와 metrics 경로의 인증 예외도 함께 확인한다.

 

**남길 증거** route별 키·역할·노출 범위를 정리한다. 일반 사용자의 관리 작업은 거부되고 관리자의 정상 작업은 처리되는지 시험하며, API 상태코드와 실제 효과를 함께 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-003) · 소스: [auth.py:38](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/auth.py#L38-L213) · [http_server.py:1009](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L1009-L1219) · [http_server.py:1265](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L1265-L1649)

 

<a id="f-sglang-CHK-OBS-007"></a>
 **조건부 하위시험 · 진단 자료 재실행 권한 (`CHK-OBS-007`)**

 

**확인할 내용** 관리·진단 작업의 권한을 점검할 때, 실제로 배치된 debug dump loader 등 자료를 사용하는 프로그램(consumer)의 읽기 권한과 실행 권한을 구분한다. 자료를 읽을 수 있는 계정이 별도 허가 없이 재실행할 수 있는지 확인한다.

 

**남길 증거** 도구의 배치·접근 경로와 실행 계정을 남긴다. 읽기 전용 계정과 실행을 허용받은 계정으로 같은 정상 자료를 재실행하고, 허용·거부 결과와 실제 작업 시작 여부를 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-007) · 소스: [dump_loader.py:32](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/debug_utils/dump_loader.py#L32-L85)

 

<a id="f-sglang-CHK-REQ-005"></a>

 

##### CHK-REQ-005 · 모델·adapter 접근 권한

 

**확인할 내용** base model:adapter로 선택한 대상과 native API 또는 관리 API로 변경한 대상을 확인한다. 각 경로에서 실제로 선택되는 모델을 추적한다.

 

**남길 증거** 호출자별 허용표와 최종 모델·adapter를 대조한다. 사용 종료나 alias 변경 뒤에도 실제 선택 대상과 거부 결과를 확인해 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-005) · 소스: [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135) · [http_server.py:1265](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L1265-L1649) · [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600)

 

<a id="f-sglang-CHK-REQ-006"></a>

 

##### CHK-REQ-006 · 저장된 응답의 접근 권한

 

**확인할 내용** enable_response_store 설정과 response ID를 사용하는 조회·취소 동작을 확인한다. session API의 점검 결과는 이 항목과 구분한다.

 

**남길 증거** 사용자 A와 B가 저장한 객체의 소유자(owner)와 공유·이어쓰기·취소 정책을 기록한다. Gateway 경유와 직통 요청이 실제로 어느 객체에 영향을 주는지 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-006) · 소스: [serving_responses.py:204](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_responses.py#L204-L213) · [serving_responses.py:1581](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_responses.py#L1581-L1628) · [serving.py:26](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/serving.py#L26-L31)

 

<a id="f-sglang-CHK-SUP-002"></a>

 

##### CHK-SUP-002 · 배포·승격 권한

 

**확인할 내용** CI/CD와 수동 배포 경로에서 누가 배포하거나 승격할 수 있는지 확인한다. 각 경로에서 권한을 실제로 검사하는 위치도 찾는다.

 

**남길 증거** 배포 주체별로 허용된 모델과 환경을 정리한다. 허용 범위를 벗어난 배포가 거부되는지 시험하고, 실제 실행된 배포를 식별할 수 있는 기록을 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-002) · 소스: [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

<a id="f-sglang-CHK-SUP-001"></a>

 

##### CHK-SUP-001 · 제출·승인 권한 분리

 

**확인할 내용** 승인 기록과 역할 분리는 조직의 승인 저장소와 배포 절차에서 확인한다. checksum 함수의 무결성 검사와 승인 권한의 분리 여부를 각각 확인한다.

 

**남길 증거** 실제 제출 계정과 승인 계정, 승인 저장소의 ACL을 기록한다. 승인 변경이 거부되는 경우와 정상적으로 승인되는 경우를 시험하고, 각각의 독립된 이력을 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-001) · 소스: [model_file_verifier.py:74](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/model_file_verifier.py#L74-L98) · [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600)

 

<a id="f-sglang-CHK-PLT-001"></a>

 

##### CHK-PLT-001 · 엔진 프로세스의 최소 권한

 

**확인할 내용** 엔진과 하위 프로세스(subprocess)의 실제 UID, mount, 장치, capability를 필요한 권한 목록과 대조한다.

 

**남길 증거** 필요 권한표와 실행 중인 process·namespace 정보를 기록한다. 무해한 방식으로 허용되지 않은 파일·장치 접근이 거부되는지 시험하고 실제 사용하는 분산 실행 동작과 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-001) · 소스: [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

<a id="f-sglang-CHK-PLT-002"></a>

 

##### CHK-PLT-002 · IPC 채널의 접근 권한

 

**확인할 내용** scheduler ZMQ와 선택적으로 사용하는 weight daemon socket에 누가 접근할 수 있는지 채널별로 확인한다.

 

**남길 증거** 채널 주소와 상위 경로, owner와 mode, namespace를 기록한다. 허용되지 않은 프로세스가 같은 UID 또는 다른 UID로 연결을 시도한 결과와 실제 메시지 처리 여부를 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-002) · 소스: [ipc_channels.py:25](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/ipc_channels.py#L25-L88) · [network.py:400](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/network.py#L400-L436) · [ipc_loader.py:451](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L451-L500)

 

<a id="f-sglang-CHK-PLT-006"></a>

 

##### CHK-PLT-006 · 공유 권한과 침해 영향 범위

 

**확인할 내용** 같은 호스트의 ZMQ·TP 통신과 자료 해석기(reader)가 사용하는 UID와 권한을 확인한다. 어떤 권한을 함께 사용하는지와 그 경계를 기록한다.

 

**남길 증거** 채널별 자료 직렬화 방식(serialization)과 허용한 통신 상대(peer)를 남긴다. 공유하는 UID로 접근할 수 있는 자원과 실행 가능한 명령(command)의 범위도 기록한다. 허용되지 않은 상대의 접근 차단 결과와 남은 위험도 함께 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-006) · 소스: [ipc_channels.py:25](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/ipc_channels.py#L25-L88) · [network.py:400](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/network.py#L400-L436) · [common.py:3417](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/common.py#L3417-L3441)

 

<a id="f-sglang-CHK-PLT-003"></a>

 

##### CHK-PLT-003 · 모델 취득 계정의 접근 범위

 

**확인할 내용** Hugging Face(HF)에서 모델을 다운로드하거나 로컬 자료를 반입할 때 실제로 사용하는 계정과 자격을 확인한다. 그 자격으로 접근할 수 있는 저장소·파일의 범위를 허용 목록과 대조한다.

 

**남길 증거** 사용한 SDK와 공급자가 확인한 신원(provider identity), 최종 저장소·객체를 기록한다. 허용·비허용 접근의 감사 기록도 남긴다. 비밀값은 기록에서 제외한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-003) · 소스: [weight_utils.py:621](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L621-L714) · [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600)

 

<a id="f-sglang-CHK-PLT-004"></a>

 

##### CHK-PLT-004 · worker에 전달하는 자격

 

**확인할 내용** 하위 프로세스(subprocess)를 만들 때 worker에 전달되는 환경변수(env)·파일·마운트(mount)를 확인한다. 각 경로로 받은 자격이 worker의 작업에 필요한지, 실제로 어느 자원에 접근하는지 조사한다.

 

**남길 증거** 부모 프로세스에서 worker로 전달한 자격의 참조값과 수신자, 전달이 필요한 이유, 실제 접근 결과를 남긴다. secret 원문은 수집하지 않는다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-004) · 소스: [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

<a id="f-sglang-CHK-PLT-005"></a>

 

##### CHK-PLT-005 · 자격 만료·누락 시 대체 접근

 

**확인할 내용** 모델 취득에 사용하는 SDK에서 자격이 만료된 경우와 누락된 경우를 각각 확인한다. 캐시(cache)·익명 접근(anonymous)·다른 자격 공급자(provider)를 대신 선택하는지 조사하고, 그 선택을 승인한 대체 정책과 대조한다.

 

**남길 증거** 선택한 SDK의 판본과 각 만료·누락 조건에서 실제 사용한 자격·공급원, 허용한 대체 방식과 취득 결과를 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-005) · 소스: [weight_utils.py:621](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L621-L714) · [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600)

 

<a id="f-sglang-CHK-PLT-007"></a>

 

##### CHK-PLT-007 · 외부 송신 목적지와 작업 제한

 

**확인할 내용** 다운로드·실행·OTLP 전송에서 실제로 접속하는 목적지를 확인한다. 각 송신이 운영 정책에서 허용한 목적지와 작업에 해당하는지 대조한다.

 

**남길 증거** 프로세스별 DNS 조회·연결 기록과 허용한 목적지·작업 목록을 남긴다. 무해한 시험 송신으로 금지된 통신의 거부를 확인하고, 필요한 모델 취득과 추적 기능이 정상 동작한 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-007) · 소스: [weight_utils.py:621](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L621-L714) · [trace.py:277](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/observability/trace.py#L277-L290)

 

<a id="f-sglang-CHK-PLT-010"></a>

 

##### CHK-PLT-010 · 자격 철회 후 신규 접근 차단

 

**확인할 내용** 고정 API key와 외부 발급자(issuer)·Gateway에서 자격 철회를 처리하는 방식을 확인한다. 새 접근을 언제부터 거부해야 하는지 정한 기준과 실제 동작을 대조한다.

 

**남길 증거** 철회 담당 주체와 시각, 적용이 전파되어야 하는 기한, key 갱신·재시작이 필요한 조건을 남긴다. 그 기한 뒤 신규 요청을 거부한 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-010) · 소스: [auth.py:38](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/auth.py#L38-L213) · [http_server.py:2670](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2670-L2685)

 

<a id="f-sglang-CHK-PLT-011"></a>

 

##### CHK-PLT-011 · 철회 전 연결·접근권의 처리

 

**확인할 내용** 이미 열린 스트림(stream), native session, IPC handle을 자격 철회 후 어떻게 처리하는지 각각 확인한다. 유지하거나 종료할 대상을 정한 철회 정책에 따라 시험한다.

 

**남길 증거** 철회 전에 확보한 연결·객체·handle, 유지·종료 정책과 처리 기한을 남긴다. 정한 기한 뒤 각 대상에 실제로 접근할 수 있는지 시험한 결과도 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-011) · 소스: [tokenizer_manager.py:1950](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1950-L1978) · [session_controller.py:370](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/session/session_controller.py#L370-L455) · [ipc_loader.py:183](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/weight_cache/ipc_loader.py#L183-L228)

 

<a id="f-sglang-CHK-PLT-012"></a>

 

##### CHK-PLT-012 · 폐기한 자격 사본의 재사용 차단

 

**확인할 내용** 배포 환경과 worker, 파일·Secret에 남은 자격 사본을 확인한다. 교체하거나 폐기한 이전 key를 다시 사용할 수 있는지 조사한다.

 

**남길 증거** 자격 사본이 있는 위치와 수신자, 교체·폐기 기록을 남긴다. 기존 사본으로 신규 접근을 시도한 결과와 이미 열린 연결에서 접근을 계속할 수 있는지 확인한 결과를 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-PLT-012) · 소스: [auth.py:38](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/auth.py#L38-L213) · [engine.py:1121](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1121-L1368)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 — LoRA 적재·trace 설정의 관리 권한



| 코드에서 확인한 차이 | v0.5.21의 POST /load_lora_adapter_from_tensors와 GET·POST /set_trace_level에는 기준판의 ADMIN_OPTIONAL 지정이 없다. 기본 NORMAL 인증으로 처리된다. |
| --- | --- |
| 수행 방법 | 일반 API key와 관리 key를 분리한 구성에서 두 경로를 각각 호출한다. v0.5.21은 앞단의 관리 경로 허용 목록과 직통 차단을 확인한다. 무해한 LoRA·trace 설정을 쓰고 시험 뒤 이전 상태로 복원한다. |
| 확인할 결과·남길 자료 | 경로별 실제 auth level·허용 작업과 변경 결과, 직통 거부·복원. API key가 있다는 사실만으로 관리 권한 분리를 판정하지 않는다. |



확인할 체크리스트: [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001) · [CHK-REQ-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-003)



### v0.5.21 · v0.5.23 — 서버 종류별 인증 적용 범위



| 코드에서 확인한 차이 | SGLang의 Python HTTP key middleware와 Rust HTTP·native gRPC 서비스 등록은 다른 경로다. 검토한 Rust HTTP·native gRPC 등록에는 같은 key·관리 key 검사를 설치하지 않는다. |
| --- | --- |
| 수행 방법 | 실제 frontend와 추가 gRPC·sidecar 포트를 목록화한다. Rust HTTP·native gRPC를 쓰면 앞단 인증·업무 권한과 직통 차단을 확인하고, 무자격 관리 작업의 실제 거부를 시험한다. 별도 smg-grpc-servicer 모드는 설치 패키지의 인증·TLS도 따로 확인한다. |
| 확인할 결과·남길 자료 | 서버 종류·listener·등록 서비스·상대 인증·TLS·직통 거부·요청 크기 제한. Python HTTP의 정상 key 시험을 다른 frontend 결과로 전용하지 않는다. |



확인할 체크리스트: [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001) · [CHK-REQ-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-002) · [CHK-REQ-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-003)



### v0.5.23 — 여러 HTTP worker의 준비·종료



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



확인할 체크리스트: [CHK-REQ-001](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-001)



### v0.5.23 — 콜론이 들어간 모델·LoRA 이름



| 코드에서 확인한 차이 | model 문자열이 served_model_name과 정확히 같거나 그 이름 뒤에 :LoRA가 붙었는지 먼저 확인한다. 이전판의 첫 콜론 분리와 다르다. |
| --- | --- |
| 수행 방법 | 콜론이 포함된 실제 served_model_name과 허용·비허용 LoRA 이름을 따로 시험한다. 요청 문자열과 최종 선택 모델·LoRA를 함께 기록한다. |
| 확인할 결과·남길 자료 | 실제 model 선택·거부 결과, 활성·해제 LoRA 목록. 모델 선택 성공과 호출자 권한 검사는 별도로 확인한다. |



확인할 체크리스트: [CHK-REQ-005](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-005)

