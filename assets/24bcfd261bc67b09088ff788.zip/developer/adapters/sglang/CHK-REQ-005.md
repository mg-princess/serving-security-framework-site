# CHK-REQ-005 — SGLang

[공통 시험 명세](../../checks/CHK-REQ-005.md) · [기준판 상세 구현](../baseline/CHK-REQ-005.md)

기존 소스 대조 자료에서 옮긴 판본별 차이다. 실제 실행 성공과 보안 충족 여부는 해당 환경의 증거로 판단해야 한다.

## v0.5.21



### SGLang v0.5.21 · 공통 절차 적용



비교 기준: v0.5.22



이 항목은 위의 공통 시험 순서와 판정 기준을 사용해야 한다. 적용 기능과 실제 집행 위치를 확인하고, 남길 자료를 같은 요청·실행에 맞춰 수집해야 한다.



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/entrypoints/openai/serving_base.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/entrypoints/openai/serving_base.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/e00930c5489053f26d86b179cee0d087f846acbb/python/sglang/srt/model_loader/loader.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



## v0.5.23



### SGLang v0.5.23 · 시험 보완 1건



비교 기준: v0.5.22



| 코드에서 확인한 차이 | model 문자열이 served_model_name과 정확히 같거나 그 이름 뒤에 :LoRA가 붙었는지 먼저 확인한다. 이전판의 첫 콜론 분리와 다르다. |
| --- | --- |
| 수행 방법 | 콜론이 포함된 실제 served_model_name과 허용·비허용 LoRA 이름을 따로 시험한다. 요청 문자열과 최종 선택 모델·LoRA를 함께 기록한다. |
| 확인할 결과·남길 자료 | 실제 model 선택·거부 결과, 활성·해제 LoRA 목록. 모델 선택 성공과 호출자 권한 검사는 별도로 확인한다. |



### 고정 소스와 확인 범위



[python/sglang/srt/entrypoints/http_server.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/http_server.py) · [python/sglang/srt/entrypoints/openai/serving_base.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/entrypoints/openai/serving_base.py) · [python/sglang/srt/model_loader/loader.py](https://github.com/sgl-project/sglang/blob/297e54fd105e974cdf401e5b4d20253a22c16f90/python/sglang/srt/model_loader/loader.py)



설치 이미지·의존성·활성 기능과 실제 실행 결과는 해당 환경의 증거로 확인해야 한다.



