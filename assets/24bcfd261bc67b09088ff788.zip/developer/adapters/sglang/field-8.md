

### SGLang · 8. 감사 기록·관측 신뢰성

 

<a id="f-sglang-field-8"></a>
 
<a id="f-sglang-CHK-OBS-001"></a>

 

##### CHK-OBS-001 · 필수 사건과 감사 기록의 연결

 

**확인할 내용** 엔진의 요청 로그와 외부 승인·배포·관리 이력을 같은 실행 식별정보로 연결한다. 실제로 발생한 필수 사건과 확보한 기록을 대조한다.

 

**남길 증거** 필수 사건의 기록 정책, 행위자·대상·실행 ID와 실제 사건 기록을 남긴다. 사용한 대상이 승인 대상과 일치하는지 확인할 근거도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-001) · 소스: [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173) · [loader.py:478](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/loader.py#L478-L600) · [http_server.py:1009](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L1009-L1219)

 

<a id="f-sglang-CHK-OBS-009"></a>

 

##### CHK-OBS-009 · 사용자 입력에 의한 로그 위조

 

**확인할 내용** native·OpenAI API의 요청 로그에서 사용자 입력이 기록되는 위치와 행위자·대상·상태를 정하는 신뢰 필드를 확인한다. 입력을 바꿨을 때 별개의 사건을 추가한 것처럼 기록되거나 기록의 행위자·대상·상태가 바뀌는지 대조한다.

 

**남길 증거** 로그 형식과 실제 저장 위치(sink)의 해석기(parser)를 남긴다. 입력에 개행을 넣거나 ID·header를 바꾼 시험 결과를 저장된 기록의 행위자·대상·상태와 대조한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-009) · 소스: [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173) · [serving_base.py:40](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_base.py#L40-L135)

 

<a id="f-sglang-CHK-OBS-010"></a>

 

##### CHK-OBS-010 · 기록 변경·삭제의 제한과 탐지

 

**확인할 내용** 최종 기록 저장소의 쓰기(writer)·읽기(reader)·관리(admin) 권한을 계정별로 확인한다. 허용되지 않은 변경·삭제를 제한하는 동작과 그 행위를 독립적으로 탐지하는 동작을 각각 대조한다.

 

**남길 증거** 실제 접근 권한(ACL)과 허용되지 않은 변경·삭제 시도의 거부 결과를 남긴다. 필수 사건의 탐지 결과·기한과 별도 위치에 보존한 증거도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-010) · 소스: [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173)

 

<a id="f-sglang-CHK-OBS-002"></a>

 

##### CHK-OBS-002 · 실제 실행 상태와 기록의 일치

 

**확인할 내용** 준비·warmup·watchdog·shutdown 단계에서 기록한 상태를 실제 실행 상태와 대조한다. profiler를 사용하는 경우에는 해당 기능의 상태도 함께 확인한다.

 

**남길 증거** 상태 기록과 별도로 관측한 rank별 준비·실패, 작업 종료와 수집 종료의 결과·시각을 남긴다. 같은 실행과 사건을 가리키는 기록끼리 비교할 수 있게 연결한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-002) · 소스: [engine.py:989](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L989-L1025) · [http_server.py:2412](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/http_server.py#L2412-L2501) · [watchdog.py:103](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/watchdog.py#L103-L223) · [engine.py:1438](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/engine.py#L1438-L1477) · [profiler_manager.py:318](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/scheduler_components/profiler_manager.py#L318-L395)

 

<a id="f-sglang-CHK-OBS-011"></a>

 

##### CHK-OBS-011 · 운영 기록 수집 장애의 탐지·알림

 

**확인할 내용** 엔진에서 수집기(collector)·저장소(sink)로 이어지는 필수 운영 기록의 수집 상태를 확인한다. 수집 중단·누락·시각 오류를 발생시켜 정한 기한에 장애가 식별되고 담당자에게 알려지는지, 복구 후 수집이 재개되는지 확인한다. 증거 부족에 따른 시험 판정은 프레임워크 6장 「검증과 결과 평가」의 규칙에 따라 별도로 처리한다.

 

**남길 증거** 주입한 장애·누락·시각 오류와 식별·경보 시각, 담당자에게 전달된 알림을 남긴다. 복구 시각과 수집 재개 기록, 확보한 대체 증거도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-011) · 소스: [request_logger.py:89](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/request_logger.py#L89-L173) · [trace.py:277](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/observability/trace.py#L277-L290)

 

### SGLang · 다른 버전에서 적용할 때



### v0.5.21 — LoRA 적재·trace 설정의 관리 권한



| 코드에서 확인한 차이 | v0.5.21의 POST /load_lora_adapter_from_tensors와 GET·POST /set_trace_level에는 기준판의 ADMIN_OPTIONAL 지정이 없다. 기본 NORMAL 인증으로 처리된다. |
| --- | --- |
| 수행 방법 | 일반 API key와 관리 key를 분리한 구성에서 두 경로를 각각 호출한다. v0.5.21은 앞단의 관리 경로 허용 목록과 직통 차단을 확인한다. 무해한 LoRA·trace 설정을 쓰고 시험 뒤 이전 상태로 복원한다. |
| 확인할 결과·남길 자료 | 경로별 실제 auth level·허용 작업과 변경 결과, 직통 거부·복원. API key가 있다는 사실만으로 관리 권한 분리를 판정하지 않는다. |



확인할 체크리스트: [CHK-OBS-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-003)



### v0.5.23 — 구형 모델 파일을 읽는 방식



| 코드에서 확인한 차이 | _load_pt_file에서 구형 tar 오류 뒤 weights_only=False로 다시 읽던 처리가 제거됐다. v0.5.21·v0.5.22에는 해당 fallback이 있다. |
| --- | --- |
| 수행 방법 | 선택한 PT loader에 정상 자료·구형 tar·금지 객체를 나타내는 무해한 자료를 각각 제공한다. v0.5.23은 거부 위치를 확인하고 실패한 자료를 자동으로 제한 없는 reader로 다시 읽지 않는다. |
| 확인할 결과·남길 자료 | 최종 reader·weights_only, 선택 파일, 거부·정상 결과와 부수 동작. 호환되지 않는 자료는 승인 절차에 따라 변환·재검증한다. |



확인할 체크리스트: [CHK-OBS-008](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-008)



### v0.5.23 — 서비스 상태와 요청 접수 준비



| 코드에서 확인한 차이 | /ping은 이전판의 고정 200에서 is_healthy 기반 200/503으로 바뀐다. 일시정지 중에도 healthy이면 /ping은 200이고 /ready는 접수 준비 여부를 별도로 표시한다. |
| --- | --- |
| 수행 방법 | 기동 중·정상·일시정지·종료·실패에서 /ping과 /ready를 대조한다. 운영 접수 gate는 준비 상태와 실제 정상 요청·필수 rank를 함께 사용한다. |
| 확인할 결과·남길 자료 | 상태별 응답, 필수 worker·모델 준비와 canary, 접수·종료 기록. /ping 성공만으로 접수를 재개하지 않는다. |



확인할 체크리스트: [CHK-OBS-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-002)



### v0.5.23 — 여러 HTTP worker의 준비·종료



| 코드에서 확인한 차이 | 여러 HTTP worker 기동에 enable_http_worker_reuseport 선택과 worker별 warmup·GC 후속 처리가 추가된다. Granian HTTP/1 header timeout도 SGLANG_TIMEOUT_KEEP_ALIVE 설정을 별도 변환한다. multi-tokenizer 기동은 기존과 같이 api_key 지원 제한을 검사한다. |
| --- | --- |
| 수행 방법 | single·multi-tokenizer, Uvicorn·Granian과 reuseport 선택을 기록한다. 모든 HTTP worker의 준비·실패·종료와 접수 gate를 확인하고 인증은 해당 모드에서 지원하는 앞단 통제로 집행한다. |
| 확인할 결과·남길 자료 | worker PID·listener·준비·warmup·실패 전달·종료와 정상 요청, 유효 header timeout. 하나의 port 응답으로 모든 worker 준비를 판정하지 않는다. |



확인할 체크리스트: [CHK-OBS-002](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-002)



### v0.5.23 — 중첩된 로그의 비밀값 가림



| 코드에서 확인한 차이 | watermark 비밀값 마스킹이 enable_watermark 설정과 연결되고, 긴 list·tuple 안의 값도 재귀적으로 처리한다. |
| --- | --- |
| 수행 방법 | watermark 활성·비활성 구성과 중첩 list·dict의 무해 표식으로 실제 요청 로그를 확인한다. 단순 문자열·길이 제한만으로 비밀값 제거를 판정하지 않는다. |
| 확인할 결과·남길 자료 | 로그 설정, 중첩 표식의 저장 여부, 출력 파일·수집기·보관본. 시험 표식과 추가 로그 설정은 회수한다. |



확인할 체크리스트: [CHK-OBS-003](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-003)

