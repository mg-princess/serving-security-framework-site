

### SGLang · 3. 입력 처리·코드 실행 안전성

 

<a id="f-sglang-field-3"></a>
 
<a id="f-sglang-CHK-REQ-007"></a>

 

##### CHK-REQ-007 · 템플릿 적용 후 입력 제한

 

**확인할 내용** 대화 템플릿 kwargs가 템플릿 처리(render)에 어떻게 적용되는지 확인한다. 변환이 끝난 최종 입력에도 제한이 적용되는지 살핀다.

 

**남길 증거** render 전후의 입력과 최종 token 수·길이를 기록한다. 필수 정책이 실제로 집행되는지 시험하고 정상 템플릿 결과와 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-007) · 소스: [serving_chat.py:1038](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L1038-L1048) · [serving_chat.py:1705](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L1705-L1759) · [tokenizer_manager.py:1308](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1308-L1375)

 

<a id="f-sglang-CHK-REQ-008"></a>

 

##### CHK-REQ-008 · input_ids 우회 입력

 

**확인할 내용** native input_ids와 OpenAI chat input_ids가 템플릿 처리를 우회하는 경로를 확인한다.

 

**남길 증거** 외부 재사용 token을 금지하는 정책에 따라 해당 입력이 거부되거나 제거되고 모델에서 사용되지 않는지 확인한다. 정책을 변경한 경우에는 우회 입력의 유효성과 변경된 정책의 검사 결과를 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-008) · 소스: [io_struct.py:180](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/io_struct.py#L180-L300) · [serving_chat.py:1458](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L1458-L1476) · [tokenizer_manager.py:1535](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1535-L1625)

 

<a id="f-sglang-CHK-REQ-009"></a>

 

##### CHK-REQ-009 · 최종 token의 유효 범위

 

**확인할 내용** context 한도, 입력 절단과 total-token 검사 결과를 모델에 실제 전달한 입력과 대조한다. sampling용 vocab 검사와 전체 input_ids의 검증 범위는 구분해 확인한다.

 

**남길 증거** 선정한 모델의 vocab과 길이, 변환 후 token이 실제로 사용되거나 거부된 결과를 기록한다. backend별로 정상 처리되는 범위도 함께 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-009) · 소스: [tokenizer_manager.py:1308](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1308-L1375) · [tokenizer_manager.py:1535](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1535-L1625) · [sampling_params.py:229](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/sampling/sampling_params.py#L229-L305)

 

<a id="f-sglang-CHK-REQ-010"></a>

 

##### CHK-REQ-010 · 생성 옵션의 값·조합 검사

 

**확인할 내용** SamplingParams.verify가 검사하는 값과 grammar 조합을 확인하고, 실제 runner가 사용하는 값과 대조한다.

 

**남길 증거** 수치와 개수, 조합의 경계를 시험하고 정상 생성 결과와 비교한다. 오류 이후 후속 요청의 처리 결과도 남긴다. custom processor를 선택한 경우에는 별도로 확인한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-010) · 소스: [sampling_params.py:229](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/sampling/sampling_params.py#L229-L305) · [tokenizer_manager.py:1535](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1535-L1625)

 

<a id="f-sglang-CHK-SUP-008"></a>

 

##### CHK-SUP-008 · 요청별 코드 판본 선택

 

**확인할 내용** 실제 설치판에서 요청별 코드 revision 선택 기능과 코드 소비 경로를 확인한다. 해당 경로가 있으면 승인된 코드의 선택·소비·차단 증거를 수집한다. custom callable은 SUP-012에서 확인한다.

 

**남길 증거** 활성 API schema와 확장 기능 전체를 조사해 코드 판본을 선택하는 값이 어디로 전달되는지 기록한다. 해당 기능이 없음을 확인하기 전까지는 비적용 여부의 확정을 보류한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-008) · 소스: [io_struct.py:180](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/io_struct.py#L180-L300) · [serving_chat.py:1038](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L1038-L1048) · [custom_logit_processor.py:15](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/sampling/custom_logit_processor.py#L15-L48)

 

<a id="f-sglang-CHK-SUP-009"></a>

 

##### CHK-SUP-009 · 추가 코드 실행 설정

 

**확인할 내용** model config의 trust_remote_code 값이 어떻게 전달되는지 확인하고, 선언된 기본값과 실제 적용값을 대조한다.

 

**남길 증거** 유효 설정과 선정한 모델이 실제로 사용하는 추가 코드를 기록한다. 금지된 코드가 실행되지 않는지 시험하고, 승인된 모델이 정상적으로 로딩되는 경우와 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-009) · 소스: [model_config.py:492](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/configs/model_config.py#L492-L600) · [model.py:90](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/model.py#L90-L110)

 

<a id="f-sglang-CHK-SUP-010"></a>

 

##### CHK-SUP-010 · 플러그인 발견·허용 범위

 

**확인할 내용** 설치된 플러그인 그룹마다 entry point를 발견하고 필터링한 뒤 hook을 적용하는 과정을 확인한다.

 

**남길 증거** 설치된 entry point와 이를 제공하는 distribution 패키지를 확인하고, 실제 검색·로드 결과를 허용 목록과 대조한다. 필터에서 제외되는 경우도 시험하고 정상 로드 결과와 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-010) · 소스: [**init**.py:35](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/plugins/__init__.py#L35-L141)

 

<a id="f-sglang-CHK-SUP-011"></a>

 

##### CHK-SUP-011 · HiCache backend 로딩

 

**확인할 내용** HiCache의 동적 backend import 경로를 확인한다. 이 경로는 general plugin을 발견하는 경로와 구분해 살핀다.

 

**남길 증거** 선택한 backend와 module, class를 기록하고 실행 모드별로 실제 import 대상을 확인한다. 허용되지 않은 import가 거부되는 증거를 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-011) · 소스: [backend_factory.py:21](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/mem_cache/storage/backend_factory.py#L21-L165)

 

<a id="f-sglang-CHK-SUP-012"></a>

 

##### CHK-SUP-012 · 역직렬화·자료 읽기 경로

 

**확인할 내용** PT의 legacy tar 대체 처리(fallback), 선택한 callable, dump 해석기와 daemon의 자료 읽기 경로를 각각 조사한다.

 

**남길 증거** 선택한 reader와 설치된 torch·dill 판본, 실제 적용되는 gate를 기록한다. 무해한 비허용 객체를 넣어 실제 부수 동작이나 거부 결과를 확인하고, 정상 자료를 읽는 경우와 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-012) · 소스: [weight_utils.py:1398](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L1398-L1415) · [custom_logit_processor.py:15](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/sampling/custom_logit_processor.py#L15-L48) · [tokenizer_manager.py:1417](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/managers/tokenizer_manager.py#L1417-L1425) · [exec_.py:68](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/arg_groups/fields/exec_.py#L68-L71) · [common.py:3417](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/utils/common.py#L3417-L3441) · [dump_loader.py:32](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/debug_utils/dump_loader.py#L32-L85)

 

<a id="f-sglang-CHK-SUP-013"></a>

 

##### CHK-SUP-013 · 대화 템플릿 실행 제한

 

**확인할 내용** chat 템플릿에 실제로 사용하는 renderer와 transformers 판본을 확인한다. 이 조합에 적용되는 sandbox의 허용·제한 조건도 살핀다.

 

**남길 증거** 공급된 템플릿의 출처와 실제 renderer, 의존성을 기록한다. 금지된 동작이 거부되는지 시험하고 정상 render 결과와 비교한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-SUP-013) · 소스: [jinja_template_utils.py:73](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/parser/jinja_template_utils.py#L73-L80) · [serving_chat.py:1705](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/entrypoints/openai/serving_chat.py#L1705-L1759)

 

<a id="f-sglang-CHK-OBS-008"></a>

 

##### CHK-OBS-008 · 변조된 진단 자료와 해석 권한

 

**확인할 내용** 실제로 사용하는 프로그램(consumer)별로 dump reader가 자료를 역직렬화하는 방식과 실행 권한을 확인한다. 변조된 자료를 처리할 때 발생하는 파일·통신·코드 실행이 승인 범위를 지키는지도 점검한다.

 

**남길 증거** 무해하게 변조한 dump의 처리·거부 결과와 파일 접근·통신·코드 실행의 부수 동작을 남긴다. 격리된 실행 권한과 정상 자료의 처리 결과도 함께 기록한다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-OBS-008) · 소스: [dump_loader.py:32](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/debug_utils/dump_loader.py#L32-L85) · [weight_utils.py:1398](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/model_loader/weight_utils.py#L1398-L1415)

 

<a id="f-sglang-CHK-REQ-019"></a>

 

##### CHK-REQ-019 · GPU 연산의 입력 경계

 

**확인할 내용** 선택한 attention과 backend가 실제 설치된 kernel에서 dtype과 shape에 따라 어떤 경로를 실행하는지 확인한다.

 

**남길 증거** 실제 GPU, 선택한 backend와 kernel 판본을 기록한다. 경계 입력에 대한 메모리 계측, 초기화·오류 처리, 정상 연산 결과를 함께 남긴다.

 

[현재 점검 항목](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=CHK-REQ-019) · 소스: [flashinfer_backend.py:77](https://github.com/sgl-project/sglang/blob/baa9befa381511cd4d56f83980951e5a45fffc6d/python/sglang/srt/layers/attention/flashinfer_backend.py#L77-L106)

