# CHK-LIF-010 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-LIF-010.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 요청 취소·연결 종료 후 실제 작업을 기한 안에 멈추고 불필요한 상태·자원을 정리하는가? · CHK-LIF-010

<a id="CHK-LIF-010"></a>
 
<a id="641-취소연결-종료-후-실제-작업이-정한-기한-안에-중단되고-더-이상-사용하지-않는-상태자원이-정리되는가"></a>

지연 결과의 영향은 이전 시도의 출력·시도 세대·후속 요청과 실제 수신 기록을 연결해 확인한다. 같은 ID로 보낸 두 응답의 해시가 달라졌다면 자연 출력 변동과 구분할 근거를 함께 확보한다. 
<a id="source-10-04550"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 일반·스트리밍 요청의 대기·계산·출력 단계에서 취소·연결 종료·timeout 처리를 확인한다. |
| --- | --- |
| 권장 설정·조치 | 취소·연결 종료·timeout을 해당 내부 실행의 중단과 scheduler·worker 상태 정리까지 전달한다. stop 문자열로 응답을 끝냈는데 Core 실행이 남아 있으면 중단을 전달한다. 엔진 장애 시에는 오류 전달과 실행 그룹·잔존 자원 정리를 확인한다. 계산·전송·참조별 종료를 관측하고 기한을 넘긴 작업의 추가 정리 절차를 마련한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-resources) |
| 확인 방법 | 취소 응답과 내부 실행·GPU 작업·전송·참조·자원의 종료를 구분해 확인한다. 늦은 결과의 폐기와 다음 요청의 정상 처리도 대조하되 결과 귀속과 자원 회수는 각각 판정한다.<br>**정상 동작:** 정상 완료 요청은 실행·전송·참조를 정한 기한에 정리한다. |
| 판정 기준 | 충족<br>정한 기한 안에 작업이 중단되고 scheduler·worker 상태와 자원이 각 회수 조건에 맞게 정리된다. 내부 실행·자원의 회수 증거가 부족하면 해당 결과는 미확인으로 기록한다.<br>미충족<br>요구한 종료 기한 뒤에도 해당 작업·참조가 지속된다.<br>미확인<br>HTTP 취소 응답·집계 GPU 수치만 있고 해당 요청의 실제 종결을 모른다. |
| 남길 자료 | - 중단 요청 접수와 내부 실행 종료 시각, 참조·전송·자원 정리 기록 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 취소 뒤 GPU 작업·출력·참조 잔존 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/7`<br>관련 관측 | 클라이언트 연결 종료와 후속 정상 요청을 관측했다. | 취소 후 GPU 작업·출력·참조의 종료는 계측하지 않았다. |

### NIST 요구와 이 점검의 대응 범위

**SC-6 · SA-8(19) · SA-8(24) — 일부 대응**

자원 가용성과 종료·실패 중 연속 보호를 유지한다.

취소 뒤 실제 GPU 계산·전송·참조·요청 상태가 기한 내 종료되는지 확인한다.

AC-12의 사용자 세션 종료를 GPU 작업 종료의 직접 근거로 사용하지 않는다.

#### 담당자와 시험 준비

| 운영 담당자 | 실제 종료·취소 기한과 종료 대상 프로세스·작업·공유 참조 목록을 준비해야 한다. |
| --- | --- |
| 시험 담당자 | 종료 요청·응답 종료·실제 작업 종료·자원 반환을 각각 확인해야 한다. |
| 계측 담당자 | GPU·비동기 작업은 완료 기록과 참조 해제·재사용을 연결해야 한다. 응답 종료만으로 내부 자원 반환을 판단하지 않아야 한다. |

 

**시험 준비**

 

요청별 종결·자원 회수를 관측할 방법과 기한을 정한다.

 

**시험에서 확인할 내용**

 

HTTP 연결 종료, Core의 중단(abort), 완료된 요청 ID(finished ID), worker 내부의 행(row) 상태, KV 참조, GPU 작업·전송 완료를 각각 관측한다. 같은 취소 시험에서 늦게 도착한 출력이 새 요청이나 재시도(attempt)에 잘못 연결되는지는 CHK-REQ-012에서 따로 판정한다. 올바른 출력 폐기만으로 내부 실행·자원의 회수가 완료됐다고 처리하지 않는다. worker/그룹 실패의 잔여 자원 정리는 CHK-LIF-011에서 판정한다.

 

**시험 순서**

 

1. 대기·계산·출력 중인 요청에 취소·연결 종료·timeout을 각각 적용한다.
2. 종료 기한의 기준으로 정한 시작 사건을 기록한다. 그 사건부터 core·worker 작업 중단, 전송 완료, 참조·자원 반환까지 각 시각을 기록한다.
3. 각 종결 조건과 기한을 대조하고, 후속 정상 요청의 처리 결과를 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 요청 취소 뒤에도 GPU 작업·출력·참조가 남음 | 일반·스트리밍(streaming) 요청의 대기·계산·출력 단계에서 취소·연결 종료·시간 초과(timeout)·stop에 따른 종료를 확인한다. | SC-18-01 |

 

**함께 확인할 보호 요구**

 

- [요청·결과 귀속](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-1): 요청과 결과가 같은 사용자·모델·실행에 연결되는지 해당 점검에서 확인한다.
 
- [실행 상태·버퍼 수명](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-4): 참조의 사용 완료·해제·재사용 순서와 잔존 상태를 해당 점검에서 확인한다.

 

**엔진별 확인 사항**

 

**오류 종류별 취소와 정리 경로 — R11**

 

`CancelledError`·`GeneratorExit`가 발생했을 때 collector가 있으면 해당 collector의 내부 ID로 abort한다. `EngineDeadError`는 개별 abort 없이 오류를 전달하므로 실행 그룹의 실패·종료를 확인한다. `VLLMClientError`·`GracefulHTTPError`도 이 분기에서는 abort하지 않는다. `InputStreamError`와 그 밖의 예외는 collector가 있으면 내부 ID로 abort한 뒤 오류를 전달한다. 등록·전처리 과정에서 만들어진 상태는 별도의 정리 경로를 확인한다.

 

scheduler는 종료한 요청 ID를 `finished_req_ids`에 넣어 다음 `SchedulerOutput`으로 전달한다. V1은 `GPUModelRunner._update_states()`에서 요청 상태와 InputBatch 항목을 제거한다. V2는 `finish_requests()`에서 `_remove_request()`로 이어지는 경로에서 request slot과 관련 상태를 정리한다.

 

실제로 사용하는 runner에 맞춰 이 경로를 추적한다. scheduler의 종료 처리, 후속 실행 정보의 전달, worker 상태 정리를 각각 확인한다. GPU 작업의 실제 완료 시점은 별도 장치 계측으로 확인하고, 메모리 소거가 필요한 자료는 해당 보존·삭제 정책에 따라 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.4.2 · 인쇄 50 / PDF 60](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=60) / [서비스 제공자 4.2.1 · 인쇄 99 / PDF 109](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=109)

자원 소모 제한·복구라는 관련 목적은 있다.

**OWASP ASVS:** [V1.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V13.1.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).HTTP 취소→Core abort→worker/KV/GPU/전송 완료의 실제 종결을 연결한다.

취소 응답이나 결과 폐기만으로 내부 실행·참조 회수를 확정할 수 없다.

**관련 위협 시나리오:** [SC-18-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-18-01)

 

**관련 근거:** [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [SC-18-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-18-01)

