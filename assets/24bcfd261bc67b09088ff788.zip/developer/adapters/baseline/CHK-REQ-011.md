# CHK-REQ-011 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-011.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 동시에 들어온 요청의 일반·스트리밍 응답이 각각 올바른 요청자에게 돌아가는가? · CHK-REQ-011

<a id="CHK-REQ-011"></a>
 
<a id="411-동시-요청과-스트리밍-응답이-각각-올바른-요청자에게-돌아가는가"></a>
 
<a id="source-10-02858"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 일반·스트리밍 요청의 결과 귀속을 확인한다. 외부 ID·child·별도 시도는 실제 사용 시 추가한다. |
| --- | --- |
| 권장 설정·조치 | 외부 요청·내부 실행·출력 수신 대상을 검증한 사용자와 작업 ID로 구분한다. 동시 요청과 스트리밍에서 응답 조각·종료 신호를 원래 요청에 반환하도록 상태 등록·전달 규칙을 유지한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | 사용자 A와 B가 서로 구별되는 내용을 동시에 요청한다. 각 응답과 스트리밍 조각·종료 신호를 요청 ID와 수신 연결에 대조해 다른 사용자의 결과가 섞이지 않는지 확인한다.<br>**정상 동작:** 고유 표식이 있는 A·B 일반·스트리밍 요청이 각각 올바른 연결로 반환된다. |
| 판정 기준 | 충족<br>결과가 다른 사용자·요청에 전달되지 않는다.<br>미충족<br>다른 요청의 결과·종료 신호가 잘못된 호출자에게 반환된다.<br>미확인<br>응답 표식 또는 연결별 ID 대응을 확보하지 못했다. |
| 남길 자료 | - 서버 생성 ID·클라이언트 ID/chunk 순서·연결/각 요청 결과 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 요청 ID 충돌을 이용한 결과·취소 대상 혼동 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261106](../../../site/references/evidence/gpu-a-dev1-phase2-20261106.json)<br>`/runs/0`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 PASS | 새 결과 ID·스트리밍 동시 요청의 PASS 기록이다. | 선정 조건 밖의 전체 충돌·취소·결과 귀속은 추가 확인해야 한다. |
| [CPU 20261023](../../../site/references/evidence/automation-phase3-20261023.json)<br>`/attempts/0/checks/2`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 PASS | CPU의 선정 native INFO·수집기·표시 또는 요청 귀속을 관측했다. | 기업 SIEM과 모든 수집·변환 경로 및 분기 전체의 증거는 확보하지 못했다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-18`<br>관련 관측 | 정상·스트리밍 요청을 관측했다. | ID 충돌과 취소·지연 결과의 귀속은 시험하지 않았다. |

### NIST 요구와 이 점검의 대응 범위

**AC-4 · SC-4 — 요구 직접 대응**

비허용 정보 흐름과 공유 자원을 통한 정보 전달을 방지한다.

동시 일반·stream 응답이 원 요청자에게 귀속되는지 확인한다.

요청 ID와 실제 반환 내용의 독립 대조를 유지한다.

 

**시험 준비**

 

동시에 처리하는 요청 수를 적게 제한해 시험한다. 각 요청을 구별할 무해한 표식과 응답 수집기를 준비한다.

 

**시험에서 확인할 내용**

 

시험 사용자 두 명이 동시에 일반·스트리밍 요청을 보내게 한다. 검증된 신원에서 외부·내부 ID, worker·결과 수집기(collector), 연결과 응답 조각(chunk), 종료 신호까지 같은 요청의 기록을 이어서 추적한다. 외부 ID나 하위 실행(child)을 실제로 사용한다면 같은 외부 ID가 겹치는 경우와 내부 ID를 분리하는 경우의 영향을 비교한다. 각 요청이 정상 결과를 받는지도 확인한다. 기본 internal ID의 무작위 접미사와 유효 randomization 설정을 기록한다. 실제 등록된 abort 경로·자기 요청 취소·타 요청 영향은 CHK-REQ-012와 같은 ID 관측 자료를 공유하되, 이 행은 동시 결과·종료 신호의 수신자 귀속을 판정한다. 근거 원문: [요청 ID와 취소 경로](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=request-id-evidence).

 

**시험 순서**

 

1. 두 요청을 동시에 실행한다.
2. 한 요청의 응답 속도만 지연시킨다.
3. 각 연결의 request ID와 응답 조각(chunk), 종료 신호가 어느 요청에 해당하는지 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 요청 ID가 겹쳐 다른 요청의 결과 조회·취소 | 일반/동시/streaming 요청을 확인하고 외부 ID·child를 사용하면 그 분기를 추가한다. | SC-02-02 |

 

**엔진별 확인 사항**

 

**요청 ID와 내부 실행의 연결 — R11**

 

외부 ID 하나에 여러 내부 실행이 연결될 수 있다. 외부 ID로 abort하면 연결된 실행들이 대상이 될 수 있고, 내부 ID는 해당 실행 또는 상위 요청인 parent에 속한 하위 실행인 child를 찾는 데 쓰인다. ID를 구분하는 동작과 요청 소유자의 권한 검사는 각각 확인한다. 취소 요청은 실제로 제공되는 API와 처리 경로를 확인한 뒤 시험한다.

 

`generate`가 결과 수집기인 collector를 아직 받지 못했더라도 로컬 요청 등록이 이미 이루어졌을 수 있다. 단일 요청은 로컬 등록을 마친 뒤 Core 전송을 기다린다. 병렬 child 등록 중 실패하면 parent의 내부 ID로 abort하는 처리가 있다.

 

등록 전, Core 전송 도중, 등록 완료 후에 발생한 실패·취소를 나눠 시험한다. 각 경우의 외부 ID·내부 ID·parent·child와 실제 종료 대상을 연결해 기록한다. 공개 Chat 취소 API의 제공 여부도 실제 등록 경로에서 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.3.3 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97) / [서비스 제공자 2.4.2 · 인쇄 90 / PDF 100](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=100)

데이터 접근·기밀성 및 호출 권한을 비동기 결과 반환에 적용한다.

**OWASP ASVS:** [V8.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 동시·streaming 처리의 외부/내부 ID→worker→collector→최종 수신 연결을 추적한다.

객체 인가 조항만으로 비동기 결과 귀속 전체의 구현 정확성이 입증되지는 않는다.

**NIST SP 800-53 Rev.5:** [AC-4](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 정보 흐름만 허용한다. 동시에 처리한 응답이 허용된 요청자에게 전달되는지 확인한다.

**관련 위협 시나리오:** [SC-02-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-02-02)

 

**관련 근거:** [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [SC-02-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-02-02)

