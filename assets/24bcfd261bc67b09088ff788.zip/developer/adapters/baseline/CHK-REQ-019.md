# CHK-REQ-019 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-019.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### GPU 연산이 입력·버퍼 범위를 지키고 필요한 메모리를 초기화하는가? · CHK-REQ-019

<a id="CHK-REQ-019"></a>
 
<a id="341-실제-사용하는-gpu-연산-코드가-입력버퍼-경계를-지키고-필요한-영역을-초기화하는가"></a>
 
<a id="source-10-02783"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실제 GPU/backend/dtype/shape·의존성에 도달하는 kernel 분기를 확인한다. 다른 kernel의 결과를 전용하지 않는다. |
| --- | --- |
| 권장 설정·조치 | 선택한 kernel·의존성의 수정 버전을 적용하고 실제 buffer 크기·입력 범위에 맞춰 접근·초기화 조건을 검사한다. 수정 전 임시 제한은 확인된 영향 경로에 적용하고 유효 입력의 정상 처리도 함께 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 실제로 선택된 GPU 연산 코드와 입력 크기·자료형을 고정한다. 경계 입력·메모리 접근·초기화와 대조 출력을 확인하며, 집계 GPU 지표만으로 판정하지 않는다.<br>**정상 동작:** 선택한 kernel이 유효 shape·length 입력으로 대조 구현과 맞는 결과를 낸다. |
| 판정 기준 | 충족<br>시험한 kernel 분기에서 주소·인덱스·크기 계산과 필요한 영역의 초기화가 유효한 범위를 지키고, 범위 밖 접근이나 초기화되지 않은 값의 소비가 확인되지 않으며 정상 대조 연산이 성립한다. slot 상태·graph replay·통신 버퍼의 소유자와 시간 순서는 CHK-REQ-018·CHK-REQ-020·CHK-REQ-021의 결과와 연결한다. 계측 미비는 미확인으로 둔다.<br>미충족<br>유효 범위 밖 접근이나 초기화되지 않은 값의 소비가 증거로 확인된다.<br>미확인<br>집계 GPU 지표만 있거나 kernel·buffer 수준 증거를 얻지 못했다. |
| 남길 자료 | - kernel·GPU·dtype/buffer 범위·초기화/동기화 오류·대조 출력 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### GPU 메모리 경계 오류로 다른 요청 자료 노출 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-19-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | 커널 fixture 관측이며 실제 서빙 도달·초기화 전 읽기·compute-sanitizer 증거는 없다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/11`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 커널 fixture의 UNKNOWN·cold PASS 기록이다. | 실제 서빙 경로 도달·초기화 전 읽기·전체 GPU 메모리 범위는 확인하지 못했다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/12`<br>부분 결과<br>보안 PASS · 기능 UNKNOWN · 성능 UNKNOWN | 커널 fixture의 UNKNOWN·cold PASS 기록이다. | 실제 서빙 경로 도달·초기화 전 읽기·전체 GPU 메모리 범위는 확인하지 못했다. |

### NIST 요구와 이 점검의 대응 범위

**SI-10 · SC-4 — 일부 대응**

입력 유효성과 공유 자원을 통한 비허용 정보 전달을 제한한다.

GPU kernel의 경계 접근·초기화·유효 버퍼 범위를 실제 연산 경로에서 확인한다.

SI-16의 기본 요구는 비인가 코드 실행 방지다. 일반 GPU 메모리 안전의 직접 근거로 쓰지 않는다.

#### 담당자와 시험 준비

| 개발 담당자 | 실제 로더·전처리·GPU kernel과 지원 입력의 형식·크기·자료형 계약을 정해야 한다. |
| --- | --- |
| 시험 담당자 | 정상 입력과 경계·비정상 입력을 준비하고 입력 검증 결과와 실제 native 실행을 연결해야 한다. |
| 계측 담당자 | 선택한 경로에서 잘못된 메모리 접근을 확인할 도구·오류 기록을 준비해야 한다. 오류를 관측하지 못한 실행과 도구가 검사한 범위를 구분해야 한다. |

 

**시험 준비**

 

GPU 연산 코드(kernel)를 시험할 작은 입력 자료와 메모리 접근을 기록·검사할 도구를 준비한다. 출력 차이만으로 메모리 유출을 확정하지 않는다.

 

**시험에서 확인할 내용**

 

구현 근거에 따라 경계값 입력을 만들고 격리 환경에서 시험한다. 의도한 분기가 실제로 실행됐는지 확인하고, 메모리 접근·오류 기록과 정상 출력을 확보한다.

 

**시험 순서**

 

1. 활성 kernel·dtype·shape와 유효 buffer 범위를 고정하고 정상 연산 결과를 기록한다.
2. 길이 경계와 padding을 바꾼 작은 시험 자료(fixture)를 실행한다.
3. 메모리 접근·초기화 검사 기록, 오류와 guard 확인 결과, 출력을 확인한다. 이를 유효 접근 범위와 비교 기준 구현의 결과에 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| GPU 메모리 경계 오류로 다른 요청의 자료 노출 | 선택한 kernel·backend, 자료형(dtype)·배열 형태(shape) 또는 실제 CUDA Graph 경로를 확인한다. 각 경로는 별도로 확인하며 다른 경로의 결과로 대신하지 않는다. | SC-06-02 |

 

**함께 확인할 보호 요구**

 

- [실행 상태·버퍼 수명](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-4): 선정 kernel의 유효 buffer 범위와 초기화 결과를 제공한다. slot 상태 이동·graph replay·native 등록 참조의 시간 순서는 CHK-REQ-018·020·021에서 판정한다.

 

**엔진별 확인 사항**

 

**GPU 메모리 접근을 확인할 증거**

 

시험할 buffer의 유효 접근 범위와 사용 전에 초기화해야 하는 영역을 구현 근거에서 확인한다. 실제로 실행된 kernel의 메모리 접근·초기화 검사 결과를 그 범위와 대조한다.

 

경계 접근, 초기화 여부와 이전 상태의 혼입, 정상 출력의 결과를 각각 남긴다. 출력이 같더라도 관측하지 못한 메모리 접근까지 안전하다고 판단하지 않는다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.1.1 · 인쇄 82·83 / PDF 92·93](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=92) / [개발자 3.3.2 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

메모리 사용·런타임 오류의 동적 분석과 외부 코드 검증 방법은 관련된다.

**OWASP ASVS:** [V1.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V1.4.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 일반 메모리/정수 경계 보호를 선정 GPU kernel·dtype·shape·실제 device 관측으로 구체화한다.

V1.4.1은 버퍼 경계, V1.4.2는 정수 경계의 근거다. 초기화되지 않은 값 소비 전체는 이 조항들만으로 설명하지 않으며 CWE-457·kernel 계약·장치 관측을 추가한다.

**관련 위협 시나리오:** [SC-06-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-06-02)

 

**관련 근거:** [Q-C06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C06) · [SC-06-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-06-02)

