# CHK-SUP-008 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-008.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 요청값을 바꿔 승인하지 않은 코드 판본을 선택할 수 없는가? · CHK-SUP-008

<a id="CHK-SUP-008"></a>
 
<a id="321-요청에-넣은-값으로-허용받지-않은-코드-버전을-선택할-수-없는가"></a>
 
<a id="source-10-02313"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 요청의 코드 판본 선택 필드와 실제 지원·노출 경로를 먼저 확인한다. 금지 구성에서도 해당 필드의 거부·제거를 확인하고, 허용 구성에서는 실제 선택·소비 판본을 추가 확인한다. 입력 미지원·비노출을 근거로 확인하면 코드 소비 분기만 비적용 후보로 남긴다. 지원 여부나 선택 허용 정책이 미정이면 해당 분기의 적용을 미정으로 둔다. |
| --- | --- |
| 권장 설정·조치 | 요청에서 코드 버전을 바꾸는 필드와 전달 경로를 제한한다. 운영 설정에 승인한 버전을 고정하고, 예외적으로 허용한 요청 값도 최종 코드 선택 전에 승인 범위와 대조한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 실제 지원하는 코드 선택 필드가 최종 모듈·출처·판본에 어떻게 반영되는지 확인한다. 금지한 선택값의 제거·거부와 허용한 선택값의 승인 범위 검사를 비교한다.<br>**정상 동작:** 요청의 판본 덮어쓰기 없이 승인한 처리 모듈·코드로 정상 요청을 처리한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다. |
| 판정 기준 | 충족<br>허용 밖 코드 판본 선택이 import·실행 전에 차단되고 승인한 정상 요청은 처리된다. 허용된 선택 분기에서는 최종 소비 코드가 승인 대상과 일치한다.<br>미충족<br>금지 override가 코드 선택에 반영되거나 승인 밖 코드가 소비된다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.<br>미확인<br>적용한 분기에서 kwargs 전달까지만 확인했거나 선정 processor의 최종 코드 선택·실행 전 거부를 확인하지 못했다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다. |
| 남길 자료 | - 실제 지원·노출된 코드 판본 선택 필드, 호출자·선택 허용 범위와 유효 설정<br>- 제출값·검증/제거·전달 결과, 최종 선택 모듈·출처·불변 판본과 import/실행 또는 사전 거부<br>- 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 요청의 코드 버전 변경으로 비승인 모듈 로딩 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-SUP-08-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | code 선택 요청의 응답을 관측했으나 최종 소비를 확인하지 못한 UNKNOWN 기록을 유지한다. |
| [GPU 20261103](../../../site/references/evidence/gpu-a-SUP-08-20261103.json)<br>`/runs/1`<br>부분 결과<br>보안 UNKNOWN · 기능 PASS · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | code 선택 요청의 응답을 관측했으나 최종 소비를 확인하지 못한 UNKNOWN 기록을 유지한다. |
| [GPU 20261103](../../../site/references/evidence/gpu-a-SUP-08-20261103.json)<br>`/runs/2`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | code 선택 요청의 응답을 관측했으나 최종 소비를 확인하지 못한 UNKNOWN 기록을 유지한다. |
| [PoC 20261111](../../../site/references/evidence/sup08-code-selection-20261111.json)<br>`/product_update/baseline`<br>부분 결과<br>PASS | v0.7.0·v0.30.0·v0.31.0의 단일 모델 PoC에서 code 선택을 대조했다. | 원문 ignored·consumed·rejected 및 PASS·FAIL을 각각 유지한다. DRAFT 정책의 선정 모델 결과로 전체 엔진 보호를 확정하지 않는다. |
| [PoC 20261111](../../../site/references/evidence/sup08-code-selection-20261111.json)<br>`/standalone_controls/0`<br>부분 결과<br>PASS | v0.7.0·v0.30.0·v0.31.0의 단일 모델 PoC에서 code 선택을 대조했다. | 원문 ignored·consumed·rejected 및 PASS·FAIL을 각각 유지한다. DRAFT 정책의 선정 모델 결과로 전체 엔진 보호를 확정하지 않는다. |
| [PoC 20261111](../../../site/references/evidence/sup08-code-selection-20261111.json)<br>`/standalone_controls/1`<br>부분 결과<br>PASS | v0.7.0·v0.30.0·v0.31.0의 단일 모델 PoC에서 code 선택을 대조했다. | 원문 ignored·consumed·rejected 및 PASS·FAIL을 각각 유지한다. DRAFT 정책의 선정 모델 결과로 전체 엔진 보호를 확정하지 않는다. |

##### 요청의 코드 버전 변경으로 비승인 모듈 로딩 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [PoC 20261111](../../../site/references/evidence/sup08-code-selection-20261111.json)<br>`/product_update/candidate`<br>부분 결과<br>FAIL · PASS | v0.7.0·v0.30.0·v0.31.0의 단일 모델 PoC에서 code 선택을 대조했다. | 원문 ignored·consumed·rejected 및 PASS·FAIL을 각각 유지한다. DRAFT 정책의 선정 모델 결과로 전체 엔진 보호를 확정하지 않는다. |

### NIST 요구와 이 점검의 대응 범위

**CM-7(5) · CM-3 — 요구 직접 대응**

승인된 출처·판본의 소프트웨어만 실행한다.

요청이 코드 revision 선택을 바꾸는 실제 경로를 시험한다.

허용 목록의 단순 존재보다 최종 선택 코드와 대조한다.

 

**시험 준비**

 

선정 엔진에서 코드를 선택하는 필드, 실제로 사용하는 모듈과 의존성 판본을 확인하고 무해한 판본 시험 자료를 준비한다. 기능의 비노출·미지원 여부는 호출 경로의 근거로 확인한다.

 

**시험에서 확인할 내용**

 

요청에서 코드 판본을 선택하는 필드가 실제로 어느 모듈에 사용되는지 확인한다. 허용된 값과 허용되지 않은 값이 수용·제거·거부되는지 비교한다. 최종 코드의 출처·판본과 실행 전에 적용된 제한도 대조한다.

 

**시험 순서**

 

1. 선정한 엔진에서 요청→코드 선택→실제 사용으로 이어지는 경로와 지원 필드를 확인한다.
2. 금지 구성에서 무해한 비허용 판본 선택의 거부·제거와 정상 요청을 대조한다.
3. 코드 판본 선택을 허용한 구성에서는 승인된 판본과 승인되지 않은 판본을 비교하고, 최종적으로 사용된 코드를 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 요청에서 코드 버전을 바꿔 승인되지 않은 코드 로딩 유도 | 기본 금지 정책의 endpoint에서 code_revision/mm kwargs 필드가 거부·제거되는지 확인한다. MM 비사용 설정만으로 전달 거부를 추정하지 않는다. | SC-11-01 |
| 요청에서 코드 버전을 바꿔 승인되지 않은 코드 로딩 유도 | 선정한 멀티모달 processor와 trust-request-mm-kwargs 등 해당 opt-in이 실제로 활성화된 경우에만 추가한다. 실제 선택된 processor·코드 판본이 승인 내용과 맞는지 확인한다. | SC-11-01 |

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 요청별 코드 판본 선택**

 

MM processor 경로는 `trust_request_mm_kwargs`를 허용했을 때 확인한다. 기본값인 `trust_request_mm_kwargs=false`에서는 비어 있지 않은 request kwargs를 거부한다. LoRA resolver는 설치·활성화되어 있고, 요청한 repo가 운영자의 `repo_list`에 포함된 경우를 대상으로 확인한다.

 

기본 설정에서는 `code_revision`이 포함된 요청의 `mm_processor_kwargs`가 processor에 사용되기 전에 거부되는지 시험한다. 이를 허용하는 opt-in 환경에서는 `code_revision`이 dynamic kwargs 필터, processor kwargs, `from_pretrained`로 전달되는 과정을 추적한다. 실제로 선택된 processor·Transformers·`auto_map`·`trust_remote_code` 조합과 최종 import된 코드의 출처·판본을 승인 내용에 대조한다.

 

resolver는 목록 안·밖의 repo와, 같은 이름으로 원격 자료가 바뀐 경우를 각각 시험한다. 같은 이름·경로를 보았다는 사실에 그치지 않고 실제 immutable snapshot의 식별값과 다운로드한 객체를 확인한다. `trust_request_mm_kwargs`의 유효값, processor factory에 전달된 인수, 최종 import·repo·revision을 기록한다.

 

허용되지 않은 선택과 허용된 선택은 무해한 표식으로 구분한다. 정상 대조에서는 요청에서 processor·코드 판본을 바꾸지 않은 기본 텍스트 요청과 승인된 모델·adapter가 정상 처리되어야 한다. MM을 사용하지 않는 텍스트 구성에서 해당 경로에 도달하지 않는다면, 그 분기의 비사용 근거를 확인해 따로 기록한다.

 

**멀티모달 경로의 세부 시험**

 

<a id="mm-processor"></a>

 

**요청별 processor 선택과 판본 제한**

 

**적용할 환경:** 요청의 mm_processor_kwargs·code_revision 등 값이 processor 선택·생성·호출에 전달되는 경로를 조사한다. 금지 설정에서는 거부·제거를 확인하고, 실제 opt-in과 지원 경로가 확인된 경우에 코드 선택 시험을 추가한다.

 

**확인할 환경 정보:**

 

- 요청 필드, 서버 옵션, trust-request-mm-kwargs 등 실제로 활성화된 opt-in
 
- processor의 실제 선택 함수·모듈·출처·불변 판본
 
- 단순 처리 옵션과 코드 선택 옵션의 구분

 

**정책과 담당·검사 위치:** 운영 담당자는 요청에서 바꿀 수 있는 옵션과 코드 판본을 정하고, API·processor 담당자는 실제 선택 전에 집행한다. 크기·patch/crop/frame 수가 바꾸는 비용은 LIF-003, 입력 배치는 REQ-009에서 판정한다.

 

**호출 권한과 실패 경계:** 실제 노출된 mm_processor_kwargs·판본 선택 필드를 제출할 수 있는 호출자를 전제로 한다. 요청에서 바꿀 수 있는 범위가 승인한 processor 코드 선택 범위를 넘는지 확인한다.

 

**정상 대조:** 요청의 판본 덮어쓰기 없이 승인한 processor가 정상 미디어를 처리한다. 허용한 옵션·판본 선택도 승인 범위에서 정상 처리된다.

 

**조건을 달리한 시험:**

 

- 실제 지원하는 필드 하나에 무해한 비허용 판본 또는 허용 범위 밖 선택값을 지정하는 시험을 설계한다.
 
- 금지 경로의 제거·거부와 허용 경로의 최종 processor 판본을 각각 대조한다. 일반 처리 옵션을 코드 판본 변경으로 간주하지 않는다.

 

**필수 관측:**

 

- 제출값, 실제로 활성화된 opt-in, 검사·제거·전달 결과
 
- 최종 processor 모듈·출처·불변 판본과 import/실행 또는 사전 거부
 
- 같은 정상 미디어의 처리 결과와 입력·비용 시험 참조

 

**충족:** 금지한 요청별 코드 선택은 반영되지 않고, 허용한 선택은 승인된 processor만 사용한다.

 

**미충족:** 금지된 override가 코드 선택에 반영되거나 승인되지 않은 코드가 실제로 사용된다.

 

**미확인:** kwargs 전달만 확인했고 해당 processor의 최종 코드 선택·실행 전 거부를 확인하지 못하면 미확인이다. 허용 범위를 벗어난 코드 선택이 확인됐다면, 이후 피해를 관측하지 못한 경우와 구분해 기록한다.

 

**원복과 재시험:** 요청·서버 옵션과 processor 판본을 원복하고 정상 미디어를 처리한다. schema·opt-in·processor 전달/선택 경로가 바뀌면 재시험한다.

 

**근거:** [요청별 processor kwargs와 자원 영향](https://github.com/vllm-project/vllm/security/advisories/GHSA-gx7p-2j49-hfq4) · [고정판 요청·processor 입력](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/multimodal/processing/inputs.py)

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.1 · 인쇄 48 / PDF 58](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=58) / [개발자 3.3.2 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

외부 라이브러리의 출처·판본 확인과 위험 검증을 요청의 코드 선택 경로로 확장한다.

**OWASP ASVS:** [V2.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 요청이 선택하는 코드 판본을 허용값·허용 작업으로 제한하는 일반 입력/실행 통제다.

ASVS가 특정 code_revision 필드를 지정하지는 않는다. 필드명과 코드 출처의 실제 확인은 적용 절차다.

**NIST SP 800-53 Rev.5:** [CM-7(5)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 소프트웨어만 실행하도록 허용 목록을 적용한다. 실제 선택한 코드의 출처와 판본을 확인한다.

**관련 위협 시나리오:** [SC-11-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-01)

 

**관련 근거:** [Q-R05-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-03) · [SC-11-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-01)

