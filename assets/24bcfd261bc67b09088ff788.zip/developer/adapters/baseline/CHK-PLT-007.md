# CHK-PLT-007 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-007.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 엔진이 허용된 목적지로 허용된 작업만 송신하는가? · CHK-PLT-007

<a id="CHK-PLT-007"></a>
 
<a id="161-엔진의-외부-송신이-허용된-목적지와-작업에-한정되는가"></a>
 
<a id="source-10-01409"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 취득·엔진 실행·관측의 외부 송신을 기본 확인한다. 외부 연결이 불필요한 구성도 금지 송신의 집행을 확인한다. |
| --- | --- |
| 권장 설정·조치 | 모델 취득·엔진 실행·관측 단계별 허용 목적지·포트·프로토콜·작업을 정해 해당 송신 지점에 적용한다. DNS·redirect 뒤 최종 목적지와 정책 적용 상태를 기록하고 정상 허용 통신도 유지되는지 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 자료 취득·추론 운영·통계 보고·관측 자료 전송을 수행하는 프로세스별로 확인한다. DNS 조회와 주소 재지정 뒤의 최종 목적지, 포트·프로토콜·작업과 실제 차단 결과를 대조한다.<br>**정상 동작:** 필요한 저장소·관측 목적지에 승인된 연결만 발생한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다. |
| 판정 기준 | 충족<br>금지 송신은 차단되고 필요한 취득·서비스·관측은 동작한다.<br>미충족<br>금지 목적지·작업의 송신이 실제 성공한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.<br>미확인<br>센서 관측·정책 적용 상태·최종 송신 결과가 부족해 실제 차단 여부를 판단할 수 없다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다. |
| 남길 자료 | - 송신 프로세스·목적지·포트·프로토콜, 정책 적용 위치, 허용·차단 기록, DNS 조회·redirect 결과<br>- 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측 |

### 세부시험과 구현 근거

#### 분산·KV 통신의 실제 노출 확인

| 선정할 경로 | 수행·확인할 내용 |
| --- | --- |
| 기능별 listener | 선택한 KV 전송·broker·scheduler·분리 encoder·expert backup·diffusion·DP 통신의 bind 주소·실제 포트·송수신 주체를 조사한다. V0 사례는 실제 V0·다중 호스트·PyNcclPipe 사용 여부를 먼저 확인한다. |
| 허용·비허용 경로 | 허용 peer의 정상 통신과 비허용 네트워크·주체의 무해한 연결·메시지를 비교한다. HTTP API 키 검사와 내부 통신의 peer 보호를 각각 확인한다. 연결·방화벽·서버 수신과 최종 reader 기록을 구분하고 서비스에 필요한 통신만 허용한다. |

정상 처리와 금지 동작의 거부·실행 여부를 같은 환경·정책에서 기록해야 한다. 시험 자료·임시 권한·추가 기록 설정은 회수하고 승인 구성과 정상 요청을 다시 확인해야 한다. 원치 않는 코드 실행·파일 변경·송신이 관찰되면 시험을 중단하고 접수를 제한한 뒤 증거를 보존하고 승인된 구성으로 복구해야 한다.

관련 공개 기록: [CVE-2025-29783](https://cveawg.mitre.org/api/cve/CVE-2025-29783) · [CVE-2025-32444](https://cveawg.mitre.org/api/cve/CVE-2025-32444) · [CVE-2025-30165](https://cveawg.mitre.org/api/cve/CVE-2025-30165) · [CVE-2025-47277](https://cveawg.mitre.org/api/cve/CVE-2025-47277) · [CVE-2026-3059](https://cveawg.mitre.org/api/cve/CVE-2026-3059) · [CVE-2026-3060](https://cveawg.mitre.org/api/cve/CVE-2026-3060) · [CVE-2026-7301](https://cveawg.mitre.org/api/cve/CVE-2026-7301) · [CVE-2026-14890](https://cveawg.mitre.org/api/cve/CVE-2026-14890) · [CVE-2026-93088](https://cveawg.mitre.org/api/cve/CVE-2026-93088) · [CVE-2026-93034](https://cveawg.mitre.org/api/cve/CVE-2026-93034). [코드 실행 관련 공지와 적용 조건](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=rce-path-reference)

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.6.1 네트워크 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-1)<br>서빙 구성요소가 네트워크에 연결될 때<br>[공식 안내서 PDF 105쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=105) · 주요 확인사항 1,2 | **부분 대응**<br>엔진의 허용 목적지·포트·프로토콜·작업과 최종 송신을 대조한다. | [2.6.1 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-1) |
| [2.6.7 인터넷 접속 통제](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-7)<br>서빙 호스트·엔진이 인터넷에 접속할 때<br>[공식 안내서 PDF 120쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=120) · 주요 확인사항 2 | **부분 대응**<br>모델 취득·서비스·관측 단계의 실제 최종 목적지와 비허용 송신 차단을 확인한다. | 관리·개인정보 취급 단말의 인터넷 통제와 해당 환경에 적용되는 망 차단 의무를 별도로 확인한다. |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 서버 자격을 이용한 다른 저장소 자료 접근 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 승인 코드의 과도한 권한을 이용한 피해 확대 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-05`<br>부분 결과 | 선정 송신 대상 제한을 관측했다. | 실제 모델 취득·redirect·DNS·L7 최종 수신과 전체 송신 경로를 추가 확인해야 한다. |
| [런타임 20261111](../../../site/references/evidence/AWS_GPU_서버16회차_결과_20261111.md)<br>`보고서 전체`<br>관련 관측 | IMDS·공인 IP 송신 제한을 관측했다. | 선정 송신 외의 전체 실제 취득·최종 수신·정상 허용 송신은 추가 확인해야 한다. |

##### 설정 조작으로 금지한 사용통계 보고 재개 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 허용하지 않은 사용통계 항목·목적지 전송 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 엔진→수집기 구간에서 기록 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**AC-4 · SC-7 — 요구 직접 대응**

승인된 통신·정보 흐름만 허용한다.

엔진의 실제 송신 목적지와 수행 작업을 정책에 대조한다.

도메인 허용만으로 최종 IP·redirect·작업 권한까지 확인했다고 판단하지 않는다.

 

**시험 준비**

 

시험 목적지와 송신 제한을 적용할 위치를 정하고, 실제 차단 여부를 확인할 기록을 준비한다.

 

**시험에서 확인할 내용**

 

자료 취득·runtime·usage·관측 등 각 송신 프로세스에서 DNS 조회와 redirect 후 최종적으로 연결한 목적지·포트·protocol과 수행 작업을 기록한다. 송신 정책이 실제로 적용되는 위치도 기록한다. 허용 목적지에서 자료 취득·서비스·관측이 정상 동작하는지 확인한다. 허용되지 않은 시험 목적지·작업으로 무해한 송신을 시도해 실제 연결·차단 결과를 대조한다. 내장 usage가 처음으로 보고 여부를 판단하는 과정, 보고 생성 중단과 payload 필드는 CHK-OBS-004·CHK-OBS-005에서 별도로 판정한다. 허용된 관측 경로의 TLS와 상대 인증은 CHK-PLT-009에서 판정한다. 관측 exporter를 쓰면 실제 SDK·endpoint·proxy와 연결 시작 주체를 식별해 이 행의 목적지 허용표에 포함한다. 근거 원문: [F37](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f37--%EA%B4%80%EC%B8%A1-%EC%9E%90%EB%A3%8C%EC%9D%98-%EC%A0%84%EC%86%A1-%EB%B3%B4%ED%98%B8).

 

**시험 순서**

 

1. 프로세스별 실제 송신 목적지·작업과 허용 기준을 수집하고 정상 통신을 확인한다.
2. 금지한 시험 목적지·작업으로 무해한 송신을 시도한다.
3. Gateway를 거치지 않는 엔진 송신에서도 제한이 적용되는지 확인하고 실제 연결·차단 결과를 기록한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 서버의 저장소 자격으로 허용 범위 밖 자료 접근 | 취득·반입 경로가 실제 원격 연결·DNS·redirect를 사용해 송신할 때 허용 목적지·작업과 실제 연결을 확인한다. 네트워크 송신이 없는 로컬 공급은 이 분기와 구분하며 다른 송신 경로의 기본 점검은 유지한다. | SC-14-01 |
| 승인된 코드의 과도한 실행 권한으로 피해 확대 | 승인된 코드가 실제 엔진 계정·장치·파일·통신 권한으로 실행된다. | SC-14-04 |
| 설정을 바꿔 금지된 사용통계 보고 재개 | usage를 금지한 정책에서 rank0의 env·config를 확인한다. 새 프로세스가 처음으로 보고 여부를 판단한 결과와 실제 보고 생성·송신 여부도 확인한다. | SC-22-01 |
| 허용되지 않은 사용통계 항목·목적지로 전송 | usage 보고를 일부 또는 전체 허용한 구성에서 runtime 필드와 목적지를 지정한다. | SC-22-02 |
| 엔진에서 수집기로 보내는 기록 도청·변조 | 엔진이 collector로 관측 자료를 송신할 때 연결 시작 주체·최종 목적지·작업의 egress 제한을 확인한다. 같은 구간의 exporter protocol·TLS/peer 검증은 CHK-PLT-009에서 판정한다. | SC-24-01 |

 

**함께 확인할 보호 요구**

 

- [사용·환경 정보 수집과 전송](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-5-3): usage reporter의 실제 목적지·연결·네트워크 차단 증거를 공유한다. 생성 금지와 허용 payload·항목·주기는 CHK-OBS-004·005에서 판정한다.

 

**엔진별 확인 사항**

 

**송신 통제의 시험 사례**

 

[평가 방법의 적용 사례](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_D_%ED%8F%89%EA%B0%80%EC%96%91%EC%8B%9D%EA%B3%BC_%EC%82%AC%EB%A1%80.md&anchor=source-05-00279)에서는 허용 도메인 목록이 자료를 실제로 가져오는 함수까지 전달되는지 확인했다. 이 사례를 적용할 때는 현재 구성에서 송신을 제한하는 위치를 찾고, 허용한 목적지와 금지한 목적지에 대한 실제 통신 결과를 비교한다.

 

**멀티모달 경로의 세부 시험**

 

<a id="mm-fetch"></a>

 

**미디어 취득 경로의 최종 목적지 제한**

 

**적용할 환경:** 미디어 URL을 받아 네트워크로 취득하는 공통 connector·모델 전용 loader·라이브러리/배치·비동기 경로를 각각 확인한다. data/base64와 로컬 파일은 네트워크 fetch와 구분해 reader·파일 접근 점검으로 넘긴다.

 

**확인할 환경 정보:**

 

- 입력 진입점·제출자 권한·원격 내용 변경권
 
- 실제 URL parser·connector/전용 loader·동기/비동기 client
 
- URL scheme·허용 대상·DNS/redirect 설정과 최종 연결
 
- 다운로드 캐시·서버 인증정보·대리 요청 권한

 

**정책과 담당·검사 위치:** 운영·네트워크 담당자는 허용 목적지·작업과 서버 자격 사용 범위를 정한다. 각 fetch 구현과 네트워크 통제는 실제 최종 연결에서 이를 집행한다. 로컬 경로의 허용 범위는 PLT-001·SUP-012에서 확인한다.

 

**호출 권한과 실패 경계:** 미디어 URL 제출권과 원격 내용·redirect·DNS 변경권을 각각 기록한다. 서버가 자료를 가져오는 권한을 이용해 금지한 최종 목적지·작업에 접근하는 경계를 확인한다.

 

**정상 대조:** 허용 시험 수신처의 작은 정상 미디어가 선정 경로에서 취득·처리된다. redirect·캐시 hit는 허용 정책에 맞는 경우에만 정상 대조에 포함한다.

 

**조건을 달리한 시험:**

 

- 실제 사용하는 취득 경로마다 통제된 허용·금지 시험 목적지를 지정한다.
 
- 처음 URL은 허용되지만 redirect 또는 DNS 결과가 금지 대상이 되는 조건 하나를 분리해 설계한다. 실제 외부 서비스·metadata 주소로 요청하지 않는다.
 
- 모델 전용 loader에도 공통 connector의 제한이 적용되는지 확인한다. 캐시 hit 때는 새 연결이 발생하는지와 어떤 자료를 실제로 사용하는지 각각 관측한다.

 

**필수 관측:**

 

- 입력 URL, parser 결과, DNS·redirect 단계, 최종 목적지·포트와 사용한 client
 
- 송신 프로세스·사용 자격 범위·정책 집행 위치·허용/차단 기록
 
- 실제 연결·수신 기록과 이후 decoder까지 전달됐는지에 대한 기록
 
- 공통/전용 loader·동기/비동기 경로별 정상 대조

 

**충족:** 각 실제 취득 경로의 최종 연결과 작업이 허용 범위 안에 있고, 금지 연결은 제한된다.

 

**미충족:** 금지 목적지·작업으로 실제 송신이 성공하거나 서버 자격이 승인 범위 밖의 취득에 사용된다.

 

**미확인:** URL 검사 결과나 decoder 오류만 확인되고 최종 연결과 실제 적용 정책을 확인하지 못한 부분은 미확인이다. 파일 해석이 실패해도 이미 확인한 금지 송신은 미충족으로 유지한다.

 

**원복과 재시험:** 시험 수신처·DNS/redirect·캐시·임시 자격을 원복하고 허용 미디어 취득을 확인한다. 모델 loader·HTTP client·네트워크/redirect 정책 변경 시 재시험한다.

 

**근거:** [모델 전용 loader의 제한 우회](https://github.com/vllm-project/vllm/security/advisories/GHSA-4hhp-h66f-j5j7) · [고정판 공통 미디어 connector](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/multimodal/media/connector.py#L314-L444)

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59) / [개발자 3.4.1 · 인쇄 50 / PDF 60](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=60) / [서비스 제공자 2.3.4 · 인쇄 88 / PDF 98](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=98)

외부 API/네트워크 접근 제한, 외부 데이터 소스 접근통제와 유출 방어를 다룬다.

**OWASP ASVS:** [V13.2.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V13.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 외부 목적지 허용목록과 redirect 뒤 실제 송신을 확인한다.

모델 취득·usage·exporter는 송신 경로 목록에 넣을 대상이다.

**NIST SP 800-53 Rev.5:** [AC-4](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 시스템 내부와 연결된 시스템 사이의 정보 흐름을 승인 범위로 제한한다.

**관련 위협 시나리오:** [SC-14-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-14-04) · [SC-14-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-14-01) · [SC-22-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-22-01) · [SC-22-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-22-02) · [SC-24-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-24-01)

 

**관련 근거:** [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [Q-R05-09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-09) · [SC-14-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-14-01) · [SC-14-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-14-04) · [SC-22-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-22-01) · [SC-22-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-22-02) · [SC-24-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-24-01)

 

**미디어 URL·KV 전송 목적지의 공개 사례**

 

일반 API 이용자의 URL 제출→엔진 fetch→최종 목적지는 [미디어 fetch 경로](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=case-media-fetch)로 확인한다. 요청 ID→KV connector의 목적지 해석→연결·tensor 전송은 [KV 라우팅 경로](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=case-kv-routing)로 구분한다. 신뢰된 ID 발급·설정에서 목적지를 정하고 활성 connector의 peer/최종 주소·전송 자료를 검증한다. 정상 목적지의 송신과 금지 목적지의 실제 차단을 비교하며, 접속 실패와 송신 정책에 의한 거부를 구분한다.

