# CHK-PLT-009 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-009.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 엔진에서 기록 수집기와 최종 저장소까지 각 전송 구간을 보호하는가? · CHK-PLT-009

<a id="CHK-PLT-009"></a>
 
<a id="552-엔진에서-기록-수집기와-최종-저장소까지-필요한-전송-보호가-유지되는가"></a>
 
<a id="source-10-03956"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 외부 collector 또는 별도 sink로 관측 자료를 보낼 때 적용한다. 엔진→collector와 collector→sink를 따로 확인한다. |
| --- | --- |
| 권장 설정·조치 | 엔진에서 관측 수집기까지, 수집기에서 최종 저장소까지 각 전송 구간의 상대 검증·보호 설정을 적용한다. proxy·SDK·중계 구간을 포함해 실제 목적지와 보호 상태를 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-data) |
| 확인 방법 | 엔진→수집기→저장소에서 실제로 연결을 시작하는 주체, 상대 인증과 전송 보호를 확인한다. 잘못된 상대·인증서의 거부와 정상 수신을 구간별로 비교한다.<br>**정상 동작:** 엔진→collector→sink의 승인 기록이 지정 종단으로 전달된다. |
| 판정 기준 | 충족<br>어느 구간도 필요한 보호에서 누락되지 않는다.<br>미충족<br>TLS·상대 확인을 요구한 구간에서 비보호 전송 또는 다른 수신지가 허용된다.<br>미확인<br>URL scheme만 보고 SDK 동작·후속 구간을 확인하지 못했다. |
| 남길 자료 | - 엔진·수집기·저장소 사이 실제 전송/수집 방식, 연결 주체·종단과 송수신 도구/라이브러리 판본·유효 설정<br>- 구간별 실제 protocol·상대 인증·보호 채널·수신 결과와 잘못된 상대 연결의 처리 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.7.1 암호정책 적용](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-7-1)<br>암호화가 필요한 개인정보·중요정보를 저장·전송할 때<br>[공식 안내서 PDF 122쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=122) · 주요 확인사항 2 | **부분 대응**<br>엔진→수집기→최종 저장소의 각 구간에서 필요한 전송 보호를 확인한다. | [2.7.1 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-7-1) |
| [2.10.5 정보전송 보안](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-5)<br>다른 조직과 개인정보·중요정보를 주고받을 때<br>[공식 안내서 PDF 164쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=164) · 주요 확인사항 1,2 | **보조 자료**<br>다른 조직의 수집기·저장소로 중요정보를 전송할 때 해당 구간의 보호 자료를 활용한다. | [2.10.5 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-10-5) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 엔진→수집기 구간에서 기록 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 수집기→저장소 구간에서 기록 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SC-8 · IA-9 — 요구 직접 대응**

감사·관측 자료 전송과 수신 서비스의 신원을 보호한다.

엔진→수집기→저장소의 각 구간을 추적한다.

첫 구간의 TLS만으로 이후 구간까지 보호됐다고 판단하지 않는다.

 

**시험 준비**

 

실제 송수신 도구·수집기·저장소 설정을 확인하고, 채택한 보호 채널의 시험 자격·인증서를 준비한다. 자격 원문은 수집하지 않는다.

 

**시험에서 확인할 내용**

 

각 구간의 실제 송수신 구성요소·종단·상대 확인·자격·전송 보호와 수신 기록을 대조한다. push/pull에 따라 연결을 시작하는 주체와 TLS 종료점을 확인하고 잘못된 상대·인증서를 거부하는지 정상 연결과 비교한다.

 

**시험 순서**

 

1. 각 구간에서 연결을 시작하는 주체와 실제 송수신 도구·protocol·보호 요구를 확인한다.
2. 시험 인증서가 일치하지 않는 조건과 수신지가 일치하지 않는 조건을 적용한다.
3. 잘못된 연결의 거부 여부와 실제 수신 결과를 확인한다. 정상 설정으로 복구한 결과와도 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 엔진에서 수집기로 보내는 기록 도청·변조 | 엔진이 collector로 관측 자료를 전송한다. exporter SDK·protocol·TLS/peer·proxy를 조사한다. | SC-24-01 |
| 수집기에서 저장소로 보내는 기록 도청·변조 | collector 이후 별도 sink·저장소로 자료를 전달한다. | SC-24-02 |

 

**함께 확인할 보호 요구**

 

- [실행 상태 관측·수집 건전성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-8-3): 통제 결과와 함께 해당 실행의 관측 누락·수집 장애 여부를 확인한다.

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 관측 자료 전송 구간**

 

사용하는 protocol, endpoint scheme, exporter SDK 판본, 인증서, 프록시 설정을 함께 확인한다. SDK가 `https`를 TLS 연결로 강제하는지 코드를 검토한 뒤 실제 handshake를 시험한다.

 

격리 환경에서 승인된 TLS endpoint, 인증서가 일치하지 않는 endpoint, 허용되지 않은 endpoint에 각각 연결한다. 실제 handshake·peer 검증·수신 기록을 비교하고, 잘못된 인증서나 수신지를 적용했을 때의 거부와 정상 설정으로 복구한 결과를 확인한다.

 

엔진에서 collector로, collector에서 최종 저장소인 sink로 보내는 각 구간의 상대 확인·자격·전송 보호를 따로 기록한다. OTLP SDK 판본과 env, 실제 protocol·TLS peer, collector→sink 설정을 남기되 인증정보의 원문은 수집하지 않는다. 정상 대조에서는 승인된 collector로 연결·수집이 성공하고, TLS peer 검증 또는 채택한 보호 채널이 실제로 적용되어야 한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 3.1.3 · 인쇄 94 / PDF 104](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=104) / [서비스 제공자 2.3.4 · 인쇄 88 / PDF 98](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=98)

로그 전송에 TLS를 적용하는 예시와 전송 중요정보 보호가 대응한다.

**OWASP ASVS:** [V12.3.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V12.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 기록을 보내는 각 경로에서 통신 상대를 확인하고 전송을 보호하는지 점검한다.

collector 이후 구간도 포함해야 하지만 일반 관측 시스템에도 같은 요구가 적용된다.

**NIST SP 800-53 Rev.5:** [SC-8](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 각 구간의 전송 정보에 정한 기밀성·무결성 보호를 적용한다.

**관련 위협 시나리오:** [SC-24-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-24-01) · [SC-24-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-24-02)

 

**관련 근거:** [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [Q-C11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C11) · [SC-24-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-24-01) · [SC-24-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-24-02)

