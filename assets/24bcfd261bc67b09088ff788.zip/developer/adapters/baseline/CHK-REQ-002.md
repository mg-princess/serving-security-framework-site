# CHK-REQ-002 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-002.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 요청 경로가 바뀌어도 실제 실행할 API에 필요한 인증·권한 검사를 거치는가? · CHK-REQ-002

<a id="CHK-REQ-002"></a>
 
<a id="122-gateway서버의-경로-설정에-따라-요청-경로가-바뀌어도-최종-실행-api에-필요한-인증권한-검사가-적용되는가"></a>
 
<a id="source-10-00591"></a>

CHK-REQ-001 안에서 확인하는 조건부 하위시험이다. 적용 여부·증거·결과는 이 ID로 구분해 기록해야 한다.

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | root_path·경로 prefix·Gateway/프록시 재작성이 있을 때 적용한다. 재작성 비사용은 기본 route 인증 점검의 제외 사유가 아니다. |
| --- | --- |
| 권장 설정·조치 | Gateway·프록시·인증 계층·router가 해석하는 요청 경로를 대조하고 재작성 규칙을 일치시킨다. root_path·경로 prefix를 포함한 최종 API에 필요한 권한 검사를 적용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | Gateway나 서버가 요청 경로를 바꾸는 경우를 포함한다. 외부 요청, 인증·권한 검사가 판단한 경로와 작업, 실제 실행한 API를 같은 요청으로 연결해 비교한다.<br>**정상 동작:** 기본 경로와 승인된 prefix 설정에서 같은 작업에 같은 권한이 적용된다. |
| 판정 기준 | 충족<br>경로 변환을 이용해 비허용 handler가 수행되지 않는다.<br>미충족<br>경로 변환으로 권한 검사를 벗어난 동일 작업이 실행된다.<br>미확인<br>외부 응답만 있고 내부 경로·handler 선택을 확인할 수 없다. |
| 남길 자료 | - 외부 요청 주소·작업, 프록시/Gateway의 변환 설정과 변환 후 경로<br>- 인증·인가가 판단한 경로/작업과 최종 처리 함수의 선택·실행 또는 거부 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.6.3 응용프로그램 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-3)<br>서빙 애플리케이션이 사용자·역할별 작업이나 자료를 제공할 때<br>[공식 안내서 PDF 110쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=110) · 주요 확인사항 1 | **부분 대응**<br>경로 재작성 뒤에도 실제 실행 API의 인증·권한 검사가 유지되는지 확인한다. | [2.6.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-3) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 경로 재작성 차이를 이용한 인증 우회 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/13`<br>관련 관측<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 선정 native 경로 호출 기록이 있다. | 경로 재작성·정규화 우회와 최종 실행 경로는 확인하지 못했다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-19`<br>관련 관측 | 미지원 경로·필드의 거부를 관측했다. | 경로 재작성 뒤 인증을 건너뛰는지 시험한 결과는 없다. |

### NIST 요구와 이 점검의 대응 범위

**AC-3 · AC-25 — 요구 직접 대응**

도달하는 접근 요청마다 필요한 인가를 집행한다.

경로 별칭·재작성·실제 API 선택 뒤 검사 누락을 시험한다.

AC-25 전체 설계 요건 충족으로 확대하지 않고 매번 검사하는 성질만 연결한다.

 

**시험의 검출 능력 확인 예**

같은 API를 기본 경로와 재작성 경로에서 시험한다. 격리 환경의 알려진 우회 사례나 통제된 시험 구성으로, 인증 없이 보호 handler가 실행됐을 때 시험이 미충족으로 잡아내는지 확인한다. Gateway에서 거부됐는지 엔진에서 거부됐는지도 기록한다.

 

**시험 준비**

 

시험할 서버·프록시에 실제 적용된 경로 변환 설정을 확인한다. 각 요청의 인증 결과와 최종 실행 작업을 함께 추적할 방법을 준비한다.

 

**시험에서 확인할 내용**

 

기본 경로와 재작성한 경로에서 요청을 각각 실행한다. 실행별로 원래 요청, 인증에 사용한 입력, 최종 처리 함수(handler)와 허용·거부 결과를 함께 기록한다.

 

**시험 순서**

 

1. 실제 서버·프록시의 경로 prefix·재작성 설정을 수집한다.
2. 같은 작업을 원래 경로와 변환된 경로로 각각 호출한다.
3. 인증·인가가 판단한 경로·작업과 최종 처리 함수의 선택·실행을 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 요청 경로가 바뀌면서 인증 검사 누락 | root_path 또는 proxy/Gateway 경로 재작성이 사용된다. | SC-01-02 |

 

**엔진별 확인 사항**

 

**경로 변환을 사용하는 구성**

 

외부 URL에서 Gateway의 rewrite를 거쳐 ASGI의 `path`·`root_path`와 최종 handler로 이어지는 경로를 확인한다. 실제 프록시의 rewrite 설정과 `root_path`를 확보하고, 요청이 어느 handler에 도달했는지 추적할 수 있도록 준비한다.

 

같은 작업을 원래 경로와 변환된 경로로 각각 호출한다. 두 요청의 인증정보가 전달되는 위치와 선택된 handler를 비교하고, 외부 URL·Gateway 설정·ASGI 경로·실행 handler의 대응을 증거로 남긴다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.4.2 · 인쇄 90 / PDF 100](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=100) / [개발자 4.2.4 · 인쇄 58 / PDF 68](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=68)

API 요청별 인증·작업 권한은 경로가 바뀌어도 적용할 기존 요구다.

**OWASP ASVS:** [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.3.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). URL 재작성 뒤 실제 handler에도 같은 권한을 적용하는 일반 인가 우회 점검이다.

root_path·prefix로 경로를 바꾼 뒤에도 최종 API의 권한 검사가 유지되는지 확인한다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 요청 경로에 관계없이 승인된 접근 권한을 집행한다. 실제 선택된 API에서 권한 검사가 유지되는지 확인한다.

**관련 위협 시나리오:** [SC-01-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-01-02)

 

**관련 근거:** [Q-C01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C01) · [SC-01-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-01-02)

