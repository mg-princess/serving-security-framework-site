# CHK-OBS-009 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-OBS-009.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 요청값을 조작해 로그의 사용자·대상·상태를 위조할 수 없는가? · CHK-OBS-009

<a id="CHK-OBS-009"></a>
 
<a id="821-요청에-넣은-값으로-로그의-사용자대상상태를-위조할-수-없는가"></a>
 
<a id="source-10-05277"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 외부 입력이 로그의 신원·대상·상태 또는 사건 경계에 반영될 때 적용한다. parser 거부와 실제 기록 소비를 구분한다. |
| --- | --- |
| 권장 설정·조치 | 신원·대상·상태의 신뢰 필드는 서버에서 만들고 요청 입력과 분리해 구조화한다. 줄바꿈·제어문자·필드 충돌을 처리하고 원본부터 수집기·화면까지 허위 사건이 만들어지지 않는지 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-audit) |
| 확인 방법 | 수용 가능한 무해한 구분문자와 신뢰 필드처럼 보이는 입력을 사용한다. 원본 로그·수집기·표시 화면을 대조해 사건이 나뉘거나 신뢰 필드가 바뀌는지 확인한다.<br>**정상 동작:** 정상 ID와 복수행 콘텐츠가 하나의 올바른 사건으로 기록된다. |
| 판정 기준 | 충족<br>비신뢰 입력이 신뢰 필드를 덮어쓰거나 별도 사건처럼 해석되지 않는다.<br>미충족<br>입력이 신뢰 필드를 덮거나 별도 허위 사건으로 해석된다.<br>미확인<br>raw→collector→표시 변환을 확인하지 못했다. parser가 거부한 header는 해당 경로 거부로 기록한다. |
| 남길 자료 | - 입력 수용·거부/raw와 구조화 기록/화면 사건·신원 대응 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.9.4 로그 및 접속기록 관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-4)<br>운영 로그·접속기록을 생성·수집·보관할 때<br>[공식 안내서 PDF 145쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=145) · 주요 확인사항 2 | **부분 대응**<br>요청값으로 사건의 신원·대상·상태가 위조되지 않는지 확인한다. | [2.9.4 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-9-4) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 요청 필드를 이용한 로그 신원·결과 오인 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261106](../../../site/references/evidence/gpu-a-dev1-phase2-20261106.json)<br>`/runs/1`<br>부분 결과<br>기능 UNKNOWN · 성능 UNKNOWN · 보안 UNKNOWN | 로그 포맷·수집의 UNKNOWN과 PASS 기록이다. | 선정 입력 밖의 이벤트·모든 수집·표시 경로와 정상 대조를 확인해야 한다. |
| [GPU 20261106](../../../site/references/evidence/gpu-a-dev1-phase2-20261106.json)<br>`/runs/3`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 PASS | 로그 포맷·수집의 UNKNOWN과 PASS 기록이다. | 선정 입력 밖의 이벤트·모든 수집·표시 경로와 정상 대조를 확인해야 한다. |
| [CPU 20261023](../../../site/references/evidence/automation-phase3-20261023.json)<br>`/attempts/0/checks/0`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 PASS | CPU의 선정 native INFO·수집기·표시 또는 요청 귀속을 관측했다. | 기업 SIEM과 모든 수집·변환 경로 및 분기 전체의 증거는 확보하지 못했다. |
| [CPU 20261023](../../../site/references/evidence/automation-phase3-20261023.json)<br>`/attempts/1/checks/0`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 PASS | CPU의 선정 native INFO·수집기·표시 또는 요청 귀속을 관측했다. | 기업 SIEM과 모든 수집·변환 경로 및 분기 전체의 증거는 확보하지 못했다. |

### NIST 요구와 이 점검의 대응 범위

**SI-10(6) · AU-3 · AU-9 — 요구 직접 대응**

비신뢰 자료 주입을 막고 감사 내용의 신뢰성을 보호한다.

줄바꿈·필드 충돌이 수집기·조회 화면에서 허위 사건으로 해석되는지 확인한다.

저장 뒤 변조 방지와 생성 단계 로그 주입을 분리한다.

 

**시험 준비**

 

입력과 기록을 맞춰 볼 시험 표식과 실제 로그 파서를 준비한다. 개행 문자 CRLF가 포함된 HTTP 헤더를 서버가 받아들이는지는 먼저 확인해야 한다.

 

**시험에서 확인할 내용**

 

시험용 구분문자와 예약 필드처럼 보이는 표식을 입력한 뒤, 구조화된 로그를 실제 사건과 대조한다.

 

**시험 순서**

 

1. 정상 ID·여러 줄 콘텐츠의 기록을 확보한 뒤, HTTP가 수용하는 무해한 구분문자·예약필드 유사 입력을 보낸다.
2. 같은 요청의 raw 로그·collector 기록·표시 화면을 비교한다.
3. 사건 경계와 사용자·대상·상태 필드가 원래 사건을 유지하는지 확인한다. 입력 단계에서 거부된 경우에는 해당 거부 경로를 기록한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 요청값을 바꿔 로그의 사용자·처리 결과 오인 유도 | 수용된 외부 입력이 formatter·collector·화면의 사건·신뢰 필드에 반영된다. | SC-23-01 |

 

**함께 확인할 보호 요구**

 

- [신원 인증·전달](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-1): 권한 판단에 사용한 신원과 그 검증·전달 기록을 연결한다.

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 로그 구분문자 처리**

 

해당 코드 검토에서는 로그 작성기(formatter)의 개행 치환과 외부 request ID의 수용을 확인했다. HTTP parser의 개행 헤더 수용 여부와 실제 로그 위조 가능성은 미확인 상태다.

 

HTTP parser가 받아들이는 `request_id`와 JSON 요청 필드에 무해한 구분문자 또는 예약 필드와 비슷한 문자열을 넣는다. 원본 로그(raw), collector를 거친 기록, 표시 화면을 비교해 하나의 사건이 잘못 나뉘거나 신뢰 필드가 바뀌는지 확인한다. parser가 CR/LF 헤더를 거부하면 그 결과를 기록한다. 정상 대조에서는 정상 ID와 여러 줄의 콘텐츠가 하나의 사건으로 정확히 기록돼야 한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 3.1.1 · 인쇄 92 / PDF 102](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=102) / [서비스 제공자 3.1.3 · 인쇄 94 / PDF 104](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=104)

기록을 관리하고 무단 변조를 막는 요구와 관련된다.

**OWASP ASVS:** [V16.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 입력으로 사건 경계·사용자·상태를 위조하는 log injection을 막는다.

request ID를 포함해 로그 작성기·수집기·파서별로 입력이 처리되는 과정을 확인하는 것은 일반 로그 위조 시험을 이 환경에 적용하는 절차다.

**NIST SP 800-53 Rev.5:** [SI-10(6)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [AU-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 비신뢰 입력의 주입을 막고 감사 기록이 실제 사건과 관련 신원을 담도록 한다.

**관련 위협 시나리오:** [SC-23-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-23-01)

 

**관련 근거:** [Q-C11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C11) · [Q-R05-15](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-15) · [SC-23-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-23-01)

