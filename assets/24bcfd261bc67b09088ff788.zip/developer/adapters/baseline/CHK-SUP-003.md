# CHK-SUP-003 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-003.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 모델 실행에 함께 쓰는 설정·tokenizer·template와 추가 모델 파일도 승인 대상에 포함되어 있는가? · CHK-SUP-003

<a id="CHK-SUP-003"></a>
 
<a id="211-기본-모델과-함께-읽는-설정tokenizerchat-template-하위-모델추가-공급원의-파일도-승인-범위에-포함되는가"></a>
 
<a id="source-10-01663"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 모델을 로딩하는 환경. 기본 config·tokenizer·template를 포함하고, secondary source·redirect·adapter는 실제 사용 시 추가한다. |
| --- | --- |
| 권장 설정·조치 | 기본 모델이 함께 읽는 설정·tokenizer·chat 템플릿과 선택한 하위 모델·추가 공급원의 파일을 승인 목록에 포함한다. 실제 로딩 시 선택한 경로·버전을 목록과 대조한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-supply) |
| 확인 방법 | 기본 모델 외에 실제로 읽는 파일과 하위 모델·추가 저장소를 목록에 포함한다. 저장소 이름뿐 아니라 고정된 판본·파일과 최종 선택 경로를 승인 목록에 대조한다.<br>**정상 동작:** 승인 목록에 포함된 config·tokenizer·template와 필요한 하위 모델로 정상 로딩한다. |
| 판정 기준 | 충족<br>모든 필수 소비 대상이 승인 목록과 연결되고 누락 대상은 사용 전에 처리된다.<br>미충족<br>승인에 필요한 하위 자료가 목록에 없거나 다른 판본인데 실제로 사용된다.<br>미확인<br>하위 모델·resolver·redirect 활성 여부 또는 실제 소비 자료를 확인하지 못했다. |
| 남길 자료 | - resolved repo·commit·파일/redirect·secondary source 설정/승인 목록과 실제 읽기 대응 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 승인에서 빠진 하위 자료로 모델 동작 변경 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-SUP-03-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | 선정 template 해시 관측이며 승인한 모든 하위 자료의 소비까지 확인하지 못했다. |

### NIST 요구와 이 점검의 대응 범위

**CM-8 · SR-4 · CM-2 — 요구 직접 대응**

실제 구성요소를 목록화하고 출처·기준 구성을 관리한다.

모델 외 tokenizer·대화 템플릿·adapter·하위 모델의 최종 판본을 승인 묶음에 포함한다.

CM-8은 목록 요건이다. 승인 여부는 변경·무결성 통제와 함께 확인한다.

 

**시험 준비**

 

선정 모델과 의존성별로 실제 읽기 경로를 관측할 방법을 준비한다. 선택 기능에는 별도의 시험 자료를 사용한다.

 

**시험에서 확인할 내용**

 

실제로 사용하는 config·토크나이저·대화 템플릿·generation config와 하위·추가 공급원을 목록으로 정리하고 각 repo·불변 판본·파일을 승인 범위에 연결한다. 선택 MM processor·LoRA resolver의 실제 소비·다운로드 대상을 포함하고, 요청의 코드 판본 선택 제한은 CHK-SUP-008에서 판정한다. Ultravox secondary·speculators_config 등 실제 선택된 하위/verifier 모델의 별도 repo·resolved commit·파일을 포함한다. redirect가 실제 설정되면 유효 env·매핑 파일 digest·resolved model/tokenizer 경로를 같은 목록에 포함한다. 동일 표시명만으로 공급원을 식별하지 않는다. 근거 원문: [F10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f10--%EB%AF%B8%EB%94%94%EC%96%B4-%EC%A0%84%EC%B2%98%EB%A6%AC%EC%99%80-lora-%EC%BD%94%EB%93%9C-%EC%84%A0%ED%83%9D) · [F11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f11--%ED%95%98%EC%9C%84-%EB%AA%A8%EB%8D%B8%EA%B3%BC-tokenizer-%EC%84%A0%ED%83%9D) · [F34](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F34).

 

**시험 순서**

 

1. 실제로 읽는 자료와 공급원 목록을 확보하고 승인한 묶음의 정상 로딩을 확인한다.
2. 하위 자료 하나를 승인 목록에서 뺀 시험 묶음을 준비한다.
3. 새로 기동해 해당 자료가 선택·사용되는지 또는 사용 전에 차단되는지 관측하고, 승인 목록과 연결해 기록한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 승인에서 빠진 설정·추가 파일로 모델 동작 변경 | 모델 config·tokenizer 등 실제로 사용하는 자료의 공급원을 확인한다. secondary source·resolver·redirect는 사용할 때 추가한다. | SC-10-02 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.2 · 인쇄 85 / PDF 95](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=95) / [개발자 3.3.1 · 인쇄 48 / PDF 58](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=58)

모델 무결성 및 라이브러리 출처·목록·버전 관리 원칙을 함께 적용한다.

**OWASP ASVS:** [V15.1.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 의존 구성요소의 출처 관리 원칙을 resolver가 추가 선택하는 tokenizer·template·하위 모델의 실제 소비 사슬까지 확장한다.

ASVS의 SW 구성요소 목록과 모델 데이터 전체의 승인 묶음은 범위가 다르다. 실제 공급원과 선택된 판본, 해당 자료의 실제 사용 여부를 각각 확인해야 한다.

**NIST SP 800-53 Rev.5:** [CM-8](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 현재 시스템을 정확히 반영하도록 필요한 수준의 구성요소 목록을 관리하는 요구와 연결된다.

**관련 위협 시나리오:** [SC-10-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-10-02)

 

**관련 근거:** [Q-R05-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-02) · [SC-10-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-10-02)

