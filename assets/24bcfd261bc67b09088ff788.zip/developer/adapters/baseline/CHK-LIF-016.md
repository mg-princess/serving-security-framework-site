# CHK-LIF-016 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-LIF-016.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 복구할 때 변조된 자료나 이전 실행의 남은 상태가 결과에 섞이지 않는가? · CHK-LIF-016

<a id="CHK-LIF-016"></a>
 
<a id="742-변조된-복원-자료나-남은-상태가-복구-결과에-섞이지-않는가"></a>
 
<a id="source-10-05141"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 사용하는 backup·복원 자료를 확인한다. 특수 snapshot은 지원 조건·실제 선택을 따로 확인한다. |
| --- | --- |
| 권장 설정·조치 | 복원 자료·외부 파일·자격·캐시를 현재 승인 내용과 대조하고 쓰기 권한·무결성을 확인한다. 이전 실행의 잔존 상태를 정리하고 복원 검증과 필수 준비가 끝난 뒤 외부 요청을 허용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-deployment-profile) |
| 확인 방법 | 승인된 백업·설정·자격 참조와 실제 복원 자료·파일·접수 시각을 확인한다. snapshot은 지원 조건·생성 제한과 실제 재로딩·정상 요청을 별도로 대조한다.<br>**정상 동작:** 기본 재배포: 승인된 백업·설정·자격 참조·volume·Gateway 상태를 실제 배포 구성에 맞게 복원하고 정상 요청을 처리한다. 선택 snapshot: 생성 제한을 만족한 승인 자료로 재로딩·oracle·외부 gate 시험을 수행한다. |
| 판정 기준 | 충족<br>복원 대상이 현재 승인 내용과 일치하고 필요한 검증·준비가 끝난 뒤 서비스를 재개한다. 복원으로 영향받은 권한·자격 참조·cache·작업 상태는 관련 CHK의 기준과 증거를 연결해 확인한다.<br>미충족<br>비승인 복원 자료가 사용되거나 필수 검증 전에 외부 요청을 허용한다. 복원으로 영향받은 권한·자격 참조·cache·작업 상태가 현재 승인·재개 조건을 위반한 사실이 확인된 경우도 포함한다. 지원 제약을 우회한 실험은 정상 복원 판정과 분리한다.<br>미확인<br>1토큰 oracle만 통과했거나 전체 파일 일치·외부 gate를 확인하지 못했다. 정상 생성 경로에서 옛 API key 복원을 전제하지 않는다. |
| 남길 자료 | - 복원 전후 승인 자료·설정·자격 참조/실제 파일/설정 소비·외부 접수·정상 요청/사본과 잔존 접근/snapshot 지원 조건·생성 거부 근거/snapshot 및 다시 읽는 모델·설정 파일 digest/oracle·listener·외부 gate 시각과 실제 요청 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.9.3 백업 및 복구관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-3)<br>서빙 구성이나 자료를 백업·복원할 때<br>[공식 안내서 PDF 143쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=143) · 주요 확인사항 2 | **부분 대응**<br>복원 자료·권한·잔존 상태의 검증과 서비스 재개 조건을 확인한다. | [2.9.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-9-3) |
| [2.11.5 사고 대응 및 복구](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-11-5)<br>서빙 관련 사고를 인지하고 대응·복구할 때<br>[공식 안내서 PDF 183쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=183) · 주요 확인사항 1 | **보조 자료**<br>복원 검증·이전 상태 정리·재개 확인 결과를 사고 복구 기록의 일부로 사용한다. | [2.11.5 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-11-5) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 변조된 백업의 실행·서비스 사용 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/11`<br>관련 관측 | 과거의 잘못된 기동 구성 시험 기록이 있다. | 실제 백업 변조·검증 실패와 복원 후 접수 제한을 시험해야 한다. |

##### snapshot 복원 검증 전에 추론 요청 접수 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**CP-10 · CP-9 · SI-7 · SA-8(24) — 일부 대응**

복원 자료를 보호하고 안전한 상태로 복구한다.

백업·snapshot·자격·캐시·잔존 작업의 복원 후 현재 정책 적용을 확인한다.

지원 snapshot 범위와 일반 복구를 구분하고 복구 시험을 유지한다.

 

**시험 준비**

 

실제로 사용하는 백업·설정·인증정보·볼륨(volume)·Gateway 가운데 무엇을 복원할지와 승인 기준을 확인한다. 무해한 변경 시험 자료와 실제 소비를 관측할 방법을 준비한다. snapshot을 선택하면 지원 플랫폼·CRIU·단일 GPU·외부 gate도 준비한다.

 

**시험에서 확인할 내용**

 

시험용 백업에 변경을 가하고, 복원 순서, 남은 캐시(cache)·작업, 요청 접수 장치(gate)와 정상 요청 결과를 대조한다. 스냅샷 경로는 별도로 조사한다. 배포 템플릿, 외부 ConfigMap/Secret 값, 볼륨(volume), Gateway/IAM 정책을 각각 어느 단위로 복원하는지 확인한다. 스냅샷에 메모리와 환경의 인증정보 사본이 포함되는지 확인한다. 자료 목록(manifest)을 마스킹했다는 사실만으로 비밀정보가 제거됐다고 판정하지 않는다. vLLM v0.31.0의 해당 snapshot 기능을 선택한 경우 정상 create 경로는 API key·TLS·middleware 및 TP>1을 거부한다. 별도 단일 GPU 선택환경에서 현재 승인된 모델(model)·판본(revision), 실제로 다시 로딩하는 파일과 snapshot을 대조한다. 포트 수신(listener), 결과 확인(oracle)과 외부 요청 접수 장치(gate)의 동작 시각도 확인한다. 옛 API key 복원을 정상 생성 경로의 시험 전제로 쓰지 않는다.

 

**시험 순서**

 

1. 기본: 실제 사용하는 백업·설정 저장소(ConfigMap/Secret 사용 시 포함)·volume·Gateway의 복원 대상과 현재 승인을 기록한다.
2. 기본: 격리 사본의 파일이나 설정에 무해한 변경 또는 누락을 하나 만든다. 사용 전에 거부하는지, 실패 후 외부 요청 접수가 제한되는지 확인한다.
3. 기본: 승인된 원본으로 복구한 뒤 정상 요청의 처리 결과와 남아 있는 접근·사본의 상태를 비교한다.
4. 선택 기능인 스냅샷은 별도의 TP1 지원 구성에서 시험한다. 다시 로딩하는 파일, 생성 캐시의 지문(generated-cache fingerprint), 1토큰 결과 확인(oracle)과 외부 요청 접수 장치(gate)의 동작 순서를 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 변조된 백업을 실행하거나 서비스에 사용 | 백업(backup)·복원 사본을 실제 사용하는 구성요소(consumer)가 읽는 경로를 확인한다. | SC-20-02 |
| 스냅샷 복원 검증이 끝나기 전에 추론 요청 접수 | 특수 snapshot을 실제 선택하고 해당 플랫폼·단일 rank 등 지원 조건을 확인한다. 실제 사용하는 다중 프로세스·분산 실행 재배포와 구분한다. 상세 지원 조건은 기존 SC-20-04 기록을 함께 확인한다. | SC-20-04 |

 

**함께 확인할 보호 요구**

 

- [실제 사용의 무결성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-2-2): 실제로 읽거나 사용하는 자료가 현재 승인한 내용과 일치하는지 해당 점검에서 확인한다.
 
- [실행 상태·버퍼 수명](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-4): 참조의 사용 완료·해제·재사용 순서와 잔존 상태를 해당 점검에서 확인한다.

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 실행 상태 snapshot을 사용하는 복구**

 

이 선택 기능은 같은 Linux x86_64 호스트에서 사용하는 snapshot을 대상으로 한다. TP·PP·DP·PCP는 모두 1이어야 하고, 내용이 고정된 원격 모델인 immutable remote model과 40자리 revision을 사용해야 한다. 전송 방식은 인증·암호화가 없는 단일 HTTP 서버인 single unauthenticated plaintext HTTP를 전제로 한다. 기본 다중 GPU TP 구성에는 적용하지 않는다.

 

정상 create 경로는 `api_key`·`VLLM_API_KEY`, TLS, middleware, speculative decoding을 거부한다. 따라서 격리된 시험망과 외부 요청을 차단·허용하는 Gate를 사용한다. snapshot 생성 조건, 고정한 모델 revision, 실제로 사용하는 파일 목록·digest와 현재의 외부 승인 내용을 기록한다.

 

승인된 bundle로 snapshot create·rehearsal·restore를 수행한다. 복구한 내용을 현재 승인과 대조하고 대표 정상 요청까지 확인한 뒤 Gate를 연다. 복사한 시험 환경에서는 실제로 다시 로딩하는 대상에 무해한 대체 파일이나 누락을 만들어, 외부 파일 대조가 승인 불일치를 거부하는지 확인한다.

 

엔진의 결과 확인 절차인 oracle에서 mismatch가 발생한 경우는 별도 결과로 기록한다. oracle을 통과한 결과만으로 파일 일치를 판정하지 않는다. 기록된 generated cache의 변경·누락과 모델 파일의 변경은 서로 다른 시험으로 확인하고, manifest가 실제로 기록한 대상 범위 안에서 내장 fingerprint 검사의 효과를 판단한다.

 

listener가 열린 시각, oracle을 확인한 시각, 외부 Gate를 해제한 시각을 순서대로 기록한다. Gate가 차단된 동안 사용자 요청이 실제로 거부되는지도 확인한다. oracle이 실패하면 cleanup과 외부 요청 접수 차단이 이루어지는지 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 4.2.1 · 인쇄 99 / PDF 109](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=109) / [서비스 제공자 2.3.2 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97) / [서비스 제공자 4.2.5 · 인쇄 102 / PDF 112](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=112)

복구·백업과 저장 자료의 무결성 원칙을 스냅샷(snapshot)·파일 재읽기와 요청 접수 재개에 적용한다.

**OWASP ASVS:** [V14.2.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.5.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 복원 파일 검사·snapshot의 잔존 모델/자격/cache·재읽기·외부 접수 순서를 연결한다.

NIST CP-10도 상위 복구 근거다. ASVS의 무결성·검사/사용·fail-closed 원칙이 snapshot 기능 계약을 대신하지 않는다.

**NIST SP 800-53 Rev.5:** [CP-10](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [SI-7](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 알려진 상태로 복구하고 복원에 사용하는 정보의 무단 변경을 검출·처리한다.

**관련 위협 시나리오:** [SC-20-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-20-02) · [SC-20-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-20-04)

 

**관련 근거:** [Q-C12](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C12) · [Q-C09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C09) · [Q-R05-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-04) · [SC-20-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-20-02) · [SC-20-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-20-04)

