# CHK-PLT-005 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-005.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 인증정보가 없거나 만료돼도 승인하지 않은 다른 접근 방식으로 전환하지 않는가? · CHK-PLT-005

<a id="CHK-PLT-005"></a>
 
<a id="153-자격이-만료되거나-없을-때-승인하지-않은-다른-방식으로-접근하지-않는가"></a>
 
<a id="source-10-01339"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 선정 SDK·취득 주체가 만료·누락 자격을 처리하는 경로를 확인한다. 익명/대체 접근을 지원하면 해당 분기를 추가한다. |
| --- | --- |
| 권장 설정·조치 | 필수 자격이 없거나 만료되면 해당 취득을 보류하고 원인을 기록한다. SDK의 기본 자격·익명 접근·대체 경로를 조사해 승인하지 않은 신원으로 자동 전환되지 않게 한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 누락과 만료를 각각 시험하고 최종 접근 계정과 자료 취득 결과를 확인한다. 다른 인증정보 제공 경로·익명 접근·캐시 사용으로 전환되는지는 실제 동작으로 확인한다.<br>**정상 동작:** 유효 자격으로 승인 객체를 정상 취득한다. |
| 판정 기준 | 충족<br>허용하지 않은 자격·공급원으로 접근을 지속하지 않는다.<br>미충족<br>실패 후 승인되지 않은 identity·경로로 취득을 계속한다.<br>미확인<br>provider chain 또는 실제 fallback identity를 관측하지 못했다. |
| 남길 자료 | - 자격 선택 순서/최종 접근 identity/취득 대상·실패·fallback |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 자격 만료 뒤 승인하지 않은 대체 접근 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SC-24 · IA-5 · AC-3 — 일부 대응**

인증 실패 때도 보호 정책을 보존한다.

인증정보 부재·만료 후 익명·다른 계정·다른 취득 경로로 전환하는지 확인한다.

실패 시 기본 동작과 허용된 대체 경로를 명시한다.

 

**시험 준비**

 

격리된 시험 자격 사본과 만료 조건을 준비하고, 허용할 cache 사용 정책을 정한다.

 

**시험에서 확인할 내용**

 

인증정보가 없는 상태와 만료된 상태에서 최종적으로 사용한 인증정보의 출처, 접근 대상과 오류를 관측한다. 익명 접근으로 전환하는 fallback이 있다고 미리 가정하지 않는다.

 

**시험 순서**

 

1. 시험 자격의 만료·누락을 각각 적용한다.
2. 같은 자료의 취득을 재시도한다.
3. anonymous 접근, 다른 provider 또는 cache로 전환하는 fallback이 발생하는지 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 자격 만료·누락 후 승인되지 않은 접근 방식 사용 | 선정 SDK가 만료·누락 자격을 처리하며 익명·대체 자격 경로의 존재를 조사한다. | SC-14-02 |

 

**함께 확인할 보호 요구**

 

- [필수 검사 결과 집행](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-7-1): 인증정보 오류 뒤 선택한 identity·공급원을 기록한다. 접근을 거부했는지, 보류했는지, 허용된 대체 경로를 사용했는지도 함께 제공한다. 필수 검사 상태에 따른 운영 사용 결정은 CHK-SUP-014의 별도 결과다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94) / [개발자 4.2.3 · 인쇄 58 / PDF 68](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=68)

필요 권한만 부여하고 만료된 key를 회수하는 관련 원칙이 있다.

**OWASP ASVS:** [V13.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.5.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.5.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 인증정보를 사용할 수 없을 때 승인되지 않은 identity·경로로 우회하지 않고 안전하게 처리한다.

승인된 대체 자격은 정책에 따라 구분한다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 인증정보가 없거나 만료된 경우에도 승인된 접근 권한만 집행하는 요구와 연결된다.

**관련 위협 시나리오:** [SC-14-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-14-02)

 

**관련 근거:** [Q-R05-09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-09) · [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [SC-14-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-14-02)

