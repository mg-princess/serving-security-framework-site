# CHK-LIF-013 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-LIF-013.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 공유 가중치의 전체 해제 권한과 이후 재취득·참조 사용을 통제하는가? · CHK-LIF-013

<a id="CHK-LIF-013"></a>
 
<a id="444-공유-가중치-전체-해제-후-재취득대체-공급과-기존-참조의-사용이-승인접근수명-기준을-지키는가"></a>
 
<a id="source-10-03463"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | ipc_cache/preload 등 별도 weights daemon을 선택할 때 적용한다. 기본 TP 자체를 daemon 사용으로 간주하지 않는다. |
| --- | --- |
| 권장 설정·조치 | 별도 가중치 daemon을 사용하는 환경에서는 전체 release 권한과 허용 시점을 제한한다. 다른 사용 프로세스의 다음 취득·기존 참조 상태를 확인하고, fallback에는 승인한 공급물·접근 정책을 적용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | 별도 가중치 daemon을 사용하는 구성에서 세 결과를 나눠 확인한다. 누가 전체 해제할 수 있는지, 다른 소비자의 재취득·대체 공급이 승인 범위를 지키는지, 기존 copy·zero-copy 참조가 유효한 동안만 사용되는지 각각 기록한다.<br>**정상 동작:** daemon을 사용하지 않는 기본 TP와 별개로 선택 환경의 정상 취득·release를 확인한다. |
| 판정 기준 | 충족<br>release가 허용된 주체·범위에서 수행되고, 다른 소비자의 후속 취득·fallback이 승인 조건을 지킨다. 사용 중 참조를 잘못 해제하거나 폐기 참조를 재사용하지 않는다.<br>미충족<br>비허용 전역 release, 정책에 어긋나는 다른 소비자의 후속 취득·접근 실패, 승인 밖 fallback 소비 또는 참조 일관성 위반을 확인한다. native 참조 위반은 해당 효과의 별도 증거로 판정한다.<br>미확인<br>release 응답만 있고 다른 소비자의 후속 취득·fallback 소비 또는 기존 native 참조 효과를 확인하지 못했다. 확인하지 못한 분기를 다른 분기의 정상 결과로 대신 판정하지 않는다. |
| 남길 자료 | - daemon rank·model 범위/release 응답/후속 취득·소비·native 참조 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 전역 cache 해제로 다른 소비자의 참조 손상 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-LIF-13-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | 두 소비자의 zero-copy 참조와 전역 release 후 동작을 관측했다. | 수동 UNKNOWN이며 copy 경로·전체 모델·해제 권한·모든 소비자 참조는 미확인이다. |
| [GPU 20261106](../../../site/references/evidence/gpu-a-dev1-phase2-20261106.json)<br>`/runs/2`<br>부분 결과<br>기능 UNKNOWN · 성능 UNKNOWN · 보안 UNKNOWN | zero-copy 해제와 참조의 추가 UNKNOWN 기록이다. | copy 경로와 모든 소비자·권한·모델 반환은 미확인이다. |

### NIST 요구와 이 점검의 대응 범위

**AC-3 · SC-4 · SA-8(19) — 일부 대응**

공유 자원 접근과 상태 전환 중 권한을 유지한다.

가중치 daemon의 전체 해제 권한·다른 소비자의 재취득·zero-copy 수명을 나눠 본다.

전체 해제 인가·후속 공급 승인·참조 수명을 별도 결과로 보존한다.

#### 담당자와 시험 준비

| 시험 담당자 | 같은 공유 가중치를 사용하는 소비자를 둘 이상 준비하고, 각 소비자의 모델·세대·참조와 copy·zero-copy 사용 방식을 확인해야 한다. |
| --- | --- |
| 운영·보안 담당자 | 가중치 전체를 해제할 수 있는 주체와 해제 후 기존 참조의 처리 정책을 정하고, 권한이 있는 주체와 없는 주체의 해제 요청을 비교해야 한다. |
| 개발·계측 담당자 | 해제 전후의 기존 참조 사용·새 소비자의 재취득·fallback을 실제 가중치와 세대에 연결해야 한다. 정상 소비와 해제·재취득의 결과를 비교하고, 확인하지 못한 권한·참조·backend는 미확인으로 남겨야 한다. |

 

**시험 준비**

 

선택 기능인 데몬(daemon) 환경과 네이티브(native) 참조를 관측할 계측을 준비한다. 해제가 개별 핸들(handle) 단위로 이루어진다고 가정하지 않는다.

 

**시험에서 확인할 내용**

 

선택한 별도의 가중치 데몬(weights daemon)에서 두 소비자가 가중치를 정상 취득하게 한다. 이후 전체 해제(release)를 수행한 주체·범위·시점, 다른 소비자의 재취득·대체 공급(fallback), 기존 복사(copy)·무복사(zero-copy) 참조를 같은 실행의 기록으로 추적한다. 해제(release) 권한, 후속 공급과 기존 참조 수명에 관한 세 가지 필수 결과를 각각 남긴다. 실제 사용하는 다중 프로세스·분산 실행는 대상이 아니며 실제 daemon socket 신뢰·copy/zero_copy를 고정한다. copy 완료/실패 자동 release와 zero_copy 소비 중 release를 구분해 이후 요청·기존 CUDA IPC 참조·fallback을 관측한다. peer 접근은 CHK-PLT-002, 최종 payload 승인은 CHK-SUP-006, fallback reader는 CHK-SUP-012, 일반 작업/그룹 회수는 CHK-LIF-010·CHK-LIF-011과 관측을 공유하되 전체 release 전후 다른 소비자의 상태 전이를 이 행에서 판정한다. 근거 원문: [F05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f05--%EA%B3%B5%EC%9C%A0-%EA%B0%80%EC%A4%91%EC%B9%98-%ED%95%B4%EC%A0%9C%EC%99%80-%EB%A9%94%EC%8B%9C%EC%A7%80-%EC%B2%98%EB%A6%AC).

 

**시험 순서**

 

1. 실제 release 경로와 허용 주체·범위·시점을 확인한 뒤, 동일 daemon에서 시험 소비자 둘이 가중치를 정상 취득하게 한다.
2. 선정한 복사(copy)·무복사(zero-copy) 조건에서 데몬 전체를 해제(release)한다.
3. 각 소비자가 다음에 가중치를 취득하거나 대체 공급(fallback)을 받는 과정과 기존 참조를 사용하는 과정을 추적한다. 이를 현재 승인 조건과 참조 수명 기준에 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 공유 캐시 전체를 해제해 다른 작업의 가중치 사용 방해 | ipc_cache/preload 등 별도 daemon과 실제 release 경로를 사용한다. copy/zero-copy를 나눈다. | SC-16-04 |

 

**따로 기록할 결과**

 

| 결과 | 확인할 경우 | 충족 기준 |
| --- | --- | --- |
| 전체 release 권한 | 별도 weights daemon의 release 경로 사용 시 | 허용한 주체·범위·시점에만 전체 release가 수행된다. |
| 재취득·대체 공급 | 다른 소비자가 다시 취득하거나 fallback할 때 | 후속 취득·fallback이 승인한 공급물과 접근 조건을 지킨다. |
| 기존 참조의 수명 | copy/zero-copy 소비 중 참조가 남아 있을 때 | GPU 작업과 buffer 참조의 수명을 지킨다. 계측 부족은 해당 결과의 미확인으로 남긴다. |

 

**함께 확인할 보호 요구**

 

- [작업·대상 인가](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-2): 전체 release의 허용 주체·범위·시점이라는 필수 세부 결과를 판정한다. 다른 관리 작업의 역할 검사는 CHK-REQ-003과 구분한다.
 
- [실제 사용의 무결성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-2-2): release 뒤 다른 소비자의 재취득/fallback payload가 승인 공급물과 일치하는지 확인한다. 최초 적재의 일반 증거는 CHK-SUP-006과 공유한다.
 
- [종결·자원 회수](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-6-4): 전체 release 뒤 기존 copy/zero-copy 참조·GPU 작업의 수명을 확인한다. 일반 요청 종료·worker 그룹 자원 회수는 CHK-LIF-010·011의 별도 범위다.
 
- [복구 정책·상태 검증](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-7-4): release 뒤 재취득·대체 공급과 현재 승인/접근 상태를 대조한다. 배포 묶음을 되돌리거나(rollback) 백업(backup)을 복원할 때의 일반적인 복원 승인·적용 조건(gate)은 CHK-LIF-015·016에서 판정한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94) / [서비스 제공자 4.2.1 · 인쇄 99 / PDF 109](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=109)

모델 접근권한·복구는 이 복합 항목의 일부와 관련된다.

**OWASP ASVS:** [V1.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).weights daemon의 전역 release가 다른 소비자의 copy/zero-copy 참조·재취득·fallback에 미치는 영향을 확인한다.

권한·참조 수명은 기존 원칙이다. 실제 daemon·공유 방식의 계약과 세 필수 세부 결과는 별도 확인이 필요하다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 공유 가중치의 전체 해제 작업에도 승인된 접근 권한을 집행한다.

**관련 위협 시나리오:** [SC-16-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-16-04)

 

**관련 근거:** [Q-C13](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C13) · [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [Q-C12](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C12) · [SC-16-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-16-04)

