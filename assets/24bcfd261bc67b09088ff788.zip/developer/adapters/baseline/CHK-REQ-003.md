# CHK-REQ-003 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-003.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 일반 사용자에게 허용하지 않은 관리·진단 작업이 차단되는가? · CHK-REQ-003

<a id="CHK-REQ-003"></a>
 
<a id="123-일반-사용자가-허용받지-않은-관리진단-작업을-할-수-없는가"></a>
 
<a id="source-10-00660"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 관리 접점의 등록·노출·권한을 기본 확인한다. 진단·profiler 등은 활성 기능별로 추가한다. |
| --- | --- |
| 권장 설정·조치 | 관리·진단 API를 일반 추론 API와 구분해 작업별 허용 역할을 적용한다. 사용하지 않는 경로는 비활성화하거나 접근을 제한하고, profiler 등 선택 기능도 실제 실행 전에 권한을 검사한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 일반 계정과 관리 계정으로 실제 제공되는 관리·진단 API를 각각 호출한다. 응답과 실행 기록을 함께 확인해 허용된 역할만 해당 작업을 실행하는지 비교한다.<br>**정상 동작:** 관리 역할은 허용 작업을 수행하고 일반 호출자는 추론만 수행한다. |
| 판정 기준 | 충족<br>역할 범위 밖 작업이 수행되지 않는다. API key 존재만으로 역할 인가를 충족 처리하지 않는다.<br>미충족<br>일반 호출자가 금지 관리·진단 동작을 실행한다.<br>미확인<br>관리 작업·경로 목록이 불완전하거나, 실제 활성 작업에서 허용·거부와 작업 결과를 확인하지 못했다. 기능 비사용은 유효 설정·등록 및 노출 목록·소비 경로로 입증하고, 망 차단은 비허용 출발점의 실제 차단과 허용 출발점의 정상 작업을 대조한다. 기능을 켜서 시험할 필요는 없다. |
| 남길 자료 | - route별 요구 역할/키·신원별 응답/실제 관리·진단 동작 |

### 세부시험과 구현 근거

#### 가중치·LoRA·dumper 작업의 실제 접근 권한

| 선정할 경로 | 수행·확인할 내용 |
| --- | --- |
| 등록·노출 조사 | SGLang의 POST /update_weights_from_tensor, /update_weights_from_disk, /load_lora_adapter_from_tensors와 /dumper/configure는 해당 판본에서 실제 등록되는지 먼저 확인한다. dumper는 DUMPER_SERVER_PORT와 배포의 라우팅·앞단 허용표를 대조한다. |
| 요청과 handler의 분리 | 허용 관리 역할의 정상 작업과 일반 역할·키 누락·잘못된 키의 무해 요청을 비교한다. HTTP 상태뿐 아니라 비허용 요청이 handler의 설정 변경·객체 해석·실행에 도달하지 않았는지 기록한다. handler 비동기 효과가 있으면 실제 작업과 다음 처리 시점도 확인한다. |

정상 처리와 금지 동작의 거부·실행 여부를 같은 환경·정책에서 기록해야 한다. 시험 자료·임시 권한·추가 기록 설정은 회수하고 승인 구성과 정상 요청을 다시 확인해야 한다. 원치 않는 코드 실행·파일 변경·송신이 관찰되면 시험을 중단하고 접수를 제한한 뒤 증거를 보존하고 승인된 구성으로 복구해야 한다.

관련 공개 기록: [CVE-2025-10164](https://cveawg.mitre.org/api/cve/CVE-2025-10164) · [CVE-2026-7304](https://cveawg.mitre.org/api/cve/CVE-2026-7304) · [CVE-2026-15969](https://cveawg.mitre.org/api/cve/CVE-2026-15969) · [CVE-2026-15971](https://cveawg.mitre.org/api/cve/CVE-2026-15971) · [CVE-2026-15976](https://cveawg.mitre.org/api/cve/CVE-2026-15976) · [CVE-2026-86793](https://cveawg.mitre.org/api/cve/CVE-2026-86793) · [CVE-2026-111391](https://cveawg.mitre.org/api/cve/CVE-2026-111391). [코드 실행 관련 공지와 적용 조건](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=rce-path-reference)

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.5.5 특수 계정 및 권한 관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-5-5)<br>관리·진단 기능의 특수 계정·권한을 사용할 때<br>[공식 안내서 PDF 101쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=101) · 주요 확인사항 1,2 | **부분 대응**<br>관리·진단 API의 허용 역할과 비허용 역할의 실제 작업 수행 여부를 비교한다. | 관리자 계정·권한 목록, 최소 인원, 공식 신청·승인과 특수 계정 관리 절차의 실제 이행을 확인한다. |
| [2.6.3 응용프로그램 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-3)<br>서빙 애플리케이션이 사용자·역할별 작업이나 자료를 제공할 때<br>[공식 안내서 PDF 110쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=110) · 주요 확인사항 3 | **부분 대응**<br>일반 사용자에게 허용되지 않은 관리·진단 작업이 실행되지 않는지 확인한다. | [2.6.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-3) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 추론용 자격을 이용한 관리 API 실행 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/5`<br>부분 결과<br>보안 UNKNOWN · 기능 FAIL · 성능 UNKNOWN | 선정 관리 API 호출 기록이 있다. | 원문 security UNKNOWN·functional FAIL을 유지하며 허용 관리자와 비허용 주체를 추가 대조해야 한다. |

### NIST 요구와 이 점검의 대응 범위

**AC-3 · SC-2 · AC-6 — 요구 직접 대응**

일반 기능과 관리 기능을 분리하고 특권 작업을 제한한다.

관리·진단 API의 노출과 실제 실행 권한을 정상 추론과 구분한다.

진단 재실행은 OBS-007 조건부 하위시험으로 연결한다.

 

**시험 준비**

 

무해한 관리 호출을 선정하고, 활성화된 개발·동적 기능의 경로를 따로 표시한다.

 

**시험에서 확인할 내용**

 

인증정보가 없는 호출자, 일반 사용자와 관리자가 실제 등록된 각 경로(route)를 호출하게 한다. 각 작업의 응답과 실제 실행 여부를 역할별로 비교해 기록한다.

 

**시험 순서**

 

1. 실제로 사용할 수 있는 관리·진단 API 경로(route)를 목록으로 작성한다.
2. 일반 키와 관리 권한으로 같은 무해한 조회·진단 작업을 각각 호출한다.
3. 역할별 응답과 실제 관리·진단 작업의 수행 여부를 비교해 기록한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 추론용 키로 모델 변경·관리 작업 실행 | 관리 접점을 기본 조사하고, 진단 기능은 실제 등록·노출된 경로를 추가한다. | SC-01-03 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.4.2 · 인쇄 90 / PDF 100](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=100) / [개발자 4.2.4 · 인쇄 58 / PDF 68](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=68)

역할과 API 접속점(endpoint)에 따라 권한을 구분하고 민감한 작업을 제한하는 요구에 해당한다.

**OWASP ASVS:** [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 일반 사용자와 관리자 기능의 접근 권한을 구분한다.

진단 API도 기능별 인가를 적용할 대상이다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [SC-2](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 관리 기능과 사용자 기능을 구분하고 승인된 권한으로 접근을 제한한다.

**관련 위협 시나리오:** [SC-01-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-01-03)

 

**관련 근거:** [Q-C01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C01) · [SC-01-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-01-03)

조건부 하위시험: CHK-OBS-007

