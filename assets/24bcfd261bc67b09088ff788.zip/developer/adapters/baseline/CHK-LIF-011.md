# CHK-LIF-011 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-LIF-011.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### worker 장애 후 프로세스·통신·공유 자원을 정리하고 다시 기동할 수 있는가? · CHK-LIF-011

<a id="CHK-LIF-011"></a>
 
<a id="642-실패한-worker와-내부-통신공유-자원을-정리해-다음-기동이-가능한가"></a>
 
<a id="source-10-04609"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실제 사용하는 다중 프로세스·분산 실행 worker·통신·자원 회수와 다음 기동을 확인한다. Ray·PP는 사용 시 추가한다. |
| --- | --- |
| 권장 설정·조치 | 장애가 난 실행 그룹의 프로세스·IPC·GPU 관련 자원과 잔존 참조를 정한 기한에 정리한다. 정리 완료를 확인하고 새 실행 그룹의 기동·정상 요청을 시험한 뒤 서비스를 재개한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-resources) |
| 확인 방법 | 실패 전후의 프로세스·GPU·소켓·공유 메모리와 선택한 분산 실행 자원을 비교한다. 종료 함수 호출뿐 아니라 실제 회수와 같은 환경의 재기동·정상 추론을 확인한다.<br>**정상 동작:** 정상 종료 후 TP process·통신 자원을 정리하고 다시 기동한다. |
| 판정 기준 | 충족<br>정한 자원이 회수되고 후속 정상 기동이 가능하다. shutdown 호출만으로 완료 처리하지 않는다.<br>미충족<br>정한 회수 기한을 위반하거나, 잔존 자원 때문에 다음 기동·정상 요청이 실패한다.<br>미확인<br>자원 목록·소유자·기한 또는 실패 후 재기동을 확인하지 못했다. |
| 남길 자료 | - PID·rank·IPC 자원/cleanup 결과/재기동 준비·추론 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.9.2 성능 및 장애관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-2)<br>서비스의 용량·가용성과 장애를 관리할 때<br>[공식 안내서 PDF 141쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=141) · 주요 확인사항 3 | **부분 대응**<br>장애 뒤 프로세스·통신·공유 자원 정리와 후속 정상 기동을 확인한다. | [2.9.2 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-9-2) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### worker 장애 뒤 그룹 자원 정리 실패 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/8`<br>관련 관측 | worker 장애 전후 프로세스·공유 메모리 일부를 관측했다. | 컨테이너 종료 뒤 자원 목록을 확인하지 못해 그룹 전체 반환은 미확인이다. |

##### rank 준비 실패를 놓친 채 요청 수용 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**CP-10 · SA-8(24) · SC-6 — 일부 대응**

장애 후 알려진 상태로 복구하고 자원 가용성을 회복한다.

worker·IPC·GPU 잔존 참조 정리 후 같은 환경의 재기동·추론을 확인한다.

함수 호출이 아니라 회수 완료와 다음 기동 증거를 유지한다.

 

**시험 준비**

 

자원별 회수 기한을 정하고 시험 전후의 자원 목록을 수집한다.

 

**시험에서 확인할 내용**

 

격리 환경에서 초기화 또는 실행 중인 worker·그룹에 실패를 주입한다. 실패 전후 프로세스(process)·대기열(queue)·GPU·IPC·공유 메모리(shared memory), 선택한 actor·placement·DAG·channel의 목록과 소유자를 대조한다. 어떤 자원이 남았고 언제 반환됐는지도 확인한다. shutdown 호출 뒤 실제 자원 회수와 같은 시험 환경의 재기동·정상 요청을 확인한다. 실패 감지·상위 전달은 CHK-LIF-008, 초기 부분 실패의 집계는 CHK-LIF-009, 준비 후 접수 gate는 CHK-LIF-007에서 각각 판정한다. vLLM v0.31.0의 공통 근거 중 선정 executor·그룹 종료에 해당하는 조건을 참조한다. 근거 원문: [F32](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F32).

 

**시험 순서**

 

1. 격리된 worker에 실패를 주입한다.
2. 프로세스(process)·IPC·공유 메모리(shared memory)가 남아 있는지 조사한다.
3. 같은 시험 환경을 재기동하고 정상 요청을 보낸다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 모델 실행 프로세스 장애 뒤 그룹 자원 정리 실패 | 선정 executor/collective의 worker 감시·장애·그룹 회수 경로를 확인한다. | SC-18-02 |
| 일부 분산 프로세스가 준비되지 않았는데 요청 접수 | 기본 재시작·재배포에서 rank별 준비·부분 실패·정리를 확인한다. Ray/live는 선택 시만 추가한다. | SC-17-01 |

 

**함께 확인할 보호 요구**

 

- [실행 상태·버퍼 수명](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-4): 참조의 사용 완료·해제·재사용 순서와 잔존 상태를 해당 점검에서 확인한다.
 
- [기동 준비 확인](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-7-2): 필수 준비가 끝나기 전에 요청을 받지 않는지 해당 점검에서 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 4.2.1 · 인쇄 99 / PDF 109](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=109) / [서비스 제공자 4.1.2 · 인쇄 97 / PDF 107](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=107)

서비스 장애 복구·오류 대응을 실패한 worker/그룹의 자원 회수와 재기동으로 구체화한다.

**OWASP ASVS:** [V1.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V13.1.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.5.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 실패한 executor의 process·IPC·공유 메모리·GPU 자원 회수와 다음 기동을 연결한다.

각 자원의 소유자·반환 시점·다음 정상 추론을 실제 관측해야 한다.

**NIST SP 800-53 Rev.5:** [CP-10](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 장애 후 정한 시간 안에 알려진 상태로 복구할 수 있도록 한다. 자원 정리 후 재기동도 확인한다.

**관련 위협 시나리오:** [SC-18-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-18-02) · [SC-17-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-17-01)

 

**관련 근거:** [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [Q-C09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C09) · [SC-18-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-18-02) · [SC-17-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-17-01)

