# CHK-SUP-012 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-012.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 파일·메시지를 읽을 때 허용하지 않은 객체 생성이나 동작을 막는가? · CHK-SUP-012

<a id="CHK-SUP-012"></a>
 
<a id="331-실제로-사용하는-파일메시지-해석기가-금지된-객체나-동작을-거부하는가"></a>
 
<a id="source-10-02581"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 기본 모델·설정의 reader를 확인한다. 대체 파일·compiled cache·공유 daemon 메시지·직렬화 engine은 실제 소비 경로별로 추가한다. |
| --- | --- |
| 권장 설정·조치 | 실제로 읽는 파일·메시지 형식과 reader를 정하고 해당 reader·의존성의 검토된 버전을 사용한다. 허용하지 않은 형식으로의 자동 fallback을 제한하고, 해석 프로세스의 코드 실행·파일·통신 권한을 필요한 범위로 줄인다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 실제 사용하는 형식과 해석기에서 정상 자료·금지 객체를 나타내는 무해한 자료·손상 자료를 비교한다. 오류 뒤 다른 해석기나 자료로 전환하는 경로와 파일 접근·통신·코드 실행도 확인한다.<br>**정상 동작:** 선정 엔진에서 승인한 형식·reader·의존성 조합으로 정상 모델·설정 또는 메시지 자료를 처리한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다. |
| 판정 기준 | 충족<br>비허용 동작이 발생하지 않고 정상 공급물은 처리된다. PT 선택 자체를 코드 실행 결함으로 판정하지 않는다.<br>미충족<br>불허 reader·형식으로 조용히 fallback하거나 허용하지 않은 부수 동작이 발생한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.<br>미확인<br>확장자만 보거나 실제 reader·fallback·부수 접근을 관측하지 못했다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다. |
| 남길 자료 | - 파일 형식·magic·실제 reader/거부 또는 fallback 경로/실패 후 상태<br>- 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측 |

### 세부시험과 구현 근거

#### 실제로 사용하는 reader·해석기별 확인

| 선정할 경로 | 수행·확인할 내용 |
| --- | --- |
| 가중치 파일·의존성 | 실제 파일 형식·torch.load 호출·weights_only·PyTorch 버전과 실패 뒤 fallback을 기록한다. 옵션 이름뿐 아니라 최종 reader에서 금지 객체·부수 동작이 거부되는지 확인한다. 정상 파일·금지 객체를 나타내는 무해한 사본·대체 형식·손상 자료를 분리한다. |
| 관리 API의 tensor·LoRA 객체 | 실제 등록된 가중치·LoRA 경로와 사용 serializer를 확인한다. 허용된 관리 역할의 정상 작업과 무해한 비허용 객체를 비교하고 최종 reader의 global/class 허용 범위·중첩 reader·부수 동작을 기록한다. 접근 인가는 CHK-REQ-003의 결과와 함께 사용한다. |
| 내부 ZMQ·PickleWrapper | broker·scheduler·encoder·expert backup·diffusion·DP attention 중 실제 기능과 listener만 선정한다. 송신 주체에서 최종 decoder까지 추적하고, 외부 형식이 msgpack이거나 pickle IPC 옵션이 꺼져 있어도 내부 wrapper·frame이 pickle.loads에 전달되는지 확인한다. 비허용 peer의 접근 검사는 PLT-007·008과 증거를 공유한다. |
| 도구 호출·미디어·dumper 해석 | 모델이 만든 tool 인자, 실제 이미지·영상 bytes와 decoder, 선택 dumper의 filter 표현식을 각각 처리하는 함수를 확인한다. 정상 자료와 허용 밖 참조·동작을 표시한 무해한 시험 자료로 거부와 처리 범위를 비교한다. 모델 파일 reader의 통과 결과를 다른 해석기의 결과로 재사용하지 않는다. |
| 고정 판본의 관측 범위 | SGLang 0.5.21·22·23의 확인한 _maybe_unwrap_pickle에는 pickle.loads, _evaluate_filter에는 re.search·re.match를 제공하는 eval 호출이 남아 있다. 같은 판본의 SafeUnpickler.find_class는 정확한 global 허용표와 torch storage의 별도 reader를 사용한다. 함수 존재만으로 설치판 RCE를 확정하지 않고 실제 호출자·도달·권한·거부를 확인한다. |

정상 처리와 금지 동작의 거부·실행 여부를 같은 환경·정책에서 기록해야 한다. 시험 자료·임시 권한·추가 기록 설정은 회수하고 승인 구성과 정상 요청을 다시 확인해야 한다. 원치 않는 코드 실행·파일 변경·송신이 관찰되면 시험을 중단하고 접수를 제한한 뒤 증거를 보존하고 승인된 구성으로 복구해야 한다.

관련 공개 기록: [CVE-2025-24357](https://cveawg.mitre.org/api/cve/CVE-2025-24357) · [CVE-2025-32434](https://cveawg.mitre.org/api/cve/CVE-2025-32434) · [CVE-2025-29783](https://cveawg.mitre.org/api/cve/CVE-2025-29783) · [CVE-2025-32444](https://cveawg.mitre.org/api/cve/CVE-2025-32444) · [CVE-2025-30165](https://cveawg.mitre.org/api/cve/CVE-2025-30165) · [CVE-2025-47277](https://cveawg.mitre.org/api/cve/CVE-2025-47277) · [CVE-2025-9141](https://github.com/vllm-project/vllm/security/advisories/GHSA-79j6-g2m3-jgfw) · [CVE-2026-22778](https://cveawg.mitre.org/api/cve/CVE-2026-22778) · [CVE-2026-115915](https://cveawg.mitre.org/api/cve/CVE-2026-115915) · [CVE-2025-62164](https://cveawg.mitre.org/api/cve/CVE-2025-62164) · [GHSA-mcmc-2m55-j8jj](https://github.com/vllm-project/vllm/security/advisories/GHSA-mcmc-2m55-j8jj) · [CVE-2026-73557](https://cveawg.mitre.org/api/cve/CVE-2026-73557) · [CVE-2026-115912](https://cveawg.mitre.org/api/cve/CVE-2026-115912) · [CVE-2025-10164](https://cveawg.mitre.org/api/cve/CVE-2025-10164) · [CVE-2026-3059](https://cveawg.mitre.org/api/cve/CVE-2026-3059) · [CVE-2026-3060](https://cveawg.mitre.org/api/cve/CVE-2026-3060) · [CVE-2026-7301](https://cveawg.mitre.org/api/cve/CVE-2026-7301) · [CVE-2026-7304](https://cveawg.mitre.org/api/cve/CVE-2026-7304) · [CVE-2026-14890](https://cveawg.mitre.org/api/cve/CVE-2026-14890) · [CVE-2026-15969](https://cveawg.mitre.org/api/cve/CVE-2026-15969) · [CVE-2026-15971](https://cveawg.mitre.org/api/cve/CVE-2026-15971) · [CVE-2026-15976](https://cveawg.mitre.org/api/cve/CVE-2026-15976) · [CVE-2026-86793](https://cveawg.mitre.org/api/cve/CVE-2026-86793) · [CVE-2026-93088](https://cveawg.mitre.org/api/cve/CVE-2026-93088) · [CVE-2026-93034](https://cveawg.mitre.org/api/cve/CVE-2026-93034) · [CVE-2026-111391](https://cveawg.mitre.org/api/cve/CVE-2026-111391) · [CVE-2026-3989](https://cveawg.mitre.org/api/cve/CVE-2026-3989). [코드 실행 관련 공지와 적용 조건](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=rce-path-reference)

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.10.9 악성코드 통제](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-9)<br>엔진·주변 시스템의 악성코드 예방·탐지·대응을 관리할 때<br>[공식 안내서 PDF 173쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=173) · 주요 확인사항 1 | **부분 대응**<br>파일·메시지 해석에서 비허용 객체·동작이 발생하지 않는지 확인한다. | [2.10.9 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-10-9) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 모델 파일 역직렬화로 비승인 코드 실행 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 자동 파일 선택으로 승인 밖 형식 로딩 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 공유 공급 실패 뒤 승인 밖 파일로 전환 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 허용 client 메시지로 비허용 객체·명령 처리 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 실제 미디어 형식과 decoder 선택 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 공개 미디어 입력과 내부 SHM 객체 해석 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SI-10(6) · SI-10 · AC-6 — 요구 직접 대응**

비신뢰 자료가 코드·명령으로 실행되는 것을 막는다.

파일·메시지 해석기의 객체 생성·파일·통신·역직렬화 경로와 fallback을 시험한다.

형식 검증과 해석기 실행 권한 제한을 함께 유지한다.

 

**시험 준비**

 

격리된 손상 시험 자료와 파일 읽기를 관측할 방법을 준비한다. 공유 weight·replay는 자료를 읽어 사용하는 구성요소의 조건에 맞춰 따로 확인한다.

 

**시험에서 확인할 내용**

 

모델·설정·compiled cache·공유 daemon 등에서 파일·메시지를 실제로 읽어 사용하는 각 경로를 조사한다. 경로마다 승인된 형식·reader·의존성 판본을 고정한다. 정상 자료와 금지 형식의 자료, 허용 형식 안에서 금지 객체·부수 동작을 나타내는 무해한 fixture, 손상 자료를 각각 비교한다. 최종 reader와 fallback, 객체 생성 여부, 파일 접근·통신·코드 실행 등의 부수 동작을 확인한다. 공급원의 접근 자격 변경은 CHK-PLT-005, writer의 변조 가능성은 CHK-SUP-007에서 각각 판정한다. 템플릿 renderer는 CHK-SUP-013, 외부 진단 자료 consumer는 CHK-OBS-008의 고유 조건과 같은 reader 증거를 공유한다.

 

**시험 순서**

 

1. 실제로 적용된 형식 선택값, 파일·메시지의 식별정보와 reader를 기록한다.
2. 정상 자료, 금지 형식의 자료, 허용 형식 안에서 금지 객체·동작을 나타내는 무해한 fixture와 손상 자료를 각각 제공한다.
3. 자료가 거부되는지 또는 fallback·대체 공급원이 선택되는지 확인한다. 최종 reader, 객체 생성 여부와 파일 접근·통신·코드 실행 등의 부수 동작도 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 모델 파일을 읽는 과정에서 승인되지 않은 코드 실행 | 선정 loader/reader가 파일·객체를 해석한다. serialized engine·pickle/cache는 해당 reader 사용 시 추가한다. | SC-11-06 |
| 자동 파일 선택으로 승인되지 않은 형식 로딩 | 기본 loader의 후보 형식·대체 파일 선택을 조사한다. 원격 취득·daemon 비사용만으로 제외하지 않는다. | SC-13-02 |
| 가중치 공유 실패 후 승인되지 않은 파일로 전환 | 공유 weights daemon/공급원과 실제 fallback 분기가 선택된다. | SC-13-03 |
| 가중치 공유 메시지로 허용되지 않은 객체·명령 처리 | 별도 weights daemon의 실제 메시지·역직렬화 경로를 사용한다. 접근 가능한 peer/UID를 조사한다. | SC-16-02 |
| 실제 미디어 형식과 decoder 선택 | URL·data/base64·업로드·허용 로컬 파일에서 미디어 bytes를 해석하는 경로. 이미지·오디오·비디오별 실제 reader·의존성·외부 실행 프로그램과 fallback을 확인한다. weights reader와 따로 조사한다. |  |
| 공개 미디어 입력과 내부 SHM 객체 해석 | 공개 API나 분리형 generate가 받은 미디어 객체·직렬화 자료·참조가 내부 SHM 캐시와 worker reader로 전달되는 구성. 단순 내부 통신 비노출이나 insecure serialization 옵션 이름만으로 제외하지 않는다. |  |

 

**엔진별 확인 사항**

 

**파일 형식과 reader의 선택**

 

실제로 사용하는 reader, 파일 형식, 의존성 판본을 고정하고 정상 자료와 금지 객체를 나타내는 무해한 fixture를 비교한다. 설치된 torch 판본과 reader 옵션을 확인해 해당 구성의 동작을 판단한다. 과거 `weights_only` 취약점은 현재 설치판의 영향 여부를 별도로 확인한다.

 

정상 대조에서는 고정한 safetensors reader가 승인된 checkpoint를 읽을 수 있어야 한다. `load_format`과 파일 선택 패턴, 실제 reader를 기록한 뒤 금지한 형식과 무해한 손상 파일을 각각 제공한다. 다른 파일이나 reader로 전환하는 fallback·secondary source 경로가 있다면 최종 선택까지 확인한다.

 

**기본 loader의 후보 파일 선택 — SC-13-02**

 

팀의 고정 safetensors 설정과 `auto`·`hf` 선택 분기를 각각 시험한다. 승인된 safetensors 파일과 무해한 다른 형식의 파일이 함께 있는 fixture를 준비하고, 설정에 따라 어느 후보를 선택하는지 기록한다. 우선 사용하는 파일이 없을 때에도 최종 파일·reader와 승인 내용의 일치를 확인한다. 정상 대조에서는 승인된 safetensors만 있는 고정 형식 로딩이 성공해야 한다.

 

`load_format`, `allow_patterns_override`, `fall_back_to_pt`, 실제 선택한 파일·digest·reader와 적재·거부 결과를 남긴다. 승인되지 않은 후보 파일이나 팀에서 금지한 reader·형식을 실제 사용하면 미충족이다. 패턴 선택만 알고 실제 사용이나 승인 대응을 확인하지 못했다면 미확인으로 둔다. 파싱 실패 뒤 자동 retry가 발생하는지는 실제 경로에서 확인한다.

 

코드 근거는 `vllm/model_executor/model_loader/default_loader.py:154-225`이다.

 

**가중치 서비스 실패 후의 대체 로딩 — SC-13-03**

 

이 시험은 R08의 `ipc_cache`를 선택했고 실제 fallback 경로가 있는 경우에 적용한다. 실제 사용하는 다중 프로세스·분산 실행 시험과 구분한다. 격리한 daemon에서 승인된 weights를 정상 취득하는지 먼저 확인한 뒤, daemon을 사용할 수 없는 조건을 제한적으로 발생시킨다. 이어 `auto` DefaultModelLoader fallback에서 선택한 파일·형식·승인 상태·reader를 확인한다.

 

daemon 오류와 fallback 진입, fallback의 `load_format=auto`·extra config, 실제 대체 파일·reader·승인 내용을 기록한다. 주 공급원 실패 뒤 승인되지 않은 자료나 금지 형식을 사용하면 미충족이다. fallback이 활성화되어 해당 경로에 도달했는지, 어떤 대체 자료를 사용했는지 확인하지 못했다면 미확인이다.

 

코드 근거는 `vllm/model_executor/model_loader/weight_cache/ipc_loader.py:401-416`이다.

 

**daemon 메시지의 해석과 접근 권한 — SC-16-02**

 

선택한 daemon protocol에서 양쪽이 pickle 메시지를 읽는 방식과 실제 peer의 신뢰 범위를 확인한다. 정상 대조에서는 승인된 client와 daemon이 정상 형식의 무해한 메시지를 교환해야 한다.

 

socket에 접근하는 프로세스와 양방향 `recv_msg` 처리 경로를 찾는다. 다른 UID의 client와 같은 UID의 별도 client가 무해한 메시지를 보낼 때의 접근 결과를 비교하고, 허용한 serializer·명령·reader와 실제 처리 결과를 대조한다.

 

`SO_PEERCRED`의 지원 여부와 검사 실패 처리, socket 접근 결과, `pickle.loads`까지의 도달 여부, 허용 peer·명령·reader를 기록한다. 신뢰하지 않는 메시지가 허용된 신뢰 범위를 넘어 해석되거나 명령으로 실행되면 미충족이다. pickle을 사용한다는 사실만 확인되고 비신뢰 peer의 도달과 실제 메시지 처리를 확인하지 못했다면 미확인이다.

 

코드 근거는 `vllm/model_executor/model_loader/weight_cache/protocol.py:212-227,391-400`이다.

 

**멀티모달 경로의 세부 시험**

 

<a id="mm-decoder"></a>

 

**실제 미디어 형식과 decoder 선택**

 

**적용할 환경:** URL·data/base64·업로드·허용 로컬 파일에서 미디어 bytes를 해석하는 경로. 이미지·오디오·비디오별 실제 reader·의존성·외부 실행 프로그램과 fallback을 확인한다. weights reader와 따로 조사한다.

 

**확인할 환경 정보:**

 

- 표시 MIME·확장자와 실제 형식/signature
 
- 선택한 reader·decoder/backend·의존성 판본·fallback
 
- 임시 파일·업로드 파일의 경로, 접근 계정과 삭제 책임
 
- 외부 변환 프로그램의 설치·호출 조건과 권한

 

**정책과 담당·검사 위치:** 모델·운영 담당자는 허용 형식·decoder·부수 동작을 정하고 reader 담당자는 실제 bytes를 해석할 때 집행한다. 파일·장치·통신 권한은 PLT-001·PLT-007과 공유하고 비용은 LIF-003에서 판정한다.

 

**호출 권한과 실패 경계:** 허용 입력 경로로 미디어 bytes를 제출할 수 있는 호출자를 전제로 한다. 실제 내용이 승인하지 않은 decoder·외부 프로그램·fallback을 선택하게 하는 경계를 확인하며 필요한 의존성과 호스트 설치 조건을 함께 기록한다.

 

**정상 대조:** 허용 형식의 작은 정상 미디어가 승인된 decoder로 처리된다. 정상적으로 허용한 backend 전환도 그 조건과 결과를 대조한다.

 

**조건을 달리한 시험:**

 

- 작은 무해 미디어의 MIME·확장자와 실제 형식 중 하나를 다르게 지정하거나 손상된 자료를 사용하는 시험을 설계한다.
 
- 선정한 backend를 사용할 수 없거나 해석에 실패하는 조건에서 실제 fallback과 외부 프로그램 호출을 관측하도록 설계한다. 실행 gadget이나 취약 decoder exploit은 만들지 않는다.
 
- 업로드·임시 파일은 승인 경로에서 읽고 정리하는지 확인한다.

 

**필수 관측:**

 

- 원본 식별정보, 표시 형식과 실제 형식, 최종 reader·decoder와 의존성
 
- 실제로 선택된 경로와 fallback, 외부 프로세스 호출 여부, 파일 접근·통신 등의 부수 동작
 
- 허용·거부 위치·임시 파일 상태·후속 정상 미디어

 

**충족:** 실제 형식에 맞는 승인 reader만 사용하고 금지 객체·부수 동작을 제한한다. 손상·미지원 입력은 정한 범위에서 처리한다.

 

**미충족:** 금지 형식·reader·fallback이 실제 사용되거나 허용하지 않은 객체 생성·파일/통신/코드 부수 동작이 발생한다.

 

**미확인:** MIME 검사·HTTP 오류만 있고 실제 선택 decoder·외부 호출·부수 동작을 확인하지 못한 부분은 미확인이다. 오류 반환 뒤라도 이미 확인한 금지 동작은 미충족으로 유지한다.

 

**원복과 재시험:** 임시/업로드 파일·decoder 프로세스를 정리하고 정상 미디어 처리를 확인한다. 형식 허용표·dependency·backend/fallback·실행 이미지 변경 시 재시험한다.

 

**근거:** [형식 자동 선택과 의존성 조건](https://github.com/vllm-project/vllm/security/advisories/GHSA-h3rc-j82p-2c3h) · [고정판 이미지 reader](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/multimodal/media/image.py#L64-L108) · [고정판 오디오 backend](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/multimodal/media/audio.py#L407-L472)

 

<a id="mm-shm-reader"></a>

 

**공개 미디어 입력과 내부 SHM 객체의 경계**

 

**적용할 환경:** 공개 API나 분리형 generate가 받은 미디어 객체·직렬화 자료·참조가 내부 SHM 캐시와 worker reader로 전달되는 구성. 단순 내부 통신 비노출이나 insecure serialization 옵션 이름만으로 제외하지 않는다.

 

**확인할 환경 정보:**

 

- 공개 입력·인증 권한과 내부 객체/SHM 전달 경로
 
- 캐시 종류, 참조를 발급하는 주체, 주소·세대, 객체·키의 대응 관계
 
- worker reader의 실제 해석 방식·검사 위치·캐시 초기화 조건

 

**정책과 담당·검사 위치:** API와 SHM/worker 담당자는 외부 입력과 서버가 발급한 참조를 구분하고 출처·세대·허용 객체 범위를 검증한다. 특정 HMAC 방식 하나를 공통 필수 구현으로 정하지 않는다. daemon 메시지·모델 파일 reader와 별도 범위를 기록한다.

 

**호출 권한과 실패 경계:** 공개 미디어·분리형 요청을 보낼 수 있는 호출자를 전제로 한다. 공개 입력 객체가 서버의 SHM 캐시로 전달되는 경로를 따라 확인한다. 객체와 맞지 않는 참조가 worker의 객체 읽기·역직렬화 권한을 이용하는 데 사용되는지 시험한다.

 

**정상 대조:** 서버가 정상 발급한 미디어 참조가 해당 객체·현재 세대의 자료로 해석돼 정상 처리된다.

 

**조건을 달리한 시험:**

 

- 통제된 작은 정상 객체를 사용해 참조의 객체·키 대응, 주소 또는 세대 중 하나만 맞지 않도록 바꾼 시험을 설계한다.
 
- 공개 입력 검사와 worker의 참조 검사·객체 읽기 경계를 각각 관측한다. 임의 코드 실행용 객체는 제출하지 않는다.
 
- 캐시 초기화 뒤 이전 세대 참조가 처리되는 방식과 후속 정상 요청을 대조한다.

 

**필수 관측:**

 

- 공개 요청 ID·호출자·입력 객체와 서버 발급 참조
 
- 캐시 key·주소·세대와 검사 결과, worker에 도달했는지에 대한 기록
 
- 실제 SHM 읽기·역직렬화 함수와 허용하지 않은 부수 동작
 
- 초기화·원복 뒤 정상 요청 결과

 

**충족:** 허용된 서버 발급 객체와 현재 세대의 참조만 해석한다. 객체와 맞지 않는 참조는 허용되지 않은 객체를 사용하기 전에 제한한다.

 

**미충족:** 출처·세대·객체 범위를 위반한 참조가 해당 검사 지점을 넘어 해석되거나 허용하지 않은 객체·부수 동작이 발생한다.

 

**미확인:** 상위 API 거부만 확인하고 선정 worker reader로 이어지는 경로·검사 위치를 확인하지 못한 부분은 미확인이다. 객체 사용·부수 동작에서 이미 확인한 위반은 다른 관측의 누락과 구분한다.

 

**원복과 재시험:** 시험 객체·SHM 캐시·관련 프로세스 세대를 원복하고 새 정상 참조로 처리를 확인한다. 공개 객체 schema·참조 검증·캐시 초기화·serializer 변경 시 재시험한다.

 

**근거:** [공개 입력→SHM→worker 공지](https://github.com/vllm-project/vllm/security/advisories/GHSA-6757-hggm-hp2w) · [고정판 feature 객체 해석](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/entrypoints/scale_out/token_in_token_out/mm_features.py#L109-L140) · [고정판 SHM reader](https://github.com/vllm-project/vllm/blob/db9527a46873454610df6dbedf79a36d6bf1a7f6/vllm/distributed/device_communicators/shm_object_storage.py#L375-L400)

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [부록 2.3 · 인쇄 170·171 / PDF 180·181](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=180) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

부록은 다운로드한 ML 아티팩트의 역직렬화를 통한 임의 코드 실행 위험을 직접 설명한다.

**OWASP ASVS:** [V1.5.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 비신뢰 자료의 안전한 역직렬화와 위험한 reader의 보호라는 일반 요구다.

파일·메시지 형식별 fallback·부수 동작 확인은 실제 reader 적용 범위를 확인하는 절차다.

**NIST SP 800-53 Rev.5:** [SI-10](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [AC-6](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 파일·메시지 입력의 유효성을 검사하고 해석 프로세스에 필요한 권한만 허용한다.

**관련 위협 시나리오:** [SC-11-06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-06) · [SC-13-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-13-02) · [SC-13-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-13-03) · [SC-16-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-16-02)

 

**관련 근거:** [Q-R05-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-07) · [Q-R05-11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-11) · [Q-C13](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C13) · [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [SC-11-06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-06) · [SC-13-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-13-02) · [SC-13-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-13-03) · [SC-16-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-16-02)

