# CHK-OBS-003 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-OBS-003.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 로그·진단·추적·덤프에 수집을 허용한 정보만 남기는가? · CHK-OBS-003

<a id="CHK-OBS-003"></a>
 
<a id="521-로그진단추적덤프-파일에-허용된-정보만-남기는가"></a>
 
<a id="source-10-03612"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 기본 로그·엔진 예외 dump의 필드·독자를 확인한다. debug·trace·profiler는 실제 활성 경로별로 추가한다. |
| --- | --- |
| 권장 설정·조치 | 로그 수준·오류·debug·trace·dump별 허용 필드를 정하고 기록 생성·수집 단계에 필터를 적용한다. 합성 민감 표식으로 원본·사본을 확인하고 불필요한 본문·자격정보 기록을 제거한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-data) |
| 확인 방법 | 정상 요청과 안전한 오류 요청에 합성 표식을 넣고 실제 기록을 확인한다. 로컬 원본과 회전 파일·수집기 이후 사본을 구분하고, 추가 진단 수준은 활성화한 경우에 확인한다.<br>**정상 동작:** 허용 로그 수준에서 고유 무해 표식 요청이 승인한 필드만 남긴다. |
| 판정 기준 | 충족<br>금지한 필드·문맥을 수집하지 않고 필요한 사건은 남긴다.<br>미충족<br>금지 민감 필드가 기록되거나 수집 목적 밖 사본에 포함된다.<br>미확인<br>오류 분기·선택 로그 수준·원본 파일을 확인하지 못했다. |
| 남길 자료 | - 활성 로그·dump 설정/실제 필드·표식/원본과 사본 필터 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.9.4 로그 및 접속기록 관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-4)<br>운영 로그·접속기록을 생성·수집·보관할 때<br>[공식 안내서 PDF 145쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=145) · 주요 확인사항 1 | **부분 대응**<br>정한 로그 유형·필드에 따라 필요한 사건을 남기고 비허용 정보의 수집을 제한한다. | [2.9.4 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-9-4) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 로그 읽기 권한으로 비공개 입력 사본 열람 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261023](../../../site/references/evidence/automation-phase1-20261023.json)<br>`/all_eight/checks/0`<br>부분 결과<br>UNKNOWN · PASS | CPU 실제 실행에서 로그 관측 일부가 수집됐다. | 원문 security UNKNOWN과 빠진 log/dump 사건을 유지한다. 반환 응답 노출 시험으로 로그 사본의 보호를 대신하지 않는다. |

##### 반환 옵션·오류를 이용한 입력·내부 정보 노출 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**AU-3(3) · AC-4 · IA-5 — 일부 대응**

감사 기록의 개인정보를 제한하고 비밀정보·정보 흐름을 보호한다.

입력·가중치·자격 표식을 기본 로그·덤프·회전 파일·수집 사본에서 확인한다.

AU-3(3)은 개인정보 범위다. 모든 비밀정보 최소 수집의 동등 조항으로 확대하지 않는다.

 

**시험 준비**

 

실제 민감정보 대신 시험용 표식을 만들고, 수집을 허용한 필드 목록을 준비한다. shape·anon_repr처럼 정제한 표현과 실제 프롬프트 원문을 구분해 확인한다.

 

**시험에서 확인할 내용**

 

시험용 민감정보 표식을 넣은 정상 요청과 안전한 오류 요청을 보내 기본 로그와 예외 덤프를 수집한다. debug·trace·profiler를 사용하면 해당 경로의 기록도 수집한다. 원본, 회전된 로그 파일, collector를 거친 사본마다 필드·주변 문맥·마스킹·필터가 수집 정책을 지키는지 확인한다. shape·anon_repr로 정제한 표현과 원문 필드를 구분해야 하며, collector의 필터와 별개로 로컬 원본도 확인해야 한다. 반환 옵션·echo·logprobs·오류 입력은 CHK-REQ-013과 같은 시험에서 사용할 수 있다. 입력이 남긴 기록의 필드·문맥은 이 항목에서, API 응답에 포함된 정보는 CHK-REQ-013에서 각각 판정한다. 같은 로그·덤프 파일의 조회·반출 권한과 저장 암호화는 CHK-OBS-006에서 판정한다. 로그·예외 덤프의 생성 조건은 [로그·예외 dump 생성 조건](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=log-dump-evidence)을 참조한다.

 

**시험 순서**

 

1. 정상·안전한 오류 요청에 표식을 포함한다.
2. 기본 exception dump와 선택 기능인 debug/trace를 각각 수집한다.
3. 원본·collector 사본의 필드를 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 로그 읽기 권한으로 비공개 입력 사본 열람 | 기본 로그·예외 dump·저장 기록을 확인하며 debug/진단 사본은 실제 생성 조건으로 추가한다. | SC-21-02 |
| 응답 옵션·오류 메시지로 비공개 입력·내부 정보 노출 | 일반/stream 응답·오류를 기본 확인하고 반환 옵션은 지원·수용/거부와 실제 필드별로 추가한다. | SC-21-01 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 3.1.2 · 인쇄 93 / PDF 103](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=103) / [서비스 제공자 2.3.3 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97) / [개발자 4.2.2 · 인쇄 57 / PDF 67](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=67)

API key·토큰 등 중요정보를 로그에서 제거하거나 분리하고, 수집을 최소화하거나 익명화하는 요구와 대응한다.

**OWASP ASVS:** [V14.1.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 민감정보의 수집 금지·필드 제한·마스킹을 확인한다.

덤프(dump)·추적 기록(trace)·profiler 결과와 수집기(collector)를 거치기 전후의 사본을 확인 대상으로 삼는다.

**NIST SP 800-53 Rev.5:** [AU-3(3)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [IA-5](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 감사 기록의 개인정보를 정한 항목으로 제한하고 인증정보의 무단 노출을 방지한다.

**관련 위협 시나리오:** [SC-21-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-21-01) · [SC-21-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-21-02)

 

**관련 근거:** [Q-C11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C11) · [SC-21-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-21-02) · [SC-21-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-21-01)

