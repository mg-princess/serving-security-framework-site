# CHK-PLT-002 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-002.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 같은 호스트의 내부 통신에 허용된 프로세스만 접속할 수 있는가? · CHK-PLT-002

<a id="CHK-PLT-002"></a>
 
<a id="142-같은-호스트의-내부-통신-접점에-허용된-프로세스만-접근하는가"></a>
 
<a id="source-10-01093"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | API/core/worker가 실제 사용하는 로컬 IPC 경로와 접근 가능한 주체를 확인한다. |
| --- | --- |
| 권장 설정·조치 | 로컬 socket·공유 메모리와 이를 생성하는 디렉터리의 소유자·권한을 제한한다. 허용 프로세스가 사용할 접점과 명령 범위를 확인하고 비허용 계정의 읽기·연결·명령 전달을 차단한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 실제 소켓·공유 메모리·내부 TCP 접점을 식별하고 허용·비허용 프로세스의 접속을 비교한다. 파일 권한 설정뿐 아니라 실제 연결과 메시지 처리 여부를 확인한다.<br>**정상 동작:** 승인 core·worker가 IPC를 통해 정상 요청을 수행한다. |
| 판정 기준 | 충족<br>채널별 정책이 요구하는 연결·열기·자료 읽기/쓰기·명령 수용의 접근 제한을 지키고 허용 프로세스의 정상 IPC 작업은 유지된다. 연결 가능성, 보호 자료 접근, 명령 소비의 결과를 구분해 기록한다.<br>미충족<br>채널 정책이 금지한 비허용 프로세스의 연결·열기·보호 자료 읽기/쓰기 또는 명령 수용이 실제 성립한다.<br>미확인<br>파일 mode만 확인하고 namespace·상위 디렉터리·실제 접속을 확인하지 못했다. |
| 남길 자료 | - IPC 주소·소유자·mode/실제 process UID/연결·열기·작업 영향 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 로컬 socket 접근을 통한 내부 제어 침입 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**AC-3 · SC-39 — 요구 직접 대응**

내부 자원 접근을 승인된 프로세스에 제한한다.

같은 호스트의 IPC·소켓 접속 주체와 실제 연결 결과를 확인한다.

TCP 통제와 파일·IPC 권한을 따로 시험한다.

 

**시험의 검출 능력 확인 예**

로컬 socket·공유 메모리는 파일·IPC 접근 권한을 확인한다. 내부 TCP 경로에서 네트워크 정책을 대조할 때는 다른 인증층이 계속 차단할 수 있으므로, 접속 도달·상대 인증·작업 인가를 구분해 관측한다.

 

**시험 준비**

 

IPC 종류별로 무해한 연결 시험 자료를 준비한다. 임의로 구성한 역직렬화 payload는 사용하지 않는다.

 

**시험에서 확인할 내용**

 

허용된 시험 프로세스와 허용되지 않은 시험 프로세스에서 각각 연결하고 메시지를 보낸다. 연결·메시지 수용 결과를 대조하고 소켓·SHM 권한을 기록한다.

 

**시험 순서**

 

1. 실제 socket·shared memory·TCP IPC 목록을 확보한다.
2. 허용되지 않은 시험 UID로 연결하거나 자원을 여는 작업을 시도한다.
3. 허용 주체와 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 로컬 소켓에 접속해 내부 제어 기능 호출 | 실제 socket·SHM 등 로컬 IPC 경로가 있고, 해당 경로에 접속하는 peer의 접근 권한을 확인한다. | SC-08-01 |

 

**함께 확인할 보호 요구**

 

- [통신 접근·송신 제한](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-6): 로컬 IPC에서 허용되지 않은 peer의 접속과 자료·명령 접근이 제한되는지 확인한다. 외부 목적지와 송신 작업의 허용 범위는 CHK-PLT-007에서 판정한다.

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 로컬 통신 접근 권한**

 

실제로 사용하는 `RPC_BASE_PATH`와 socket·SHM의 소유자·mode·mount namespace를 확인한다. 해당 경로에 접근할 수 있는 프로세스의 PID와 UID도 기록한다.

 

허용된 프로세스, 같은 UID를 쓰지만 허용되지 않은 프로세스, 다른 UID의 허용되지 않은 프로세스에서 각 통신 채널에 접속하고 무해한 메시지를 보내 본다. 접속 가능한지, 메시지가 수용되는지, 임의 명령 실행까지 가능한지는 각각 구분해 확인한다.

 

OS 권한·namespace와 실제 채널 사용 결과를 증거로 남긴다. 정상 대조에서는 허용된 프로세스의 TP 요청이 처리되어야 하며, 그 과정의 채널별 연결·사용 기록을 확보한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

모델 환경의 비인가 접근 방지·격리 원칙을 같은 호스트의 내부 IPC에 적용한다.

**OWASP ASVS:** [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V13.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 로컬 서비스 접점의 허용 프로세스·객체 접근을 확인한다.

socket·SHM 접근 제한이 OS에서 실제로 적용되는지 확인해야 한다. 로컬 IPC 접근통제는 일반 SW에도 적용되는 점검이다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 내부 자원에 대한 접근도 승인된 권한에 따라 제한한다. 같은 호스트의 실제 IPC·소켓 접속을 확인한다.

**관련 위협 시나리오:** [SC-08-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-01)

 

**관련 근거:** [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [SC-08-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-01)

