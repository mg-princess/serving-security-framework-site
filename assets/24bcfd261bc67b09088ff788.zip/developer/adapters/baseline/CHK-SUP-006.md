# CHK-SUP-006 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-006.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 각 worker가 자신에게 배정된 승인 모델 파일·shard를 실제로 적재하는가? · CHK-SUP-006

<a id="CHK-SUP-006"></a>
 
<a id="222-각-worker가-배정받은-승인-모델-파일shard를-실제로-메모리에-올리는가"></a>
 
<a id="source-10-01839"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 기본 worker 적재는 항상 확인한다. 공유·원격 weights를 사용하면 publisher·model·rank·generation·layout·payload 대응을 추가한다. |
| --- | --- |
| 권장 설정·조치 | 각 worker·rank가 읽을 승인 파일과 담당 shard를 기록하고 실제 적재 결과와 대조한다. 필수 부분이 없거나 다른 모델·버전이 적재되면 준비 완료로 처리하지 않고 원인을 해소한 뒤 정상 추론을 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-supply) |
| 확인 방법 | worker별로 읽은 파일, 필요한 tensor와 변환·후처리 결과를 확인한다. 공유·원격 가중치를 사용하면 배포 주체·모델 세대·배치 형식과 실제 적재된 내용까지 대조한다.<br>**정상 동작:** 완전한 checkpoint로 필요한 모든 TP rank가 자신에게 배정된 부분을 로딩한다. |
| 판정 기준 | 충족<br>필요한 worker의 실제 적재 대상이 승인 내용과 일치한다. 공유·원격 weights를 사용하면 승인된 model·rank·generation·layout의 payload가 실제 적재돼야 한다. 전체 접수 준비·재개는 7.2 기동 준비 확인의 CHK-LIF-007·CHK-LIF-009에서 별도로 판정한다.<br>미충족<br>필수 배정 부분이 없거나 승인과 다른데 정상 적재로 인정한다.<br>미확인<br>모델별 필수 tensor·의도된 후처리 생성값 또는 rank 소비 기록을 알 수 없다. 공유·원격 weights에서 key·header만 확인하고 payload의 실제 적재를 확인하지 못한 경우도 포함한다. |
| 남길 자료 | - rank·shard·mapper·변환 설정/필수 tensor 정의·tracking 반환/로딩 완료 또는 거부. 공유·원격 weights 사용 시 publisher·세대·layout·payload와 실제 적재의 대응도 확보한다. |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 가중치 누락·변환 변경으로 승인과 다른 모델 제공 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 가중치 payload 교체로 모델·세대 혼입 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SI-7 · CM-2 — 일부 대응**

사용 정보의 무결성과 기준 구성 일치를 유지한다.

worker·rank가 담당 shard·tensor를 실제 적재했는지 변환 후 결과까지 확인한다.

파일 검증에서 GPU 적재 내용으로 넘어가는 추가 증거를 유지한다.

#### 담당자와 시험 준비

| 모델·파일 담당자 | 승인한 파일·shard와 배정 worker/rank의 대응표를 준비해야 한다. |
| --- | --- |
| 개발·계측 담당자 | 각 worker가 실제 읽은 파일과 적재 완료를 같은 실행 식별정보로 연결해야 한다. |
| 시험 담당자 | 필수 부분이 빠진 사본과 정상 모델을 구분해 비교해야 한다. health·파일 존재만 확인한 범위는 적재 확인과 구분해야 한다. |

 

**시험 준비**

 

모델과 양자화 방식별로 반드시 적재해야 할 tensor의 기준을 정한다. 각 rank의 실제 적재 결과를 관측할 방법도 준비한다.

 

**시험에서 확인할 내용**

 

필요한 각 node/rank에서 승인된 model·shard·필수 tensor를 확인한다. 실제 read/load 결과와 mapper·변환·후처리 결과를 승인 자료에 대응시켜 기록한다. 공유·원격 weights는 publisher·model·rank·generation·layout·payload의 실제 적재까지 대조한다. 경로명이 같거나 key·header가 일치한다는 사실, canary가 성공했다는 결과만으로 실제 적재 내용이 일치한다고 판정하지 않는다. 선정 model.load_weights 반환·양자화·enable_weights_track 유효값을 고정하고 완전 checkpoint와 필수 tensor 누락 fixture를 비교한다. 의도된 후처리 생성값과 누락을 구분한다. redirect 사용 시 최종 resolved 파일이 각 worker에 배정된 승인 대상과 일치하는지 기록한다. 전체 접수 준비·재개는 CHK-LIF-007·CHK-LIF-009의 판정과 연결한다. 근거 원문: [F33](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f33--%EA%B0%80%EC%A4%91%EC%B9%98-%EB%A1%9C%EB%94%A9%EA%B3%BC-%EB%88%84%EB%9D%BD-%EA%B2%80%EC%82%AC) · [F34](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F34).

 

**시험 순서**

 

1. 각 rank에 배정된 승인 자료와 정상 적재 결과를 기록한다.
2. 필수 tensor 일부가 없는 별도 시험 자료(fixture)로 기동한다.
3. 누락된 부분이 어떻게 처리되는지와 각 worker의 실제 적재·준비 상태를 확인한다. 전체 기동·접수 준비 결과는 CHK-LIF-007·CHK-LIF-009와 연결한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 가중치 누락·변환 차이로 승인한 모델과 다르게 실행 | 선정 모델을 worker에 적재한다. 양자화·mapper·후처리·live reload는 실제 선택 조건으로 구분한다. | SC-10-04 |
| 공유 가중치를 바꿔 다른 모델·실행 세대와 섞이게 함 | 공유·원격 weights의 model·rank·generation·layout·payload를 선택·적재한다. | SC-16-03 |

 

**엔진별 확인 사항**

 

**공유·원격 가중치의 실제 적재 — SC-16-03**

 

공유·원격 weights를 사용하는 경우에는 model, rank, generation, layout과 실제 적재된 payload를 연결해 확인한다. 정상 대조에서는 승인된 publisher가 제공한 동일 묶음의 자료가 배정된 rank와 layout에 맞게 적재되어야 한다.

 

먼저 정상 publisher의 payload가 어느 rank에 배정되는지 기록한다. 이어 무해한 시험 사본에서 model generation 또는 layout 식별값 하나를 바꾸고, header·key 검사 결과와 실제 tensor 적재 결과를 각각 확인한다. 적재된 내용이 승인 자료와 일치하는지도 대조한다.

 

publisher·key·header, 승인된 payload, rank·generation·layout, 실제 적재·거부 결과를 증거로 남긴다. 승인받지 않은 실제 자료나 잘못된 rank·세대·layout의 자료가 수용되면 미충족이다. key·header의 hash만 확인하고 payload와 실제 적재를 확인하지 못했다면 미확인이다.

 

기존 고정 코드 근거는 `vllm/model_executor/model_loader/weight_cache/protocol.py:251-340`이다. payload와 native 적재에 대한 실제 시험은 아직 수행하지 않았다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.2 · 인쇄 85 / PDF 95](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=95)

배포 전후 모델 상태 비교와 운영 중 무결성 확인 원칙을 분산 적재로 구체화한다.

**OWASP ASVS:** 이 점검의 주요 판정 기준에 해당하는 ASVS 조항은 확인되지 않았다. 승인한 파일이 각 rank의 배정 shard·필수 tensor와 실제 메모리 적재로 이어졌는지 확인한다.

NIST SI-7은 무결성의 상위 근거다. 변환·양자화 뒤 tensor 대응과 최소 적재 증거는 ASVS 조항만으로 확정할 수 없다.

**NIST SP 800-53 Rev.5:** [SI-7](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 정보의 무단 변경을 검출·처리하는 요구를 모델 적재 자료의 무결성 확인에 적용한다.

**관련 위협 시나리오:** [SC-10-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-10-04) · [SC-16-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-16-03)

 

**관련 근거:** [Q-R05-14](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-14) · [Q-C13](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C13) · [SC-10-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-10-04) · [SC-16-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-16-03)

