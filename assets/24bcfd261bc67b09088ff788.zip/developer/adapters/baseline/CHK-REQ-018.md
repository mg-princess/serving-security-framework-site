# CHK-REQ-018 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-018.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 요청 처리 자리를 옮기거나 다시 쓸 때 이전 요청의 제한 상태가 다음 요청에 남지 않는가? · CHK-REQ-018

<a id="CHK-REQ-018"></a>
 
<a id="441-batch-slot을-옮기거나-재사용할-때-이전-요청의-제한-상태가-남지-않는가"></a>
 
<a id="source-10-03264"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실제 runner의 batch 자리 이동·재사용 경로를 확인한다. V1 CPU mask 시험과 V2 상태/count 시험을 구분한다. |
| --- | --- |
| 권장 설정·조치 | 실제 runner가 관리하는 요청별 제한 상태를 batch slot 이동·교환·완료·재사용에 맞춰 갱신한다. 선택한 실행기의 이전 제한 상태를 초기화하고 최종 sampling에 사용되는 상태가 현재 요청의 것인지 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | batch slot 등 실행기가 재사용하는 단위를 확인한다. 요청 A가 사용한 자리를 B가 쓸 때 실제 적용한 제한 상태와 출력을 B의 단독 실행 결과에 대조한다.<br>**정상 동작:** 서로 다른 sampling 제한의 A·B를 새 실행 자리에서 각각 처리해 요청별 상태와 정상 출력 범위를 확보한다. |
| 판정 기준 | 충족<br>현재 요청의 mask·sampling 제한이 최종 계산에 반영되고 다른 요청의 제한을 상속하지 않는다.<br>미충족<br>다른 요청의 제한 상태가 현재 요청의 최종 계산에 적용되거나, 현재 요청에 필요한 제한이 누락·잘못 적용된 사실이 확인된다. 출력 변화와 후속 영향은 별도로 기록한다.<br>미확인<br>slot 재사용 또는 해당 runner 상태 갱신을 계측하지 못했다. |
| 남길 자료 | - 실제 실행기·요청 ID·재사용 단위/생성 세대와 현재 요청의 sampling 제한<br>- 이동·초기화·갱신 전후 상태, 최종 계산에 사용된 상태와 B 단독/재사용 시 결과 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 재사용 배치 자리의 토큰 제한 상태 혼입 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/engine-callback-cpu-20261102.json)<br>`/results/4`<br>부분 결과<br>COMPLETED · True | V1 슬롯 재사용과 출력 동작을 관측했다. | 선정 슬롯의 모든 제한 상태와 정상 대조를 추가 확인해야 한다. |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-18-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 PASS · 기능 UNKNOWN · 성능 UNKNOWN | 단일 L4의 선정 경로 결과를 연결했다. 정확한 실행 조건·판정은 각 원문을 따른다. | V1 경로의 결과다. V2 실행과 분리하고 제한 상태·정상 대조를 확인해야 한다. |

##### 재사용 배치 자리의 토큰 제한 상태 혼입 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-18-20261103.json)<br>`/runs/1`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | V2 수동 fixture의 기존 결과다. | 원문 UNKNOWN을 유지한다. V1 결과로 V2를 충족 처리하지 않는다. |

### NIST 요구와 이 점검의 대응 범위

**SA-8(20) · SC-4 — 설계 원칙 대응**

정확한 실행에 필요한 메타데이터와 공유 상태를 보호한다.

batch slot 이동·재사용 뒤 현재 요청의 mask·생성 제한이 최종 계산에 적용되는지 확인한다.

제한 상태 위반 자체와 실제 출력 변화를 별도로 기록한다.

 

**시험 준비**

 

시험할 실행기에서 요청별 sampling 제한 상태를 확인하고, 실행 자리를 재사용한 뒤 최종 계산에 어떤 상태가 적용되는지 추적할 방법을 준비한다. 제한이 없는 요청 B를 단독 실행한 결과도 비교 기준으로 확보한다.

 

**시험에서 확인할 내용**

 

선정 실행기가 관리하는 요청별 sampling 제한 상태와 재사용 단위를 식별한다. 요청 A의 종료·자리 이동 뒤 요청 B가 같은 단위를 사용하게 한다. 그때 최종 계산에 적용된 제한 상태와 허용 출력 범위를 B의 단독 실행 결과와 비교한다.

 

**시험 순서**

 

1. 실제로 사용하는 실행기(runner)를 확인한다.
2. 요청 A가 종료된 뒤 요청 B가 같은 실행 자리(slot)를 사용하도록 작은 배치를 실행한다.
3. B의 실제 제한 상태와 출력을 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 배치 자리를 재사용하며 이전 요청의 토큰 제한 적용 | 실제로 V1 runner를 사용하고 CPU mask가 할당된 condense 경로에 도달할 때. A 제한 요청 종료/이동 뒤 B의 동일 slot 재사용을 확인한다. | SC-06-01 |
| 배치 자리를 재사용하며 이전 요청의 토큰 제한 적용 | 실제로 V2 runner가 선택되고 해당 sampling 옵션이 소비될 때. slot·count/flag·staged write와 B의 무제한 정상 대조를 확인한다. V1의 시험 결과를 이 경로의 결과로 대신하지 않는다. | SC-06-01 |

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 V1과 V2 요청 상태 재사용**

 

기동 config와 실제 runner를 먼저 확인한다. 요청 ID가 어느 slot에 배정되는지와 mask의 이동·초기화를 관측하고, 제한이 있는 요청과 없는 요청을 각각 단독 실행한 결과와 비교한다. V1과 V2는 상태 갱신 경로가 다르므로 실제 runner에 맞는 시험을 사용한다. GPU 실행 시험은 아직 수행하지 않았다.

 

V1은 CPU mask가 할당된 condense 경로를 대상으로 한다. 제한이 있는 요청 A의 종료와 배치 이동을 시험하면서 mask 행의 이동과 원래 행의 초기화를 확인한다. 이후 요청 B의 mask와 새 slot에서 B만 실행한 결과를 비교한다.

 

V2는 실제 runner·사용 endpoint·유효한 effective sampling params를 기록하고, 무해한 token 집합 A와 B를 준비한다. 요청 A에 `allowed_token_ids` 또는 `logit_bias`·`min_tokens`-stop 조건을 부여해 정상 종료한 뒤, 해당 옵션이 없는 요청 B가 같은 slot을 재사용하도록 시험한다. `max_num_seqs=1`을 사용하거나 slot을 관측할 수 있는 다중 요청 환경을 사용하며, 바꾼 시험 설정을 기록한다.

 

새 엔진·새 상태에서 B만 실행한 정상 대조와 비교해 토큰 제한 적용, request→slot→idx mapping, count·flag 갱신을 확인한다. V1에서는 condense mask 분기를, V2에서는 slot·count 갱신 분기를 확인한다. V1의 CPU mask와 V2의 상태 배열은 각각 계측한다.

 

V1/V2 실행기(runner), 실행 자리(slot)와 생성 세대를 기록한다. mask·count·bias의 staged write 기록과 출력 결과도 남긴다. `allowed_token_ids`를 지원하는 endpoint나 내부 sampling 전달 경로를 확인하지 못한 분기는 미확인으로 둔다. 여러 요청의 순서를 바꾸거나 종료하고, 선점한 요청을 다시 추가하는 경우도 시험한다. 완료·취소 처리와 실행 자리(slot)의 재사용은 실제 기록으로 확인한다. HTTP 완료 응답만으로 slot이 해제됐다고 판단하지 않는다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.1.1 · 인쇄 82·83 / PDF 92·93](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=92)

동적 분석으로 동시성 문제·잘못된 출력을 확인한다는 방법론적 설명은 있다.

**OWASP ASVS:** [V8.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).batch condense·swap·slot 재사용 시 이전 요청의 제한 상태가 남는지 확인한다.

공식 단위시험의 조건과 실제 runner·GPU 전달·출력을 구분한다.

**관련 위협 시나리오:** [SC-06-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-06-01)

 

**관련 근거:** [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [Q-C04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C04) · [Q-C06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C06) · [SC-06-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-06-01)

