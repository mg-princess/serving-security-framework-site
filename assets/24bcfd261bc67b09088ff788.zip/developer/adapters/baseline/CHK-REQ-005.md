# CHK-REQ-005 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-005.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 호출자에게 허용된 모델만 실행되고, 사용을 종료한 모델은 실행되지 않는가? · CHK-REQ-005

<a id="CHK-REQ-005"></a>
 
<a id="124-최종-선택된-모델에-호출자의-사용-권한이-적용되고-사용-종료한-모델의-실행이-차단되는가"></a>
 
<a id="source-10-00715"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 모델 1개에서도 허용 대상을 확인한다. alias·adapter·공유 모델 소비는 실제 선택 시 추가한다. 모델을 사용 종료하거나 alias를 변경한 경우에는 이전 경로가 선택하는 최종 모델도 확인한다. |
| --- | --- |
| 권장 설정·조치 | 별칭·adapter·공유 가중치가 최종적으로 선택하는 모델을 확인하고 그 대상에 호출자의 사용 권한을 검사한다. 모델 선택 설정의 변경 권한을 제한하고 변경 이력을 남긴다.<br>- 사용 종료한 모델의 신규 실행을 중단하고 Gateway·엔진의 남은 route·alias를 현재 승인 대상과 대조한다. 공용 API를 유지할 때도 사용 종료 모델을 선택하지 않도록 설정한다. 기존 요청의 완료·중단과 자원 정리는 LIF에서 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 요청의 모델명·별칭·adapter가 최종적으로 선택한 모델과 호출자의 권한을 대조한다. 모델 사용 종료 후에는 이전 이름·주소·자격으로 실제 무엇이 실행되는지 확인한다. 다른 승인 모델을 가리키도록 별칭을 재사용한 경우도 구분한다.<br>**정상 동작:** 호출자가 허용된 활성 모델을 정상 사용한다. 사용 종료 시험에서는 다른 활성 모델과 현재 승인된 alias 매핑도 정상 동작한다. |
| 판정 기준 | 충족<br>호출자에게 허용된 모델·adapter만 실행되며 사용 종료한 모델은 실행되지 않는다. 공용 API·alias를 현재 승인된 다른 모델에 재사용하면 실제 선택 결과가 그 승인과 일치한다. 실제 파일의 승인 여부는 모델·소프트웨어 무결성 분야에서 판정한다.<br>미충족<br>허용되지 않은 최종 모델이나 adapter가 선택·사용된다. 사용 종료한 모델이 이전 이름·alias·직통 경로에서 계속 선택·실행된다.<br>미확인<br>API 표시명만 확인했거나 조건부 resolver·endpoint의 최종 대상을 모른다. 사용 종료 대상·기한 또는 실제 실행 모델을 확인하지 못했다. |
| 남길 자료 | - 역할×모델 허용표/선택값/최종 모델·adapter·실제 소비<br>- 모델 사용 종료 대상·승인 시각, Gateway·엔진의 route/alias 전후 값, 실제 선택·실행 모델, 활성 모델의 정상 응답 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.6.3 응용프로그램 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-3)<br>서빙 애플리케이션이 사용자·역할별 작업이나 자료를 제공할 때<br>[공식 안내서 PDF 110쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=110) · 주요 확인사항 1 | **부분 대응**<br>호출자에게 허용한 모델만 실제로 선택·실행되는지 확인한다. | [2.6.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-3) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 모델 선택값 변경을 통한 비허용 모델 실행 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261105](../../../site/references/evidence/gpu-b-phase1-status-20261105.json)<br>`/reused_evidence/14`<br>부분 결과<br>기능 UNKNOWN · 성능 UNKNOWN · 보안 UNKNOWN | 과거 증거를 재사용한 기록이며 새 GPU 실행은 0건이다. | 원문 FAIL·UNKNOWN과 재사용 범위를 유지한다. 현 구성의 전체 권한·소비 범위를 추가 확인해야 한다. |

##### 모델 별칭 변경을 통한 승인 대상 바꿔치기 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### daemon 접속으로 권한 밖 가중치 읽기 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**AC-3 · AC-3(8) — 요구 직접 대응**

대상별 접근 권한과 변경된 권한의 철회를 집행한다.

모델 별칭·최종 모델 선택과 사용 종료 뒤 실제 실행을 대조한다.

모델 서비스 종료와 인증정보 철회를 구분해 유지한다.

 

**시험 준비**

 

활성 endpoint별로 최종 선택 모델을 관측할 방법을 준비하고, 설치된 추가 기능만 시험한다. 사용 종료 모델은 시험 사본에서 확인하며, 사용 종료 정책·기한과 최종 실행 모델의 관측 방법을 정한다.

 

**시험에서 확인할 내용**

 

실제로 사용하는 접속점(endpoint)과 모델 선택 방식(selector)을 목록으로 작성한다. 이름 생략, 별칭, adapter, resolver 등 각 방식에서 호출자 신원, 제출한 선택값, 최종 모델·adapter와 사용 권한을 함께 추적한다. 허용·비허용 모델과 정상 호출을 비교한다. 모델 사용을 종료하거나 별칭(alias)이 가리키는 모델을 바꾼 경우에는 이전 이름·주소·인증정보로 호출한다. 실제 선택된 모델을 현재 승인 대상과 비교하고, 다른 활성 모델의 정상 처리도 확인한다. 멀티모달(MM) 기본 LoRA, resolver와 SageMaker adapter 주입은 실제로 설치하고 활성화한 경우에만 추가 점검한다. 외부 decorator가 처리하는 헤더(header)와 검증 절차는 확인한 범위를 기록한다. 최종적으로 선택한 adapter, 판본(revision)과 경로에 사용자 권한 검사가 적용되는지 확인한다. 파일·payload의 승인 일치는 CHK-SUP-003·CHK-SUP-005·CHK-SUP-006에서 별도로 판정한다. 근거 원문: [최종 모델·adapter 선택](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=model-selector-evidence).

 

**시험 순서**

 

1. 활성 모델 선택 경로 목록을 확보한다.
2. 표시명·adapter·대체 endpoint 선택값을 변경한다.
3. 최종 모델·파일 선택과 인가를 대조한다.
4. 시험 사본에서 모델 하나를 사용 종료 처리하고 이전 모델명·alias·주소·기존 자격으로 호출한다.
5. 실제 선택·실행된 모델을 확인하고 승인된 다른 활성 모델의 정상 처리와 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 모델 선택값을 바꿔 허용되지 않은 모델 실행 | 모델 선택 방식(selector)을 확인한다. adapter·resolver는 지원하고 활성화한 경우에 추가 점검한다. 모델 사용을 종료했다면 이전 선택 방식으로 호출했을 때 실제로 실행되는 모델도 확인한다. | SC-02-01 |
| 모델 별칭의 연결 대상을 바꿔 승인되지 않은 모델 제공 | 서비스 이름·alias·worker에 실제 모델을 연결하는 경로가 있다. 단일 모델도 포함한다. 사용 종료·재매핑 후에도 alias의 현재 승인 대상과 실제 실행을 대조한다. | SC-02-04 |
| 가중치 공유 서비스에서 권한 밖 모델 읽기 | 별도 weights daemon 또는 공유 모델 공급 구현을 사용한다. 실제 사용하는 다중 프로세스·분산 실행과 구분한다. | SC-16-01 |

 

**따로 기록할 결과**

 

| 결과 | 확인할 경우 | 충족 기준 |
| --- | --- | --- |
| 모델별 사용 권한 | 모델을 선택하는 모든 경로 | 호출자에게 허용된 최종 모델만 사용한다. |
| 사용 종료 모델의 실행 중단 | 모델 사용 종료·alias 변경 시 | 사용 종료 모델은 실행되지 않고 남은 route·alias는 현재 승인 대상과 일치한다. |

 

**엔진별 확인 사항**

 

**공유 가중치 서비스의 모델별 권한 — SC-16-01**

 

공유 weights daemon을 사용하는 경우, 가중치를 가져가는 consumer의 권한을 따로 확인한다. 이 consumer는 HTTP 요청을 보낸 사용자와 구분되는 실행 주체다. 정상 대조에서는 허용된 로컬 consumer가 승인된 모델의 weights를 가져올 수 있어야 한다.

 

시험할 consumer의 UID, socket 접근 권한, 모델별 허용 목록을 정한다. 같은 UID의 허용되지 않은 consumer와 다른 UID의 허용되지 않은 consumer로 무해한 취득 요청을 보내고, socket 접속 권한과 특정 모델의 가중치를 가져갈 권한을 각각 확인한다.

 

socket의 소유자·mode·peer UID, consumer와 모델의 허용 관계, 실제 attach·read 결과를 기록한다. 정책상 허용되지 않은 consumer가 가중치를 가져가면 미충족이다. 같은 UID인지 검사한 사실만 확인되고 모델별 권한 검사나 실제 attach를 확인하지 못했다면 미확인으로 남긴다.

 

코드 근거는 `vllm/model_executor/model_loader/weight_cache/protocol.py:212-227`이다. 관련 기준은 [KISA AI 보안 안내서](https://www.kisa.kr/2060204/form?postSeq=19&page=1)의 서비스 제공자 6.1.3, 인쇄 109쪽 / PDF 119쪽이다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94) / [서비스 제공자 6.1.3 · 인쇄 109 / PDF 119](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=119)

모델 접근 제한과 사용 종료 모델의 API/인터페이스 비활성화를 직접 다룬다.

**OWASP ASVS:** [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 최종 자원의 접근 권한과 철회 반영을 확인하는 일반 인가 요구다.

모델·adapter·alias는 대상과 참조 방식이다. 이를 확인했다는 이유만으로 별도 서빙 원칙으로 세지 않는다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [AC-3(8)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 대상별 접근 권한과 정한 철회 정책을 집행한다. 모델 사용 권한과 철회 후 실행 여부를 확인한다.

**관련 위협 시나리오:** [SC-02-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-02-01) · [SC-02-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-02-04) · [SC-16-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-16-01)

 

**관련 근거:** [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [Q-R05-14](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-14) · [Q-C13](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C13) · [SC-02-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-02-01) · [SC-02-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-02-04) · [SC-16-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-16-01)

