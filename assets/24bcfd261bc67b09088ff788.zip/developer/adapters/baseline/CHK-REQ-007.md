# CHK-REQ-007 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-007.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### chat template으로 변환한 뒤의 입력에도 필요한 제한이 적용되는가? · CHK-REQ-007

<a id="CHK-REQ-007"></a>
 
<a id="311-chat-template-적용으로-입력이-바뀐-뒤에도-필요한-제한이-유지되는가"></a>
 
<a id="source-10-02044"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 선정 endpoint가 template를 적용할 때 확인한다. 요청 template·kwargs 변경은 해당 필드를 수용할 때 추가한다. |
| --- | --- |
| 권장 설정·조치 | 요청이 지정할 수 있는 대화 템플릿·변환 인수를 제한한다. 템플릿을 적용한 뒤 실제 모델에 전달할 입력에 필요한 길이·내용·권한 검사를 적용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 원래 메시지와 실제로 선택한 대화 템플릿, 변환과 토큰화(tokenization)를 마친 입력, 검사 위치를 비교한다. 기본 템플릿과 요청에서 바꾸는 경로를 구분한다.<br>**정상 동작:** 정상 메시지는 승인 template 적용 후 허용 길이·내용 제한을 만족한다. |
| 판정 기준 | 충족<br>실제 입력이 채택한 제한을 우회하지 않는다. 모델과 함께 제공되는 템플릿의 출처와 실행 제한은 모델·소프트웨어 자료의 관련 점검에서도 확인한다.<br>미충족<br>검사 후 렌더링된 입력이 필요한 제한을 벗어나 소비된다.<br>미확인<br>렌더 후 입력·검사 위치 또는 허용 기준을 확인하지 못했다. |
| 남길 자료 | - 원 입력·template/렌더 출력·token 수/제한 적용 위치 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### chat template 변경을 통한 입력 검사 우회 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261023](../../../site/references/evidence/automation-phase2-20261023.json)<br>`/actual_cpu_runs/cases/0/selected_measurements/checks/1`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 PASS | vLLM CPU 선정 실행의 원래 판정과 측정을 보존했다. | 선정 정책·모델에 한정된다. 전체 분기 조건·정상 대조와 원 증거 묶음을 추가 확인해야 한다. |

##### 모델 template의 위험 동작·비용 유발 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SI-10 — 요구 직접 대응**

최종 처리 입력의 유효성을 검사한다.

대화 템플릿·토큰화 뒤 실제 모델 입력에 길이·형식 제한을 확인한다.

입력 시 검사와 변환 후 검사를 구분한다.

 

**시험 준비**

 

입력에 허용한 한도와 템플릿을 적용한 결과를 확인할 방법을 준비한다. 템플릿 코드의 안전성은 모델·소프트웨어 자료의 관련 점검에서 따로 확인한다.

 

**시험에서 확인할 내용**

 

서버 지정값, processor·tokenizer의 기본값과 내장 대체값(fallback) 중 어떤 템플릿이 실제로 선택됐는지 확인한다. 요청에서 템플릿을 덮어쓰는 경우(override)도 따로 확인한다. 각 경우의 원래 messages, 변환된 token, 실제 검사 위치와 거부 위치를 비교한다.

 

**시험 순서**

 

1. 정상 메시지에 실제로 선택한 템플릿을 적용하고 원 입력·렌더 결과·토큰화 결과를 기록한다.
2. 렌더링 뒤 입력이 늘어나는 무해한 시험 자료로 정한 제한의 경계를 확인한다.
3. 검사 시점과 실제 토큰화된 모델 입력을 비교해 제한이 적용된 위치와 거부·처리 결과를 남긴다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 대화 템플릿을 바꿔 입력 검사 우회 | chat/template 변환이 수행된다. 요청 템플릿·kwargs는 실제 수용 필드별로 추가한다. | SC-03-01 |
| 모델 템플릿으로 위험한 동작·과도한 자원 사용 유발 | 서버 지정값, processor·tokenizer 또는 대체값(fallback)으로 선택한 공급 템플릿을 실제 변환기(renderer)가 사용하는 경로를 확인한다. | SC-11-07 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.4.4 · 인쇄 52 / PDF 62](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=62) / [개발자 3.4.2 · 인쇄 50 / PDF 60](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=60)

입력 형식·범위·최대 token과 단계별 비용 제한을 실제 template 변환 뒤 소비값에 적용한다.

**OWASP ASVS:** [V1.1.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V2.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V2.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 입력 검증을 messages→선택 template→실제 model token으로 변환되는 사슬에 연결한다.

V1.1.1의 정규화/디코딩과 template 렌더링은 동일 작업이 아니다. 렌더링 뒤 소비값·길이 제한은 별도 경로 관측이 필요하다.

**NIST SP 800-53 Rev.5:** [SI-10](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 정한 입력의 유효성을 검사한다. 대화 템플릿과 토큰화 뒤 실제 처리 입력에도 필요한 검사를 적용한다.

**관련 위협 시나리오:** [SC-03-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-03-01) · [SC-11-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-07)

 

**관련 근거:** [Q-C04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C04) · [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [Q-R05-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-05) · [Q-C05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C05) · [SC-03-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-03-01) · [SC-11-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-07)

