# CHK-LIF-006 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-LIF-006.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 실행 중 모델 변경이나 순차 교체를 해도 각 요청의 모델·상태가 일관되는가? · CHK-LIF-006

<a id="CHK-LIF-006"></a>
 
<a id="732-실행-중-변경이나-순차-교체-중에도-각-요청의-모델상태가-일관되는가"></a>
 
<a id="source-10-05015"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | live weights·LoRA 변경·rolling·다중 replica 전환을 실제 사용할 때 적용한다. 기본 중단 재배포와 구분한다. |
| --- | --- |
| 권장 설정·조치 | 실행 중 변경·순차 교체를 선택한 환경에서는 요청이 사용할 모델·가중치·캐시의 버전을 구분한다. 변경 전 작업의 처리·공유 상태 무효화·새 버전 전환 조건을 적용하고 부분 변경 시 복구 절차를 둔다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-deployment-profile) |
| 확인 방법 | 실제로 사용하는 live 변경·rolling·다중 replica 경로에서 요청별 모델·가중치·캐시·반환 세대를 추적한다. 허용한 전환·라우팅 정책 아래 정상 변경과 제한된 부분 실패를 각각 비교한다.<br>**정상 동작:** 선정한 live weights·LoRA 변경 또는 rolling·다중 replica 전환에서 허용한 전이·라우팅 정책을 지키며 각 요청이 일관된 모델·상태로 정상 처리된다. |
| 판정 기준 | 충족<br>요청이 허용하지 않은 부분 갱신·세대 조합을 소비하지 않는다.<br>미충족<br>사용 환경에서 비호환 weight·cache·요청 상태가 섞인다.<br>미확인<br>선택 기능 사용 여부·전이 계약 또는 세대 대응이 미확인이다. |
| 남길 자료 | - live·rolling 활성 근거/weight·cache·요청 세대/변경 실패 상태 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.8.6 운영환경 이관](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-8-6)<br>새 시스템이나 변경 구성을 운영환경으로 옮길 때<br>[공식 안내서 PDF 137쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=137) · 주요 확인사항 1,2 | **부분 대응**<br>실행 중 변경·순차 교체의 요청·가중치·캐시 세대와 실패 처리 결과를 확인한다. | [2.8.6 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-8-6) |
| [2.9.1 변경관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-1)<br>엔진·모델·의존성·설정·정책을 변경할 때<br>[공식 안내서 PDF 139쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=139) · 주요 확인사항 1,2 | **보조 자료**<br>live·rolling 변경의 부분 갱신·세대 혼합과 실패 상태를 변경 영향 검토의 자료로 사용한다. | [2.9.1 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-9-1) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 실행 중 교체에서 weights·KV 세대 혼합 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/3`<br>관련 관측 | 과거 시험 범위의 잘못된 기동 구성을 관측했다. | 실행 중 weights·KV 교체와 세대 혼합 시험은 확보하지 못했다. |

### NIST 요구와 이 점검의 대응 범위

**CM-3 · SA-8(19) · SA-8(17) — 일부 대응**

분산·실행 중 변경에서도 보호 정책이 유지되도록 한다.

live 변경·rolling·replica 전환 때 요청별 가중치·캐시·반환 세대를 대조한다.

원자적 전환·drain·부분 실패 정책은 사용 기능에 맞춰 정한다.

 

**시험 준비**

 

실제로 지원하는 엔진과 변경 방식을 선정한다. 기본 구성에 live 변경 시험을 강제로 적용하지 않는다.

 

**시험에서 확인할 내용**

 

실제로 선정한 live weights·LoRA 변경 또는 rolling·다중 replica 전환에서 정상 변경과 제한된 부분 실패를 비교한다. 진행 중인 요청마다 실제 모델(model)·가중치(weights)·캐시(cache)·복제본(replica)과 반환 결과가 속한 세대를 추적한다. 이를 허용한 전환 방식과 라우팅 정책에 대조한다. 세션 잠금(lock)만으로 추론이 격리된다고 판단하지 않는다. LoRA·가중치 전송(weight transfer)·재로딩(reload)은 하나의 공통 청크(chunk) 절차로 합치지 않고 각각 확인한다. 기본 중단 재배포의 정상 대조는 CHK-LIF-005에서 유지하고, 이 기능을 사용하지 않는다고 판단하면 실제 적용 설정과 접근 경로의 근거를 적용 판단에 남긴다. vLLM v0.31.0의 공통 근거 중 선택 live/keep/collective_rpc·abort/wait/keep 및 모델·cache·요청 세대 조건을 참조한다. 근거 원문: [F32](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F32).

 

**시험 순서**

 

1. 실제로 활성화한 변경 경로와 지원 조건을 확인한다. 허용한 전환 방식, 세대 조합과 라우팅 정책도 확인한다.
2. 선정한 경로에서 정상 변경을 수행한다. 진행 중인 요청·가중치·캐시·복제본(replica)의 세대와 실제 사용 기록을 추적한다.
3. 같은 경로의 제한된 부분 실패를 주입하고 요청별 허용 세대·상태 일관성과 실패 처리를 정상 변경과 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 실행 중 모델 교체로 가중치·KV 캐시 세대 혼합 | 실행 중 weights/LoRA 변경·rolling·다중 replica 전환을 실제 사용한다. | SC-17-03 |

 

**함께 확인할 보호 요구**

 

- [요청·결과 귀속](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-1): 요청과 결과가 같은 사용자·모델·실행에 연결되는지 해당 점검에서 확인한다.
 
- [재사용 문맥의 호환성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-4-3): 재사용할 자료의 모델·입력·설정 문맥이 현재 요청과 호환되는지 해당 점검에서 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 5.2.1 · 인쇄 64 / PDF 74](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=74) / [개발자 5.2.3 · 인쇄 65 / PDF 75](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=75)

업데이트의 기능 영향 확인·단계적 적용을 live/rolling 모델 변경에 구체화한다.

**OWASP ASVS:** [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).live/rolling 변경 중 요청·weights·LoRA·KV의 비호환 세대 혼합을 확인한다.

실제 지원·사용하는 변경 방식과 동기화·전환 계약이 필요하다.

**관련 위협 시나리오:** [SC-17-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-17-03)

 

**관련 근거:** [Q-C09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C09) · [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [SC-17-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-17-03)

