# CHK-REQ-014 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-014.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 여러 프로세스가 나눠 처리한 중간 자료와 최종 결과가 원래 요청에 맞게 처리·반환되는가? · CHK-REQ-014

<a id="CHK-REQ-014"></a>
 
<a id="413-여러-실행-프로세스가-주고받는-중간-자료와-최종-출력이-원래-요청에-맞게-처리반환되는가"></a>
 
<a id="source-10-02972"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실제 사용하는 다중 프로세스·분산 실행 내부 전달을 확인한다. 다중 노드·PP·PD는 실제 구성에 포함될 때 별도 경로로 추가한다. |
| --- | --- |
| 권장 설정·조치 | 분산 단계마다 요청·모델 버전·중간 자료의 식별정보를 대조하고 최종 출력의 수신자를 확인한다. 지연·재전송·장애 때 다른 요청이나 모델 버전의 자료가 사용되지 않도록 전달·폐기 규칙을 적용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | 요청·모델·실행 세대와 rank별 중간 버퍼, 집계·출력 경로를 연결한다. 실제 사용하는 다중 프로세스·분산 실행과 선택한 다른 분산 경로를 구분하고, 허용한 지연·실패에서도 다른 요청의 자료가 섞이지 않는지 확인한다.<br>**정상 동작:** TP 처리에서 각 rank의 담당 계산·중간 상태와 선정 출력 rank·집계 경로의 최종 반환을 요청·모델·buffer에 연결한다. |
| 판정 기준 | 충족<br>실제 사용하는 구성에서 다른 요청/세대의 자료가 잘못 소비되지 않는다. TP/PP와 PD의 결과를 별도 기록한다.<br>미충족<br>다른 요청·모델 세대의 자료가 결과에 사용되거나 잘못된 요청으로 반환된다.<br>미확인<br>분산 중간 자료·세대·buffer 대응을 계측하지 못했다. |
| 남길 자료 | - request·model·generation ID/rank·buffer 전달/완료·회수·출력 연결 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 공유 권한을 가진 worker 침해의 영향 확대 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### GPU 프로세스 통신의 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### PD 전송 참조 조작으로 KV·완료 상태 오연결 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

분기에 직접 배정하지 않은 관측: [engine-callback-cpu-20261102.json](../../../site/references/evidence/engine-callback-cpu-20261102.json) `/results/0`. 중간 tensor·세대 계보가 없고 worker 침해·전송 변조·PD 참조 시험과 직접 맞지 않아 항목의 공통 관측으로 보관한다.

### NIST 요구와 이 점검의 대응 범위

**AC-4 · SC-4 · SA-8(17) — 일부 대응**

분산 구성에서도 정책에 맞는 정보 흐름을 유지한다.

worker·rank의 중간 자료와 최종 결과가 원 요청·실행에 귀속되는지 확인한다.

TCP·IPC·전송 계층 구분과 최종 lineage 증거를 유지한다.

 

**시험 준비**

 

실제 사용하는 다중 프로세스·분산 실행 경로부터 확인한다. PD 등의 선택 기능은 활성 조건을 확인하고 해당 경로의 추적 기능을 준비한 뒤 시험한다.

 

**시험에서 확인할 내용**

 

시험할 실행기(executor)에서 요청(request)·모델(model)·세대(generation)를 기록한다. 이 정보가 actor·rank, 중간 버퍼(buffer)·블록, 집계·출력 rank를 거쳐 최종 요청까지 일관되게 연결되는지 추적한다. 허용된 범위의 지연이나 실패를 발생시킨 뒤, 다른 요청·모델 세대의 자료를 잘못 사용하거나 반환하는지 실제 사용하는 분산 실행 결과와 비교한다. 실제 사용하는 다중 프로세스·분산 실행, 선택한 Ray·PP, PD·KV connector의 실제 처리 경로와 증거를 구분한다. 이전 구현(legacy)의 출력 rank 설명을 다른 실행기에도 그대로 적용하지 않는다. PD/NIXL을 선택하면 API의 kv_transfer_params/remote peer·block 메타데이터가 실제 요청·허용 peer·블록에 연결되는지 확인한다. 잘못된 참조의 거부와 정상 전송을 대조하며 전달 자체를 성공/취약점으로 단정하지 않는다. IPC에 접근할 권한, 함께 실행되는 구성요소 간 신뢰 범위와 통신 구간 보호는 CHK-PLT-002·CHK-PLT-006·CHK-PLT-008의 결과를 함께 확인한다. 근거 원문: [F18](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f18--kv-%EC%A0%84%EC%86%A1-%EC%A0%95%EB%B3%B4%EC%99%80-%EC%9B%90%EA%B2%A9-%EC%83%81%EB%8C%80).

 

**시험 순서**

 

1. 실제 사용하는 다중 프로세스·분산 실행 요청을 추적한다.
2. 안전한 지연·실패를 한 구간에 주입한다.
3. 중간 자료와 최종 결과의 귀속을 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 침해된 모델 실행 프로세스가 공유 권한으로 피해 확대 | core·worker의 실제 UID와 protocol, 서로 신뢰하며 실행하는 범위를 확인한다. 같은 UID로 실행하거나 pickle로 통신하는 내부를 각각 독립된 권한 검사 경계로 가정하지 않는다. | SC-08-02 |
| GPU 프로세스 사이 통신 도청·변조 | rank 간 local collective 또는 별도 다중 노드 전송을 사용한다. transport별로 분리한다. | SC-08-03 |
| PD 전송 정보를 바꿔 KV 캐시·완료 상태 잘못 연결 | PD 또는 KV transfer connector가 실제 지원·선택된다. 실제 사용하는 다중 프로세스·분산 실행과 별개이며 prompt_token_ids 입력 경로 전체와 동일시하지 않는다. | SC-08-04 |

 

**함께 확인할 보호 요구**

 

- [통신 상대·전송 보호](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-5-5): 실제 자료를 주고받은 rank·peer·transport와 요청/세대 연결을 제공한다. 상대 인증·기밀성·무결성은 CHK-PLT-008의 구간별 결과와 대조한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.3.2 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97) / [서비스 제공자 2.3.3 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97)

전달 자료의 무결성·기밀성을 분산 중간 자료의 원 요청·모델 세대 대응으로 확장한다.

**OWASP ASVS:** [V8.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 원 요청/모델 세대→rank·중간 buffer/KV→최종 집계·수신까지 연결한다.

각 transport·connector의 식별자와 실제 소비 자료를 따로 관측해야 한다.

**NIST SP 800-53 Rev.5:** [AC-4](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 분산 구성요소 사이에서도 승인된 정보 흐름을 집행한다.

**관련 위협 시나리오:** [SC-08-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-02) · [SC-08-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-03) · [SC-08-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-04)

 

**관련 근거:** [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [Q-C06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C06) · [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [SC-08-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-02) · [SC-08-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-03) · [SC-08-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-04)

 

#### 공유하는 요청값 변경 시험

rank: 기존 헤더 변경 시험을 재사용한다. 서비스가 보호 대상으로 정한 값과 실제 사용 위치를 확인하고, 이 항목의 보호 조건에 따라 별도 결과를 남겨야 한다.

