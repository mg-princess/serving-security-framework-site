# CHK-LIF-007 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-LIF-007.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 필요한 worker와 모델의 실행 준비를 확인한 뒤 요청을 받는가? · CHK-LIF-007

<a id="CHK-LIF-007"></a>
 
<a id="721-필요한-worker와-모델-실행-준비가-끝난-뒤-요청을-받는가"></a>
 
<a id="source-10-04827"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실제 사용하는 다중 프로세스·분산 실행의 필수 rank·모델 준비와 접수 gate를 확인한다. 선택 graph/backend의 준비 항목은 실제 설정에 맞춰 추가한다. |
| --- | --- |
| 권장 설정·조치 | 실제 모델 로딩과 필수 worker·실행 모드 준비를 서비스 수용 조건에 반영한다. 준비 확인용 정상 추론까지 성공한 뒤 요청을 받고 일부 준비 실패 시 수용을 보류한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-deployment-profile) |
| 확인 방법 | 필수 worker의 모델·캐시·선택 실행 기능 준비 시각과 실제 요청 수용 시각을 대조한다. 포트 개방이나 health 응답과 정상 추론 준비를 구분한다.<br>**정상 동작:** 모든 필수 rank와 모델 준비 후 실제 정상 추론이 성공한다. |
| 판정 기준 | 충족<br>필수 준비 미완료 상태에서는 접수를 허용하지 않고 완료 후 정상 처리한다.<br>미충족<br>필수 준비 조건 충족 전에 서비스 수용을 허용한다.<br>미확인<br>health 응답만 있고 rank·model 준비 또는 실제 접수 시점을 모른다. |
| 남길 자료 | - rank 준비/listener 시각/readiness 판정·실제 추론 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### rank 준비 실패를 놓친 채 요청 수용 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/4`<br>관련 관측 | CPU 시작·health 상태를 관측했다. | 모든 rank·필수 모델 준비와 준비 실패 시 접수 차단을 확인해야 한다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-14`<br>관련 관측 | 시작 중 준비되지 않은 상태의 503을 관측했다. | 필수 worker·rank 전체 준비와 모델 적재 증거는 추가 확인해야 한다. |

##### 승인·준비 검증을 건너뛴 서비스 재개 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/4`<br>관련 관측 | 기동 상태 변화 기록이 있다. | 승인 대상 소비·준비 검사의 생략을 시험해야 한다. |

### NIST 요구와 이 점검의 대응 범위

**SA-8(24) · SI-6 — 설계 원칙 대응**

기동·기능 검증 중 안전한 상태를 유지한다.

모델·필수 worker 준비 시각과 실제 요청 수용 시점을 비교한다.

SI-6은 지정 보안·개인정보 기능 범위다. 일반 readiness 전체를 직접 요구하지 않는다.

 

**시험 준비**

 

준비 상태에 따라 요청을 허용하거나 막는 위치와 외부 프록시(proxy)를 확인한다. keep/dev 옵션이 실제로 어떤 값으로 적용됐는지 기록한다.

 

**시험에서 확인할 내용**

 

필수 rank의 모델 로딩·KV와 선택한 그래프(graph)·백엔드가 준비된 시각을 기록한다. 이를 외부 서비스의 요청 접수 장치(service gate)가 실제로 새 요청을 받은 시각과 대조한다. 필수 준비 하나를 지연한 동안 listener·health 응답과 실제 접수를 구분해 대조하고, 준비 완료 후 정상 canary와 요청 수용을 확인한다. 초기 준비 실패를 상위 기동 결과에 반영하는지는 CHK-LIF-009에서 따로 판정한다. vLLM v0.31.0의 공통 근거 중 기본 재배포·외부 gate·정상 로딩 조건을 참조한다. 근거 원문: [F32](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F32).

 

**시험 순서**

 

1. 필수 rank 하나의 준비를 안전하게 지연시키고, 외부 요청과 관리용 준비 확인 요청의 경로를 구분한다.
2. 준비를 지연시킨 동안 포트 수신(listener)·health 응답·Gateway의 준비 판정(readiness)을 확인한다. 외부 요청을 실제로 거부하거나 보류한 결과와 비교한다.
3. 지연을 해제하고 모든 필수 준비와 관리 경로의 정상 canary를 확인한 뒤 접수를 허용한다. 외부 경유 정상 요청으로 실제 준비·접수 순서를 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 일부 분산 프로세스가 준비되지 않았는데 요청 접수 | 기본 재시작·재배포에서 rank별 준비·부분 실패·정리를 확인한다. Ray/live는 선택 시만 추가한다. | SC-17-01 |
| 승인·준비 확인을 건너뛰고 서비스 재개 | 모델 준비·승인 확인과 외부 접수 gate/재개를 연결한다. | SC-17-02 |

 

**함께 확인할 보호 요구**

 

- [실패 감지·상위 통지](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-6-3): 실제 실패와 그 감지·상위 통지 결과를 각각 연결한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 4.1.2 · 인쇄 97 / PDF 107](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=107) / [개발자 5.2.3 · 인쇄 65 / PDF 75](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=75)

오류 탐지·운영 전 테스트는 관련 원칙이다.

**OWASP ASVS:** [V16.5.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 필수 rank의 모델·KV·그래프(graph) 준비 상태와 외부 신규 요청 접수 장치(gate)의 동작을 함께 확인한다.

포트 수신(listener)·health 응답만으로 추론 준비가 끝났다고 확정하지 않는다. 환경별로 반드시 준비돼야 할 항목과 완료 조건을 정한다.

**관련 위협 시나리오:** [SC-17-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-17-01) · [SC-17-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-17-02)

 

**관련 근거:** [Q-R05-12](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-12) · [Q-R05-14](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-14) · [Q-C09](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C09) · [SC-17-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-17-01) · [SC-17-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-17-02)

