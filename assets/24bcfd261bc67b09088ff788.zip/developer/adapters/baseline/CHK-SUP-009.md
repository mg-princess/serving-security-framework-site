# CHK-SUP-009 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-009.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 모델의 추가 코드와 동적 모듈은 승인한 조건에서만 실행되는가? · CHK-SUP-009

<a id="CHK-SUP-009"></a>
 
<a id="322-모델에-포함된-추가-코드가-허용된-조건에서만-실행되는가"></a>
 
<a id="source-10-02387"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 모델의 추가 코드와 동적 모듈을 선택·실행하는 경로에 적용한다. 허용 시 승인 코드만 실행되고, 금지 시 실제 실행을 차단하는지 확인한다. 일반 실행과 지원하는 Python 최적화 모드 등 실행 방식의 차이는 CHK-SUP-011에서 확인한다. 요청의 코드 판본 선택은 CHK-SUP-008, 플러그인의 발견·승인은 CHK-SUP-010의 결과를 함께 사용한다. |
| --- | --- |
| 권장 설정·조치 | 추가 코드 사용을 금지한 구성에서는 실제 import·실행 경로까지 차단되는 설정을 적용한다. 허용한 구성에서는 코드 출처·버전·실행 권한을 승인 묶음에 포함하고 승인한 코드만 실행한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 추가 코드의 출처·판본·의존 파일과 실제 불러온 모듈을 확인한다. 코드 사용 설정이나 auto_map의 존재만 보지 않고, 실행 전 허용 검사와 실제 실행 결과를 비교한다.<br>**정상 동작:** 추가 코드가 필요 없는 승인 모델의 정상 로딩을 확인한다. 추가 코드를 허용한 구성에서는 승인한 코드·판본·의존 파일을 사용하는 모델도 정상 로딩한다. |
| 판정 기준 | 충족<br>금지한 코드는 실행되지 않고 허용한 모델은 정상 사용된다.<br>미충족<br>금지된 추가 코드가 실제 import 또는 실행된다.<br>미확인<br>auto_map 존재만 확인했거나 실제 코드 선택·import를 관측하지 못했다. |
| 남길 자료 | - 유효 trust 설정/코드 선택 분기/import된 파일·판본·실행 계정 |

### 세부시험과 구현 근거

#### 금지 설정의 실제 집행과 재시도 확인

| 선정할 경로 | 수행·확인할 내용 |
| --- | --- |
| 모델 config·클래스·processor | 모델 저장소의 auto_map과 실제 선택 class·하위 repo·동적 캐시를 기록한다. 원격 코드를 금지한 상태에서도 해당 경로와 내부 하위 로더에 무해한 모듈 표식을 제공해 import 전에 거부하는지 확인한다. |
| Tokenizer 재시도 | 초기 로딩 실패 또는 TokenizersBackend 반환 뒤의 재호출까지 같은 trust 값이 전달되는지 추적한다. auto·slow 중 실제 지원 모드만 선택하고 승인된 기본 tokenizer의 정상 로딩과 비교한다. |
| 고정 SGLang 소스에서 확인한 범위 | 0.5.21·0.5.22·0.5.23의 확인한 tokenizer helper는 trust 값을 재호출에 전달하고, 선언 class의 동적 모듈 해석을 그 값으로 제한한다. 설치된 Transformers·선택 모델·다른 helper까지의 실제 거부는 별도 실행으로 확인한다. |

정상 처리와 금지 동작의 거부·실행 여부를 같은 환경·정책에서 기록해야 한다. 시험 자료·임시 권한·추가 기록 설정은 회수하고 승인 구성과 정상 요청을 다시 확인해야 한다. 원치 않는 코드 실행·파일 변경·송신이 관찰되면 시험을 중단하고 접수를 제한한 뒤 증거를 보존하고 승인된 구성으로 복구해야 한다.

관련 공개 기록: [CVE-2025-66448](https://cveawg.mitre.org/api/cve/CVE-2025-66448) · [CVE-2026-22807](https://cveawg.mitre.org/api/cve/CVE-2026-22807) · [CVE-2026-27893](https://cveawg.mitre.org/api/cve/CVE-2026-27893) · [CVE-2026-90553](https://cveawg.mitre.org/api/cve/CVE-2026-90553) · [CVE-2026-114053](https://cveawg.mitre.org/api/cve/CVE-2026-114053) · [CVE-2026-7669](https://cveawg.mitre.org/api/cve/CVE-2026-7669). [코드 실행 관련 공지와 적용 조건](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=rce-path-reference)

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.10.9 악성코드 통제](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-9)<br>엔진·주변 시스템의 악성코드 예방·탐지·대응을 관리할 때<br>[공식 안내서 PDF 173쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=173) · 주요 확인사항 1 | **부분 대응**<br>실제 동적 코드 경로에서 금지한 코드가 실행되지 않고 허용 모델이 정상 처리되는지 확인한다. | [2.10.9 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-10-9) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 모델에 포함된 비승인 Python 코드 실행 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [PoC 20261111](../../../site/references/evidence/sup08-code-selection-20261111.json)<br>`/trust_disabled_030_evidence`<br>관련 관측 | 신뢰 코드 비활성 조건에서 시작이 실패했다. | 정상 요청이 실행되지 않아 승인 코드의 정상 처리와 비승인 코드 차단을 함께 확인하지 못했다. |

### NIST 요구와 이 점검의 대응 범위

**CM-7(5) · AC-6 — 요구 직접 대응**

허용된 소프트웨어만 필요한 권한으로 실행한다.

모델 추가 코드의 출처·revision·의존 파일과 실제 import를 확인한다.

trust_remote_code 설정 문자열과 실제 실행 여부를 구분한다.

 

**시험 준비**

 

선정 모델에 custom code가 필요한지 확인하고, 승인 목록과 무해한 모듈 시험 자료를 준비한다.

 

**시험에서 확인할 내용**

 

auto_map이 있다는 사실만으로 코드가 실행된다고 단정하지 않는다. 실제 선택된 class, 코드 출처(로컬/모델 저장소/다른 저장소/동적 캐시), 판본과 의존 파일을 확인한다. trust 검사와 import가 이루어지는 순서도 조사하고, 허용·금지 조건에서 무해한 실행 표식의 결과를 대조한다.

 

**시험 순서**

 

1. 모델의 auto_map과 실제로 선택한 코드 출처·판본을 확인한다.
2. 무해한 실행 표식을 넣은 custom module 시험 자료를 준비한다.
3. trust 허용·거부 설정에서 실제 import·실행 또는 차단 결과를 비교하고, 승인 모델의 정상 로딩을 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 모델에 포함된 승인되지 않은 Python 코드 실행 | 모델 추가 코드의 선택·금지 설정과 trust 설정을 확인하고 실제 import 경로를 조사한다. | SC-11-02 |

 

**엔진별 확인 사항**

 

**원격 코드 신뢰 설정의 시험 사례**

 

[평가 방법의 적용 사례](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_D_%ED%8F%89%EA%B0%80%EC%96%91%EC%8B%9D%EA%B3%BC_%EC%82%AC%EB%A1%80.md&anchor=source-05-00279)에서는 원격 코드를 신뢰하도록 정한 설정이 실제 모델 로딩 경로까지 전달되는지 확인했다. 설정값과 이를 받아 사용하는 로딩 코드를 연결해 점검하는 사례로 참고한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.2 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

외부 코드 검증·격리 실행·최소 권한이 보호 원칙이다.

**OWASP ASVS:** [V15.2.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 추가 코드의 기대한 공급원과 위험한 코드 실행의 보호 조건을 확인한다.

trust 설정·import 순서 확인은 구현 점검이다. ASVS가 모델 코드를 전면 금지하거나 특정 trust 플래그를 요구하는 것은 아니다.

**NIST SP 800-53 Rev.5:** [CM-7(5)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 소프트웨어만 실행하도록 제한한다. 모델의 추가 코드에도 실제 로딩·실행 경로에서 적용한다.

**관련 위협 시나리오:** [SC-11-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-02)

 

**관련 근거:** [Q-R05-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-05) · [SC-11-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-02)

 

개발 모드·재적재에 따른 실행 경로는 아래 CHK-SUP-011에서 확인한다. 모델 추가 코드의 허용은 CHK-SUP-008, 호출 가능한 확장 기능의 허용은 CHK-SUP-010과 함께 판정해야 한다.

조건부 하위시험: CHK-SUP-011

