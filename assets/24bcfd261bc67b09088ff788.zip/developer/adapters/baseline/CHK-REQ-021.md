# CHK-REQ-021 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-021.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### TP의 GPU 작업을 다시 실행할 때 현재 실행에 속한 유효한 통신 버퍼만 사용하는가? · CHK-REQ-021

<a id="CHK-REQ-021"></a>
 
<a id="443-tp의-gpu-작업-재실행에-사용하는-통신-버퍼가-등록종료재기동-후에도-현재-실행의-유효한-버퍼를-참조하는가"></a>
 
<a id="source-10-03400"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | TP의 실제 graph/communicator buffer 등록·참조 경로가 선택될 때 적용한다. 일반 TP 통신 점검은 별도로 유지한다. |
| --- | --- |
| 권장 설정·조치 | TP graph 통신 buffer의 등록 정보·소유자·실행 세대를 관리한다. graph·통신기가 더 이상 해당 buffer를 참조하지 않고 관련 GPU 연산이 모두 끝난 뒤 참조를 해제한다. 종료·재기동 때 이전 등록 정보를 정리하고 새 실행에 유효한 참조만 사용한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | 버퍼 등록·교환·사용부터 GPU 작업 완료·참조 해제·재기동 후 재등록까지 추적한다. 이전 프로세스 세대의 버퍼나 무효한 참조를 사용하지 않는지 확인한다.<br>**정상 동작:** 정상 TP graph 등록·실행·종료 후 새 기동이 성공한다. |
| 판정 기준 | 충족<br>등록된 버퍼가 현재 실행·소유자와 일치하고, 다른 실행의 버퍼나 해제된 버퍼를 사용하지 않는다. GPU 작업 완료와 graph·통신기의 참조 해제는 기록·계측으로 확인한다.<br>미충족<br>선정 backend의 등록·소유자·실행 세대·유효 범위·참조 수명 조건을 위반한 버퍼 사용 또는 해제가 확인된다. 다음 기동 실패·결과 혼입 등 후속 영향은 별도로 기록한다.<br>미확인<br>native 통신의 실제 참조 수명·해제 효과를 계측하지 못했다. |
| 남길 자료 | - rank·process generation/등록 handle·buffer 범위/graph 완료·해제·재등록 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### GPU 메모리 경계 오류로 다른 요청 자료 노출 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### GPU 프로세스 통신의 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**SA-8(17) · SA-8(19) — 설계 원칙 대응**

분산 구성·종료·재기동 중에도 보호 정책을 유지한다.

TP 통신 버퍼의 등록·rank·실행 세대·GPU 완료·참조 해제를 추적한다.

현재 세대의 유효 참조 사용이라는 엔진별 관측을 유지한다.

#### 담당자와 시험 준비

| 분산·개발 담당자 | 실제 TP·PP·PD 그룹과 rank별 버퍼·메시지·세대의 소유 관계를 준비해야 한다. |
| --- | --- |
| 시험 담당자 | 사용하는 그룹에서 정상 통신과 지연·실패·재시도·교체 조건을 구분해 시험해야 한다. |
| 계측 담당자 | 송수신·GPU 작업 완료·참조 반환을 같은 실행과 연결해야 한다. 사용하지 않는 분산 방식은 구성 근거로 제외하고, 쓰는 방식의 미실행은 미확인으로 남겨야 한다. |

 

**시험 준비**

 

시험할 통신 backend와 native 코드의 동작을 기록할 방법을 확인한다. 운영과 분리된 환경에서 재기동 시험을 준비한다.

 

**시험에서 확인할 내용**

 

시험할 TP 그래프(graph)·통신기(communicator)에서 rank와 프로세스(process)의 실행 세대를 구분한다. 각 세대에서 버퍼·IPC handle의 등록·교환·사용, GPU 작업 완료, 참조 해제와 재등록 순서를 확인한다. 종료·재기동 뒤 현재 세대·소유자·유효 범위의 참조만 사용하는지 실제 사용하는 분산 실행 graph 실행과 대조한다. CUDA Graph caller의 입력 갱신·출력 소비는 CHK-REQ-020에서, 그룹의 회수 기한·잔존 자원·후속 정상 기동은 CHK-LIF-011에서 별도로 판정하며 같은 native 수명 관측을 공유한다.

 

**시험 순서**

 

1. 버퍼를 등록한 뒤 정상 실행한 결과를 비교 기준으로 확보한다.
2. 제한된 종료·재기동을 반복한다.
3. 새 실행 세대에서 버퍼를 등록·참조·정리하는 과정을 정상 실행 기록과 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| GPU 메모리 경계 오류로 다른 요청의 자료 노출 | 선정 TP communicator가 CUDA Graph 재실행용 buffer/IPC handle을 실제 등록·참조할 때. 해당 backend의 등록·소유자·세대·GPU 완료·참조 해제와 재등록 경로를 확인한다. | SC-06-02 |
| GPU 프로세스 사이 통신 도청·변조 | 선정 TP graph/communicator에서 rank 간 buffer/IPC handle의 등록·교환·참조 경로를 실제 사용할 때. local collective와 다중 노드 transport의 등록·수명 증거를 각각 확인한다. | SC-08-03 |

 

**함께 확인할 보호 요구**

 

- [GPU 메모리 안전성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-3-4): TP native 등록 buffer/handle의 유효 범위·소유자·세대·해제 후 참조를 확인한다. 각 kernel의 메모리 경계 시험 전체를 대신하지 않는다.
 
- [통신 상대·전송 보호](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-5-5): 실제 rank·공유 buffer/IPC handle과 교환 경로를 제공한다. transport의 peer 인증·기밀성·무결성은 CHK-PLT-008의 별도 결과다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.1.1 · 인쇄 82·83 / PDF 92·93](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=92)

실행 중 메모리·동시성 분석의 방법론적 근거다.

**OWASP ASVS:** [V1.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).TP의 등록 buffer·IPC handle이 종료·재기동 뒤에도 현재 세대를 참조하는지 확인한다.

등록·GPU 사용 완료·해제·재등록의 실제 계약이 필요하다.

**관련 위협 시나리오:** [SC-06-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-06-02) · [SC-08-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-03)

 

**관련 근거:** [Q-C06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C06) · [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [SC-06-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-06-02) · [SC-08-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-03)

