# CHK-OBS-002 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-OBS-002.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 준비·실패·종료 기록이 실제 worker·작업·수집 상태와 일치하는가? · CHK-OBS-002

<a id="CHK-OBS-002"></a>
 
<a id="831-준비실패종료-기록이-실제-실행-상태와-일치하는가"></a>
 
<a id="source-10-05405"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 준비·실패·종료 기록과 실제 상태를 기본 대조한다. profiler 종료는 해당 기능이 있을 때 추가한다. |
| --- | --- |
| 권장 설정·조치 | 기동 요청·접속 가능·모델 준비·계산 완료·수집 종료의 의미를 기록에서 구분한다. 완료 상태를 표시할 때 해당 worker·작업·수집기의 실제 상태를 확인해 중간 단계를 전체 완료로 보고하는 경로를 보완한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-audit) |
| 확인 방법 | 같은 실행의 API·health·로그 표현과 실제 상태를 독립적으로 관측해 시간순으로 대조한다. 요청 접수, 실행 준비, 작업 완료와 수집 종료를 구분한다.<br>**정상 동작:** 정상 준비·완료 기록이 실제 실행 상태와 일치한다. |
| 판정 기준 | 충족<br>준비·작업 완료·수집 종료 기록이 각각 해당 구성요소의 실제 상태와 일치한다.<br>미충족<br>접수·listener·종료 요청을 실제 준비·적용·종결 완료로 잘못 기록한다.<br>미확인<br>실제 상태를 별도로 계측하지 못해 로그 문구의 진위를 확인할 수 없다. |
| 남길 자료 | - 상태전이 시각/API·로그 표현/worker·작업·수집 실제 상태 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.9.2 성능 및 장애관리](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-2)<br>서비스의 용량·가용성과 장애를 관리할 때<br>[공식 안내서 PDF 141쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=141) · 주요 확인사항 1,3 | **부분 대응**<br>상태 기록이 실제 worker·요청·수집 상태와 일치하는지 확인한다. | [2.9.2 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-9-2) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### health 정상 표시로 실제 추론 장애 은폐 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/12`<br>부분 결과 | worker 장애 뒤 health 503과 프로세스 종료를 관측했다. | 정상 health와 실제 추론·필수 worker 준비의 불일치를 선정 조건별로 확인해야 한다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-08`<br>부분 결과 | Pod 상태 변화와 추론·관측 상태를 확인했다. | Pod 교체 결과를 개별 native worker 장애 시험으로 확대하지 않는다. |

##### profiler 정지 응답을 수집 종료로 오판 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/lab-activation-cpu-20261102.json)<br>`/results/10`<br>관련 관측 | profiler 시작·정지 응답과 trace 파일 수를 관측했다. | 수집 종료·잔류 쓰기와 오류 정지 상태는 확인하지 못했다. |

##### 대상 식별 오류로 비승인 사용을 정상 판단 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-17`<br>관련 관측 | Pod UID 변경 때 상태 초기화를 관측했다. | 실제 승인 대상 식별·소비까지 확인하지 못했다. |

### NIST 요구와 이 점검의 대응 범위

**AU-3 · SA-8(20) — 일부 대응**

정확한 사건 결과와 상태 메타데이터를 관리한다.

ready·완료·종료 표기가 실제 worker·GPU·수집 상태와 일치하는지 독립 관측한다.

일반 health 표시는 모두 감사 기록인 것은 아니다. 실제 상태 대조는 BBLS에서 구체화한 시험이다.

 

**시험 준비**

 

상태별 의미와 기한을 정하고 독립적으로 관측할 지점을 준비한다.

 

**시험에서 확인할 내용**

 

같은 실행에서 API 응답·health 응답·로그가 준비·실패·작업 완료·수집 종료를 표시한 시각과 의미를 확인한다. 이를 worker·실제 작업·backend를 독립적으로 관측한 결과와 대조한다. 요청 접수 제어, 초기화 실패 집계, 작업 종료와 자원 반환 자체는 해당 LIF 항목에서 판정하고, 이 항목에서는 기록이 그 상태를 정확히 표현했는지 판정한다. profiler가 실제로 활성화돼 있으면 CHK-LIF-014의 정상 시작·수집·종료 시험과 backend 시작·정지 실패 시험의 자료를 함께 사용할 수 있다. 이때 응답·경고·내부 상태값이 실제 수집, 결과 생성·전송, 다음 수집 시작 상태와 맞는지 확인한다. 성능 진단 API 경로의 등록·접근 조건과 격리 시험 조건을 유지한다. 근거 원문: [F38](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f38--%EC%83%81%ED%83%9C-%ED%99%95%EC%9D%B8%EA%B3%BC-%EC%84%B1%EB%8A%A5-%EC%A7%84%EB%8B%A8-%EC%A2%85%EB%A3%8C).

 

**시험 순서**

 

1. 정상 완료와 안전한 실패·종료를 각각 실행한다.
2. API 응답·로그·worker 실제 상태를 시간순으로 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 상태 API만 정상이라 실제 추론 장애를 놓침 | 준비·실패·종료의 API/health·기록과 실제 worker/추론 상태를 비교한다. | SC-23-04 |
| 성능 분석 도구의 정지 응답만 보고 수집 종료로 판단 | 선정 profiler가 활성이고 실제 등록 route·backend 종료 경로가 있다. | SC-23-05 |
| 다른 파일·실행의 기록을 섞어 승인 여부 잘못 판단 | 승인·검사·소비의 필수 사건을 실제 실행과 연결한다. | SC-23-03 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 4.1.2 · 인쇄 97 / PDF 107](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=107) / [서비스 제공자 3.1.1 · 인쇄 92 / PDF 102](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=102)

오류를 탐지하고 운영 상태를 파악하기 위해 로그를 활용하는 요구와 관련된다.

**OWASP ASVS:** [V16.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.3.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). API·health·로그에 표시된 상태를 worker·GPU·profiler의 실제 상태와 독립적으로 대조한다.

관련 ASVS 요구는 기록에 포함할 정보와 오류 기록을 다룬다. 기록의 정확성을 독립 센서와 실제 실행 상태의 변화에 대조하는 전체 시험 방법을 직접 규정한 조항은 확인되지 않았다.

**NIST SP 800-53 Rev.5:** [AU-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 감사 기록에 해당하는 준비·실패·종료 기록이 실제 사건의 결과를 담도록 하는 요구와 연결된다.

**관련 위협 시나리오:** [SC-23-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-23-05) · [SC-23-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-23-03) · [SC-23-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-23-04)

 

**관련 근거:** [Q-C11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C11) · [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [Q-R05-15](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-15) · [SC-23-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-23-04) · [SC-23-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-23-05) · [SC-23-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-23-03)

