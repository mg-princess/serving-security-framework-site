# CHK-REQ-001 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-001.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 실제 사용하는 모든 요청 경로에서 허용받지 않은 작업을 차단하는가? · CHK-REQ-001

<a id="CHK-REQ-001"></a>
 
<a id="121-gateway를-거치지-않은-요청으로-허용받지-않은-작업을-할-수-없는가"></a>
 
<a id="source-10-00535"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 엔진의 진입 경로를 항상 확인한다. Gateway 사용 시 경유·직통을 비교하고, 비사용 시 직접 진입점의 인증·인가·노출 제한을 확인한다. |
| --- | --- |
| 권장 설정·조치 | Gateway와 허용 호출자만 엔진에 접근하도록 배포망·수신 주소의 노출을 제한한다. 실제 열린 추론·관리 API 전체에서 경유·직통 경로의 작업 권한을 확인하고 우회 가능한 경로를 제한한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 시험 계정으로 Gateway 경유 요청과 엔진 직접 요청을 각각 보낸다. 허용한 작업은 처리되고 금지한 작업은 실제 실행 전에 차단되는지 확인한다. Gateway를 사용하지 않으면 엔진의 직접 진입 경로에서 확인한다.<br>**정상 동작:** 허용 신원이 실제 진입 경로에서 정상 추론한다. Gateway 사용 시 경유 요청을, 비사용 시 직접 진입점의 허용 요청을 정상 대조로 삼는다. |
| 판정 기준 | 충족<br>비허용 주체의 작업은 수행되지 않고 허용 요청은 정상 처리된다.<br>미충족<br>비허용 출발점이나 신원이 경유·직통·경로 변환 등 실제 진입 경로 중 하나에서 금지 작업을 실행한다.<br>미확인<br>/v1만 확인했거나 /invocations 등 등록 경로·도달성·집행점을 확인하지 못했다. |
| 남길 자료 | - 요청을 보낸 위치, API 경로, 인증 적용 범위, 처리 함수의 실행·거부 기록 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.5.3 사용자 인증](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-5-3)<br>서빙 API에 사용자·서비스 인증을 적용할 때<br>[공식 안내서 PDF 96쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=96) · 주요 확인사항 1 | **부분 대응**<br>인증이 필요한 실제 API에서 비허용 호출 거부와 허용 호출의 정상 처리를 확인한다. | [2.5.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-5-3) |
| [2.6.1 네트워크 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-1)<br>서빙 구성요소가 네트워크에 연결될 때<br>[공식 안내서 PDF 105쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=105) · 주요 확인사항 1 | **부분 대응**<br>Gateway 경유와 엔진 직통 진입 경로에서 허용 주체·위치를 제한한 결과를 확인한다. | [2.6.1 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-1) |
| [2.6.3 응용프로그램 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-3)<br>서빙 애플리케이션이 사용자·역할별 작업이나 자료를 제공할 때<br>[공식 안내서 PDF 110쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=110) · 주요 확인사항 1 | **부분 대응**<br>실제 요청 경로에서 주체별 허용 작업의 집행을 확인한다. | [2.6.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-3) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 엔진 직접 호출을 통한 무단 추론·관리 작업 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/2`<br>부분 결과<br>보안 PASS · 기능 PASS · 성능 UNKNOWN | 직접 접근을 닫음·열음·다시 닫음으로 나눠 PASS·FAIL·PASS를 기록했다. | 전체 API·관리 경로와 정상 대조까지 같은 정책으로 확인해야 한다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/3`<br>부분 결과<br>보안 FAIL · 기능 PASS · 성능 UNKNOWN | 직접 접근을 닫음·열음·다시 닫음으로 나눠 PASS·FAIL·PASS를 기록했다. | 전체 API·관리 경로와 정상 대조까지 같은 정책으로 확인해야 한다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/4`<br>부분 결과<br>보안 PASS · 기능 PASS · 성능 UNKNOWN | 직접 접근을 닫음·열음·다시 닫음으로 나눠 PASS·FAIL·PASS를 기록했다. | 전체 API·관리 경로와 정상 대조까지 같은 정책으로 확인해야 한다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-02`<br>부분 결과 | 키 없음·잘못된 키와 허용 키를 비교했다. | 전달 신원 위조는 별도 시험이 필요하다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-04`<br>부분 결과 | 엔진 직통 접근의 거부를 관측했다. | 전체 API 경로·관리 권한은 추가 확인해야 한다. |

함께 확인하는 보호 요구: **1.1 신원 인증·전달**. 인증을 요구하는 실제 API에서 키 없음·잘못된 키·허용 키와 최종 호출 신원·작업 결과를 대조한 범위가 신원 인증 요구에도 기여한다. 앱·Gateway의 전달 신원 덮어쓰기는 CHK-REQ-004에서 별도로 확인한다.

### NIST 요구와 이 점검의 대응 범위

**AC-3 · AC-25 — 요구 직접 대응**

논리 접근에 승인한 권한을 집행하고 검사 우회를 막는다.

Gateway를 우회한 엔진 직접 접속에서도 실제 작업 권한을 확인한다.

단순 네트워크 차단과 엔진 자체 인가 결과를 각각 기록한다.

 

**시험 준비**

 

운영 환경과 분리된 시험 접속점(endpoint)과 호출자별 허용 작업 목록을 준비한다. OPTIONS 응답을 받았는지와 실제 작업이 실행됐는지는 각각 확인한다.

 

**시험에서 확인할 내용**

 

요청을 받는 frontend, 통신 protocol, API 경로(route)와 수신 지점(listener)을 목록으로 작성한다. 각 경로에 접근을 허용한 출발점·신원과 허용하지 않은 출발점·신원으로 같은 무해한 작업을 호출해 실행·거부 결과를 비교한다. Gateway 사용 시 경유·직통을, 비사용 시 직접 진입점의 인증·인가·노출 제한을 확인한다. 경로를 재작성하는 경우에는 인증 검사에 사용한 입력과 최종 처리 함수(handler)를 함께 추적한다. 이 시험의 기록은 CHK-REQ-002에서도 사용한다. 일반 TCP가 실제로 수신하도록 연결된 주소(bind)를 확인한다. UDS와 배포 네트워크, 방화벽, Gateway의 접근 경로도 확인한다. CORS 설정과 허용/비허용 Origin의 브라우저·비브라우저 호출은 실제 사용 경로에서 확인하며, CORS 선언만으로 직통 인가를 판정하지 않는다. 허용 앱·신원의 정상 추론과 비교한다. 근거 원문: [F39](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f39--%EC%88%98%EC%8B%A0-%EC%A3%BC%EC%86%8C%EC%99%80-%EB%84%A4%ED%8A%B8%EC%9B%8C%ED%81%AC-%EB%85%B8%EC%B6%9C).

 

**시험 순서**

 

1. 실제 API 경로(route)와 수신 지점(listener)을 확인하고, 호출을 허용한 위치·신원과 허용하지 않은 위치·신원을 목록으로 작성한다.
2. Gateway 사용 시 경유·직통을, 비사용 시 직접 진입점의 키가 없는 요청·잘못된 키의 요청·허용된 키의 요청과 노출 제한을 비교한다.
3. 실제 handler의 실행·거부와 허용 요청의 정상 처리를 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 엔진에 직접 접속해 허용되지 않은 추론·관리 작업 실행 | 실제로 사용하는 추론·관리 API 경로(route)와 수신 지점(listener), 접근 경로를 확인한다. Gateway를 사용하지 않는 구성에서도 엔진 직접 접근을 제한하는지 점검한다. | SC-01-01 |

 

**엔진별 확인 사항**

 

**Gateway를 사용하지 않는 구성**

 

엔진의 직접 진입 경로에서 허용된 계정의 요청이 정상 처리되는지 먼저 확인한다. 이어 같은 진입점에서 허용되지 않은 계정의 접근이 거부되는지, 외부 노출 범위가 정한 정책을 지키는지 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.4.2 · 인쇄 90 / PDF 100](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=100)

모든 API 요청의 인증·권한 관리 요구가 대응한다.

**OWASP ASVS:** [V8.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.3.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 우회 진입점에서도 기능 인가가 집행되는지 확인하는 일반 권한 점검이다.

Gateway 직통 우회는 일반 API·웹 서비스에서도 확인하는 경로다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 접근 권한을 집행하는 요구다. 엔진 직접 접속에서도 해당 작업의 권한이 적용되는지 확인한다.

**관련 위협 시나리오:** [SC-01-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-01-01)

 

**관련 근거:** [Q-C01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C01) · [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [SC-01-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-01-01)

조건부 하위시험: CHK-REQ-002

