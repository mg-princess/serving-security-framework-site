# CHK-SUP-010 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-010.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 플러그인을 실행하기 전에 승인된 대상인지 검사하는가? · CHK-SUP-010

<a id="CHK-SUP-010"></a>
 
<a id="323-승인하지-않은-플러그인을-실행하기-전에-허용-여부를-검사하는가"></a>
 
<a id="source-10-02444"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 설치된 entry point와 자동 발견 그룹을 기본 조사한다. 실제 설치·도달하는 general·endpoint·logits·io 그룹별로 확인한다. |
| --- | --- |
| 권장 설정·조치 | 자동 발견되는 plugin 종류와 실제 호출 경로를 조사하고 종류별 허용 목록을 적용한다. plugin을 불러오거나 실행하기 전에 승인 여부를 검사하고 필요 없는 확장을 비활성화한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-input) |
| 확인 방법 | 설치된 확장 종류별로 발견·선택·모듈 로딩·호출 순서를 확인한다. 승인된 확장과 무해한 비승인 확장의 실행·거부를 각각 비교한다.<br>**정상 동작:** 승인된 plugin만 등록된 환경에서 필요한 기능이 정상 동작한다. |
| 판정 기준 | 충족<br>general·endpoint·logits_processors·io processor 등 실제 설치·도달하는 각 그룹에서 승인된 설치물만 로딩되고 필요한 정상 기능이 유지된다. VLLM_PLUGINS 설정 하나로 모든 그룹을 통과시키지 않는다.<br>미충족<br>해당 group에 요구한 제한을 우회해 비승인 plugin이 실행된다.<br>미확인<br>group 등록만 확인하고 실제 runner·hook 도달이나 제한을 확인하지 못했다. |
| 남길 자료 | - 실제 설치·도달하는 확장 종류·등록/선택 경로와 설치 목록·승인 범위<br>- 종류별 유효 제한 설정, 실제 로딩·import·hook 호출 또는 거부와 허용 기능 결과 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 플러그인 발견·허용 검사 차이로 비승인 실행 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### 작업 거부 전에 플러그인 초기화 코드 실행 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**CM-7(5) — 요구 직접 대응**

승인된 소프트웨어의 예외 허용 정책을 집행한다.

plugin의 발견·선택·모듈 로딩·호출 단계별로 허용 여부를 시험한다.

한 플러그인 그룹의 설정 효과를 다른 그룹으로 확대하지 않는다.

 

**시험 준비**

 

선정 엔진의 확장 종류별 승인 목록과 제한 설정을 확인하고 무해한 시험 확장을 준비한다. 실제 실행기와 호출 경로도 확인한다.

 

**시험에서 확인할 내용**

 

선정한 엔진에 실제로 설치되어 실행 경로에 도달하는 확장 종류를 목록으로 정리한다. 각 확장의 발견·선택·import·호출 순서도 기록한다. 종류별 승인 설치물·허용 설정을 실제 로딩과 대조하고, 승인 확장과 무해한 비승인 시험 확장의 실행·거부를 각각 확인한다. 한 종류의 필터 결과로 다른 종류를 대신 판정하지 않는다.

 

**시험 순서**

 

1. 설치된 entry point와 plugin group을 수집하고 그룹별 승인 범위를 확인한다.
2. 승인되지 않은 무해한 시험 plugin을 격리 환경에 등록한다.
3. 각 group의 import·호출·차단 결과를 승인 plugin의 정상 동작과 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 플러그인 발견·허용 검사 차이로 승인되지 않은 코드 실행 | 설치된 general·logits_processors와 실제 선택 io processor 등 그룹을 조사한다. 자동 발견·filter 적용 위치를 그룹별로 확인하며, VLLM_PLUGINS 하나로 모두 보호된다고 판단하지 않는다. | SC-11-03 |
| 작업을 거부하기 전에 플러그인 초기화 코드 실행 | endpoint plugin이 설치·활성돼 실제 factory/등록 경로로 로딩된다. | SC-11-04 |

 

**엔진별 확인 사항**

 

**vLLM v0.31.0의 플러그인 선택과 로딩**

 

설치된 entry point와 실제로 사용하는 runner를 먼저 조사한다. V1 TPU는 custom logitsprocs 조사에서 제외한다. io processor는 초기화 인수인 init 또는 `hf_config`로 선택하는 경우에 확인한다.

 

`general`, `endpoint`, `logits_processors`, io processor 그룹마다 설치 목록·허용 이름·배포 승인·실제 로딩 결과를 대조한다. general·endpoint 플러그인은 발견, import, factory 호출, 필터 적용이 어떤 순서로 이루어지는지도 확인한다. `logits_processors` loader에는 `VLLM_PLUGINS` 필터가 없으므로, 이 설정이 모든 그룹을 통제한다고 가정하지 않고 승인 패키지의 설치 제한과 실제 실행 경로를 확인한다.

 

격리 환경에서 승인된 무해한 plugin과 승인되지 않은 시험 plugin을 비교한다. `VLLM_PLUGINS`를 제한한 뒤에도 logits가 import되는지 무해한 import 표식으로 확인한다. io config가 선택한 processor도 기록한다. 실제 설치·실행되는 그룹, `VLLM_PLUGINS`의 유효값, 그룹별 import·hook 호출을 증거로 남긴다.

 

정상 대조에서는 추가 plugin이 없는 승인 이미지로 추론이 정상 처리되어야 한다. plugin 사용을 허용한 구성에서는 승인된 plugin이 정상 동작하는지 확인한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.2 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

외부 코드의 사전 검증·제한 실행을 엔진 확장 로딩에 적용한다.

**OWASP ASVS:** [V15.2.4](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 승인한 확장 코드만 포함·실행되게 보호하는 일반 구성요소/위험 기능 통제다.

플러그인 종류별 import 이전 검사라는 절차를 적었다는 이유만으로 서빙엔진 고유 요구로 세지 않는다.

**NIST SP 800-53 Rev.5:** [CM-7(5)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 소프트웨어만 실행하도록 허용 목록을 관리·집행한다. 플러그인의 로딩·실행에서도 확인한다.

**관련 위협 시나리오:** [SC-11-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-03) · [SC-11-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-11-04)

 

**관련 근거:** [Q-R05-05](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-05) · [SC-11-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-03) · [SC-11-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-11-04)

