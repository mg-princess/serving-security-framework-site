# CHK-REQ-015 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-015.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 검증된 호출자 신원에 따라 캐시 공유 집단을 정하는가? · CHK-REQ-015

<a id="CHK-REQ-015"></a>
 
<a id="421-캐시를-공유할-사용자-집단을-검증된-신원에-따라-결정하는가"></a>
 
<a id="source-10-03045"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | KV/prefix 등 재사용 cache를 사용할 때 공유 집단과 신원 연결을 확인한다. 실제 집단·공유 정책 미정은 제외 사유가 아니다. |
| --- | --- |
| 권장 설정·조치 | 검증한 사용자 신원에서 캐시 공유 집단을 결정하고 모든 도달 가능한 입력 경로에 적용한다. 사용자가 임의로 공유 집단이나 salt를 지정해 다른 집단의 캐시를 사용하지 못하게 한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | 서로 캐시를 공유해도 되는 사용자와 공유하면 안 되는 사용자를 나눠 같은 입력을 요청한다. 검증된 계정의 공유 정책대로 재사용되는지, 요청값을 바꿔 다른 집단의 캐시를 사용할 수 없는지 확인한다.<br>**정상 동작:** 같은 허용 집단은 캐시를 재사용하고 다른 집단은 공유하지 않는다. |
| 판정 기준 | 충족<br>금지된 집단 간 재사용이 없다. salt 존재만으로 격리를 판정하지 않는다.<br>미충족<br>클라이언트가 공유 집단을 바꾸거나 금지 집단 간 캐시 재사용이 발생한다.<br>미확인<br>검증된 신원과 허용 공유 집단의 대응, 실제 격리·재사용 결과를 확인하지 못했다. salt·namespace·전용 실행 영역 중 채택한 방식의 실제 적용을 확인한다. 공유 기능을 쓰면 허용 집단의 재사용과 비허용 집단의 재사용 차단을 각각 관측해야 한다. |
| 남길 자료 | - 검증된 신원·공유 집단 정책과 실제 선택/정규화 결과<br>- 실제 key·namespace·실행 영역 등 공유 경계, 집단별 cache 적중·소비 또는 재사용 거부 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### cache salt 사칭을 통한 금지된 KV 공유 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261102](../../../site/references/evidence/engine-callback-cpu-20261102.json)<br>`/results/1`<br>부분 결과<br>COMPLETED · False · True | 요청 salt를 직접 지정한 CPU 비교가 있다. | 인증 주체와 salt의 강제 결합은 이 결과만으로 확인되지 않는다. |
| [CPU 20261102](../../../site/references/evidence/engine-callback-cpu-20261102.json)<br>`/results/5`<br>부분 결과<br>COMPLETED · True · False | Gateway가 주체별 salt를 부여한 CPU 비교가 있다. | 원문 normal=false를 유지하며 정상 대조 실패 원인과 허용 공유 정책을 확인해야 한다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/9`<br>부분 결과<br>보안 PASS · 기능 UNKNOWN · 성능 UNKNOWN | 선정 salt 경계의 보안 PASS 기록이다. | functional UNKNOWN을 유지하고 정상 대조와 주체별 허용 공유를 확인해야 한다. |

### NIST 요구와 이 점검의 대응 범위

**AC-3 · SC-4 · AC-16 — 요구 직접 대응**

검증 신원과 공유 정책으로 공유 자원 접근을 제한한다.

사용자 salt·집단 입력으로 금지된 캐시 집단에 진입할 수 있는지 확인한다.

캐시 salt 자체를 인증정보로 취급하지 않는다.

 

**시험의 검출 능력 확인 예**

같은 허용 집단에서의 캐시 재사용을 정상 대조로 둔다. 검출 능력을 확인할 때는 격리 환경의 알려진 결함 사례나 금지 집단 간 재사용을 일으키는 시험용 구성을 사용할 수 있다. 이때 실제 소비·집단 귀속 관측으로 위반을 구별하는지 확인한다. 응답 시간이 짧아졌다는 사실만으로 재사용을 단정하지 않는다.

 

**시험 준비**

 

어떤 시험 사용자끼리 자료를 공유해도 되는지 정하고, 검증된 시험 신원을 준비한다. 시험할 엔진에서 캐시(cache)가 실제로 재사용돼 요청 처리에 쓰이는지 확인할 방법을 준비한다.

 

**시험에서 확인할 내용**

 

검증된 신원에서 공유를 허용한 집단이 결정되고, 그 범위에 따라 캐시가 적중하고 사용되는지 추적한다. 시험할 엔진의 key·namespace나 실행 영역 분리 등 실제 보호 수단을 확인한다. 공유 집단을 위조하거나 생략한 요청을 보내고, 금지된 집단 사이에서 캐시가 재사용되는지 비교한다.

 

**시험 순서**

 

1. A·B 신원과 허용 공유 관계를 기록하고 같은 입력을 반복한다.
2. 클라이언트가 보낼 수 있는 공유 선택값의 위조·누락을 시험한다.
3. 정책에서 정한 집단과 실제 캐시의 재사용 범위·사용 결과를 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 캐시 구분값을 사칭해 다른 사용자의 KV 캐시 공유 | KV/prefix cache를 재사용하며 신뢰 집단별 공유 관계를 정해야 한다. | SC-05-01 |

 

**함께 확인할 보호 요구**

 

- [신원 인증·전달](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-1): 공유 집단 결정에 사용한 검증 신원과 client 선택값의 정규화 증거를 제공한다. 다른 작업의 신원 전달은 CHK-REQ-004의 범위다.
 
- [작업·대상 인가](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-2): 해당 cache의 공유 집단별 허용/거부와 실제 재사용을 확인한다. 모델·저장 객체·관리 작업의 인가 결과를 대신하지 않는다.
 
- [부채널 노출 제한](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-5-6): 금지 집단 간 실제 hit/재사용 여부를 제공한다. 허용된 관측자의 시간·hit 신호로 비공개 정보를 추론하는지는 CHK-REQ-017의 반복·잡음 대조와 기준으로 판정한다.

 

**엔진별 확인 사항**

 

**검증된 신원과 캐시 공유 범위**

 

검증된 사용자 신원에서 공유 집단이 정해지고, 그 집단이 salt·key와 실제 cache hit·재사용에 반영되는지 확인한다. salt 값 자체를 권한의 증거로 삼지 않고, 누가 그 값을 정하고 검증했는지 함께 확인한다.

 

사용자 A와 B로 같은 입력을 반복한 뒤, 클라이언트가 salt를 위조하거나 생략한 요청을 보낸다. Gateway가 정한 집단과 실제 캐시 공유 결과를 비교한다. 검증된 신원, 주입·정규화한 salt, 실제 공유 집단과 cache hit 기록을 남긴다. 시험 전에 허용한 공유 관계와 캐시 관측 방법을 준비한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.3.3 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97) / [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94)

허용 주체로 데이터·모델 접근을 제한하는 원칙을 cache 공유 집단에 적용한다.

**OWASP ASVS:** [V8.3.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.3.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 검증 신원→허용 집단→prefix/미디어 cache의 실제 재사용 범위로 격리를 구체화한다.

salt 설정만으로 전체 cache·외부 connector의 격리를 확정할 수 없다. 공식 vLLM 문서는 구현별 추가 근거다.

**NIST SP 800-53 Rev.5:** [AC-3](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 승인된 접근 정책을 집행한다. 검증된 신원과 정책에 따라 캐시 공유 범위를 결정한다.

**관련 위협 시나리오:** [SC-05-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-05-01)

 

**관련 근거:** [Q-C03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C03) · [SC-05-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-05-01)

