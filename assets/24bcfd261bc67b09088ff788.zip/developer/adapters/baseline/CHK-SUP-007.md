# CHK-SUP-007 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-SUP-007.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 생성된 코드·파일과 공유 컴파일 캐시를 허가 없이 바꾸지 못하게 하는가? · CHK-SUP-007

<a id="CHK-SUP-007"></a>
 
<a id="223-생성된-코드파일이나-공유-컴파일-캐시를-권한-없이-바꿀-수-없는가"></a>
 
<a id="source-10-01898"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실제 compile/AOT·파생 cache의 생성·읽기 경로를 먼저 확인한다. 명시적 활성 옵션이 없다는 이유로 기본 cache를 제외하지 않는다. |
| --- | --- |
| 권장 설정·조치 | 컴파일 결과·생성 파일·캐시의 작성자와 읽는 프로세스를 구분하고 저장 위치의 쓰기 권한을 제한한다. 생성 입력·도구·설정의 식별정보를 기록하고, 무단 변경된 결과를 읽기 전에 거부하거나 승인한 조건으로 다시 생성한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-supply) |
| 확인 방법 | 누가 생성물을 쓸 수 있는지와 어느 프로세스가 실제로 읽는지 연결한다. 무해한 변경 시도와 재기동 후 사용·거부 결과를 비교하고, 엔진 자신의 쓰기 권한과 변경 내용의 잔존도 확인한다.<br>**정상 동작:** 새 묶음의 빈 cache에서 생성하고 동일 묶음으로 정상 재기동한다. |
| 판정 기준 | 충족<br>허용되지 않은 생성·변조 결과를 소비하지 않는다. 생성 결과마다 사람의 별도 승인을 필수로 요구하지 않는다.<br>미충족<br>비허용 writer가 바꾼 생성물을 요구한 검사 없이 소비한다.<br>미확인<br>cache 파일 변경은 확인했지만 소비 도달·내용 검증·권한 집행을 확인하지 못했다. |
| 남길 자료 | - cache 경로·소유자·writer/묶음 식별·cache key/pickle 등 reader 도달과 소비 기록 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 공유 컴파일 캐시 변조를 통한 코드 실행 · 관련 관측

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-11`<br>관련 관측 | 정상 요청의 경보와 캐시 동작을 관측했다. | 비허용 작성자의 캐시 변조와 소비는 시험하지 않았다. |

### NIST 요구와 이 점검의 대응 범위

**SI-7 · CM-5 — 요구 직접 대응**

생성 코드·정보의 무단 변경과 사용을 제한한다.

공유 컴파일 캐시의 작성자·소비자·재기동 뒤 실제 사용을 연결한다.

캐시 파일 변경과 코드 실행·계산 사용 여부를 분리한다.

 

**시험 준비**

 

격리된 cache와 안전한 관측 방법을 준비한다. 임의 코드를 실행하는 payload는 사용하지 않는다.

 

**시험에서 확인할 내용**

 

실제 파생 결과·compiled·npcache를 생성하는 구성요소, 쓰는 주체(writer), 저장 경로와 사용하는 구성요소(consumer·reader)를 확인한다. 사용 전에 무결성을 검사·강제하는지도 확인한다. 허용되지 않은 writer가 무해한 변경·교체를 시도한 결과를 승인된 생성물의 정상 사용 결과와 비교한다. 변경된 파일이 실제로 읽혔는지와 사용이 거부됐는지를 기록한다. pickle 등 reader의 해석 안전성은 CHK-SUP-012와 증거를 공유한다. 실제 backend·AOT·기본 cache 활성값·의존성 판본을 고정하고 VLLM_CACHE_ROOT·compilation_config.cache_dir·TORCHINDUCTOR_CACHE_DIR·TRITON_CACHE_DIR 중 사용 경로와 rank별 파일을 조사한다. 다른 계정과 엔진 자체에 쓰기 권한이 남아 있는지, 변조된 내용이 계속 사용되는지 각각 확인한다. 근거 원문: [F03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=basis-F03).

 

**시험 순서**

 

1. vLLM·Inductor·Triton의 실제 cache 경로와 writer·reader를 확인한다.
2. 비허용 계정으로 무해한 표식을 변경하려 시도한다.
3. 재기동할 때 변경된 결과의 사용 전 차단과 실제 읽기 여부를 확인하고, 승인한 생성물의 정상 재사용과 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 공유 컴파일 캐시를 바꿔 승인되지 않은 코드 실행 | 유효 compile/AOT·파생 cache의 생성·읽기 경로를 조사한다. 기본 비활성이나 safetensors 정책만으로 제외하지 않는다. | SC-12-01 |

 

**함께 확인할 보호 요구**

 

- [자료 해석 안전성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-3-3): 변조된 생성물의 실제 reader 도달·소비 증거를 공유한다. reader의 금지 객체 생성·부수 동작은 CHK-SUP-012의 범위와 대조한다.
 
- [실행 최소 권한](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-4): 실제 생성자·비허용 writer·엔진의 잔존 쓰기권을 확인한다. 호스트·장치 등 나머지 최소 권한은 CHK-PLT-001의 별도 범위다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.2 · 인쇄 85 / PDF 95](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=95) / [서비스 제공자 2.3.2 · 인쇄 87 / PDF 97](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=97) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

모델·데이터 무결성과 위험한 라이브러리의 제한 실행을 생성 코드·cache 소비에 적용한다.

**OWASP ASVS:** [V8.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 생성 파일·컴파일 cache의 비허용 쓰기와 안전하지 않은 공유 접근을 제한한다.

주 근거는 객체별 쓰기 권한이다. V15.4.1의 동기화만으로 비허용 writer 차단을 설명하지 않는다. 공식 vLLM cache 보안 권고도 별도로 연결돼 있다.

**NIST SP 800-53 Rev.5:** [CM-5](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [SI-7](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 생성 코드와 캐시의 변경 권한을 제한하고 무단 변경을 검출·처리한다.

**관련 위협 시나리오:** [SC-12-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-12-01)

 

**관련 근거:** [Q-R05-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-04) · [Q-R05-07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-R05-07) · [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [SC-12-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-12-01)

