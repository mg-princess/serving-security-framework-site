# CHK-PLT-008 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-008.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### API와 내부 통신의 각 구간에서 상대를 확인하고 전송 자료를 보호하는가? · CHK-PLT-008

<a id="CHK-PLT-008"></a>
 
<a id="551-api내부-통신의-각-구간에서-통신-상대-인증과-기밀성무결성-기준을-지키는가"></a>
 
<a id="source-10-03888"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 호출 앱·사용자→Gateway→엔진의 실제 API 전송 구간과 기본 IPC/TP를 확인한다. Gateway가 없으면 호출 주체→엔진을 확인한다. 다중 노드·PP는 사용 시 추가한다. |
| --- | --- |
| 권장 설정·조치 | 호출 주체→Gateway→엔진과 내부 통신을 구간별로 나누고 채택한 상대 인증·기밀성·무결성 보호를 적용한다. TLS 종료 후 엔진까지의 구간도 확인한다. 인증서를 사용하는 구간에서는 신뢰되지 않거나 이름이 다른 인증서를 거부하는지 시험한다. 로컬 IPC는 실제 계정·namespace·접근권에 맞게 보호한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-data) |
| 확인 방법 | API와 내부 IPC·TP 통신을 나누고 구간별 상대 인증·기밀성·무결성 기준을 확인한다. TLS가 끝나는 위치와 이후 구간도 확인하며, 각 구간의 결과를 따로 기록한다.<br>**정상 동작:** 허용한 호출 주체가 각 API 구간에서 정상 요청·스트리밍 응답을 주고받고, 승인한 rank 사이 TP 처리도 정상 완료된다. |
| 판정 기준 | 충족<br>API·내부 통신의 각 구간에서 채택한 상대 인증·기밀성·무결성 요구를 증거로 확인하고 정상 요청·TP가 동작한다. 내부 IPC의 OS 접근 제한 등 실제 보호 수단도 구간별로 평가한다.<br>미충족<br>채택한 정책에서 금지한 평문 통신·비허용 상대 연결·변조 자료 수용이 확인되거나, 필수 상대 검증을 수행하지 않는다.<br>미확인<br>API의 실제 종단·TLS 종료점 또는 내부 transport·peer·보호 설정과 결과를 확인하지 못했다. 필수 보호 요구가 미정이면 해당 기준의 판정을 보류한다. |
| 남길 자료 | - 구간·transport·peer/인증·암호화 설정/연결·무결성 결과<br>- 호출 주체→Gateway→엔진 주소와 TLS 종료·재암호화 위치, 실제 handshake·인증서 검증, 금지 평문 연결·정상 응답 결과 |

### 세부시험과 구현 근거

#### 내부 메시지의 상대·전송 보호

| 선정할 경로 | 수행·확인할 내용 |
| --- | --- |
| 상대와 reader 연결 | 통신 상대의 식별·인증·구간 보호를 실제 serializer/decoder 및 수신 프로세스와 연결한다. 사설 주소 사용이나 127.0.0.1 바인딩의 관측 범위를 UID·namespace·다른 작업의 접근 가능성과 함께 기록한다. |
| 현재 구성 대조 | 공개 권고의 과거 listener 문제를 현재 V1 또는 다른 ZMQ 기능의 동일 결함으로 판정하지 않는다. 선정 peer의 정상 처리와 비허용 peer·변경된 메시지의 거부 결과로 현재 구성을 판단한다. |

정상 처리와 금지 동작의 거부·실행 여부를 같은 환경·정책에서 기록해야 한다. 시험 자료·임시 권한·추가 기록 설정은 회수하고 승인 구성과 정상 요청을 다시 확인해야 한다. 원치 않는 코드 실행·파일 변경·송신이 관찰되면 시험을 중단하고 접수를 제한한 뒤 증거를 보존하고 승인된 구성으로 복구해야 한다.

관련 공개 기록: [CVE-2025-29783](https://cveawg.mitre.org/api/cve/CVE-2025-29783) · [CVE-2025-32444](https://cveawg.mitre.org/api/cve/CVE-2025-32444) · [CVE-2025-30165](https://cveawg.mitre.org/api/cve/CVE-2025-30165) · [CVE-2025-47277](https://cveawg.mitre.org/api/cve/CVE-2025-47277) · [CVE-2026-3059](https://cveawg.mitre.org/api/cve/CVE-2026-3059) · [CVE-2026-3060](https://cveawg.mitre.org/api/cve/CVE-2026-3060) · [CVE-2026-7301](https://cveawg.mitre.org/api/cve/CVE-2026-7301) · [CVE-2026-14890](https://cveawg.mitre.org/api/cve/CVE-2026-14890) · [CVE-2026-93088](https://cveawg.mitre.org/api/cve/CVE-2026-93088) · [CVE-2026-93034](https://cveawg.mitre.org/api/cve/CVE-2026-93034). [코드 실행 관련 공지와 적용 조건](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=rce-path-reference)

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.6.6 원격접근 통제](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-6)<br>원격 운영 채널에 해당 API 통신을 실제로 사용할 때<br>[공식 안내서 PDF 117쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=117) · 주요 확인사항 1,2 | **보조 자료**<br>API를 원격 관리 채널로 사용하는 경우 그 구간의 상대 인증·암호화 결과를 확인한다. | 원격 운영의 필요성·승인, 지정 단말, 허용 범위·기간, 단말 보안과 강화 인증의 실제 이행을 확인한다. |
| [2.7.1 암호정책 적용](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-7-1)<br>암호화가 필요한 개인정보·중요정보를 저장·전송할 때<br>[공식 안내서 PDF 122쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=122) · 주요 확인사항 2 | **부분 대응**<br>API·내부 통신의 각 구간에서 채택한 전송 기밀성·무결성을 확인한다. | [2.7.1 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-7-1) |
| [2.10.5 정보전송 보안](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-5)<br>다른 조직과 개인정보·중요정보를 주고받을 때<br>[공식 안내서 PDF 164쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=164) · 주요 확인사항 1,2 | **보조 자료**<br>실제 조직 간 중요정보 전송 구간으로 사용하는 API 통신의 상대 인증·암호화 결과를 협약의 기술 자료로 사용한다. | [2.10.5 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-10-5) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 로컬 socket 접근을 통한 내부 제어 침입 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### GPU 프로세스 통신의 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### GPU 프로세스 통신의 도청·변조 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**IA-9 · SC-8 · SC-23 — 요구 직접 대응**

서비스 상대·세션의 진위를 확인하고 전송 정보를 보호한다.

API·내부 통신의 hop별 인증·기밀성·무결성과 실제 종단을 확인한다.

암호화와 상대 인증을 각각 확인하고 TLS 밖 IPC 구간을 별도 기록한다.

 

**시험의 검출 능력 확인 예**

허용 peer의 정상 통신과 비허용 peer의 접속·메시지 거부를 비교한다. 시험할 전송 backend·connector가 여러 개면 각 경로에서 설정한 상대 검증이 실제 동작하는지 확인하고 경로별 결과를 남긴다.

 

**시험 준비**

 

실제 API·IPC·TP 구간과 보호 요구를 확인하고, TLS 시험 endpoint·인증서·지원 시험기를 준비한다. 기업별 보호 방식과 예외를 정한 뒤 실제 시험을 수행해야 한다.

 

**시험에서 확인할 내용**

 

서비스 API와 API/core/worker·rank 사이 실제 제어·데이터 통신을 구간별로 식별하고, 각 구간의 허용 peer·상대 확인·기밀성·무결성 요구와 정상 API·스트리밍·TP 처리를 대조한다. 제어 SHM/socket·overflow·collective·선택 PP/다중 노드 transport를 구분한다. 로컬 IPC의 UID·namespace·socket/SHM 접근과 무해 메시지 수용 관측은 CHK-PLT-002와 공유할 수 있다. 이 항목에서는 그 근거가 해당 구간의 보호 요구를 충족하는지 판정하고, 로컬 IPC 인가만으로 다른 구간의 전송 보호를 통과시키지 않는다. API는 실제 TLS 종료점·재암호화·서버 인증과 필요한 호출 주체 인증을 구분하며, 정상 인증서·신뢰되지 않거나 이름이 다른 인증서와 정책상 금지된 평문 연결을 격리 환경에서 대조한다. 관측 자료 전용 collector/sink 전송은 CHK-PLT-009에서 구간별로 판정한다. vLLM v0.31.0의 공통 근거를 참조한다. 근거 원문: [F21](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=f21--%EB%82%B4%EB%B6%80-%EB%A9%94%EC%8B%9C%EC%A7%80%EC%99%80-%EA%B3%B5%EC%9C%A0-%EB%A9%94%EB%AA%A8%EB%A6%AC-%EC%A0%91%EA%B7%BC).

 

**시험 순서**

 

1. API·IPC·TP 구간, 실제 종단과 구간별 보호 요구를 확보한다.
2. 허용된 정상 API·스트리밍·TP 처리를 확인한다.
3. 해당 시험을 지원하는 시험기로 API의 잘못된 인증서와 금지된 평문 연결을 시험한다. 내부 통신에서는 허용되지 않은 peer와 무해한 자료 변조를 적용해 결과를 대조한다.
4. 각 구간의 상대 인증·기밀성·무결성 결과를 따로 기록한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 로컬 소켓에 접속해 내부 제어 기능 호출 | 실제 socket·SHM 등 로컬 IPC 경로와 peer 접근권이 있다. | SC-08-01 |
| GPU 프로세스 사이 통신 도청·변조 | 선정한 local collective·SHM·CUDA IPC 등의 전송 방식을 실제로 사용할 때 확인한다. UID·namespace와 native 자원에 대한 접근 경계도 조사한다. | SC-08-03 |
| GPU 프로세스 사이 통신 도청·변조 | 다중 노드·PP 등 별도 transport를 실제 사용하면 추가한다. local TP의 결과를 원격 구간 보호 근거로 쓰지 않는다. | SC-08-03 |

 

**따로 기록할 결과**

 

| 결과 | 확인할 경우 | 충족 기준 |
| --- | --- | --- |
| API 전송 보호 | 모든 실제 API 호출 구간. Gateway 사용 여부에 따라 구간을 나눠 확인한다. | 실제 API 각 구간의 필수 상대 인증·기밀성·무결성 요구와 정상 처리를 확인한다. |
| 내부 IPC·TP 전송 보호 | 기본 IPC·TP와 선택한 분산 통신 | 구간별 허용 peer·보호 요구를 지키고 실제 사용하는 분산 실행가 완료된다. |

 

**함께 확인할 보호 요구**

 

- [신원 인증·전달](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-1): 권한 판단에 사용한 신원과 그 검증·전달 기록을 연결한다.
 
- [작업·대상 인가](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-2): 같은 실행에서 작업·대상별 허용 여부를 함께 확인하고, 해당 권한 점검의 결과를 연결한다.

 

**엔진별 확인 사항**

 

**관련 보안 기준**

 

[KISA AI 보안 안내서](https://www.kisa.kr/2060204/form?postSeq=19&page=1)의 서비스 제공자 2.4.1·2.4.3을 참고한다. 해당 내용은 인쇄 90–91쪽 / PDF 100–101쪽에서 확인할 수 있다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.4.1 · 인쇄 90 / PDF 100](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=100) / [서비스 제공자 2.4.3 · 인쇄 91 / PDF 101](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=101) / [서비스 제공자 2.3.4 · 인쇄 88 / PDF 98](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=98)

API 암호화 요구는 직접 대응한다. 전송 보호 원칙은 API·core·worker·TP 사이의 실제 통신 구간에도 적용한다.

**OWASP ASVS:** [V12.2.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V12.3.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V12.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V12.3.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V12.3.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 외부·내부 연결의 상대 인증·전송 보호와 비보호 fallback 방지를 확인한다.

TP·core/worker 통신도 적용 구간이다. 실제 transport의 보호 수단·노출 범위가 필요하며 ASVS의 적용 요건과 예외는 별도로 검토한다.

**NIST SP 800-53 Rev.5:** [IA-9](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [SC-8](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 연결할 서비스를 식별·인증하고 전송 정보의 정한 기밀성·무결성을 보호한다.

**관련 위협 시나리오:** [SC-08-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-01) · [SC-08-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-08-03)

 

**관련 근거:** [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [SC-08-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-01) · [SC-08-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-08-03)

