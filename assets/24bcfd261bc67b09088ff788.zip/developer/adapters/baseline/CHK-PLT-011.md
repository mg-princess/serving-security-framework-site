# CHK-PLT-011 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-011.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 권한을 철회한 뒤 기존 연결과 공유 자원 접근도 정한 정책에 따라 제한하는가? · CHK-PLT-011

<a id="CHK-PLT-011"></a>
 
<a id="172-이미-열린-연결과-공유-자원-접근권도-정한-철회-정책대로-제한되는가"></a>
 
<a id="source-10-01539"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 철회 대상 자격으로 생성된 지속 연결·session·handle이 있을 때 적용한다. 신규 요청 차단으로 대신 판정하지 않는다. |
| --- | --- |
| 권장 설정·조치 | 이미 열린 session·handle에 철회 후 허용할 작업, 재인증·제한·종료 조건과 기한을 정한다. 채택한 방침에 따라 기존 접근권을 갱신·회수하거나 세션을 종료하고, 신규 접근과 기존 접근의 처리 결과를 각각 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 철회 전에 열린 세션과 접근 핸들을 계속 사용하는 경우를 새 연결과 구분한다. 정책이 허용한 잔존 사용과 강제 종료의 적용 결과를 각각 확인한다.<br>**정상 동작:** 철회 전 기존 session·handle이 정상 동작한다. |
| 판정 기준 | 충족<br>기존 접근 유지/종료 방침과 기한을 지킨다.<br>미충족<br>기존 session이 채택한 철회 후 허용 범위·기한을 넘겨 동작한다.<br>미확인<br>기존 session과 재연결을 구분하지 못했거나 잔존 정책이 미정이다. |
| 남길 자료 | - session/handle 생성·소유자/철회 시각/기존·신규 접근 결과 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.5.6 접근권한 검토](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-5-6)<br>서빙 관련 계정·접근 권한을 부여·변경·회수할 때<br>[공식 안내서 PDF 103쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=103) · 주요 확인사항 3 | **부분 대응**<br>권한 회수 후 기존 연결·handle의 제한·종료 방침이 집행되는지 확인한다. | [2.5.6 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-5-6) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 철회 전 세션·handle로 접근 유지 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

### NIST 요구와 이 점검의 대응 범위

**AC-3(8) · AC-12 — 요구 직접 대응**

철회 조건에 따른 기존 접근·세션의 종료를 집행한다.

기존 연결과 공유 자원 참조가 정한 철회 정책을 따르는지 확인한다.

AC-12는 사용자 세션 범위다. GPU 참조의 수명까지 이 조항에 포함시키지 않는다.

 

**시험 준비**

 

기존 연결의 처리 정책을 정하고, session을 식별할 관측 방법을 준비한다.

 

**시험에서 확인할 내용**

 

철회 전에 열린 세션이 이후에도 사용되는지와 언제 종료되는지 관측한다. 실행 중인 작업을 회수하는지는 해당 작업 종료 항목과 함께 확인한다.

 

**시험 순서**

 

1. session을 생성한다.
2. 자격을 철회한다.
3. 같은 session과 새 session에서 각각 제한된 호출을 수행한다.
4. 기존 세션의 유지·종료 시점과 후속 사용 범위를 정한 정책·기한에 대조한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 권한 철회 전의 세션·연결로 계속 접근 | 철회 대상 자격으로 열린 지속 session·연결·handle이 존재한다. | SC-19-02 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 4.2.3 · 인쇄 58 / PDF 68](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=68) / [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94)

세션 만료·임시 권한 회수의 관련 원칙은 있다.

**OWASP ASVS:** [V7.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V8.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 철회 뒤 이미 열린 세션·접근권의 후속 사용도 제한한다.

일반 권한 철회 적용 범위다. GPU 작업 종결·참조 수명 문제는 해당 LIF/REQ 항목에서 별도로 점검한다.

**NIST SP 800-53 Rev.5:** [AC-3(8)](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 정한 철회 정책을 기존 접근에도 집행한다. 열린 연결과 공유 자원 접근에 대한 반영을 확인한다.

**관련 위협 시나리오:** [SC-19-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-19-02)

 

**관련 근거:** [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [Q-C08](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C08) · [Q-C12](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C12) · [SC-19-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-19-02)

