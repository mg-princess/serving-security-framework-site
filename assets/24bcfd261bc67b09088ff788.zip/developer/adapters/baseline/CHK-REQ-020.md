# CHK-REQ-020 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-020.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### CUDA Graph를 다시 실행할 때 현재 입력을 쓰고, 읽는 중인 출력은 덮어쓰지 않는가? · CHK-REQ-020

<a id="CHK-REQ-020"></a>
 
<a id="442-cuda-graph-재실행이-현재-입력을-쓰고-아직-읽는-출력-버퍼를-덮어쓰지-않는가"></a>
 
<a id="source-10-03338"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | CUDA Graph의 실제 활성 여부와 runner/mode를 먼저 확인한다. 명시 활성 옵션 부재만으로 비사용을 판단하지 않는다. |
| --- | --- |
| 권장 설정·조치 | CUDA Graph 실행 전에 현재 입력을 반영하고, 계산·출력 읽기·버퍼 재사용 순서를 보장한다. 실행 방식이나 버퍼가 바뀌면 그래프를 다시 만들거나 재사용할 조건을 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-state) |
| 확인 방법 | 현재 입력이 반영된 뒤 CUDA Graph가 실행되는지 확인한다. 결과를 읽기 전에 입력·출력 버퍼가 덮어써지지 않는지 버퍼 사용 순서와 실제 계산을 대조한다.<br>**정상 동작:** capture 후 동일 shape의 새 입력을 넣으면 새 입력에 해당하는 결과가 나온다. |
| 판정 기준 | 충족<br>현재 replay의 입력과 유효 길이가 실제 계산에 반영되고, 유효 길이 밖이나 이전 요청의 상태를 소비하지 않으며, 출력 소비가 끝나기 전에 같은 버퍼를 덮어쓰거나 다른 replay의 결과로 바꾸지 않는다. 입력 갱신·copy/동기화·소비·재사용 순서를 증거로 확인한다. kernel 자체의 주소·인덱스 계산은 CHK-REQ-019, TP native 등록 참조는 CHK-REQ-021의 결과와 연결한다. 주소 일치 assert만으로 충족 처리하지 않는다.<br>미충족<br>현재 replay가 현재 입력·유효 길이에 맞지 않는 값을 소비하거나, 출력 소비가 끝나기 전에 같은 버퍼를 덮어쓰는 등 필요한 동기화·수명 조건을 위반한 사실이 확인된다. 실제 출력 변화·잘못된 귀속은 별도로 기록한다.<br>미확인<br>replay 도달·copy 완료·동기화 순서를 관측하지 못했다. |
| 남길 자료 | - capture key·주소/입력 갱신·출력 소비/stream event·대조 출력 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### GPU 메모리 경계 오류로 다른 요청 자료 노출 · 실행 결과 미연결

이 분기의 성립 조건에서 허용·금지 동작과 필수 관측을 확인한 결과를 확보해야 한다.

##### GPU 메모리 경계 오류로 다른 요청 자료 노출 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261103](../../../site/references/evidence/gpu-a-REQ-20-20261103.json)<br>`/runs/0`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | V2 Graph descriptor A/B와 ARM SNorm 수동 fixture를 관측했다. | 실제 비동기 취소·요청 수명주기와 서빙 도달은 추가 확인해야 한다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/14`<br>부분 결과<br>보안 UNKNOWN · 기능 UNKNOWN · 성능 UNKNOWN | V2 Graph 비활성·활성 조건을 나눠 관측했다. | 실제 요청·취소·비동기 수명주기의 전체 경로를 추가 확인해야 한다. |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/15`<br>부분 결과<br>보안 PASS · 기능 UNKNOWN · 성능 UNKNOWN | V2 Graph 비활성·활성 조건을 나눠 관측했다. | 실제 요청·취소·비동기 수명주기의 전체 경로를 추가 확인해야 한다. |

### NIST 요구와 이 점검의 대응 범위

**SA-8(19) · SA-8(20) — 설계 원칙 대응**

실행과 상태 전환 중 보호 공백과 메타데이터 불일치를 방지한다.

CUDA Graph 입력 갱신·출력 읽기·버퍼 덮어쓰기의 순서와 수명을 확인한다.

SI-16·SI-10(4)를 CUDA Graph 수명 규칙의 직접 조항으로 연결하지 않는다.

#### 담당자와 시험 준비

| 개발 담당자 | 선택한 backend·Graph·버퍼의 생성·재사용·해제 조건을 설명해야 한다. |
| --- | --- |
| 시험 담당자 | 정상 실행과 크기·순서·동시 실행 조건을 바꾼 실행을 비교하고 실제 버퍼·요청 귀속을 남겨야 한다. |
| 계측 담당자 | 비동기 완료·참조 해제·다음 사용 시점을 연결해야 한다. 선정하지 않은 backend와 경로는 확인 범위 밖으로 기록해야 한다. |

 

**시험 준비**

 

CUDA Graph가 활성화되는 조건과 버퍼(buffer)·실행 흐름(stream)을 확인할 방법을 준비한다. 입력 갱신 누락, 잘못된 참조와 격리 위반이 발생하는지를 실패 기준에 따라 관측한다.

 

**시험에서 확인할 내용**

 

입력 갱신부터 descriptor, 그래프 기록·재실행(capture/replay), 출력 사용과 버퍼 재사용까지 순서대로 기록한다. 길이·배치를 바꾸거나 취소 후 재사용한 결과를 일반 실행(eager) 결과와 비교한다. 입력과 출력의 확인 결과는 따로 남긴다.

 

**시험 순서**

 

1. 그래프를 기록한(capture) 정상 실행 결과를 비교 기준으로 확보한다.
2. 같은 buffer에 다른 무해 입력을 넣고 replay를 실행한다.
3. 연속 replay·출력 복사·완료 순서를 대조한다.

 

**구현 보완 참고**

 

- CUDA Graph 재실행 전에 현재 입력을 갱신하고, 연산·출력 사용·buffer 재사용의 동기화 순서를 지킨다. 실행 모드나 buffer가 바뀌면 graph 관리자의 재캡처·재사용 조건을 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| GPU 메모리 경계 오류로 다른 요청의 자료 노출 | V1 runner의 해당 CUDA Graph mode가 실제 활성일 때. 현재 입력 갱신·출력 소비와 buffer 수명을 확인한다. | SC-06-02 |
| GPU 메모리 경계 오류로 다른 요청의 자료 노출 | V2 runner의 해당 CUDA Graph mode가 실제 활성일 때. 선정 caller/graph manager의 갱신·출력 소비 동기화를 확인한다. | SC-06-02 |

 

**함께 확인할 보호 요구**

 

- [GPU 메모리 안전성](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-3-4): graph caller가 실제 소비한 현재 입력·유효 길이와 출력 buffer의 갱신/소비 순서를 제공한다. kernel의 주소·인덱스·크기 계산 자체는 CHK-REQ-019에서 판정한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.1.1 · 인쇄 82·83 / PDF 92·93](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=92)

실행 중 동시성·메모리 문제를 분석하는 방법론적 근거다.

**OWASP ASVS:** [V1.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.4.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml).CUDA Graph 입력 갱신·capture/replay·출력 소비·다음 덮어쓰기의 참조 수명을 확인한다.

해제 후 참조와 동시 공유 안전 원칙을 연결한다. Graph별 메모리·event/stream 계약과 실제 완료 관측이 필요하다.

**관련 위협 시나리오:** [SC-06-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-06-02)

 

**관련 근거:** [Q-C06](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C06) · [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [SC-06-02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-06-02)

