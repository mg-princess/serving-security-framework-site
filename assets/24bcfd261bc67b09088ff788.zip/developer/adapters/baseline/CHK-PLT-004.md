# CHK-PLT-004 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-004.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### worker에 실행에 필요한 인증정보와 비밀정보만 전달하는가? · CHK-PLT-004

<a id="CHK-PLT-004"></a>
 
<a id="152-worker에-필요-없는-자격비밀정보를-넘기지-않는가"></a>
 
<a id="source-10-01278"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 기본 worker 환경·자격 상속을 확인한다. Ray/원격 worker 전달은 해당 실행기를 사용할 때 추가한다. |
| --- | --- |
| 권장 설정·조치 | driver·부모 프로세스의 환경변수·Secret·파일·mount에서 worker로 전달할 자격을 필요한 것만 명시한다. worker가 받은 자격과 실제 접근 가능한 저장소·서비스를 대조하고 불필요한 전달을 제거한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 환경변수, 파일·마운트, 인증정보 제공 기능과 상속 경로를 함께 확인한다. 비밀값 자체를 수집하는 대신 시험용 표식과 실제 전달 범위로 확인한다.<br>**정상 동작:** worker가 필요한 최소 자격으로 정상 실행한다. |
| 판정 기준 | 충족<br>필요하지 않은 소비자에게 자격을 노출하지 않는다.<br>미충족<br>불필요한 자격이 worker에 전달되어 접근에 사용 가능하다.<br>미확인<br>env만 확인하고 파일·provider·상속 자격 경로를 확인하지 못했다. |
| 남길 자료 | - env·mount·credential provider/rank별 유효 자격/정상 기능 결과 |

### 세부시험과 구현 근거

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### worker에 전달된 불필요한 비밀정보 탈취 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261105](../../../site/references/evidence/gpu-b-phase1-status-20261105.json)<br>`/reused_evidence/13`<br>부분 결과<br>보안 FAIL · 기능 PASS · 성능 UNKNOWN | 과거 증거를 재사용한 기록이며 새 GPU 실행은 0건이다. | 원문 FAIL·UNKNOWN과 재사용 범위를 유지한다. 현 구성의 전체 권한·소비 범위를 추가 확인해야 한다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-10`<br>관련 관측 | 선정 비밀 파일의 읽기를 탐지했다. | 탐지는 최소 비밀 전달·접근 차단의 증거와 구분한다. |

### NIST 요구와 이 점검의 대응 범위

**AC-6 · IA-5 — 요구 직접 대응**

필요한 권한만 부여하고 인증정보의 노출·변조를 막는다.

worker에 전달된 환경변수·마운트·비밀정보가 실제 필요 범위인지 확인한다.

인증정보 전달 최소화와 보관·교체 수명주기를 구분한다.

 

**시험 준비**

 

비밀 원문을 남기지 않고 자격의 식별정보를 수집할 방법과 필요한 최소 자격 목록을 준비한다.

 

**시험에서 확인할 내용**

 

선정한 launcher·driver에서 worker로 전달하는 변수의 이름·출처와 이를 사용하는 구성요소를 대조한다. 무해한 인증정보 표식을 추가하거나 제외해 전달 결과를 비교한다. 인증정보 전달 제외 목록 파일이 없거나 형식이 손상된 경우에는 실제 전달 목록과 오류 처리를 확인한다. 비밀 원문은 기록하지 않는다.

 

**시험 순서**

 

1. launcher와 worker의 자격 전달 목록을 수집한다.
2. 불필요한 시험 자격 표식 유무를 확인한다.
3. 필요한 자격만 남긴 정상 실행을 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 모델 실행 프로세스에 불필요하게 전달된 비밀정보 탈취 | 실제 worker가 부모 환경·secret/mount·장치 권한을 전달받는다. Ray 전달은 선택 시 추가한다. | SC-14-03 |

 

**함께 확인할 보호 요구**

 

- [수집 정보 최소화](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-5-2): worker로 전달·노출된 자격의 수신자·필요성을 확인한다. 로그·dump 등 관측 자료의 수집 필드는 CHK-OBS-003에서 판정한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59) / [개발자 4.2.3 · 인쇄 58 / PDF 68](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=68)

실행 주체의 최소 권한과 API key 관리 원칙을 worker가 인증정보를 상속받는 과정에 적용한다.

**OWASP ASVS:** [V13.3.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 필요하지 않은 실행 주체에 비밀 접근 권한을 주지 않는다.

env·mount·rank별 상속 목록은 최소 권한 확인에 필요한 배포 사실이다.

**NIST SP 800-53 Rev.5:** [AC-6](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) · [IA-5](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 업무에 필요한 접근만 허용하고 인증정보를 무단 노출·변경으로부터 보호한다.

**관련 위협 시나리오:** [SC-14-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-14-03)

 

**관련 근거:** [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [Q-C07](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C07) · [SC-14-03](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-14-03)

