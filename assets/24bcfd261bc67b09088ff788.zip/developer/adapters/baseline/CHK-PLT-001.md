# CHK-PLT-001 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-PLT-001.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 엔진과 worker가 실행에 필요한 호스트·파일·장치 권한만 갖고 있는가? · CHK-PLT-001

<a id="CHK-PLT-001"></a>
 
<a id="141-엔진과-worker의-호스트파일장치-권한이-필요한-범위에-한정되는가"></a>
 
<a id="source-10-01036"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 실행 계정·호스트/컨테이너·mount·장치 접근을 기본 확인한다. 컨테이너 비사용도 제외 사유가 아니다. |
| --- | --- |
| 권장 설정·조치 | 엔진·worker 계정의 호스트·파일·mount·장치 권한을 실제 업무에 필요한 범위로 제한한다. 컨테이너 사용 여부에 맞춰 호스트 접근과 다른 작업 영역의 접근 권한을 확인한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-access) |
| 확인 방법 | 실제 실행 계정, 추가 권한, 마운트, 장치 접근 범위를 확인한다. 불필요한 대상의 접근 거부와 필요한 권한을 사용한 정상 추론을 함께 확인한다.<br>**정상 동작:** 승인 실행 계정이 필요한 모델·장치에 접근해 추론한다. |
| 판정 기준 | 충족<br>필요 밖 접근이 제한되고 정상 모델 적재·선택한 추론 경로는 유지된다.<br>미충족<br>정책상 불필요한 파일·장치·호스트 권한을 사용한다.<br>미확인<br>유효 권한·컨테이너 밖 집행 또는 필요한 권한 목록이 미정이다. |
| 남길 자료 | - 실행 계정·권한/mount·device allowlist/접근 결과·정상 추론 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.6.2 정보시스템 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-2)<br>호스트·서버·네트워크 장비를 관리할 때<br>[공식 안내서 PDF 108쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=108) · 주요 확인사항 1,3 | **보조 자료**<br>엔진·worker의 실행 계정·호스트·파일·장치 권한 결과를 OS 구성 검토의 참고 자료로 사용한다. OS 접속 허용 정책과 서비스 제거 결과는 추가 확보한다. | OS 관리 접속의 사용자·위치·수단과 유휴 종료, 불필요 OS 서비스 제거·서버 분리의 실제 상태를 별도로 확인한다. API·로컬 IPC 인가와 OS 접속 관리를 구분한다. |
| [2.10.2 클라우드 보안](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-2)<br>클라우드에서 서빙 시스템·저장소를 운영할 때<br>[공식 안내서 PDF 156쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=156) · 주요 확인사항 2 | **부분 대응**<br>클라우드 실행 환경의 엔진·worker에 필요한 호스트·파일·장치 권한을 확인한다. | [2.10.2 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-10-2) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 승인 코드의 과도한 권한을 이용한 피해 확대 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [CPU 20261023](../../../site/references/evidence/automation-phase2-20261023.json)<br>`/actual_cpu_runs/cases/0/selected_measurements/checks/0`<br>부분 결과<br>{'POST /v1/completions': 200} · 기능 PASS · 성능 UNKNOWN · 보안 PASS | vLLM CPU 선정 실행의 원래 판정과 측정을 보존했다. | 선정 정책·모델에 한정된다. 전체 분기 조건·정상 대조와 원 증거 묶음을 추가 확인해야 한다. |
| [GPU 20261105](../../../site/references/evidence/gpu-b-phase1-status-20261105.json)<br>`/reused_evidence/12`<br>부분 결과<br>보안 FAIL · 기능 UNKNOWN · 성능 UNKNOWN | 과거 증거를 재사용한 기록이며 새 GPU 실행은 0건이다. | 원문 FAIL·UNKNOWN과 재사용 범위를 유지한다. 현 구성의 전체 권한·소비 범위를 추가 확인해야 한다. |
| [런타임 20261104](../../../site/references/evidence/AWS_GPU_서버2회차_결과_20261104.md)<br>`AWS-06`<br>부분 결과 | 모델 경로 읽기 전용 설정을 관측했다. | 다른 권한·마운트·장치·capability를 추가 확인해야 한다. |

### NIST 요구와 이 점검의 대응 범위

**AC-6 · SC-39 · CM-7 — 요구 직접 대응**

프로세스에 필요한 권한과 기능만 제공한다.

엔진·worker의 호스트 파일·장치·컨테이너 권한을 실제 접근으로 확인한다.

하드웨어 격리까지 확인하지 않았다면 SC-49 충족을 주장하지 않는다.

 

**시험 준비**

 

실제 허용 권한표와 접근 허용·거부를 확인할 무해한 시험 자원(sentinel)을 준비한다.

 

**시험에서 확인할 내용**

 

계정·capability·mount·device와 쓰기 가능한 대상의 목록을 확보한다. 무해한 접근 시험으로 허용된 접근과 허용되지 않은 접근의 결과를 대조한다.

 

**시험 순서**

 

1. 유효 UID·capability·mount·device를 수집한다.
2. 실행에 필요하지 않은 시험 파일·장치에 읽기와 쓰기를 요청한다.
3. 정상 추론과 권한 거부를 확인한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 승인된 코드의 과도한 실행 권한으로 피해 확대 | 승인된 코드가 실제 엔진 계정·장치·파일·통신 권한으로 실행된다. | SC-14-04 |

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [서비스 제공자 2.2.1 · 인쇄 84 / PDF 94](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=94) / [개발자 3.3.3 · 인쇄 49 / PDF 59](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=59)

모델 환경 접근 최소화와 라이브러리의 최소 권한·격리 실행이 대응한다.

**OWASP ASVS:** [V13.2.2](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.2.5](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 실행 계정의 파일·장치·호스트 권한을 최소화한다.

worker·GPU 장치는 최소 권한을 적용할 대상이다.

**NIST SP 800-53 Rev.5:** [AC-6](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 사용자와 프로세스에 업무 수행에 필요한 접근만 허용한다. 엔진과 worker의 파일·호스트·장치 권한을 확인한다.

**관련 위협 시나리오:** [SC-14-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-14-04)

 

**관련 근거:** [Q-C10](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C10) · [SC-14-04](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-14-04)

