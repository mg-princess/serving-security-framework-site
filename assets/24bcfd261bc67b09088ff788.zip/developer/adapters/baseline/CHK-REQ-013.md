# CHK-REQ-013 기준판 상세 시험·구현 근거

[공통 시험 명세](../../checks/CHK-REQ-013.md)

기준판: 기존 문서의 vLLM v0.31.0·SGLang v0.5.22 자료. 아래 설정·소스·관측 방법은 각 문단에 적힌 엔진·기능·조건을 따른다. 실행 여부와 판정은 원문에 적힌 확인 범위를 따른다.



### 응답 옵션이나 오류 메시지를 통해 허용하지 않은 정보가 전달되지 않는가? · CHK-REQ-013

<a id="CHK-REQ-013"></a>
 
<a id="511-응답-옵션과-오류-메시지가-수신자에게-허용된-정보만-반환하는가"></a>
 
<a id="source-10-03543"></a>

**점검 결과:** □ 충족 / □ 미충족 / □ 미확인 / □ 해당 없음

| 적용 대상 | 기본 응답·오류를 확인한다. 추가 반환 옵션이 금지돼 있어도 요청 수용·제거·거부를 확인하며, 허용 시 필드·독자별로 추가한다. |
| --- | --- |
| 권장 설정·조치 | 응답을 받는 사용자·앱에 허용할 필드·반환 옵션·오류 정보를 정하고 실제 전달 경로에 적용한다. 엔진에 해당 제한 기능이 없으면 Gateway 등 지원하는 위치에서 제한하고 직통 접근도 함께 관리한다.<br>[설정·실행 방법 펼쳐 보기](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=ops-data) |
| 확인 방법 | 수신자에게 허용된 반환 필드와 실제 응답을 비교한다. 비공개 합성 표식을 사용해 반환 옵션·오류 분기와 Gateway 경유·직통 경로를 각각 확인한다.<br>**정상 동작:** 일반 응답과 안전한 오류가 허용된 필드만 반환한다. |
| 판정 기준 | 충족<br>비허용 문맥·내부 자료가 반환되지 않는다. 팀 참조 구성에서는 prompt 원문·token ID 추가 반환 옵션을 차단한다. 기업에서 자기 입력 사본 반환을 허용하려면 정책을 변경하고 독자·필드별 권한을 확인한다. 정상 생성 결과가 자기 입력을 인용하는 것과 추가 반환 옵션은 구별한다.<br>미충족<br>정책이 필드 수용 자체를 금지하면 해당 필드를 수용한 경우 미충족이다. 정책이 옵션 작동이나 정보 반환을 제한하면 비허용 옵션이 실제로 작동하거나 허용 밖 정보가 반환된 경우 미충족이다. 단순 필드 존재·무시·정규화와 실제 작동·반환을 구분한다.<br>미확인<br>특정 옵션이나 오류 경로를 실행하지 못했거나 직통 접근 결과를 모른다. |
| 남길 자료 | - 실제 요청 옵션/Gateway 제거·거부/원응답·오류·독자 권한 |

### 세부시험과 구현 근거

#### 관련 ISMS-P 요구

| 관련 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| [2.6.3 응용프로그램 접근](../../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-3)<br>서빙 애플리케이션이 사용자·역할별 작업이나 자료를 제공할 때<br>[공식 안내서 PDF 110쪽](../../../site/references/ISMS-P_인증기준_안내서_2023-11.pdf#page=110) · 주요 확인사항 4,5 | **부분 대응**<br>응답 옵션·오류 메시지의 비허용 필드와 내부 정보 반환을 제한한다. | [2.6.3 공통 운영 확인](../../../site/index.html#view=framework&doc=%EB%B6%80%EB%A1%9D_F_%EC%99%B8%EB%B6%80%EA%B8%B0%EC%A4%80%EA%B3%BC_%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC.md&anchor=isms-p-2-6-3) |

#### 이 분기에 연결한 기존 시험 결과

원래 실행 환경의 부분 결과와 관련 관측이다. 현재 선택한 엔진·판본의 충족 판정은 해당 환경의 증거로 확인해야 한다.

##### 반환 옵션·오류를 이용한 입력·내부 정보 노출 · 부분 결과

| 기존 결과 | 확인한 범위 | 더 확인할 내용 |
| --- | --- | --- |
| [GPU 20261105](../../../site/references/evidence/gpu-a-dev1-phase2-20261105.json)<br>`/runs/7`<br>부분 결과<br>보안 FAIL · 기능 PASS · 성능 UNKNOWN | 반환 정보 시험의 FAIL 기록이다. | 실제 노출 필드·승인 반환 정책·후속 수정 결과를 확인해야 한다. |
| [CPU 20261023](../../../site/references/evidence/automation-phase2-20261023.json)<br>`/actual_cpu_runs/cases/0/selected_measurements/checks/2`<br>부분 결과<br>기능 PASS · 성능 UNKNOWN · 보안 FAIL | vLLM CPU 선정 실행의 원래 판정과 측정을 보존했다. | 선정 정책·모델에 한정된다. 전체 분기 조건·정상 대조와 원 증거 묶음을 추가 확인해야 한다. |

### NIST 요구와 이 점검의 대응 범위

**SI-11 · AC-4 — 요구 직접 대응**

오류와 출력이 비허용 정보를 노출하지 않도록 한다.

응답 옵션·오류 경로별 공개 정보와 수신자의 허용 범위를 확인한다.

SI-11 직접 대응은 오류 정보 부분이며 모든 정상 출력 의미를 포괄하지 않는다.

 

**시험 준비**

 

민감정보 대신 사용할 시험용 표식과 응답으로 반환해도 되는 필드 목록을 준비한다.

 

**시험에서 확인할 내용**

 

시험용 비공개 표식을 넣고 정상 응답, 오류 응답과 각 반환 옵션의 출력을 확인한다. 각 출력이 해당 수신자에게 허용된 정보인지 정책과 비교한다. 시험할 각 반환 경로에서 확인할 수 있도록 해당 표식을 실제로 처리되는 입력에 배치한다. 올바른 수신자에게 반환됐는지와 반환 필드가 그 수신자에게 허용되는지를 각각 판정한다. 앱이 넣은 합성 비공개 system 표식으로 return_prompt_text·return_token_ids를 요청해 Gateway/직통 및 등록 alias에서 비교한다. 선택한 코드의 반환 분기에는 운영자가 별도로 차단하는 장치(gate)가 없다. 따라서 Gateway가 해당 옵션을 거부·제거하는지와 엔진 직통 접근이 제한되는지를 실제 보호 조치로 확인한다. echo·prompt_logprobs·logprobs는 해당 API의 필드·허용 정보별로 따로 판정한다. 오류에는 /workspace/x·s3://bucket/key·가짜 자격 표식을 사용한다. 같은 입력으로 생성된 로그·dump의 필드·문맥은 CHK-OBS-003에서, 저장된 관측 사본의 조회·반출·암호화는 CHK-OBS-006에서 각각 판정한다.

 

**시험 순서**

 

1. 민감정보 대신 사용할 무해한 비공개 표식을 시험 입력에 넣는다.
2. return_prompt_text·return_token_ids 등의 옵션과 오류 분기를 시험한다.
3. Gateway와 직통 응답을 비교한다.

 

**기능·환경별 시험**

 

| 시험 | 확인할 기능·구성 | 시나리오 |
| --- | --- | --- |
| 응답 옵션·오류 메시지로 비공개 입력·내부 정보 노출 | 일반/stream 응답·오류를 기본 확인하고 반환 옵션은 지원·수용/거부와 실제 필드별로 추가한다. | SC-21-01 |

 

**함께 확인할 보호 요구**

 

- [작업·대상 인가](../../../site/index.html#doc=06_%EB%B3%B4%EC%95%88%EC%A0%90%EA%B2%80%ED%91%9C%EC%99%80_%EB%B3%B4%EC%99%84%EB%B0%A9%EB%B2%95.md&anchor=purpose-security-1-2): 같은 실행에서 작업·대상별 허용 여부를 함께 확인하고, 해당 권한 점검의 결과를 연결한다.

 

**엔진별 확인 사항**

 

**오류 응답의 정보 노출 시험 사례**

 

[평가 방법의 적용 사례](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_D_%ED%8F%89%EA%B0%80%EC%96%91%EC%8B%9D%EA%B3%BC_%EC%82%AC%EB%A1%80.md&anchor=source-05-00279)에서는 오류 처리 코드가 정보 정리 함수를 실제로 호출하는지 확인했다. 구별 가능한 합성 입력을 넣고 최종 응답까지 대조한 사례로, 오류 처리 중 정보가 제거되는지 확인할 때 참고한다.

 

### 외부 기준·관련 시나리오

**KISA AI 보안 안내서:** [개발자 3.4.3 · 인쇄 51 / PDF 61](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=61) / [개발자 3.4.4 · 인쇄 52 / PDF 62](../../../site/references/KISA_AI_Security_Guide_Corrected_2026-03.pdf#page=62)

API 응답의 민감정보 마스킹·제거와 오류 메시지의 내부 정보 제한을 직접 다룬다.

**OWASP ASVS:** [V14.2.6](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V15.3.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml) · [V16.5.1](https://github.com/OWASP/ASVS/blob/v5.0.0/5.0/docs_en/OWASP_Application_Security_Verification_Standard_5.0.0_en.xml). 허용된 최소 필드만 반환하고 오류로 내부 정보를 노출하지 않는 기존 요구다.

logprobs·echo 등 옵션은 응답 필드 정책에 대입할 대상이다.

**NIST SP 800-53 Rev.5:** [SI-11](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final). 오류 메시지는 조치에 필요한 정보를 제공하되 악용 가능한 정보를 드러내지 않고 허용된 대상에게 제공한다.

**관련 위협 시나리오:** [SC-21-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=cwe-SC-21-01)

 

**관련 근거:** [Q-C02](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C02) · [Q-C11](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_C_%EC%A0%95%EC%B1%85%EA%B3%BC_%EC%A0%90%EA%B2%80%EA%B7%BC%EA%B1%B0.md&anchor=Q-C11) · [SC-21-01](../../../site/index.html#doc=%EB%B6%80%EB%A1%9D_B_%EC%9C%84%ED%98%91%EA%B3%BC_%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4.md&anchor=SC-21-01)

