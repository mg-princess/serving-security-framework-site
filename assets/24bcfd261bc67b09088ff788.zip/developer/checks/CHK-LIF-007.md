# CHK-LIF-007 필요한 worker와 모델의 실행 준비를 확인한 뒤 요청을 받는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-007.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-007.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-007.md)

## 적용 대상

실제 사용하는 다중 프로세스·분산 실행의 필수 rank·모델 준비와 접수 gate를 확인한다. 선택 graph/backend의 준비 항목은 실제 설정에 맞춰 추가한다.

## 권장 설정·조치

- 실제 모델 로딩과 필수 worker·실행 모드 준비를 서비스 수용 조건에 반영한다. 준비 확인용 정상 추론까지 성공한 뒤 요청을 받고 일부 준비 실패 시 수용을 보류한다.

## 시험 전 준비

준비 상태에 따라 요청을 허용하는 위치와 외부 proxy를 확인한다. keep/dev 옵션의 유효값을 기록한다.

## 확인 방법

필수 rank의 모델 로딩·KV·선택 graph/backend 준비와 외부 service gate의 실제 신규 요청 수용 시각을 연결한다. 필수 준비 하나를 지연한 동안 listener·health 응답과 실제 접수를 구분해 대조하고, 준비 완료 후 정상 canary와 요청 수용을 확인한다. 초기 준비 실패를 상위 기동 결과에 반영하는지는 CHK-LIF-009에서 따로 판정한다. vLLM v0.31.0의 공통 근거 중 기본 재배포·외부 gate·정상 로딩 조건을 참조한다. 근거 원문: [F32](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33911).

## 정상 대조

모든 필수 rank와 모델 준비 후 실제 정상 추론이 성공한다.

## 시험 순서

1. 준비 단계의 rank 하나를 안전하게 지연시킨다.
2. listener·health·Gateway readiness·추론 결과를 비교한다.
3. 준비 후 허용을 확인한다.

## 필수 증거

1. rank 준비/listener 시각/readiness 판정·실제 추론

## 충족

필수 준비 미완료 상태에서는 접수를 허용하지 않고 완료 후 정상 처리한다.

## 미충족

필수 준비 조건 충족 전에 서비스 수용을 허용한다.

## 미확인

health 응답만 있고 rank·model 준비 또는 실제 접수 시점을 모른다.

## 기능·환경별 분기

1. - name: rank 준비 실패를 놓친 채 요청 수용
- scenario_ids: 1. SC-17-01
- apply_when: 기본 재시작·재배포에서 rank별 준비·부분 실패·정리를 확인한다. Ray/live는 선택 시만 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-17-01
2. - name: 승인·준비 검증을 건너뛴 서비스 재개
- scenario_ids: 1. SC-17-02
- apply_when: 모델 준비·승인 확인과 외부 접수 gate/재개를 연결한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-17-02

## 시험 식별자

1. Q-R05-12/SC-17-01
2. Q-C09/SC-17-02

## 외부 기준과 대응 범위

SA-8(24), SI-6 / 설계 원칙 대응

기동·기능 검증 중 안전한 상태를 유지한다.

모델·필수 worker 준비 시각과 실제 요청 수용 시점을 비교한다.

SI-6은 지정 보안·개인정보 기능 범위다. 일반 readiness 전체를 직접 요구하지 않는다.
