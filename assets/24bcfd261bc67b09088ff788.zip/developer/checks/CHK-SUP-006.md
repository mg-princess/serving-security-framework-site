# CHK-SUP-006 각 worker가 자신에게 배정된 승인 모델 파일·shard를 실제로 적재하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-006.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-006.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-006.md)

## 적용 대상

기본 worker 적재는 항상 확인한다. 공유·원격 weights를 사용하면 publisher·model·rank·generation·layout·payload 대응을 추가한다.

## 권장 설정·조치

- 각 worker·rank가 읽을 승인 파일과 담당 shard를 기록하고 실제 적재 결과와 대조한다. 필수 부분이 없거나 다른 모델·버전이 적재되면 준비 완료로 처리하지 않고 원인을 해소한 뒤 정상 추론을 확인한다.

## 시험 전 준비

모델·양자화별로 필수 tensor 기준을 정하고 rank별 적재를 관측할 방법을 준비한다.

## 확인 방법

필요한 node/rank마다 승인된 model·shard·필수 tensor와 실제 read/load·mapper·변환·후처리 결과를 연결한다. 공유·원격 weights는 publisher·model·rank·generation·layout·payload의 실제 적재까지 대조한다. 동일 경로명·key/header 또는 canary 성공만으로 적재 일치를 판정하지 않는다. 선정 model.load_weights 반환·양자화·enable_weights_track 유효값을 고정하고 완전 checkpoint와 필수 tensor 누락 fixture를 비교한다. 의도된 후처리 생성값과 누락을 구분한다. redirect 사용 시 최종 resolved 파일이 각 worker에 배정된 승인 대상과 일치하는지 기록한다. 전체 접수 준비·재개는 CHK-LIF-007·CHK-LIF-009의 판정과 연결한다. 근거 원문: [F33](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33757) · [F34](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33778).

## 정상 대조

완전한 checkpoint로 필요한 모든 TP rank가 자신에게 배정된 부분을 로딩한다.

## 시험 순서

1. rank별 정상 적재를 기록한다.
2. 필수 tensor 일부가 없는 별도 fixture로 기동한다.
3. 누락 처리와 준비 상태를 확인한다.

## 필수 증거

1. rank·shard·mapper·변환 설정/필수 tensor 정의·tracking 반환/로딩 완료 또는 거부. 공유·원격 weights 사용 시 publisher·세대·layout·payload와 실제 적재의 대응도 확보한다.

## 충족

필요한 worker의 실제 적재 대상이 승인 내용과 일치한다. 공유·원격 weights를 사용하면 승인된 model·rank·generation·layout의 payload가 실제 적재돼야 한다. 전체 접수 준비·재개는 7.2 기동 준비 확인의 CHK-LIF-007·CHK-LIF-009에서 별도로 판정한다.

## 미충족

필수 배정 부분이 없거나 승인과 다른데 정상 적재로 인정한다.

## 미확인

모델별 필수 tensor·의도된 후처리 생성값 또는 rank 소비 기록을 알 수 없다. 공유·원격 weights에서 key·header만 확인하고 payload의 실제 적재를 확인하지 못한 경우도 포함한다.

## 기능·환경별 분기

1. - name: 가중치 누락·변환 변경으로 승인과 다른 모델 제공
- scenario_ids: 1. SC-10-04
- apply_when: 선정 모델을 worker에 적재한다. 양자화·mapper·후처리·live reload는 실제 선택 조건으로 구분한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-10-04
2. - name: 가중치 payload 교체로 모델·세대 혼입
- scenario_ids: 1. SC-16-03
- apply_when: 공유·원격 weights의 model·rank·generation·layout·payload를 선택·적재한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-16-03

## 시험 식별자

1. Q-R05-14/SC-10-04
2. Q-C13/SC-16-03

## 외부 기준과 대응 범위

SI-7, CM-2 / 일부 대응

사용 정보의 무결성과 기준 구성 일치를 유지한다.

worker·rank가 담당 shard·tensor를 실제 적재했는지 변환 후 결과까지 확인한다.

파일 검증에서 GPU 적재 내용으로 넘어가는 추가 증거를 유지한다.
