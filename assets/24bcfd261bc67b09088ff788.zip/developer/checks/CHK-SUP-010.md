# CHK-SUP-010 플러그인을 실행하기 전에 승인된 대상인지 검사하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-010.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-010.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-010.md)

## 적용 대상

설치된 entry point와 자동 발견 그룹을 기본 조사한다. 실제 설치·도달하는 general·endpoint·logits·io 그룹별로 확인한다.

## 권장 설정·조치

- 자동 발견되는 plugin 종류와 실제 호출 경로를 조사하고 종류별 허용 목록을 적용한다. plugin을 불러오거나 실행하기 전에 승인 여부를 검사하고 필요 없는 확장을 비활성화한다.

## 시험 전 준비

선정 엔진의 확장 종류별 승인 목록과 제한 설정을 확인하고 무해한 시험 확장을 준비한다. 실제 실행기와 호출 경로도 확인한다.

## 확인 방법

선정 엔진에서 실제 설치·도달하는 확장 종류와 발견·선택·import·호출 순서를 목록화한다. 종류별 승인 설치물·허용 설정을 실제 로딩과 대조하고, 승인 확장과 무해한 비승인 시험 확장의 실행·거부를 각각 확인한다. 한 종류의 필터 결과로 다른 종류를 대신 판정하지 않는다.

## 정상 대조

승인된 plugin만 등록된 환경에서 필요한 기능이 정상 동작한다.

## 시험 순서

1. 설치 entry point와 plugin group을 수집한다.
2. 비승인 무해 plugin을 격리 환경에 등록한다.
3. group별 import·호출과 제한 결과를 확인한다.

## 필수 증거

1. 실제 설치·도달하는 확장 종류·등록/선택 경로와 설치 목록·승인 범위
2. 종류별 유효 제한 설정, 실제 로딩·import·hook 호출 또는 거부와 허용 기능 결과

## 충족

general·endpoint·logits_processors·io processor 등 실제 설치·도달하는 각 그룹에서 승인된 설치물만 로딩되고 필요한 정상 기능이 유지된다. VLLM_PLUGINS 설정 하나로 모든 그룹을 통과시키지 않는다.

## 미충족

해당 group에 요구한 제한을 우회해 비승인 plugin이 실행된다.

## 미확인

group 등록만 확인하고 실제 runner·hook 도달이나 제한을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 플러그인 발견·허용 검사 차이로 비승인 실행
- scenario_ids: 1. SC-11-03
- apply_when: 설치된 general·logits_processors와 실제 선택 io processor 등 그룹을 조사한다. 자동 발견·filter 적용 위치를 그룹별로 확인하며, VLLM_PLUGINS 하나로 모두 보호된다고 판단하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-11-03
2. - name: 작업 거부 전에 플러그인 초기화 코드 실행
- scenario_ids: 1. SC-11-04
- apply_when: endpoint plugin이 설치·활성돼 실제 factory/등록 경로로 로딩된다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-11-04

## 시험 식별자

1. Q-R05-05/SC-11-03
2. Q-R05-05/SC-11-04

## 외부 기준과 대응 범위

CM-7(5) / 요구 직접 대응

승인된 소프트웨어의 예외 허용 정책을 집행한다.

plugin의 발견·선택·모듈 로딩·호출 단계별로 허용 여부를 시험한다.

한 플러그인 그룹의 설정 효과를 다른 그룹으로 확대하지 않는다.
