# CHK-REQ-019 GPU 연산이 입력·버퍼 범위를 지키고 필요한 메모리를 초기화하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-019.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-019.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-019.md)

## 적용 대상

실제 GPU/backend/dtype/shape·의존성에 도달하는 kernel 분기를 확인한다. 다른 kernel의 결과를 전용하지 않는다.

## 권장 설정·조치

- 선택한 kernel·의존성의 수정 버전을 적용하고 실제 buffer 크기·입력 범위에 맞춰 접근·초기화 조건을 검사한다. 수정 전 임시 제한은 확인된 영향 경로에 적용하고 유효 입력의 정상 처리도 함께 확인한다.

## 시험 전 준비

소형 kernel 시험 입력 자료와 계측·검사 도구를 준비한다. 출력 차이만으로 메모리 유출을 확정하지 않는다.

## 확인 방법

근거 있는 경계 입력을 격리 환경에서 시험하고 실제 분기 도달·메모리/오류 계측·정상 출력을 확보한다.

## 정상 대조

선택한 kernel이 유효 shape·length 입력으로 대조 구현과 맞는 결과를 낸다.

## 시험 순서

1. 활성 kernel·dtype·shape를 고정한다.
2. 길이 경계와 padding 변형을 작은 fixture로 실행한다.
3. 오류·guard·출력을 비교한다.

## 필수 증거

1. kernel·GPU·dtype/buffer 범위·초기화/동기화 오류·대조 출력

## 충족

시험한 kernel 분기에서 주소·인덱스·크기 계산과 필요한 영역의 초기화가 유효한 범위를 지키고, 범위 밖 접근이나 초기화되지 않은 값의 소비가 확인되지 않으며 정상 대조 연산이 성립한다. slot 상태·graph replay·통신 버퍼의 소유자와 시간 순서는 CHK-REQ-018·CHK-REQ-020·CHK-REQ-021의 결과와 연결한다. 계측 미비는 미확인으로 둔다.

## 미충족

유효 범위 밖 접근이나 초기화되지 않은 값의 소비가 증거로 확인된다.

## 미확인

집계 GPU 지표만 있거나 kernel·buffer 수준 증거를 얻지 못했다.

## 기능·환경별 분기

1. - name: GPU 메모리 경계 오류로 다른 요청 자료 노출
- scenario_ids: 1. SC-06-02
- apply_when: 선택한 kernel/backend·dtype·shape 또는 실제 CUDA Graph 경로를 확인한다. 각 경로를 서로 대체하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-06-02

## 시험 식별자

1. Q-C06/SC-06-02

## 외부 기준과 대응 범위

SI-10, SC-4 / 일부 대응

입력 유효성과 공유 자원을 통한 비허용 정보 전달을 제한한다.

GPU kernel의 경계 접근·초기화·유효 버퍼 범위를 실제 연산 경로에서 확인한다.

SI-16의 기본 요구는 비인가 코드 실행 방지다. 일반 GPU 메모리 안전의 직접 근거로 쓰지 않는다.
