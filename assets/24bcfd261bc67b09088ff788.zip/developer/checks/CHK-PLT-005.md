# CHK-PLT-005 인증정보가 없거나 만료돼도 승인하지 않은 다른 접근 방식으로 전환하지 않는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-PLT-005.md) · [vLLM 판본 차이](../adapters/vllm/CHK-PLT-005.md) · [SGLang 판본 차이](../adapters/sglang/CHK-PLT-005.md)

## 적용 대상

선정 SDK·취득 주체가 만료·누락 자격을 처리하는 경로를 확인한다. 익명/대체 접근을 지원하면 해당 분기를 추가한다.

## 권장 설정·조치

- 필수 자격이 없거나 만료되면 해당 취득을 보류하고 원인을 기록한다. SDK의 기본 자격·익명 접근·대체 경로를 조사해 승인하지 않은 신원으로 자동 전환되지 않게 한다.

## 시험 전 준비

격리된 시험 자격 사본과 만료 조건을 준비하고, 허용할 cache 사용 정책을 정한다.

## 확인 방법

없음·만료 상태에서 최종 자격 출처·대상·오류를 관측한다. 익명 fallback 존재를 미리 가정하지 않는다.

## 정상 대조

유효 자격으로 승인 객체를 정상 취득한다.

## 시험 순서

1. 시험 자격의 만료·누락을 각각 적용한다.
2. 같은 자료의 취득을 재시도한다.
3. anonymous·다른 provider·cache fallback 여부를 확인한다.

## 필수 증거

1. 자격 선택 순서/최종 접근 identity/취득 대상·실패·fallback

## 충족

허용하지 않은 자격·공급원으로 접근을 지속하지 않는다.

## 미충족

실패 후 승인되지 않은 identity·경로로 취득을 계속한다.

## 미확인

provider chain 또는 실제 fallback identity를 관측하지 못했다.

## 기능·환경별 분기

1. - name: 자격 만료 뒤 승인하지 않은 대체 접근
- scenario_ids: 1. SC-14-02
- apply_when: 선정 SDK가 만료·누락 자격을 처리하며 익명·대체 자격 경로의 존재를 조사한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-14-02

## 시험 식별자

1. Q-C10/SC-14-02

## 외부 기준과 대응 범위

SC-24, IA-5, AC-3 / 일부 대응

인증 실패 때도 보호 정책을 보존한다.

인증정보 부재·만료 후 익명·다른 계정·다른 취득 경로로 전환하는지 확인한다.

실패 시 기본 동작과 허용된 대체 경로를 명시한다.
