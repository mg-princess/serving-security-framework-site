# CHK-PLT-002 같은 호스트의 내부 통신에 허용된 프로세스만 접속할 수 있는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-PLT-002.md) · [vLLM 판본 차이](../adapters/vllm/CHK-PLT-002.md) · [SGLang 판본 차이](../adapters/sglang/CHK-PLT-002.md)

## 적용 대상

API/core/worker가 실제 사용하는 로컬 IPC 경로와 접근 가능한 주체를 확인한다.

## 권장 설정·조치

- 로컬 socket·공유 메모리와 이를 생성하는 디렉터리의 소유자·권한을 제한한다. 허용 프로세스가 사용할 접점과 명령 범위를 확인하고 비허용 계정의 읽기·연결·명령 전달을 차단한다.

## 시험 전 준비

IPC 종류별로 무해한 연결 시험 자료를 준비한다. 임의로 구성한 역직렬화 payload는 사용하지 않는다.

## 확인 방법

허용/비허용 시험 프로세스로 연결·메시지 수용을 대조하고 소켓·SHM 권한을 확보한다.

vLLM v0.31.0 적용 조건: 실제 RPC_BASE_PATH, socket/SHM 소유자·mode·mount namespace·접근 가능한 PID/UID를 수집한다. 현재 접근 가능한 범위와 임의 명령 실행의 효과는 나눠 확인한다. 허용 프로세스·동일 UID 비허용 프로세스·다른 UID 비허용 프로세스에서 채널별 연결과 무해 메시지 수용을 대조한다. OS 권한·namespace와 실제 소비 여부를 기록한다. 정상 대조: 허용 프로세스의 TP 요청 정상 처리와 채널별 연결/소비 기록 확보.

## 정상 대조

승인 core·worker가 IPC를 통해 정상 요청을 수행한다.

## 시험 순서

1. 실제 socket·shared memory·TCP IPC 목록을 확보한다.
2. 비허용 시험 UID에서 연결·열기를 시도한다.
3. 허용 주체와 비교한다.

## 필수 증거

1. IPC 주소·소유자·mode/실제 process UID/연결·열기·작업 영향

## 충족

채널별 정책이 요구하는 연결·열기·자료 읽기/쓰기·명령 수용의 접근 제한을 지키고 허용 프로세스의 정상 IPC 작업은 유지된다. 연결 가능성, 보호 자료 접근, 명령 소비의 결과를 구분해 기록한다.

## 미충족

채널 정책이 금지한 비허용 프로세스의 연결·열기·보호 자료 읽기/쓰기 또는 명령 수용이 실제 성립한다.

## 미확인

파일 mode만 확인하고 namespace·상위 디렉터리·실제 접속을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 로컬 socket 접근을 통한 내부 제어 침입
- scenario_ids: 1. SC-08-01
- apply_when: 실제 socket·SHM 등 로컬 IPC 경로와 peer 접근권이 있다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-01

## 시험 식별자

1. Q-C07/SC-08-01

## 외부 기준과 대응 범위

AC-3, SC-39 / 요구 직접 대응

내부 자원 접근을 승인된 프로세스에 제한한다.

같은 호스트의 IPC·소켓 접속 주체와 실제 연결 결과를 확인한다.

TCP 통제와 파일·IPC 권한을 따로 시험한다.
