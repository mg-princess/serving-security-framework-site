# CHK-OBS-002 준비·실패·종료 기록이 실제 worker·작업·수집 상태와 일치하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-OBS-002.md) · [vLLM 판본 차이](../adapters/vllm/CHK-OBS-002.md) · [SGLang 판본 차이](../adapters/sglang/CHK-OBS-002.md)

## 적용 대상

준비·실패·종료 기록과 실제 상태를 기본 대조한다. profiler 종료는 해당 기능이 있을 때 추가한다.

## 권장 설정·조치

- 기동 요청·접속 가능·모델 준비·계산 완료·수집 종료의 의미를 기록에서 구분한다. 완료 상태를 표시할 때 해당 worker·작업·수집기의 실제 상태를 확인해 중간 단계를 전체 완료로 보고하는 경로를 보완한다.

## 시험 전 준비

상태별 의미와 기한을 정하고 독립적으로 관측할 지점을 준비한다.

## 확인 방법

같은 실행에서 API·health·로그가 표현한 준비·실패·작업 완료·수집 종료의 의미와 시각을 실제 worker·작업·backend의 독립 관측에 맞춰 대조한다. 준비 gate·초기 실패 집계·작업/자원 종결 자체는 해당 LIF 항목에서 판정하고, 이 항목은 그 상태를 기록이 정확히 표현했는지 판정한다. profiler가 실제 활성인 경우 CHK-LIF-014의 정상 시작·수집·종료와 backend 시작/정지 실패 시험 자료를 공유해, 응답·경고·내부 flag가 실제 수집·산출/전송·다음 시작 상태와 일치하는지 확인한다. 공통 근거의 route 등록·접근 조건과 격리 시험 조건을 유지한다. 근거 원문: [F38](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33961).

## 정상 대조

정상 준비·완료 기록이 실제 실행 상태와 일치한다.

## 시험 순서

1. 정상 완료와 안전한 실패·종료를 각각 실행한다.
2. API 응답·로그·worker 실제 상태를 시간순으로 대조한다.

## 필수 증거

1. 상태전이 시각/API·로그 표현/worker·작업·수집 실제 상태

## 충족

준비·작업 완료·수집 종료 기록이 각각 해당 구성요소의 실제 상태와 일치한다.

## 미충족

접수·listener·종료 요청을 실제 준비·적용·종결 완료로 잘못 기록한다.

## 미확인

실제 상태를 별도로 계측하지 못해 로그 문구의 진위를 확인할 수 없다.

## 기능·환경별 분기

1. - name: health 정상 표시로 실제 추론 장애 은폐
- scenario_ids: 1. SC-23-04
- apply_when: 준비·실패·종료의 API/health·기록과 실제 worker/추론 상태를 비교한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-23-04
2. - name: profiler 정지 응답을 수집 종료로 오판
- scenario_ids: 1. SC-23-05
- apply_when: 선정 profiler가 활성이고 실제 등록 route·backend 종료 경로가 있다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-23-05
3. - name: 대상 식별 오류로 비승인 사용을 정상 판단
- scenario_ids: 1. SC-23-03
- apply_when: 승인·검사·소비의 필수 사건을 실제 실행과 연결한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-23-03

## 시험 식별자

1. Q-C11/SC-23-04
2. Q-C08/SC-23-05
3. Q-R05-15/SC-23-03

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.9.2 성능 및 장애관리<br>서비스의 용량·가용성과 장애를 관리할 때 | 부분 대응<br>상태 기록이 실제 worker·요청·수집 상태와 일치하는지 확인한다. | [2.9.2 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-2) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

AU-3, SA-8(20) / 일부 대응

정확한 사건 결과와 상태 메타데이터를 관리한다.

ready·완료·종료 표기가 실제 worker·GPU·수집 상태와 일치하는지 독립 관측한다.

일반 health 표시는 모두 감사 기록인 것은 아니다. 실제 상태 대조는 BBLS에서 구체화한 시험이다.
