# CHK-REQ-018 요청 처리 자리를 옮기거나 다시 쓸 때 이전 요청의 제한 상태가 다음 요청에 남지 않는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-018.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-018.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-018.md)

## 적용 대상

실제 runner의 batch 자리 이동·재사용 경로를 확인한다. V1 CPU mask 시험과 V2 상태/count 시험을 구분한다.

## 권장 설정·조치

- 실제 runner가 관리하는 요청별 제한 상태를 batch slot 이동·교환·완료·재사용에 맞춰 갱신한다. 선택한 실행기의 이전 제한 상태를 초기화하고 최종 sampling에 사용되는 상태가 현재 요청의 것인지 확인한다.

## 시험 전 준비

선정 실행기의 실제 sampling 상태와 자리 재사용·최종 소비를 확인할 방법을 준비한다. 제한 없는 B 요청을 단독 실행하는 대조도 포함한다.

## 확인 방법

선정 실행기가 관리하는 요청별 sampling 제한 상태와 재사용 단위를 식별한다. A의 종료·자리 이동 뒤 B가 같은 단위를 쓸 때 현재 B의 상태가 최종 계산에 반영되는지, B의 단독 정상 대조와 상태·허용 출력 범위를 비교한다.

## 정상 대조

서로 다른 sampling 제한의 A·B를 새 실행 자리에서 각각 처리해 요청별 상태와 정상 출력 범위를 확보한다.

## 시험 순서

1. 활성 runner를 확인한다.
2. A 종료 후 B가 같은 slot을 사용하도록 작은 배치를 실행한다.
3. B의 실제 제한 상태와 출력을 대조한다.

## 필수 증거

1. 실제 실행기·요청 ID·재사용 단위/생성 세대와 현재 요청의 sampling 제한
2. 이동·초기화·갱신 전후 상태, 최종 계산에 사용된 상태와 B 단독/재사용 시 결과

## 충족

현재 요청의 mask·sampling 제한이 최종 계산에 반영되고 다른 요청의 제한을 상속하지 않는다.

## 미충족

다른 요청의 제한 상태가 현재 요청의 최종 계산에 적용되거나, 현재 요청에 필요한 제한이 누락·잘못 적용된 사실이 확인된다. 출력 변화와 후속 영향은 별도로 기록한다.

## 미확인

slot 재사용 또는 해당 runner 상태 갱신을 계측하지 못했다.

## 기능·환경별 분기

1. - name: 재사용 배치 자리의 토큰 제한 상태 혼입
- scenario_ids: 1. SC-06-01
- apply_when: 실제로 V1 runner를 사용하고 CPU mask가 할당된 condense 경로에 도달할 때. A 제한 요청 종료/이동 뒤 B의 동일 slot 재사용을 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-06-01
2. - name: 재사용 배치 자리의 토큰 제한 상태 혼입
- scenario_ids: 1. SC-06-01
- apply_when: 실제로 V2 runner가 선택되고 해당 sampling 옵션이 소비될 때. slot·count/flag·staged write와 B의 무제한 정상 대조를 확인한다. V1 결과를 전용하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-06-01

## 시험 식별자

1. Q-C02/SC-06-01

## 외부 기준과 대응 범위

SA-8(20), SC-4 / 설계 원칙 대응

정확한 실행에 필요한 메타데이터와 공유 상태를 보호한다.

batch slot 이동·재사용 뒤 현재 요청의 mask·생성 제한이 최종 계산에 적용되는지 확인한다.

제한 상태 위반 자체와 실제 출력 변화를 별도로 기록한다.
