# CHK-REQ-005 호출자에게 허용된 모델만 실행되고, 사용을 종료한 모델은 실행되지 않는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-005.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-005.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-005.md)

## 적용 대상

모델 1개에서도 허용 대상을 확인한다. alias·adapter·공유 모델 소비는 실제 선택 시 추가한다. 모델을 사용 종료하거나 alias를 변경한 경우에는 이전 경로가 선택하는 최종 모델도 확인한다.

## 권장 설정·조치

- 별칭·adapter·공유 가중치가 최종적으로 선택하는 모델을 확인하고 그 대상에 호출자의 사용 권한을 검사한다. 모델 선택 설정의 변경 권한을 제한하고 변경 이력을 남긴다.
- 사용 종료한 모델의 신규 실행을 중단하고 Gateway·엔진의 남은 route·alias를 현재 승인 대상과 대조한다. 공용 API를 유지할 때도 퇴역 모델을 선택하지 않도록 설정한다. 기존 요청의 완료·중단과 자원 정리는 LIF에서 확인한다.

## 시험 전 준비

활성 endpoint별로 최종 선택 모델을 관측할 방법을 준비하고, 설치된 추가 기능만 시험한다. 사용 종료 모델은 시험 사본에서 확인하며, 사용 종료 정책·기한과 최종 실행 모델의 관측 방법을 정한다.

## 확인 방법

활성 endpoint와 이름 생략·별칭·adapter·resolver 등 실제 selector별로 신원–제출 선택값–최종 모델/adapter–사용 권한을 연결한다. 허용·비허용 모델과 정상 호출을 비교한다. 모델 사용 종료·alias 재매핑 시에는 이전 이름·주소·자격의 호출이 선택하는 실제 모델을 현재 승인 대상과 대조하고 다른 활성 모델의 정상 처리를 확인한다. MM 기본 LoRA·resolver·SageMaker adapter 주입은 실제 설치·활성일 때만 추가한다. 외부 decorator의 header/검증은 확인한 범위를 남기고 최종 adapter·revision·경로에 사용자 인가가 적용되는지 확인한다. 파일·payload의 승인 일치는 CHK-SUP-003·CHK-SUP-005·CHK-SUP-006에서 별도로 판정한다. 근거 원문: [F20](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33520).

## 정상 대조

호출자가 허용된 활성 모델을 정상 사용한다. 사용 종료 시험에서는 다른 활성 모델과 현재 승인된 alias 매핑도 정상 동작한다.

## 시험 순서

1. 활성 모델 선택 경로 목록을 확보한다.
2. 표시명·adapter·대체 endpoint 선택값을 변경한다.
3. 최종 모델·파일 선택과 인가를 대조한다.
4. 시험 사본에서 모델 하나를 사용 종료 처리하고 이전 모델명·alias·주소·기존 자격으로 호출한다.
5. 실제 선택·실행된 모델을 확인하고 승인된 다른 활성 모델의 정상 처리와 비교한다.

## 필수 증거

1. 역할×모델 허용표/선택값/최종 모델·adapter·실제 소비
2. 모델 사용 종료 대상·승인 시각, Gateway·엔진의 route/alias 전후 값, 실제 선택·실행 모델, 활성 모델의 정상 응답

## 충족

호출자에게 허용된 모델·adapter만 실행되며 사용 종료한 모델은 실행되지 않는다. 공용 API·alias를 현재 승인된 다른 모델에 재사용하면 실제 선택 결과가 그 승인과 일치한다. 실제 파일의 승인 여부는 모델·소프트웨어 무결성 분야에서 판정한다.

## 미충족

허용되지 않은 최종 모델이나 adapter가 선택·사용된다. 사용 종료한 모델이 이전 이름·alias·직통 경로에서 계속 선택·실행된다.

## 미확인

API 표시명만 확인했거나 조건부 resolver·endpoint의 최종 대상을 모른다. 사용 종료 대상·기한 또는 실제 실행 모델을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 모델 선택값 변경을 통한 비허용 모델 실행
- scenario_ids: 1. SC-02-01
- apply_when: 모델 selector를 기본 확인하고 adapter/resolver는 지원·활성 조건에서 추가한다. 모델 사용 종료 시 이전 selector의 최종 실행 결과도 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-02-01
2. - name: 모델 별칭 변경을 통한 승인 대상 바꿔치기
- scenario_ids: 1. SC-02-04
- apply_when: 서비스 이름·alias·worker에 실제 모델을 연결하는 경로가 있다. 단일 모델도 포함한다. 사용 종료·재매핑 후에도 alias의 현재 승인 대상과 실제 실행을 대조한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-02-04
3. - name: daemon 접속으로 권한 밖 가중치 읽기
- scenario_ids: 1. SC-16-01
- apply_when: 별도 weights daemon 또는 공유 모델 공급 구현을 사용한다. 기본 TP와 구분한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-16-01

## 시험 식별자

1. Q-C02/SC-02-01
2. Q-R05-14/SC-02-04
3. Q-C13/SC-16-01

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.6.3 응용프로그램 접근<br>서빙 애플리케이션이 사용자·역할별 작업이나 자료를 제공할 때 | 부분 대응<br>호출자에게 허용한 모델만 실제로 선택·실행되는지 확인한다. | [2.6.3 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-3) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

AC-3, AC-3(8) / 요구 직접 대응

대상별 접근 권한과 변경된 권한의 철회를 집행한다.

모델 별칭·최종 모델 선택과 사용 종료 뒤 실제 실행을 대조한다.

모델 서비스 종료와 인증정보 철회를 구분해 유지한다.
