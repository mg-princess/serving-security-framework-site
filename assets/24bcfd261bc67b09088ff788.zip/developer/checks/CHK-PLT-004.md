# CHK-PLT-004 worker에 실행에 필요한 인증정보와 비밀정보만 전달하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-PLT-004.md) · [vLLM 판본 차이](../adapters/vllm/CHK-PLT-004.md) · [SGLang 판본 차이](../adapters/sglang/CHK-PLT-004.md)

## 적용 대상

기본 worker 환경·자격 상속을 확인한다. Ray/원격 worker 전달은 해당 실행기를 사용할 때 추가한다.

## 권장 설정·조치

- driver·부모 프로세스의 환경변수·Secret·파일·mount에서 worker로 전달할 자격을 필요한 것만 명시한다. worker가 받은 자격과 실제 접근 가능한 저장소·서비스를 대조하고 불필요한 전달을 제거한다.

## 시험 전 준비

비밀 원문을 남기지 않고 자격의 식별정보를 수집할 방법과 필요한 최소 자격 목록을 준비한다.

## 확인 방법

선정 launcher·driver에서 worker로 전달되는 변수 이름·출처·소비자를 대조한다. 무해 자격 표식의 추가·제외를 비교하고, 자격 전달 제외 목록의 파일 누락·형식 손상 때 실제 전달 목록과 오류 처리를 확인한다. 비밀 원문은 기록하지 않는다.

## 정상 대조

worker가 필요한 최소 자격으로 정상 실행한다.

## 시험 순서

1. launcher와 worker의 자격 전달 목록을 수집한다.
2. 불필요한 시험 자격 표식 유무를 확인한다.
3. 필요한 자격만 남긴 정상 실행을 비교한다.

## 필수 증거

1. env·mount·credential provider/rank별 유효 자격/정상 기능 결과

## 충족

필요하지 않은 소비자에게 자격을 노출하지 않는다.

## 미충족

불필요한 자격이 worker에 전달되어 접근에 사용 가능하다.

## 미확인

env만 확인하고 파일·provider·상속 자격 경로를 확인하지 못했다.

## 기능·환경별 분기

1. - name: worker에 전달된 불필요한 비밀정보 탈취
- scenario_ids: 1. SC-14-03
- apply_when: 실제 worker가 부모 환경·secret/mount·장치 권한을 전달받는다. Ray 전달은 선택 시 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-14-03

## 시험 식별자

1. Q-C10/SC-14-03

## 외부 기준과 대응 범위

AC-6, IA-5 / 요구 직접 대응

필요한 권한만 부여하고 인증정보의 노출·변조를 막는다.

worker에 전달된 환경변수·마운트·비밀정보가 실제 필요 범위인지 확인한다.

인증정보 전달 최소화와 보관·교체 수명주기를 구분한다.
