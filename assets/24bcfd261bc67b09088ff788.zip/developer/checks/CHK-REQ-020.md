# CHK-REQ-020 CUDA Graph를 다시 실행할 때 현재 입력을 쓰고, 읽는 중인 출력은 덮어쓰지 않는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-020.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-020.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-020.md)

## 적용 대상

CUDA Graph의 실제 활성 여부와 runner/mode를 먼저 확인한다. 명시 활성 옵션 부재만으로 비사용을 판단하지 않는다.

## 권장 설정·조치

- CUDA Graph 재실행 전에 현재 입력을 갱신하고, 연산·출력 사용·buffer 재사용의 동기화 순서를 지킨다. 실행 모드나 buffer가 바뀌면 graph 관리자의 재캡처·재사용 조건을 확인한다.

## 시험 전 준비

CUDA Graph의 활성 조건과 buffer·stream을 관측할 방법을 준비한다. 입력 갱신 누락·잘못된 참조·격리 위반을 실패 기준으로 관측한다.

## 확인 방법

입력 갱신→descriptor→capture/replay→출력 소비→재사용을 계측한다. 가변 길이·배치·취소 후 재사용을 eager 대조와 비교하고 입력/출력 결과를 따로 남긴다.

## 정상 대조

capture 후 동일 shape의 새 입력을 넣으면 새 입력에 해당하는 결과가 나온다.

## 시험 순서

1. capture 기준선을 확보한다.
2. 같은 buffer에 다른 무해 입력을 넣고 replay를 실행한다.
3. 연속 replay·출력 복사·완료 순서를 대조한다.

## 필수 증거

1. capture key·주소/입력 갱신·출력 소비/stream event·대조 출력

## 충족

현재 replay의 입력과 유효 길이가 실제 계산에 반영되고, 유효 길이 밖이나 이전 요청의 상태를 소비하지 않으며, 출력 소비가 끝나기 전에 같은 버퍼를 덮어쓰거나 다른 replay의 결과로 바꾸지 않는다. 입력 갱신·copy/동기화·소비·재사용 순서를 증거로 확인한다. kernel 자체의 주소·인덱스 계산은 CHK-REQ-019, TP native 등록 참조는 CHK-REQ-021의 결과와 연결한다. 주소 일치 assert만으로 충족 처리하지 않는다.

## 미충족

현재 replay가 현재 입력·유효 길이에 맞지 않는 값을 소비하거나, 출력 소비가 끝나기 전에 같은 버퍼를 덮어쓰는 등 필요한 동기화·수명 조건을 위반한 사실이 확인된다. 실제 출력 변화·잘못된 귀속은 별도로 기록한다.

## 미확인

replay 도달·copy 완료·동기화 순서를 관측하지 못했다.

## 기능·환경별 분기

1. - name: GPU 메모리 경계 오류로 다른 요청 자료 노출
- scenario_ids: 1. SC-06-02
- apply_when: V1 runner의 해당 CUDA Graph mode가 실제 활성일 때. 현재 입력 갱신·출력 소비와 buffer 수명을 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-06-02
2. - name: GPU 메모리 경계 오류로 다른 요청 자료 노출
- scenario_ids: 1. SC-06-02
- apply_when: V2 runner의 해당 CUDA Graph mode가 실제 활성일 때. 선정 caller/graph manager의 갱신·출력 소비 동기화를 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-06-02

## 시험 식별자

1. Q-C06/SC-06-02

## 외부 기준과 대응 범위

SA-8(19), SA-8(20) / 설계 원칙 대응

실행과 상태 전환 중 보호 공백과 메타데이터 불일치를 방지한다.

CUDA Graph 입력 갱신·출력 읽기·버퍼 덮어쓰기의 순서와 수명을 확인한다.

SI-16·SI-10(4)를 CUDA Graph 수명 규칙의 직접 조항으로 연결하지 않는다.
