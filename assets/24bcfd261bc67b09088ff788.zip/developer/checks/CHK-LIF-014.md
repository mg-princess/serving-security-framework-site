# CHK-LIF-014 성능 진단을 종료하면 실제 수집과 관련 자원 사용도 정한 기준대로 끝나는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-014.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-014.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-014.md)

## 적용 대상

profiler의 실제 활성·등록 route·backend 종료 경로가 있을 때 적용한다. 비사용 기능은 등록·도달성을 확인한 뒤 제외한다.

## 권장 설정·조치

- profiler의 시작·종료 요청과 실제 수집·출력·자원 정리 상태를 각각 기록한다. 종료 실패·지연을 성공으로 보고하지 않고 정한 기한 내 수집 중단·잔여 자원 정리를 확인한다.

## 시험 전 준비

짧은 profile 시험 자료와 오류 주입 방법을 준비하고 종료 기한을 정한다.

## 확인 방법

선정 진단 backend의 시작·수집·종료 계약과 산출 방식을 확인한다. 종료 응답·경고·실제 수집 상태·해당 산출물/전송·자원 사용과 다음 시작 가능 여부를 대조한다. 같은 시험의 종료 API·로그 표현과 실제 상태의 일치는 CHK-OBS-002에서 별도로 판정한다. vLLM v0.31.0의 공통 근거를 사용할 때 실제 profiler 설정·route 등록·접근 범위와 격리된 backend 시작/정지 실패 주입 조건을 유지한다. 근거 원문: [F38](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33961).

## 정상 대조

허용된 진단을 시작·종료하면 해당 backend의 수집·산출/전송이 종료 계약에 맞게 마무리된다.

## 시험 순서

1. 짧은 정상 진단을 실행하고 실제 수집을 확인한다.
2. 종료 호출 후 backend의 수집·산출/전송 완료와 자원 상태를 대조한다.
3. 별도 격리 실행에서 종료 오류를 주입하고 실제 실패 상태·다음 시작 가능 여부를 확인한다.

## 필수 증거

1. 진단 backend·종료 계약, 종료 API/명령 결과·경고와 실행 주체별 실제 수집 상태
2. backend가 사용하는 파일·스트림·원격 수신 등 산출 방식의 완료/계속 수집 여부와 자원·다음 시작 상태

## 충족

선정 backend의 종료 계약을 충족한다. 모든 backend에 파일 생성을 강제하지 않는다.

## 미충족

선정 backend에 채택한 수집 종료·산출/전송 마무리·자원 정리의 필수 조건을 위반하거나, 종료 실패를 성공으로 기록한다. 오류 주입 시험은 정한 오류 처리·복구 조건과 대조한다. 파일 산출은 해당 backend가 요구하는 범위에서 판정하며, 상태 표시의 정확성은 CHK-OBS-002와 함께 확인한다.

## 미확인

종료 응답만 있고 실제 수집 종료와 해당 backend에 필요한 산출·전송·자원 정리 상태를 확인하지 못했다.

## 기능·환경별 분기

1. - name: profiler 정지 응답을 수집 종료로 오판
- scenario_ids: 1. SC-23-05
- apply_when: 선정 profiler가 활성이고 실제 등록 route·backend 종료 경로가 있다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-23-05

## 시험 식별자

1. Q-C08/SC-23-05

## 외부 기준과 대응 범위

CM-7, SC-6, SA-8(19) / 일부 대응

불필요한 기능·자원 사용을 제한하고 종료 중 보호를 유지한다.

profiler 종료 응답·실제 수집·파일 생성·전송·자원 종료를 대조한다.

실제 종료 조건 준수와 종료 상태 보고 정확성을 각각 판정한다.
