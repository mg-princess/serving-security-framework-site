# CHK-PLT-009 엔진에서 기록 수집기와 최종 저장소까지 각 전송 구간을 보호하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-PLT-009.md) · [vLLM 판본 차이](../adapters/vllm/CHK-PLT-009.md) · [SGLang 판본 차이](../adapters/sglang/CHK-PLT-009.md)

## 적용 대상

외부 collector 또는 별도 sink로 관측 자료를 보낼 때 적용한다. 엔진→collector와 collector→sink를 따로 확인한다.

## 권장 설정·조치

- 엔진에서 관측 수집기까지, 수집기에서 최종 저장소까지 각 전송 구간의 상대 검증·보호 설정을 적용한다. proxy·SDK·중계 구간을 포함해 실제 목적지와 보호 상태를 확인한다.

## 시험 전 준비

실제 송수신 도구·수집기·저장소 설정을 확인하고, 채택한 보호 채널의 시험 자격·인증서를 준비한다. 자격 원문은 수집하지 않는다.

## 확인 방법

각 구간의 실제 송수신 구성요소·종단·상대 확인·자격·전송 보호와 수신 기록을 대조한다. push/pull에 따라 연결을 시작하는 주체와 TLS 종료점을 확인하고 잘못된 상대·인증서를 거부하는지 정상 연결과 비교한다.

## 정상 대조

엔진→collector→sink의 승인 기록이 지정 종단으로 전달된다.

## 시험 순서

1. 각 구간의 실제 연결 주체·송수신 도구·protocol·보호 요구를 확인한다.
2. 시험 인증서·수신지 불일치를 적용한다.
3. 연결 거부·실제 수신과 정상 복구를 비교한다.

## 필수 증거

1. 엔진·수집기·저장소 사이 실제 전송/수집 방식, 연결 주체·종단과 송수신 도구/라이브러리 판본·유효 설정
2. 구간별 실제 protocol·상대 인증·보호 채널·수신 결과와 잘못된 상대 연결의 처리

## 충족

어느 구간도 필요한 보호에서 누락되지 않는다.

## 미충족

TLS·상대 확인을 요구한 구간에서 비보호 전송 또는 다른 수신지가 허용된다.

## 미확인

URL scheme만 보고 SDK 동작·후속 구간을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 엔진→수집기 구간에서 기록 도청·변조
- scenario_ids: 1. SC-24-01
- apply_when: 엔진이 collector로 관측 자료를 전송한다. exporter SDK·protocol·TLS/peer·proxy를 조사한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-24-01
2. - name: 수집기→저장소 구간에서 기록 도청·변조
- scenario_ids: 1. SC-24-02
- apply_when: collector 이후 별도 sink·저장소로 자료를 전달한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-24-02

## 시험 식별자

1. Q-C07/SC-24-01
2. Q-C07/SC-24-02

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.7.1 암호정책 적용<br>암호화가 필요한 개인정보·중요정보를 저장·전송할 때 | 부분 대응<br>엔진→수집기→최종 저장소의 각 구간에서 필요한 전송 보호를 확인한다. | [2.7.1 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-7-1) |
| 2.10.5 정보전송 보안<br>다른 조직과 개인정보·중요정보를 주고받을 때 | 보조 자료<br>다른 조직의 수집기·저장소로 중요정보를 전송할 때 해당 구간의 보호 자료를 활용한다. | [2.10.5 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-5) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

SC-8, IA-9 / 요구 직접 대응

감사·관측 자료 전송과 수신 서비스의 신원을 보호한다.

엔진→수집기→저장소의 각 구간을 추적한다.

첫 구간의 TLS만으로 이후 구간까지 보호됐다고 판단하지 않는다.
