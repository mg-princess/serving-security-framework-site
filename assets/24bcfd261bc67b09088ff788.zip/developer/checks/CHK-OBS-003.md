# CHK-OBS-003 로그·진단·추적·덤프에 수집을 허용한 정보만 남기는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-OBS-003.md) · [vLLM 판본 차이](../adapters/vllm/CHK-OBS-003.md) · [SGLang 판본 차이](../adapters/sglang/CHK-OBS-003.md)

## 적용 대상

기본 로그·엔진 예외 dump의 필드·독자를 확인한다. debug·trace·profiler는 실제 활성 경로별로 추가한다.

## 권장 설정·조치

- 로그 수준·오류·debug·trace·dump별 허용 필드를 정하고 기록 생성·수집 단계에 필터를 적용한다. 합성 민감 표식으로 원본·사본을 확인하고 불필요한 본문·자격정보 기록을 제거한다.

## 시험 전 준비

합성 표식과 허용 필드표를 준비한다. shape·anon_repr와 실제 프롬프트 내용을 구분해 수집한다.

## 확인 방법

합성 민감 표식을 넣은 정상 요청과 안전한 오류 요청으로 기본 로그·예외 dump를 수집하고, debug·trace·profiler는 실제 활성 경로에서 추가한다. 원본·회전파일·collector 이후 사본별로 생성 필드·문맥·마스킹·필터와 허용 수집 정책을 대조한다. shape·anon_repr 정제와 원문 필드를 구분하고, collector 필터만으로 로컬 원본이 보호됐다고 판정하지 않는다. 반환 옵션·echo·logprobs·오류 입력은 CHK-REQ-013과 같은 시험에서 사용할 수 있다. 그 입력이 남긴 관측 자료의 필드·문맥은 이 항목에서, API 응답의 허용 정보는 CHK-REQ-013에서 따로 판정한다. 확보한 같은 로그·dump artifact의 조회·반출 권한과 저장 암호화는 CHK-OBS-006에서 판정한다. vLLM v0.31.0의 공통 근거를 참조한다. 근거 원문: [F26](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33848).

## 정상 대조

허용 로그 수준에서 고유 무해 표식 요청이 승인한 필드만 남긴다.

## 시험 순서

1. 정상·안전한 오류 요청에 표식을 포함한다.
2. 기본 exception dump와 선택 기능인 debug/trace를 각각 수집한다.
3. 원본·collector 사본의 필드를 비교한다.

## 필수 증거

1. 활성 로그·dump 설정/실제 필드·표식/원본과 사본 필터

## 충족

금지한 필드·문맥을 수집하지 않고 필요한 사건은 남긴다.

## 미충족

금지 민감 필드가 기록되거나 수집 목적 밖 사본에 포함된다.

## 미확인

오류 분기·선택 로그 수준·원본 파일을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 로그 읽기 권한으로 비공개 입력 사본 열람
- scenario_ids: 1. SC-21-02
- apply_when: 기본 로그·예외 dump·저장 기록을 확인하며 debug/진단 사본은 실제 생성 조건으로 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-21-02
2. - name: 반환 옵션·오류를 이용한 입력·내부 정보 노출
- scenario_ids: 1. SC-21-01
- apply_when: 일반/stream 응답·오류를 기본 확인하고 반환 옵션은 지원·수용/거부와 실제 필드별로 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-21-01

## 시험 식별자

1. Q-C11/SC-21-02
2. Q-C11/SC-21-01

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.9.4 로그 및 접속기록 관리<br>운영 로그·접속기록을 생성·수집·보관할 때 | 부분 대응<br>정한 로그 유형·필드에 따라 필요한 사건을 남기고 비허용 정보의 수집을 제한한다. | [2.9.4 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-4) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

AU-3(3), AC-4, IA-5 / 일부 대응

감사 기록의 개인정보를 제한하고 비밀정보·정보 흐름을 보호한다.

입력·가중치·자격 표식을 기본 로그·덤프·회전 파일·수집 사본에서 확인한다.

AU-3(3)은 개인정보 범위다. 모든 비밀정보 최소 수집의 동등 조항으로 확대하지 않는다.
