# CHK-REQ-021 TP의 GPU 작업을 다시 실행할 때 현재 실행에 속한 유효한 통신 버퍼만 사용하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-021.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-021.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-021.md)

## 적용 대상

TP의 실제 graph/communicator buffer 등록·참조 경로가 선택될 때 적용한다. 일반 TP 통신 점검은 별도로 유지한다.

## 권장 설정·조치

- TP graph 통신 buffer의 등록 정보·소유자·실행 세대를 관리한다. graph·통신기가 더 이상 해당 buffer를 참조하지 않고 관련 GPU 연산이 모두 끝난 뒤 참조를 해제한다. 종료·재기동 때 이전 등록 정보를 정리하고 새 실행에 유효한 참조만 사용한다.

## 시험 전 준비

선정 통신 backend와 native 계측을 확인하고, 격리된 재기동 시험 구성을 준비한다.

## 확인 방법

선정 TP graph/communicator의 rank·process 세대마다 buffer/IPC handle 등록·교환·소비·GPU 완료·참조 해제·재등록 순서를 확인한다. 종료·재기동 뒤 현재 세대·소유자·유효 범위의 참조만 사용하는지 정상 TP graph 실행과 대조한다. CUDA Graph caller의 입력 갱신·출력 소비는 CHK-REQ-020에서, 그룹의 회수 기한·잔존 자원·후속 정상 기동은 CHK-LIF-011에서 별도로 판정하며 같은 native 수명 관측을 공유한다.

## 정상 대조

정상 TP graph 등록·실행·종료 후 새 기동이 성공한다.

## 시험 순서

1. 등록→실행의 기준선을 확보한다.
2. 제한된 종료·재기동을 반복한다.
3. 새 세대의 buffer 등록·참조·정리를 대조한다.

## 필수 증거

1. rank·process generation/등록 handle·buffer 범위/graph 완료·해제·재등록

## 충족

등록된 버퍼가 현재 실행·소유자와 일치하고, 다른 실행의 버퍼나 해제된 버퍼를 사용하지 않는다. GPU 작업 완료와 graph·통신기의 참조 해제는 기록·계측으로 확인한다.

## 미충족

선정 backend의 등록·소유자·실행 세대·유효 범위·참조 수명 조건을 위반한 버퍼 사용 또는 해제가 확인된다. 다음 기동 실패·결과 혼입 등 후속 영향은 별도로 기록한다.

## 미확인

native 통신의 실제 참조 수명·해제 효과를 계측하지 못했다.

## 기능·환경별 분기

1. - name: GPU 메모리 경계 오류로 다른 요청 자료 노출
- scenario_ids: 1. SC-06-02
- apply_when: 선정 TP communicator가 CUDA Graph 재실행용 buffer/IPC handle을 실제 등록·참조할 때. 해당 backend의 등록·소유자·세대·GPU 완료·참조 해제와 재등록 경로를 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-06-02
2. - name: GPU 프로세스 통신의 도청·변조
- scenario_ids: 1. SC-08-03
- apply_when: 선정 TP graph/communicator에서 rank 간 buffer/IPC handle의 등록·교환·참조 경로를 실제 사용할 때. local collective와 다중 노드 transport의 등록·수명 증거를 각각 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-03

## 시험 식별자

1. Q-C06/SC-06-02
2. Q-C07/SC-08-03

## 외부 기준과 대응 범위

SA-8(17), SA-8(19) / 설계 원칙 대응

분산 구성·종료·재기동 중에도 보호 정책을 유지한다.

TP 통신 버퍼의 등록·rank·실행 세대·GPU 완료·참조 해제를 추적한다.

현재 세대의 유효 참조 사용이라는 엔진별 관측을 유지한다.
