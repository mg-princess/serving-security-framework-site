# CHK-LIF-006 실행 중 모델 변경이나 순차 교체를 해도 각 요청의 모델·상태가 일관되는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-006.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-006.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-006.md)

## 적용 대상

live weights·LoRA 변경·rolling·다중 replica 전환을 실제 사용할 때 적용한다. 기본 중단 재배포와 구분한다.

## 권장 설정·조치

- 실행 중 변경·순차 교체를 선택한 환경에서는 요청이 사용할 모델·가중치·캐시의 버전을 구분한다. 변경 전 작업의 처리·공유 상태 무효화·새 버전 전환 조건을 적용하고 부분 변경 시 복구 절차를 둔다.

## 시험 전 준비

실제로 지원하는 엔진과 변경 방식을 선정한다. 기본 구성에 live 변경 시험을 강제로 적용하지 않는다.

## 확인 방법

실제로 선정한 live weights·LoRA 변경 또는 rolling·다중 replica 전환에서 정상 변경과 제한된 부분 실패를 비교한다. 진행 요청별 실제 model/weights·cache·replica·반환 세대를 허용 전이·라우팅 정책에 맞춰 추적한다. 세션 lock을 추론 격리로 간주하지 않으며 LoRA·weight transfer·reload를 하나의 공통 chunk 절차로 합치지 않는다. 기본 중단 재배포의 정상 대조는 CHK-LIF-005에서 유지하고, 이 항목의 비사용은 유효 설정·도달성 근거로 적용 판단에 남긴다. vLLM v0.31.0의 공통 근거 중 선택 live/keep/collective_rpc·abort/wait/keep 및 모델·cache·요청 세대 조건을 참조한다. 근거 원문: [F32](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33911).

## 정상 대조

선정한 live weights·LoRA 변경 또는 rolling·다중 replica 전환에서 허용한 전이·라우팅 정책을 지키며 각 요청이 일관된 모델·상태로 정상 처리된다.

## 시험 순서

1. 실제로 활성화한 변경 경로·지원 조건과 허용 전이·세대·라우팅 정책을 확인한다.
2. 선정 경로에서 정상 변경을 수행하고 진행 요청·weights·cache·replica의 세대와 실제 소비를 추적한다.
3. 같은 경로의 제한된 부분 실패를 주입하고 요청별 허용 세대·상태 일관성과 실패 처리를 정상 변경과 비교한다.

## 필수 증거

1. live·rolling 활성 근거/weight·cache·요청 세대/변경 실패 상태

## 충족

요청이 허용하지 않은 부분 갱신·세대 조합을 소비하지 않는다.

## 미충족

사용 환경에서 비호환 weight·cache·요청 상태가 섞인다.

## 미확인

선택 기능 사용 여부·전이 계약 또는 세대 대응이 미확인이다.

## 기능·환경별 분기

1. - name: 실행 중 교체에서 weights·KV 세대 혼합
- scenario_ids: 1. SC-17-03
- apply_when: 실행 중 weights/LoRA 변경·rolling·다중 replica 전환을 실제 사용한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-17-03

## 시험 식별자

1. Q-C09/SC-17-03

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.8.6 운영환경 이관<br>새 시스템이나 변경 구성을 운영환경으로 옮길 때 | 부분 대응<br>실행 중 변경·순차 교체의 요청·가중치·캐시 세대와 실패 처리 결과를 확인한다. | [2.8.6 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-8-6) |
| 2.9.1 변경관리<br>엔진·모델·의존성·설정·정책을 변경할 때 | 보조 자료<br>live·rolling 변경의 부분 갱신·세대 혼합과 실패 상태를 변경 영향 검토의 자료로 사용한다. | [2.9.1 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-1) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

CM-3, SA-8(19), SA-8(17) / 일부 대응

분산·실행 중 변경에서도 보호 정책이 유지되도록 한다.

live 변경·rolling·replica 전환 때 요청별 가중치·캐시·반환 세대를 대조한다.

원자적 전환·drain·부분 실패 정책은 사용 기능에 맞춰 정한다.
