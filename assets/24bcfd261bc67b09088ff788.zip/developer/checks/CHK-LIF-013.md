# CHK-LIF-013 공유 가중치의 전체 해제 권한과 이후 재취득·참조 사용을 통제하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-013.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-013.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-013.md)

## 적용 대상

ipc_cache/preload 등 별도 weights daemon을 선택할 때 적용한다. 기본 TP 자체를 daemon 사용으로 간주하지 않는다.

## 권장 설정·조치

- 별도 가중치 daemon을 사용하는 환경에서는 전체 release 권한과 허용 시점을 제한한다. 다른 사용 프로세스의 다음 취득·기존 참조 상태를 확인하고, fallback에는 승인한 공급물·접근 정책을 적용한다.

## 시험 전 준비

선택 기능인 daemon 환경과 native 계측을 준비한다. handle 단위로 해제된다고 가정하지 않는다.

## 확인 방법

선택한 별도 weights daemon에서 두 소비자의 정상 취득 후 전체 release 주체·범위·시점, 다른 소비자의 재취득/fallback, 기존 copy/zero-copy 참조를 같은 실행 계보로 추적한다. release 권한·후속 공급·기존 참조 수명의 세 필수 결과를 각각 남긴다. 기본 TP는 대상이 아니며 실제 daemon socket 신뢰·copy/zero_copy를 고정한다. copy 완료/실패 자동 release와 zero_copy 소비 중 release를 구분해 이후 요청·기존 CUDA IPC 참조·fallback을 관측한다. peer 접근은 CHK-PLT-002, 최종 payload 승인은 CHK-SUP-006, fallback reader는 CHK-SUP-012, 일반 작업/그룹 회수는 CHK-LIF-010·CHK-LIF-011과 관측을 공유하되 전체 release 전후 다른 소비자의 상태 전이를 이 행에서 판정한다. 근거 원문: [F05](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33637).

## 정상 대조

daemon을 사용하지 않는 기본 TP와 별개로 선택 환경의 정상 취득·release를 확인한다.

## 시험 순서

1. 동일 daemon에서 시험 소비자 둘이 가중치를 취득한다.
2. daemon 전체에 release를 수행한다.
3. 각 소비자의 다음 취득·fallback·기존 참조를 관측한다.

## 필수 증거

1. daemon rank·model 범위/release 응답/후속 취득·소비·native 참조

## 충족

release가 허용된 주체·범위에서 수행되고, 다른 소비자의 후속 취득·fallback이 승인 조건을 지킨다. 사용 중 참조를 잘못 해제하거나 폐기 참조를 재사용하지 않는다.

## 미충족

비허용 전역 release, 정책에 어긋나는 다른 소비자의 후속 취득·접근 실패, 승인 밖 fallback 소비 또는 참조 일관성 위반을 확인한다. native 참조 위반은 해당 효과의 별도 증거로 판정한다.

## 미확인

release 응답만 있고 다른 소비자의 후속 취득·fallback 소비 또는 기존 native 참조 효과를 확인하지 못했다. 확인하지 못한 분기를 다른 분기의 정상 결과로 대신 판정하지 않는다.

## 기능·환경별 분기

1. - name: 전역 cache 해제로 다른 소비자의 참조 손상
- scenario_ids: 1. SC-16-04
- apply_when: ipc_cache/preload 등 별도 daemon과 실제 release 경로를 사용한다. copy/zero-copy를 나눈다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-16-04

## 시험 식별자

1. Q-C13/SC-16-04

## 외부 기준과 대응 범위

AC-3, SC-4, SA-8(19) / 일부 대응

공유 자원 접근과 상태 전환 중 권한을 유지한다.

가중치 daemon의 전체 해제 권한·다른 소비자의 재취득·zero-copy 수명을 나눠 본다.

전체 해제 인가·후속 공급 승인·참조 수명을 별도 결과로 보존한다.
