# CHK-LIF-004 느린 응답 수신과 진단용 버퍼의 자원 점유를 정한 범위로 제한하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-004.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-004.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-004.md)

## 적용 대상

스트리밍 수신 지연·연결 종료를 확인한다. response debug buffering은 실제 활성 route에서 추가한다.

## 권장 설정·조치

- 느린 수신자의 출력 buffer·보존 시간·전송 기한을 제한하고 필요할 때 역압력·취소를 적용한다. 사용하지 않는 진단 buffering을 끄고 활성 기능의 메모리 예산과 정리 시점을 관리한다.

## 시험 전 준비

수신 지연을 제어할 방법을 준비하고, 진단 활성 조건과 메모리 상한을 확인한다.

## 확인 방법

느린 스트림 읽기·연결 종료·debug 옵션에서 출력 대기·메모리·후속 정상 요청을 관측한다. 이 항목은 전송 중 대기·buffer 비용과 종료 뒤 해당 buffer 정리를 판정한다. 같은 연결 종료에서 내부 요청 실행·KV·전송 참조의 기한 내 종결은 CHK-LIF-010에서, debug 자료의 허용 필드는 CHK-OBS-003에서 따로 판정한다.

## 정상 대조

정상 수신 속도와 허용 진단 설정에서 메모리가 안정적이다.

## 시험 순서

1. 작은 stream 하나의 읽기만 지연시킨다.
2. 허용된 debug buffering 조건을 비교한다.
3. 메모리·backpressure·종결을 관측한다.

## 필수 증거

1. 연결별 전송량/host·buffer 비용/연결 종료 후 회수

## 충족

대기·buffer 비용이 한도 안에 있고 종료 뒤 정리된다.

## 미충족

느린 연결·진단이 정한 메모리·시간 예산을 넘겨 자원을 유지한다.

## 미확인

buffer별 비용·회수 또는 허용 예산을 알 수 없다.

## 기능·환경별 분기

1. - name: 느린 수신자로 출력 버퍼·연결 점유
- scenario_ids: 1. SC-07-03
- apply_when: streaming 연결의 느린 읽기와 연결 종료 경로가 있다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-07-03
2. - name: 디버그 응답 보관으로 메모리 고갈
- scenario_ids: 1. SC-07-04
- apply_when: 선정 route에서 응답 debug buffering이 실제 활성화되어 응답을 보관한다. 비사용은 유효 설정·등록 및 도달 경로 근거로 확인하고 활성 여부를 모르면 미정으로 남긴다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-07-04

## 시험 식별자

1. Q-C05/SC-07-03
2. Q-C05/SC-07-04

## 외부 기준과 대응 범위

SC-5, SC-6 / 요구 직접 대응

느린 통신·자원 점유가 서비스 가용성을 해치지 않게 한다.

느린 stream 수신·진단 버퍼의 메모리·시간·큐 점유를 확인한다.

정상 느린 수신과 악성 점유의 정책 기준을 구분한다.
