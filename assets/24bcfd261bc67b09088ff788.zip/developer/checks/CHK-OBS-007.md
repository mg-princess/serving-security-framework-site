# CHK-OBS-007 진단 자료를 읽을 수 있는 계정이 별도 허가 없이 재실행할 수 없는가?

조건부 하위시험. 부모 점검: [CHK-REQ-003](CHK-REQ-003.md)

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-OBS-007.md) · [vLLM 판본 차이](../adapters/vllm/CHK-OBS-007.md) · [SGLang 판본 차이](../adapters/sglang/CHK-OBS-007.md)

## 적용 대상

서빙 운영의 장애 분석·재현에 쓰는 진단 재실행 도구가 실제 배치된 경우 적용한다. 읽기 역할과 실행 역할의 접근 경로·허용 정책을 확인한다. 도구의 비사용·미노출이 확인되면 이 하위 시험은 해당 없음으로 남기고, 배치 여부가 미정이면 적용도 미정으로 둔다.

## 권장 설정·조치

- 진단 자료 읽기 역할과 replay 실행 역할을 분리하고 실행 시 권한을 검사한다. replay를 사용하지 않는 구성에서는 실행 접점의 비사용·비노출을 확인한다.

## 시험 전 준비

참조 구성에서는 replay를 사용하지 않는다. 외부 replay를 사용하는 경우에는 구현과 실행 역할을 정한 뒤 시험한다.

## 확인 방법

실제 배치된 replay consumer의 읽기 역할·실행 역할·허용 작업과 비사용/금지 정책을 확인한다. 같은 정상 합성 자료를 reader와 승인 실행 역할로 제출해 실제 실행표식·권한 검사·거부를 비교한다. 외부 도구의 존재·실행 계정·입력형식·reader를 먼저 식별한다. 이 행은 누가 replay를 시작할 수 있는지 판정하며, 자료 변조·reader의 금지 객체/부수 동작은 CHK-OBS-008에서 같은 consumer 관측과 함께 판정한다. 근거 원문: [F24](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33733).

## 정상 대조

외부 replay를 쓰는 환경에서 승인 실행 역할만 합성 자료를 재실행한다.

## 시험 순서

1. replay consumer 존재를 확인한다.
2. reader 계정과 실행 역할로 같은 무해 자료 실행을 요청한다.
3. 실행표식·권한 검사를 비교한다.

## 필수 증거

1. consumer·실행 계정/reader·executor 역할/실제 실행 및 거부 기록

## 충족

자료 읽기만 허용된 주체의 replay 실행은 거부된다. 실행이 허용된 역할은 승인한 범위에서 정상 처리하며, replay 금지 정책에서는 실행이 시작되지 않는다.

## 미충족

읽기만 허용된 주체가 replay를 실행하거나, 실행 금지 정책의 작업이 실제 시작된다.

## 미확인

적용한 consumer에서 실제 호출·실행 또는 거부 기록, reader·실행 역할의 대응을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 진단 자료 조회권을 이용한 고권한 replay
- scenario_ids: 1. SC-21-03
- apply_when: 서빙 운영의 장애 분석·재현에 쓰는 외부 도구가 진단 자료를 읽어 재실행하도록 실제 배치된다. 단순 진단 파일 보관과 구분한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-21-03

## 시험 식별자

1. Q-C11/SC-21-03

## 외부 기준과 대응 범위

AC-3, AC-6 / 요구 직접 대응

읽기와 실행처럼 서로 다른 작업에 별도 권한을 집행한다.

진단 파일 읽기 역할과 replay 시작 역할을 같은 자료로 비교한다.

조건부 하위시험을 유지한다. NIST가 진단 재실행 기능을 필수로 요구하는 것은 아니다.
