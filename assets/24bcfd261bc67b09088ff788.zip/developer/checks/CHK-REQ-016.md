# CHK-REQ-016 캐시 식별값으로 재사용에 필요한 모델·설정·입력 자료의 차이를 구분하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-016.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-016.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-016.md)

## 적용 대상

요청 처리에서 KV/prefix·입력/미디어 등 계산 상태를 cache로 재사용할 때 실제 key 문맥을 확인한다. 모델·adapter·media 등은 실제 활성 기능에 필요한 문맥으로 추가한다. 다운로드·변환·compile/npcache 생성물의 호환성은 CHK-SUP-015에서 대조한다.

## 권장 설정·조치

- 모델·입력·adapter·공유 집단 등 실제 재사용에 필요한 문맥을 캐시 키와 재사용 조건에 반영한다. 문맥이 바뀌면 이전 캐시를 구분하거나 무효화한다.

## 시험 전 준비

기본 텍스트 시험과 MM·LoRA 선택 분기를 나누고, 문맥 충돌을 확인할 시험 자료를 선정한다.

## 확인 방법

token·모델 문맥 등 필요한 요소를 하나씩 바꿔 key·lookup·실제 소비를 비교한다.

vLLM v0.31.0 적용 조건: 미디어 UUID 및 runtime LoRA는 선택 기능. UUID가 있어도 hash factors는 반영된다. 동일 UUID에 다른 내용, 동일 LoRA 이름·경로의 가중치 교체 전후를 cache 사용/비사용 대조로 확인한다. 정상 대조: 새 UUID·새 LoRA 경로 및 cache 비사용 결과와 일치 멀티모달 경로는 이 항목의 multimodal_cases에서 적용 조건·책임/집행 위치·정상 대조·단일 조건 변형·필수 관측·판정·원복/재시험을 확인한다.

## 정상 대조

기본 모델·입력과 실제 활성 재사용 문맥이 같으면 기대한 캐시를 재사용한다. adapter·media는 해당 기능을 사용할 때만 정상 대조에 포함한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다.

## 시험 순서

1. 텍스트 기본과 현재 활성 문맥의 동일 입력 기준선을 확보한다.
2. 기본 모델의 승인 세대·입력 문맥 중 key에 영향을 주는 조건 하나를 변경하고, adapter 내용·media 식별은 실제 활성 기능에 한해 별도로 변형한다.
3. 바뀐 문맥의 cache key·hit·실제 소비와 출력을 비사용 또는 새 문맥 정상 대조와 비교한다.
4. 실제 적용하는 multimodal_cases의 정상 대조·한 조건 변형·원복/재시험 설계를 케이스별로 준비한다. 시험 자극의 도달과 실제 위반, 시험기 판정을 구분한다.

## 필수 증거

1. 실제 cache key 구성/바뀐 객체 식별/hit·출력·승인 세대
2. 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측

## 충족

허용하지 않은 문맥 사이에 잘못 재사용되지 않는다. 임의 hash 충돌 가능성을 결함으로 가정하지 않는다.

## 미충족

서로 다른 비공유 문맥이 같은 cache로 처리되어 잘못된 자료를 재사용한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.

## 미확인

활성 key 구성·실제 객체 변경·재사용 효과를 확인하지 못했다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다.

## 기능·환경별 분기

1. - name: 캐시 키 충돌·누락을 이용한 다른 입력 재사용
- scenario_ids: 1. SC-05-02
- apply_when: cache key/hash를 이용해 입력·상태를 재사용한다. LoRA·media 문맥은 활성 시 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-05-02
2. - name: 미디어 변환 문맥에 맞는 캐시 재사용
- scenario_ids: 
- apply_when: 미디어 처리 결과를 전처리·embedding·KV 등 캐시로 재사용하는 경로에 적용한다. 이미지·오디오·비디오는 지원하는 경로별로 선정하며 캐시마다 실제 사용하는 자료와 변환 조건을 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/security/advisories/GHSA-c65p-x677-fgj6
- multimodal_case_refs: 1. MM-TRANSFORM-CACHE
3. - name: 거부 후 mirrored LRU 캐시 복구
- scenario_ids: 1. SC-05-02
- apply_when: 앞단 sender와 Core receiver가 상태를 나누어 보관하는 mirrored LRU 멀티모달 캐시를 실제 사용하는 경우에 적용한다. processor-only·비사용·SHM 등 다른 캐시는 각 구현의 복구 계약을 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/security/advisories/GHSA-ph3r-5jfg-f84f
- multimodal_case_refs: 1. MM-REJECT-CACHE

## 시험 식별자

1. Q-C03/SC-05-02

## 외부 기준과 대응 범위

SA-8(20), SC-4, SI-7 / 설계 원칙 대응

정확한 실행에 의존하는 메타데이터와 공유 정보의 보호가 필요하다.

모델·adapter·입력·미디어 차이가 실제 키·선택·캐시 소비에 반영되는지 확인한다.

NIST에 특정 캐시 키 필드의 명세가 있다는 식으로 설명하지 않는다.
