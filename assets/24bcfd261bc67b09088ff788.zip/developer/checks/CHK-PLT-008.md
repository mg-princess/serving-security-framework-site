# CHK-PLT-008 API와 내부 통신의 각 구간에서 상대를 확인하고 전송 자료를 보호하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-PLT-008.md) · [vLLM 판본 차이](../adapters/vllm/CHK-PLT-008.md) · [SGLang 판본 차이](../adapters/sglang/CHK-PLT-008.md)

## 적용 대상

호출 앱·사용자→Gateway→엔진의 실제 API 전송 구간과 기본 IPC/TP를 확인한다. Gateway가 없으면 호출 주체→엔진을 확인한다. 다중 노드·PP는 사용 시 추가한다.

## 권장 설정·조치

- 호출 주체→Gateway→엔진과 내부 통신을 구간별로 나누고 채택한 상대 인증·기밀성·무결성 보호를 적용한다. TLS 종료 후 엔진까지의 구간도 확인한다. 인증서를 사용하는 구간에서는 신뢰되지 않거나 이름이 다른 인증서를 거부하는지 시험한다. 로컬 IPC는 실제 계정·namespace·접근권에 맞게 보호한다.

## 시험 전 준비

실제 API·IPC·TP 구간과 보호 요구를 확인하고, TLS 시험 endpoint·인증서·지원 시험기를 준비한다. 기업별 보호 방식과 예외를 정한 뒤 실제 시험을 수행해야 한다.

## 확인 방법

서비스 API와 API/core/worker·rank 사이 실제 제어·데이터 통신을 구간별로 식별하고, 각 구간의 허용 peer·상대 확인·기밀성·무결성 요구와 정상 API·스트리밍·TP 처리를 대조한다. 제어 SHM/socket·overflow·collective·선택 PP/다중 노드 transport를 구분한다. 로컬 IPC의 UID·namespace·socket/SHM 접근과 무해 메시지 수용 관측은 CHK-PLT-002와 공유할 수 있다. 이 항목에서는 그 근거가 해당 구간의 보호 요구를 충족하는지 판정하고, 로컬 IPC 인가만으로 다른 구간의 전송 보호를 통과시키지 않는다. API는 실제 TLS 종료점·재암호화·서버 인증과 필요한 호출 주체 인증을 구분하며, 정상 인증서·신뢰되지 않거나 이름이 다른 인증서와 정책상 금지된 평문 연결을 격리 환경에서 대조한다. 관측 자료 전용 collector/sink 전송은 CHK-PLT-009에서 구간별로 판정한다. vLLM v0.31.0의 공통 근거를 참조한다. 근거 원문: [F21](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33824).

## 정상 대조

허용한 호출 주체가 각 API 구간에서 정상 요청·스트리밍 응답을 주고받고, 승인한 rank 사이 TP 처리도 정상 완료된다.

## 시험 순서

1. API·IPC·TP 구간, 실제 종단과 구간별 보호 요구를 확보한다.
2. 허용된 정상 API·스트리밍·TP 처리를 확인한다.
3. API의 잘못된 인증서·금지된 평문 연결과 내부의 비허용 peer·무해 변조를 지원 시험기로 대조한다.
4. 각 구간의 상대 인증·기밀성·무결성 결과를 따로 기록한다.

## 필수 증거

1. 구간·transport·peer/인증·암호화 설정/연결·무결성 결과
2. 호출 주체→Gateway→엔진 주소와 TLS 종료·재암호화 위치, 실제 handshake·인증서 검증, 금지 평문 연결·정상 응답 결과

## 충족

API·내부 통신의 각 구간에서 채택한 상대 인증·기밀성·무결성 요구를 증거로 확인하고 정상 요청·TP가 동작한다. 내부 IPC의 OS 접근 제한 등 실제 보호 수단도 구간별로 평가한다.

## 미충족

채택한 정책에서 금지한 평문 통신·비허용 상대 연결·변조 자료 수용이 확인되거나, 필수 상대 검증을 수행하지 않는다.

## 미확인

API의 실제 종단·TLS 종료점 또는 내부 transport·peer·보호 설정과 결과를 확인하지 못했다. 필수 보호 요구가 미정이면 해당 기준의 판정을 보류한다.

## 기능·환경별 분기

1. - name: 로컬 socket 접근을 통한 내부 제어 침입
- scenario_ids: 1. SC-08-01
- apply_when: 실제 socket·SHM 등 로컬 IPC 경로와 peer 접근권이 있다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-01
2. - name: GPU 프로세스 통신의 도청·변조
- scenario_ids: 1. SC-08-03
- apply_when: 선정 local collective·SHM·CUDA IPC 등 실제 전송이 선택될 때. UID/namespace와 native 접근 경계를 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-03
3. - name: GPU 프로세스 통신의 도청·변조
- scenario_ids: 1. SC-08-03
- apply_when: 다중 노드·PP 등 별도 transport를 실제 사용하면 추가한다. local TP의 결과를 원격 구간 보호 근거로 쓰지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-03

## 시험 식별자

1. Q-C07/SC-08-01
2. Q-C07/SC-08-03

## 코드 실행 경로별 추가 확인

| 선정 경로 | 수행·확인 |
| --- | --- |
| 상대와 reader 연결 | 통신 상대의 식별·인증·구간 보호를 실제 serializer/decoder 및 수신 프로세스와 연결한다. 사설 주소 사용이나 127.0.0.1 바인딩의 관측 범위를 UID·namespace·다른 작업의 접근 가능성과 함께 기록한다. |
| 현재 구성 대조 | 공개 권고의 과거 listener 문제를 현재 V1 또는 다른 ZMQ 기능의 동일 결함으로 판정하지 않는다. 선정 peer의 정상 처리와 비허용 peer·변경된 메시지의 거부 결과로 현재 구성을 판단한다. |

관련 공개 기록: CVE-2025-29783, CVE-2025-32444, CVE-2025-30165, CVE-2025-47277, CVE-2026-3059, CVE-2026-3060, CVE-2026-7301, CVE-2026-14890, CVE-2026-93088, CVE-2026-93034

실행 상태: 미실행 / 설치 환경 판정: 미확인. 정상 대조·거부·부수 동작을 확인하고 시험용 변경을 회수해야 한다.

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.6.6 원격접근 통제<br>원격 운영 채널에 해당 API 통신을 실제로 사용할 때 | 보조 자료<br>API를 원격 관리 채널로 사용하는 경우 그 구간의 상대 인증·암호화 결과를 확인한다. | 원격 운영의 필요성·승인, 지정 단말, 허용 범위·기간, 단말 보안과 강화 인증의 실제 이행을 확인한다. |
| 2.7.1 암호정책 적용<br>암호화가 필요한 개인정보·중요정보를 저장·전송할 때 | 부분 대응<br>API·내부 통신의 각 구간에서 채택한 전송 기밀성·무결성을 확인한다. | [2.7.1 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-7-1) |
| 2.10.5 정보전송 보안<br>다른 조직과 개인정보·중요정보를 주고받을 때 | 보조 자료<br>실제 조직 간 중요정보 전송 구간으로 사용하는 API 통신의 상대 인증·암호화 결과를 협약의 기술 자료로 사용한다. | [2.10.5 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-10-5) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

IA-9, SC-8, SC-23 / 요구 직접 대응

서비스 상대·세션의 진위를 확인하고 전송 정보를 보호한다.

API·내부 통신의 hop별 인증·기밀성·무결성과 실제 종단을 확인한다.

암호화와 상대 인증을 각각 확인하고 TLS 밖 IPC 구간을 별도 기록한다.
