# CHK-LIF-011 worker 장애 후 프로세스·통신·공유 자원을 정리하고 다시 기동할 수 있는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-011.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-011.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-011.md)

## 적용 대상

실제 사용하는 다중 프로세스·분산 실행 worker·통신·자원 회수와 다음 기동을 확인한다. Ray·PP는 사용 시 추가한다.

## 권장 설정·조치

- 장애가 난 실행 그룹의 프로세스·IPC·GPU 관련 자원과 잔존 참조를 정한 기한에 정리한다. 정리 완료를 확인하고 새 실행 그룹의 기동·정상 요청을 시험한 뒤 서비스를 재개한다.

## 시험 전 준비

자원별 회수 기한을 정하고 시험 전후의 자원 목록을 수집한다.

## 확인 방법

초기화 또는 실행 중 worker/그룹 실패를 격리 환경에서 주입하고, 실패 전후 process·queue·GPU·IPC·shared memory와 선택한 actor/placement/DAG/channel의 목록·소유자·잔존·반환 시각을 대조한다. shutdown 호출 뒤 실제 자원 회수와 같은 시험 환경의 재기동·정상 요청을 확인한다. 실패 감지·상위 전달은 CHK-LIF-008, 초기 부분 실패의 집계는 CHK-LIF-009, 준비 후 접수 gate는 CHK-LIF-007에서 각각 판정한다. vLLM v0.31.0의 공통 근거 중 선정 executor·그룹 종료에 해당하는 조건을 참조한다. 근거 원문: [F32](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33911).

## 정상 대조

정상 종료 후 TP process·통신 자원을 정리하고 다시 기동한다.

## 시험 순서

1. 격리된 worker에 실패를 주입한다.
2. process·IPC·shared memory가 남아 있는지 조사한다.
3. 같은 시험 환경을 재기동하고 정상 요청을 보낸다.

## 필수 증거

1. PID·rank·IPC 자원/cleanup 결과/재기동 준비·추론

## 충족

정한 자원이 회수되고 후속 정상 기동이 가능하다. shutdown 호출만으로 완료 처리하지 않는다.

## 미충족

정한 회수 기한을 위반하거나, 잔존 자원 때문에 다음 기동·정상 요청이 실패한다.

## 미확인

자원 목록·소유자·기한 또는 실패 후 재기동을 확인하지 못했다.

## 기능·환경별 분기

1. - name: worker 장애 뒤 그룹 자원 정리 실패
- scenario_ids: 1. SC-18-02
- apply_when: 선정 executor/collective의 worker 감시·장애·그룹 회수 경로를 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-18-02
2. - name: rank 준비 실패를 놓친 채 요청 수용
- scenario_ids: 1. SC-17-01
- apply_when: 기본 재시작·재배포에서 rank별 준비·부분 실패·정리를 확인한다. Ray/live는 선택 시만 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-17-01

## 시험 식별자

1. Q-C08/SC-18-02
2. Q-R05-12/SC-17-01

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.9.2 성능 및 장애관리<br>서비스의 용량·가용성과 장애를 관리할 때 | 부분 대응<br>장애 뒤 프로세스·통신·공유 자원 정리와 후속 정상 기동을 확인한다. | [2.9.2 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-2) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

CP-10, SA-8(24), SC-6 / 일부 대응

장애 후 알려진 상태로 복구하고 자원 가용성을 회복한다.

worker·IPC·GPU 잔존 참조 정리 후 같은 환경의 재기동·추론을 확인한다.

함수 호출이 아니라 회수 완료와 다음 기동 증거를 유지한다.
