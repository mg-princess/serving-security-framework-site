# CHK-REQ-011 동시에 들어온 요청의 일반·스트리밍 응답이 각각 올바른 요청자에게 돌아가는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-011.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-011.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-011.md)

## 적용 대상

일반·스트리밍 요청의 결과 귀속을 확인한다. 외부 ID·child·별도 시도는 실제 사용 시 추가한다.

## 권장 설정·조치

- 외부 요청·내부 실행·출력 수신 대상을 검증한 사용자와 작업 ID로 구분한다. 동시 요청과 스트리밍에서 응답 조각·종료 신호를 원래 요청에 반환하도록 상태 등록·전달 규칙을 유지한다.

## 시험 전 준비

작은 동시성으로 시험하며, 요청별로 구별할 무해한 표식과 응답 수집기를 준비한다.

## 확인 방법

두 합성 주체의 동시·스트리밍 요청에서 검증 신원→외부/내부 ID→worker/collector→연결·chunk·종료 신호를 대응시킨다. 외부 ID·child 기능을 실제 사용하면 동일 외부 ID 충돌과 내부 ID 분리의 영향을 대조하고 각 요청의 정상 결과를 확인한다. 기본 internal ID의 무작위 접미사와 유효 randomization 설정을 기록한다. 실제 등록된 abort 경로·자기 요청 취소·타 요청 영향은 CHK-REQ-012와 같은 ID 관측 자료를 공유하되, 이 행은 동시 결과·종료 신호의 수신자 귀속을 판정한다. 근거 원문: [F17](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33452).

## 정상 대조

고유 표식이 있는 A·B 일반·스트리밍 요청이 각각 올바른 연결로 반환된다.

## 시험 순서

1. 두 요청을 동시에 실행한다.
2. 한 요청의 응답 속도만 지연시킨다.
3. 연결·request ID·chunk·종료 대응을 비교한다.

## 필수 증거

1. 서버 생성 ID·클라이언트 ID/chunk 순서·연결/각 요청 결과

## 충족

결과가 다른 사용자·요청에 전달되지 않는다.

## 미충족

다른 요청의 결과·종료 신호가 잘못된 호출자에게 반환된다.

## 미확인

응답 표식 또는 연결별 ID 대응을 확보하지 못했다.

## 기능·환경별 분기

1. - name: 요청 ID 충돌을 이용한 결과·취소 대상 혼동
- scenario_ids: 1. SC-02-02
- apply_when: 일반/동시/streaming 요청을 확인하고 외부 ID·child를 사용하면 그 분기를 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-02-02

## 시험 식별자

1. Q-C02/SC-02-02

## 외부 기준과 대응 범위

AC-4, SC-4 / 요구 직접 대응

비허용 정보 흐름과 공유 자원을 통한 정보 전달을 방지한다.

동시 일반·stream 응답이 원 요청자에게 귀속되는지 확인한다.

요청 ID와 실제 반환 내용의 독립 대조를 유지한다.
