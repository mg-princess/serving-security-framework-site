# CHK-REQ-010 생성 옵션과 구조화 출력·도구 선택의 설정이 처리 조건에 맞는지 검사하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-010.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-010.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-010.md)

## 적용 대상

API가 받는 sampling 옵션의 값·개수·조합을 기본 확인한다. V2 count 한도 변형은 해당 processor가 실제 선택될 때 추가한다. 구조화 출력(schema·grammar 등)이나 tools/tool_choice를 지원하면 해당 입력의 크기·깊이·복잡도와 상호 조합·backend 제약을 추가 확인한다. 허용/금지 조합은 실제 API·판본·backend의 지원 규칙과 채택한 정책에 따라 정한다.

## 권장 설정·조치

- 기본값·별칭을 적용한 최종 sampling 값·개수·조합을 실제 runner 제약에 맞춰 검사한다. 지원하는 schema/grammar의 크기·깊이·복잡도와 tools/tool_choice의 상호 조합을 해당 API·backend 규칙에 따라 제한한다. 입력 구조를 읽는 데 필요한 제한 검사는 수행하되 고비용 재귀 변환·grammar 변환/컴파일·모델 제출로 진행하기 전에 비허용 입력을 거부·제한한다. 요청 오류와 비용이 공유 엔진 전체로 확대되는 경로를 보완하고 CHK-LIF-003의 자원 예산에 연결한다.

## 시험 전 준비

기존 V2 count 한도는 processor가 실제로 사용하는 조건을 확인한 뒤 작은 경계 시험 자료로 시험한다. 선정 API/backend에서 지원하는 구조화 출력·tool 조합과 크기·깊이·복잡도 기준, 제한을 적용하는 위치를 확인한다. 실제 거부 지점과 후속 변환·컴파일·모델 제출 경계를 관측한다. 공식 고정판과 설치판의 호환성 및 부하·중단 상한을 먼저 확인한다.

## 확인 방법

유한/비유한 값·min/max 등 관계 조건을 변환·기본값 적용 후 소비값과 비교한다. sampling 값의 범위·개수·상호 조합을 검사하고, 사용하는 실행기가 최종 소비하는 값과 대조한다. 구조화 출력·tool 선택을 실제 지원하면 schema/grammar의 크기·깊이·복잡도와 해당 API/backend의 상호 조합 규칙을 정상/비허용 입력으로 대조한다. 입력 구조를 읽는 제한 검사와 비싼 재귀 변환·grammar 변환/컴파일·모델 제출을 구분해 거부 지점·후속 도달/미도달을 확인한다. 객체 단위 예외나 HTTP 오류만으로 실제 경로 전체를 충족 처리하지 않는다. 옵션/구조/조합 결과와 오류 뒤 추론·다른 요청 영향은 따로 기록하며, 처리 비용·누적 자원 예산은 CHK-LIF-003과 관측을 공유한다.

vLLM v0.31.0 적용 조건: V2 해당 processor 도달 시 1024/1024/128 상한에서 ValueError 확인. API는 값 범위를 검사. 엔진 종료 전파는 확인하지 않음. 기존 입력 오류 시나리오의 V2 시험 변형이며 공유 엔진 종료는 미확인이다. V2가 실제 활성인 격리 환경에서 allowed IDs/logit_bias 1023·1024·1025, min_tokens>0에서 실제 all_stop_token_ids 127·128·129를 대조하고 병행 정상 요청과 후속 요청 생존을 확인한다. 모델 vocab/EOS 추가분 기록. 정상 대조: 경계 이내 유효 요청·병행 정상 요청 완료

## 정상 대조

허용 sampling 조합으로 정상 요청이 완료된다. 구조화 출력·tool 선택은 선정 API·backend가 지원하는 정상 schema와 허용 조합을 사용하며, 구조화 출력을 쓰지 않는 정상 요청도 유지된다.

## 시험 순서

1. 기존 sampling의 정상·경계·개수/관계 조건과 기본값 적용 뒤 실제 소비값을 확인하고 한 옵션만 경계 밖으로 변경한다.
2. 구조화 출력을 실제 지원하면 선정 입력 표현·backend의 크기·깊이·복잡도 기준과 집행 위치를 확인하고, 정상 구조와 한 요소를 바꾼 작은 무해 경계 입력을 대조한다.
3. tools/tool_choice를 실제 지원하면 같은 정상 tool/schema를 사용해 선택 방식·제약 종류 중 한 조합만 바꾸고 허용·비허용 결과를 비교한다.
4. 입력 구조를 읽는 제한 검사를 포함해 실제 거부·정규화 위치와 고비용 재귀 변환·grammar 변환/컴파일·모델 제출의 도달/미도달을 확인한다.
5. 해당 요청의 제한·조합 결과와 병행/후속 정상 요청·core/worker 상태 및 실제 처리 비용을 구분해 기록한다.

## 필수 증거

1. sampling 유효값·개수·관계/실제 runner·worker 제한/요청 오류·core·worker 생존
2. 선정 API·판본·구조화 출력 backend, 제출/정규화한 schema·grammar·tools/tool_choice, 실제 허용 조합과 크기·깊이·복잡도 기준
3. 제한/조합 검사·거부 지점과 고비용 재귀 변환·grammar 변환/컴파일·모델 제출의 실제 도달/미도달 근거
4. 허용 조합의 정상 처리와 비허용 입력의 거부·정규화, 비용·지연 및 병행/후속 정상 요청의 독립 결과

## 충족

sampling과 실제 지원하는 구조화 출력·tool 선택이 채택한 값·개수·크기·깊이·복잡도·조합 기준과 backend 제약을 지키고 허용 입력은 정상 처리된다. 비허용 schema/grammar·조합은 해당 제한 지점에서 거부·제한되어 고비용 재귀 변환·grammar 변환/컴파일·모델 제출로 진행하지 않는다. 입력 구조를 읽는 데 필요한 제한 검사는 허용하며, 실제 처리 비용과 자원 예산은 CHK-LIF-003에서 함께 대조한다. health 응답만으로 복구를 판정하지 않는다.

## 미충족

채택한 값·개수·크기·깊이·복잡도·조합 제한을 위반한 sampling·구조화 출력·tool 선택 입력이 해당 제한 지점을 넘어 수용·소비되거나, 비허용 입력이 고비용 후속 변환/컴파일·모델 제출로 진행한다. 한 요청 오류가 정한 허용 범위 밖 다른 요청에 영향을 주는 경우도 포함한다. 제한·조합 위반과 실제 비용·엔진/다른 요청 영향은 각각 증거로 기록한다.

## 미확인

적용할 옵션/구조화 출력·tool 선택의 제한·허용 조합·backend 제약·집행 위치 또는 변환 후 소비값을 확인하지 못했다. 객체 검증 오류나 HTTP400만 있고 실제 거부 지점·후속 변환/컴파일·모델 제출의 미도달 근거가 없는 부분은 미확인으로 남긴다. 엔진·다른 요청의 영향만 미확인인 경우에는 이미 확인한 제한·조합 위반의 미충족을 유지하고 영향의 확인 상태를 따로 남긴다.

## 기능·환경별 분기

1. - name: 생성 옵션 조합으로 실행기 예외 유발
- scenario_ids: 1. SC-04-02
- apply_when: API가 해당 sampling 옵션을 받는다. V2 개수 경계는 해당 processor 도달 시만 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-04-02
2. - name: 구조화 출력의 크기·깊이·복잡도 제한
- scenario_ids: 
- apply_when: 선정 API/backend가 schema·grammar·structural_tag 등 구조화 출력 입력을 실제 지원·수용할 때 추가한다. 해당 입력의 제한 검사와 고비용 재귀 변환·grammar 변환/컴파일·모델 제출 경계를 확인한다. 담당 CHK의 고유 추가 시험으로 선정하며 기존 SC 원문은 당시 범위로 보존한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/blob/5d35ce3934a7804b298559d2d99eec33792e1eb9/tests/entrypoints/openai/chat_completion/test_chat_error.py#L685-L701
3. - name: 구조화 출력·tool 선택의 상호 조합 검증
- scenario_ids: 
- apply_when: 선정 API가 구조화 출력과 tools/tool_choice의 조합을 실제 지원·수용할 때 추가한다. 해당 판본/API/backend가 허용한 조합과 비허용 조합을 같은 정상 tool/schema로 대조한다. 담당 CHK의 고유 추가 시험으로 선정하며 기존 SC 원문은 당시 범위로 보존한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/blob/5d35ce3934a7804b298559d2d99eec33792e1eb9/tests/tool_use/test_chat_completion_request_validations.py#L135-L184

## 시험 식별자

1. Q-C04/SC-04-02

## 외부 기준과 대응 범위

SI-10, SC-5 / 요구 직접 대응

입력 유효성과 서비스 거부 위험을 통제한다.

sampling·schema·grammar·tool 조합을 고비용 변환·실행 전에 제한한다.

입력 검사와 총 자원 예산은 REQ-010·LIF-003에서 각각 판정한다.
