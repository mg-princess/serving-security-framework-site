# CHK-LIF-016 복구할 때 변조된 자료나 이전 실행의 남은 상태가 결과에 섞이지 않는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-016.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-016.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-016.md)

## 적용 대상

사용하는 backup·복원 자료를 확인한다. 특수 snapshot은 지원 조건·실제 선택을 따로 확인한다.

## 권장 설정·조치

- 복원 자료·외부 파일·자격·캐시를 현재 승인 내용과 대조하고 쓰기 권한·무결성을 확인한다. 이전 실행의 잔존 상태를 정리하고 복원 검증과 필수 준비가 끝난 뒤 외부 요청을 허용한다.

## 시험 전 준비

실제로 사용하는 백업·설정·자격·volume·Gateway의 복원 대상과 승인 기준을 확인한다. 무해한 변경 시험 자료와 실제 소비를 관측할 방법을 준비한다. snapshot을 선택하면 지원 플랫폼·CRIU·단일 GPU·외부 gate도 준비한다.

## 확인 방법

합성 백업 변경·복원 순서·잔존 cache/작업·접수 gate·정상 요청을 대조한다. snapshot 경로는 별도로 조사한다. 배포 template, 외부 ConfigMap/Secret 값, volume, Gateway/IAM 정책의 복원 단위를 따로 확인한다. snapshot은 메모리·환경 자격 사본을 포함하는지 확인하며 manifest 마스킹만으로 비밀 제거를 판정하지 않는다. vLLM v0.31.0의 해당 snapshot 기능을 선택한 경우 정상 create 경로는 API key·TLS·middleware 및 TP>1을 거부한다. 별도 단일 GPU 선택환경에서 현재 승인 model/revision·실제 재로딩 파일과 snapshot을 대조하고 listener·oracle·외부 gate 시각을 확인한다. 옛 API key 복원을 정상 생성 경로의 시험 전제로 쓰지 않는다.

## 정상 대조

기본 재배포: 승인된 백업·설정·자격 참조·volume·Gateway 상태를 실제 배포 구성에 맞게 복원하고 정상 요청을 처리한다. 선택 snapshot: 생성 제한을 만족한 승인 자료로 재로딩·oracle·외부 gate 시험을 수행한다.

## 시험 순서

1. 기본: 실제 사용하는 백업·설정 저장소(ConfigMap/Secret 사용 시 포함)·volume·Gateway의 복원 대상과 현재 승인을 기록한다.
2. 기본: 격리 사본의 파일 또는 설정에 무해 변경/누락을 하나 주입하고 소비 전 거부와 실패 후 외부 접수 제한을 확인한다.
3. 기본: 승인 원본으로 복구한 뒤 정상 요청과 잔존 접근·사본 상태를 비교한다.
4. 선택 snapshot은 별도 TP1 지원 구성에서 재로딩 파일·generated-cache fingerprint·1토큰 oracle·외부 gate 순서를 시험한다.

## 필수 증거

1. 복원 전후 승인 자료·설정·자격 참조/실제 파일/설정 소비·외부 접수·정상 요청/사본과 잔존 접근/snapshot 지원 조건·생성 거부 근거/snapshot 및 다시 읽는 모델·설정 파일 digest/oracle·listener·외부 gate 시각과 실제 요청

## 충족

복원 대상이 현재 승인 내용과 일치하고 필요한 검증·준비가 끝난 뒤 서비스를 재개한다. 복원으로 영향받은 권한·자격 참조·cache·작업 상태는 관련 CHK의 기준과 증거를 연결해 확인한다.

## 미충족

비승인 복원 자료가 사용되거나 필수 검증 전에 외부 요청을 허용한다. 복원으로 영향받은 권한·자격 참조·cache·작업 상태가 현재 승인·재개 조건을 위반한 사실이 확인된 경우도 포함한다. 지원 제약을 우회한 실험은 정상 복원 판정과 분리한다.

## 미확인

1토큰 oracle만 통과했거나 전체 파일 일치·외부 gate를 확인하지 못했다. 정상 생성 경로에서 옛 API key 복원을 전제하지 않는다.

## 기능·환경별 분기

1. - name: 변조된 백업의 실행·서비스 사용
- scenario_ids: 1. SC-20-02
- apply_when: backup/복원 사본을 실제 consumer가 읽는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-20-02
2. - name: snapshot 복원 검증 전에 추론 요청 접수
- scenario_ids: 1. SC-20-04
- apply_when: 특수 snapshot을 실제 선택하고 해당 플랫폼·단일 rank 등 지원 조건을 확인한다. 기본 TP 재배포와 구분한다. 상세 지원 조건은 기존 SC-20-04 기록을 함께 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-20-04
- implementation_condition_detail: 선택 기능: Linux x86_64 동일호스트 snapshot, TP/PP/DP/PCP 모두1, immutable remote model 및40자리 revision, single unauthenticated plaintext HTTP. 정상 create는 api_key/VLLM_API_KEY, TLS, middleware, speculative decoding을 거부. 공통 다중GPU TP 기본구성에서는 비적용.

## 시험 식별자

1. Q-C12/SC-20-02
2. Q-C12/SC-20-04

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.9.3 백업 및 복구관리<br>서빙 구성이나 자료를 백업·복원할 때 | 부분 대응<br>복원 자료·권한·잔존 상태의 검증과 서비스 재개 조건을 확인한다. | [2.9.3 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-3) |
| 2.11.5 사고 대응 및 복구<br>서빙 관련 사고를 인지하고 대응·복구할 때 | 보조 자료<br>복원 검증·이전 상태 정리·재개 확인 결과를 사고 복구 기록의 일부로 사용한다. | [2.11.5 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-11-5) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

CP-10, CP-9, SI-7, SA-8(24) / 일부 대응

복원 자료를 보호하고 안전한 상태로 복구한다.

백업·snapshot·자격·캐시·잔존 작업의 복원 후 현재 정책 적용을 확인한다.

지원 snapshot 범위와 일반 복구를 구분하고 복구 시험을 유지한다.
