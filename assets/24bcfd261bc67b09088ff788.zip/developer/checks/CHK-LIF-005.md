# CHK-LIF-005 재배포할 때 이전 요청과 새 모델·설정이 섞이지 않도록 전환하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-LIF-005.md) · [vLLM 판본 차이](../adapters/vllm/CHK-LIF-005.md) · [SGLang 판본 차이](../adapters/sglang/CHK-LIF-005.md)

## 적용 대상

재시작·재배포의 접수 중단·진행 요청·그룹 종료·새 모델 준비를 확인한다.

## 권장 설정·조치

- 재배포 시 신규 요청을 제한하고 진행 요청을 정한 방식으로 처리한 뒤 기존 실행 그룹을 종료한다. 새 모델·설정과 필수 rank의 준비·정상 추론을 확인한 뒤 해당 배포로 요청을 보낸다.

## 시험 전 준비

drain·전환 기준과 배포별 식별정보를 관측할 방법을 정한다.

## 확인 방법

진행 요청을 둔 기본 중단·재시작 재배포에서 접수 중단→이전 요청의 허용 drain/종결→그룹 종료→새 승인 모델·설정 준비→라우팅 재개의 전이를 기록한다. 각 요청·worker·weights·cache의 배포 세대와 실제 소비·반환을 연결해 비호환 혼합이나 준비 전 전환을 확인한다. 새 배포의 준비 gate와 부분 실패 집계는 CHK-LIF-007·CHK-LIF-009와 같은 시험에서 별도 판정한다. 실제 live/rolling·다중 replica 변경은 CHK-LIF-006에 연결한다. vLLM v0.31.0의 공통 근거 중 기본 재배포 조건을 참조한다. 근거 원문: [F32](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33911).

## 정상 대조

이전 배포 요청을 정책에 맞게 끝내고 승인 새 배포로 신규 요청을 받는다.

## 시험 순서

1. 기존 요청 하나를 진행한다.
2. 새 묶음을 재배포한다.
3. 각 요청의 model generation·drain·라우팅을 추적한다.

## 필수 증거

1. 요청 세대/배포 digest·설정/종료·준비·라우팅 전이

## 충족

변경 경계를 넘는 비허용 상태 혼합 없이 요청 처리 방침을 지킨다.

## 미충족

한 요청에 비호환 세대가 섞이거나 준비 전 새 배포로 요청을 보낸다.

## 미확인

요청 세대·drain 정책·실제 전환 시점을 알 수 없다.

## 기능·환경별 분기

1. - name: rank 준비 실패를 놓친 채 요청 수용
- scenario_ids: 1. SC-17-01
- apply_when: 기본 재시작·재배포에서 rank별 준비·부분 실패·정리를 확인한다. Ray/live는 선택 시만 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-17-01
2. - name: 승인·준비 검증을 건너뛴 서비스 재개
- scenario_ids: 1. SC-17-02
- apply_when: 모델 준비·승인 확인과 외부 접수 gate/재개를 연결한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-17-02

## 시험 식별자

1. Q-R05-12/SC-17-01
2. Q-C09/SC-17-02

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.8.6 운영환경 이관<br>새 시스템이나 변경 구성을 운영환경으로 옮길 때 | 부분 대응<br>새 모델·설정으로 전환할 때 기존 요청 종결·새 실행 준비·라우팅을 확인한다. | [2.8.6 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-8-6) |
| 2.9.1 변경관리<br>엔진·모델·의존성·설정·정책을 변경할 때 | 보조 자료<br>재배포 경계에서 요청·모델·설정이 섞이지 않는지 확인한 결과를 변경 영향 검토의 자료로 사용한다. | [2.9.1 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-9-1) |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

CM-3, SA-8(19) / 일부 대응

승인 변경과 전환 중 연속 보호를 유지한다.

재배포 전후 요청·모델·설정·캐시 세대의 혼입을 추적한다.

변경 승인과 실행 세대의 일관성은 서로 다른 증거로 확인한다.
