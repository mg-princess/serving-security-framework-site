# CHK-REQ-014 여러 프로세스가 나눠 처리한 중간 자료와 최종 결과가 원래 요청에 맞게 처리·반환되는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-014.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-014.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-014.md)

## 적용 대상

실제 사용하는 다중 프로세스·분산 실행 내부 전달을 확인한다. 다중 노드·PP·PD는 실제 구성에 포함될 때 별도 경로로 추가한다.

## 권장 설정·조치

- 분산 단계마다 요청·모델 버전·중간 자료의 식별정보를 대조하고 최종 출력의 수신자를 확인한다. 지연·재전송·장애 때 다른 요청이나 모델 버전의 자료가 사용되지 않도록 전달·폐기 규칙을 적용한다.

## 시험 전 준비

실제 사용하는 다중 프로세스·분산 실행 경로부터 확인한다. PD 등의 선택 기능은 활성 조건을 확인하고 해당 경로의 추적 기능을 준비한 뒤 시험한다.

## 확인 방법

선정 executor에서 request·model·generation→actor/rank·중간 buffer/블록→집계·출력 rank→최종 요청 연결을 추적한다. 허용된 지연·실패 변형에서 다른 요청·모델 세대의 자료를 잘못 소비·반환하는지 실제 사용하는 분산 실행 결과와 비교한다. 실제 사용하는 다중 프로세스·분산 실행, 선택 Ray/PP, PD/KV connector의 실제 경로·증거를 구분하고 legacy 출력 rank 설명을 다른 executor에 일반화하지 않는다. PD/NIXL을 선택하면 API의 kv_transfer_params/remote peer·block 메타데이터가 실제 요청·허용 peer·블록에 연결되는지 확인한다. 잘못된 참조의 거부와 정상 전송을 대조하며 전달 자체를 성공/취약점으로 단정하지 않는다. IPC 접근 인가·공유 실행 신뢰·구간 보호는 CHK-PLT-002·CHK-PLT-006·CHK-PLT-008의 결과와 연결한다. 근거 원문: [F18](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33474).

## 정상 대조

TP 처리에서 각 rank의 담당 계산·중간 상태와 선정 출력 rank·집계 경로의 최종 반환을 요청·모델·buffer에 연결한다.

## 시험 순서

1. 실제 사용하는 다중 프로세스·분산 실행 요청을 추적한다.
2. 안전한 지연·실패를 한 구간에 주입한다.
3. 중간 자료와 최종 결과의 귀속을 확인한다.

## 필수 증거

1. request·model·generation ID/rank·buffer 전달/완료·회수·출력 연결

## 충족

실제 사용하는 구성에서 다른 요청/세대의 자료가 잘못 소비되지 않는다. TP/PP와 PD의 결과를 별도 기록한다.

## 미충족

다른 요청·모델 세대의 자료가 결과에 사용되거나 잘못된 요청으로 반환된다.

## 미확인

분산 중간 자료·세대·buffer 대응을 계측하지 못했다.

## 기능·환경별 분기

1. - name: 공유 권한을 가진 worker 침해의 영향 확대
- scenario_ids: 1. SC-08-02
- apply_when: core·worker의 실제 UID·protocol·공유 실행 신뢰 범위를 확인한다. 같은 UID/pickle 내부를 독립 인가 경계로 가정하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-02
2. - name: GPU 프로세스 통신의 도청·변조
- scenario_ids: 1. SC-08-03
- apply_when: rank 간 local collective 또는 별도 다중 노드 전송을 사용한다. transport별로 분리한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-03
3. - name: PD 전송 참조 조작으로 KV·완료 상태 오연결
- scenario_ids: 1. SC-08-04
- apply_when: PD 또는 KV transfer connector가 실제 지원·선택된다. 실제 사용하는 다중 프로세스·분산 실행과 별개이며 prompt_token_ids 입력 경로 전체와 동일시하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-08-04

## 시험 식별자

1. Q-C07/SC-08-02
2. Q-C07/SC-08-03
3. Q-C02/SC-08-04

## 외부 기준과 대응 범위

AC-4, SC-4, SA-8(17) / 일부 대응

분산 구성에서도 정책에 맞는 정보 흐름을 유지한다.

worker·rank의 중간 자료와 최종 결과가 원 요청·실행에 귀속되는지 확인한다.

TCP·IPC·전송 계층 구분과 최종 lineage 증거를 유지한다.
