# CHK-REQ-009 입력이 모델과 각 처리 단계의 조건에 맞는지 검사하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-009.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-009.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-009.md)

## 적용 대상

활성 입력 endpoint의 token·길이·변환 후 값을 선정 모델·runner 기준으로 확인한다. embedding을 실제 지원·수용하면 consumer가 요구하는 값·차원/shape·필요 dtype·입력 길이와 token/embedding·선택 mask의 대응을 추가 확인한다. routed_experts_prompt_start 등 offset 파라미터를 수용하면 embedding 사용이나 관련 출력 기능의 활성 여부와 별개로 그 의미·형식·유효 위치 범위를 확인한다. 금지·미지원 입력은 실제 거부·제거 근거와 지원 범위를 기록한다.

## 권장 설정·조치

- 실제 모델·consumer의 token·길이와 지원 입력의 값·차원/shape·필요 dtype·정합성을 해당 집행 위치에서 검사한다. embedding·token/mask의 대응과 별도로 수용하는 offset의 의미·형식·유효 위치를 검증하고 비허용 값을 후속 소비 전에 제한한다. 절단·변환을 허용하면 방식·시점과 변환 뒤 소비값을 명시한다. vocab·버퍼 범위 등 구현상 제약을 유지하고 오류는 요청 단위에서 처리한다.

## 시험 전 준비

선정 모델·endpoint·consumer의 token·길이 범위를 확인한다. embedding의 값·차원/shape·필요 dtype·token/mask 대응 규칙과 별도로 수용하는 offset의 규칙을 확인한다. 작은 경계 시험 자료와 실제 거부 지점·모델 제출 경계를 관측할 방법을 준비한다.

## 확인 방법

모델·처리 단계별 token/길이 유효 범위와 채택한 입력 제한·집행 위치를 정하고 정상·경계·범위 밖 입력의 실제 소비값을 대조한다. embedding 지원 경로에서는 consumer의 값·차원/shape·필요 dtype와 token/embedding·mask 대응을 정상 입력과 한 요소가 어긋난 작은 무해 입력으로 비교한다. routed_experts_prompt_start 등 수용 offset은 embedding 사용·관련 출력 활성 여부와 별개로 의미·형식·유효 위치 범위를 확인한다. 거부·정규화와 후속 worker/모델 제출의 도달/미도달을 기록한다. 허용한 절단·변환은 적용 시점과 변환 뒤 값을 확인한다. 제한·정합성 결과와 메모리 접근·상태 오염·다른 요청 영향은 각각 기록한다. 멀티모달 경로는 이 항목의 multimodal_cases에서 적용 조건·책임/집행 위치·정상 대조·단일 조건 변형·필수 관측·판정·원복/재시험을 확인한다.

## 정상 대조

선정 tokenizer·모델의 유효 ID와 길이 경계 안 요청이 정상 처리된다. embedding 지원 경로에서는 consumer 규칙에 맞는 값·shape/차원·dtype와 token/mask 대응을 가진 정상 입력을 실제 지원 조합에서 대조한다. offset 파라미터는 embedding·관련 출력의 활성 여부와 별개로 허용 범위 안 값이 정상 처리됨을 확인한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다.

## 시험 순서

1. 모델·consumer의 token/길이 유효 범위와 채택한 입력 제한·집행 위치를 확인하고, 실제 지원 embedding의 값·차원/shape·필요 dtype와 token/embedding·mask 대응 규칙을 기록한다.
2. 기존 정상·경계·최소 범위 밖 ID·길이를 단독 제출해 거부 또는 허용 절단·변환과 실제 소비값을 대조한다.
3. embedding 지원 경로에서는 정상 구조와 비교해 차원/shape·필요 dtype·mask 길이/대응 중 하나만 바꾼 작은 무해 입력을 제출한다.
4. offset을 수용하는 경로에서는 embedding·관련 출력 기능의 활성 여부와 별개로 offset 형식·경계 안/밖 값을 대조한다.
5. 거부·정규화 위치와 최종 소비값, 후속 worker/모델 제출의 도달/미도달을 기록하고 메모리 오류·상태·다른 요청/후속 정상 요청 영향은 따로 남긴다.
6. 실제 적용하는 multimodal_cases의 정상 대조·한 조건 변형·원복/재시험 설계를 케이스별로 준비한다. 시험 자극의 도달과 실제 위반, 시험기 판정을 구분한다.

## 필수 증거

1. 모델 vocab·처리 단계별 유효 범위와 입력 제한·집행 위치, 허용된 절단·변환 조건
2. 실제 지원 embedding의 값·차원/shape·필요 dtype·입력 길이와 token/embedding·mask 대응 규칙 및 제출/변환/소비값
3. offset 파라미터의 수용 경로·의미·형식·입력 길이에 따른 유효 위치 범위, embedding·관련 출력의 유효 설정과 독립된 offset 거부/소비 결과
4. 실제 거부 지점·후속 worker/모델 제출의 도달/미도달, 메모리 오류·상태·후속 정상 요청 결과; 단위 mock과 실제 설치 경로의 증거 구분
5. 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측

## 충족

채택한 입력 제한과 실제 consumer의 값·길이·차원/shape·필요 dtype·정합성 요구를 각 집행 위치에서 지키고 정상 입력은 처리된다. embedding·token/mask의 대응과, 별도로 수용하는 offset의 의미·유효 위치 범위가 유지되며 비허용 입력은 후속 소비 전에 제한된다. 절단·변환을 허용하면 채택한 방식·시점과 변환 뒤 소비값을 확인한다.

## 미충족

채택한 입력 제한이나 실제 consumer의 token·길이·embedding 값/차원/shape/필요 dtype·token/mask 정합성 또는 독립된 offset 유효 범위를 위반한 값이 해당 제한 지점을 넘어 수용·소비된다. 비허용 메모리 접근·상태 오염·다른 요청의 피해는 발생 여부와 증거를 별도로 기록한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.

## 미확인

적용할 제한·정합성 규칙·집행 위치·허용된 절단/변환 조건 또는 최종 소비값을 확인하지 못했다. 오류 응답만 있고 의도한 입력 처리기/모델 제출 경계의 실제 거부·미도달을 확인하지 못한 부분은 미확인으로 남긴다. 이미 확인한 제한·정합성 위반은 후속 영향의 증거 부족과 구분해 미충족으로 기록한다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다.

## 기능·환경별 분기

1. - name: 잘못된 토큰 입력으로 공유 추론 서비스 방해
- scenario_ids: 1. SC-04-01
- apply_when: 선정 endpoint가 token 또는 토큰화할 입력을 처리한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-04-01
2. - name: 지원 입력의 차원·정합성과 offset 유효 범위
- scenario_ids: 
- apply_when: 선정 endpoint/입력 처리기가 embedding 또는 token/embedding 선택 mask를 실제 지원·수용하거나, 별도로 routed_experts_prompt_start 등 offset 파라미터를 수용할 때 추가한다. embedding은 값·차원/shape·필요 dtype·token/mask 대응을, offset은 embedding·관련 출력 활성 여부와 독립된 의미·형식·위치 범위를 확인한다. token·길이 기본 분기는 유지한다. 담당 CHK의 고유 추가 시험으로 선정하며 기존 SC 원문은 당시 범위로 보존한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/blob/5d35ce3934a7804b298559d2d99eec33792e1eb9/tests/test_request_input_bounds.py#L61-L122
3. - name: 멀티모달 입력 배치와 변환 정합성
- scenario_ids: 
- apply_when: 이미지·오디오·비디오 또는 미리 계산한 멀티모달 embedding을 받는 경로에 적용한다. 일반 API가 미디어를 처리하는 경로와 render 결과·features를 다시 받는 분리형 경로를 각각 확인한다. 지원하지 않는 입력은 실제 거부 여부를 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: https://github.com/vllm-project/vllm/security/advisories/GHSA-34qw-q2h2-jp3m
- multimodal_case_refs: 1. MM-INPUT-LAYOUT
2. MM-TRANSFORM-INPUT

## 시험 식별자

1. Q-C04/SC-04-01

## 코드 실행 경로별 추가 확인

| 선정 경로 | 수행·확인 |
| --- | --- |
| Sparse embedding | 기능 활성화 여부와 실제 tensor reader·sparse invariants 검사·최종 to_dense 도달을 확인한다. 정상·손상 자료와 동시 입력을 무해한 격리 환경에서 비교하고 전역 검증 상태의 경쟁과 거부 위치를 기록한다. |
| SHM 내부 참조 | 공개 features가 내부 발급 참조로 해석되는 경로를 조사한다. 주소·세대·cache key·발급 권한의 결합을 확인하고 다른 객체나 clear 뒤의 참조가 소비 전에 거부되는지 비교한다. 공개 공지의 코드 실행 보고와 이번 환경의 실제 관측은 각각 기록한다. |

관련 공개 기록: CVE-2025-62164, GHSA-mcmc-2m55-j8jj, CVE-2026-73557, CVE-2026-115912

실행 상태: 미실행 / 설치 환경 판정: 미확인. 정상 대조·거부·부수 동작을 확인하고 시험용 변경을 회수해야 한다.

## 외부 기준과 대응 범위

SI-10, SI-10(3) / 요구 직접 대응

입력 유효성과 잘못된 입력에 대한 예측 가능한 동작을 확인한다.

token·embedding·mask·offset의 값·shape·dtype·대응과 최종 소비값을 확인한다.

잘못된 입력의 요청 단위 거부와 다른 요청 피해를 분리한다.
