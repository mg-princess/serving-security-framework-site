# CHK-SUP-003 모델 실행에 함께 쓰는 설정·tokenizer·template와 추가 모델 파일도 승인 대상에 포함되어 있는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-003.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-003.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-003.md)

## 적용 대상

모델을 로딩하는 환경. 기본 config·tokenizer·template를 포함하고, secondary source·redirect·adapter는 실제 사용 시 추가한다.

## 권장 설정·조치

- 기본 모델이 함께 읽는 설정·tokenizer·chat template과 선택한 하위 모델·추가 공급원의 파일을 승인 목록에 포함한다. 실제 로딩 시 선택한 경로·버전을 목록과 대조한다.

## 시험 전 준비

선정 모델과 의존성별로 실제 읽기 경로를 관측할 방법을 준비한다. 선택 기능에는 별도의 시험 자료를 사용한다.

## 확인 방법

실제 소비하는 config·tokenizer·template·generation config와 하위·추가 공급원을 목록화하고 각 repo·불변 판본·파일을 승인 범위에 연결한다. 선택 MM processor·LoRA resolver의 실제 소비·다운로드 대상을 포함하고, 요청의 코드 판본 선택 제한은 CHK-SUP-008에서 판정한다. Ultravox secondary·speculators_config 등 실제 선택된 하위/verifier 모델의 별도 repo·resolved commit·파일을 포함한다. redirect가 실제 설정되면 유효 env·매핑 파일 digest·resolved model/tokenizer 경로를 같은 목록에 포함한다. 동일 표시명만으로 공급원을 식별하지 않는다. 근거 원문: [F10](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33662) · [F11](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33689) · [F34](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33778).

## 정상 대조

승인 목록에 포함된 config·tokenizer·template와 필요한 하위 모델로 정상 로딩한다.

## 시험 순서

1. 실제 읽는 공급원 목록을 확보한다.
2. 하위 자료 하나를 승인 목록에서 뺀 시험 묶음을 준비한다.
3. 새 기동에서 그 자료의 선택·소비·차단을 관측한다.

## 필수 증거

1. resolved repo·commit·파일/redirect·secondary source 설정/승인 목록과 실제 읽기 대응

## 충족

모든 필수 소비 대상이 승인 목록과 연결되고 누락 대상은 사용 전에 처리된다.

## 미충족

승인에 필요한 하위 자료가 목록에 없거나 다른 판본인데 실제로 사용된다.

## 미확인

하위 모델·resolver·redirect 활성 여부 또는 실제 소비 자료를 확인하지 못했다.

## 기능·환경별 분기

1. - name: 승인에서 빠진 하위 자료로 모델 동작 변경
- scenario_ids: 1. SC-10-02
- apply_when: 모델 config·tokenizer 등 실제 소비 공급원을 확인한다. secondary source·resolver·redirect는 사용 시 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-10-02

## 시험 식별자

1. Q-R05-02/SC-10-02

## 외부 기준과 대응 범위

CM-8, SR-4, CM-2 / 요구 직접 대응

실제 구성요소를 목록화하고 출처·기준 구성을 관리한다.

모델 외 tokenizer·대화 템플릿·adapter·하위 모델의 최종 판본을 승인 묶음에 포함한다.

CM-8은 목록 요건이다. 승인 여부는 변경·무결성 통제와 함께 확인한다.
