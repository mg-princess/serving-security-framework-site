# CHK-REQ-007 chat template으로 변환한 뒤의 입력에도 필요한 제한이 적용되는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-007.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-007.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-007.md)

## 적용 대상

선정 endpoint가 template를 적용할 때 확인한다. 요청 template·kwargs 변경은 해당 필드를 수용할 때 추가한다.

## 권장 설정·조치

- 요청이 지정할 수 있는 chat template·변환 인수를 제한한다. template을 적용한 뒤 실제 모델에 전달할 입력에 필요한 길이·내용·권한 검사를 적용한다.

## 시험 전 준비

입력 예산과 렌더링 결과를 관측할 방법을 준비한다. 템플릿 코드의 안전성은 모델·소프트웨어 자료의 관련 점검에서 따로 확인한다.

## 확인 방법

서버 지정·processor/tokenizer 기본값·내장 fallback 중 실제 선택된 template과 요청 override를 나눠 원 messages·변환 token·실제 검사·거부 위치를 대조한다.

## 정상 대조

정상 메시지는 승인 template 적용 후 허용 길이·내용 제한을 만족한다.

## 시험 순서

1. 원 입력과 렌더 결과 기준선을 확보한다.
2. 확장되는 무해 입력으로 제한 경계를 확인한다.
3. 검사 시점과 실제 tokenized 입력을 비교한다.

## 필수 증거

1. 원 입력·template/렌더 출력·token 수/제한 적용 위치

## 충족

실제 입력이 채택한 제한을 우회하지 않는다. 모델과 함께 제공되는 템플릿의 출처와 실행 제한은 모델·소프트웨어 자료의 관련 점검에서도 확인한다.

## 미충족

검사 후 렌더링된 입력이 필요한 제한을 벗어나 소비된다.

## 미확인

렌더 후 입력·검사 위치 또는 허용 기준을 확인하지 못했다.

## 기능·환경별 분기

1. - name: chat template 변경을 통한 입력 검사 우회
- scenario_ids: 1. SC-03-01
- apply_when: chat/template 변환이 수행된다. 요청 template·kwargs는 실제 수용 필드별로 추가한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-03-01
2. - name: 모델 template의 위험 동작·비용 유발
- scenario_ids: 1. SC-11-07
- apply_when: 서버 지정·processor/tokenizer·fallback 등 실제 선택된 공급 template가 renderer에서 소비된다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-11-07

## 시험 식별자

1. Q-C04/SC-03-01
2. Q-R05-05/SC-11-07

## 외부 기준과 대응 범위

SI-10 / 요구 직접 대응

최종 처리 입력의 유효성을 검사한다.

대화 템플릿·토큰화 뒤 실제 모델 입력에 길이·형식 제한을 확인한다.

입력 시 검사와 변환 후 검사를 구분한다.
