# CHK-PLT-007 엔진이 허용된 목적지로 허용된 작업만 송신하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-PLT-007.md) · [vLLM 판본 차이](../adapters/vllm/CHK-PLT-007.md) · [SGLang 판본 차이](../adapters/sglang/CHK-PLT-007.md)

## 적용 대상

취득·엔진 실행·관측의 외부 송신을 기본 확인한다. 외부 연결이 불필요한 구성도 금지 송신의 집행을 확인한다.

## 권장 설정·조치

- 모델 취득·엔진 실행·관측 단계별 허용 목적지·포트·프로토콜·작업을 정해 해당 송신 지점에 적용한다. DNS·redirect 뒤 최종 목적지와 정책 적용 상태를 기록하고 정상 허용 통신도 유지되는지 확인한다.

## 시험 전 준비

시험 목적지와 송신 제한을 적용할 위치를 정하고, 실제 차단 여부를 확인할 기록을 준비한다.

## 확인 방법

취득·runtime·usage·관측 등 송신 프로세스별로 DNS·redirect 후 최종 목적지·포트·protocol·작업과 정책 집행 위치를 기록한다. 허용 목적지의 정상 취득/서비스/관측과 비허용 시험 목적지·작업의 무해 송신을 대조해 실제 연결·차단을 확인한다. 내장 usage의 최초 판단·생성 중단·payload 필드는 CHK-OBS-004·CHK-OBS-005에서, 허용된 관측 경로의 TLS/상대 인증은 CHK-PLT-009에서 별도로 판정한다. 관측 exporter를 쓰면 실제 SDK·endpoint·proxy와 연결 시작 주체를 식별해 이 행의 목적지 허용표에 포함한다. 근거 원문: [F37](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33941). 멀티모달 경로는 이 항목의 multimodal_cases에서 적용 조건·책임/집행 위치·정상 대조·단일 조건 변형·필수 관측·판정·원복/재시험을 확인한다.

## 정상 대조

필요한 저장소·관측 목적지에 승인된 연결만 발생한다. 멀티모달은 각 세부 케이스의 지원 입력·허용 변환·정상 처리/재사용 대조를 함께 확인한다.

## 시험 순서

1. 실제 목적지·작업 기준선을 수집한다.
2. 금지 시험 목적지로 무해 연결을 시도한다.
3. Gateway 밖 엔진 송신 제한을 확인한다.
4. 실제 적용하는 multimodal_cases의 정상 대조·한 조건 변형·원복/재시험 설계를 케이스별로 준비한다. 시험 자극의 도달과 실제 위반, 시험기 판정을 구분한다.

## 필수 증거

1. 송신 프로세스·목적지·포트·프로토콜, 정책 적용 위치, 허용·차단 기록, DNS 조회·redirect 결과
2. 멀티모달 케이스별 원본→변환/선택→최종 소비·거부/후속 도달·정상 대조·복구 관측

## 충족

금지 송신은 차단되고 필요한 취득·서비스·관측은 동작한다.

## 미충족

금지 목적지·작업의 송신이 실제 성공한다. 멀티모달은 실제 적용한 세부 케이스의 보호 조건 위반을 각각 판정한다. 다른 관측 누락으로 이미 확인된 미충족을 지우지 않는다.

## 미확인

센서 관측·정책 적용 상태·최종 송신 결과가 부족해 실제 차단 여부를 판단할 수 없다. 멀티모달 세부 케이스의 소비·집행·필수 관측이 부족한 범위는 별도 미확인으로 남긴다.

## 기능·환경별 분기

1. - name: 서버 자격을 이용한 다른 저장소 자료 접근
- scenario_ids: 1. SC-14-01
- apply_when: 취득·반입 경로가 실제 원격 연결·DNS·redirect를 사용해 송신할 때 허용 목적지·작업과 실제 연결을 확인한다. 네트워크 송신이 없는 로컬 공급은 이 분기와 구분하며 다른 송신 경로의 기본 점검은 유지한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-14-01
2. - name: 승인 코드의 과도한 권한을 이용한 피해 확대
- scenario_ids: 1. SC-14-04
- apply_when: 승인된 코드가 실제 엔진 계정·장치·파일·통신 권한으로 실행된다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-14-04
3. - name: 설정 조작으로 금지한 사용통계 보고 재개
- scenario_ids: 1. SC-22-01
- apply_when: usage 금지 정책에서 rank0 env/config·새 프로세스 최초 판단·생성/송신을 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-22-01
4. - name: 허용하지 않은 사용통계 항목·목적지 전송
- scenario_ids: 1. SC-22-02
- apply_when: usage 보고를 일부/전체 허용하며 runtime 필드·목적지를 지정한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-22-02
5. - name: 엔진→수집기 구간에서 기록 도청·변조
- scenario_ids: 1. SC-24-01
- apply_when: 엔진이 collector로 관측 자료를 송신할 때 연결 시작 주체·최종 목적지·작업의 egress 제한을 확인한다. 같은 구간의 exporter protocol·TLS/peer 검증은 CHK-PLT-009에서 판정한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-24-01

## 시험 식별자

1. Q-R05-09/SC-14-01
2. Q-C10/SC-14-04
3. Q-C11/SC-22-01
4. Q-C11/SC-22-02
5. Q-C07/SC-24-01

## 코드 실행 경로별 추가 확인

| 선정 경로 | 수행·확인 |
| --- | --- |
| 기능별 listener | 선택한 KV 전송·broker·scheduler·분리 encoder·expert backup·diffusion·DP 통신의 bind 주소·실제 포트·송수신 주체를 조사한다. V0 사례는 실제 V0·다중 호스트·PyNcclPipe 사용 여부를 먼저 확인한다. |
| 허용·비허용 경로 | 허용 peer의 정상 통신과 비허용 네트워크·주체의 무해한 연결·메시지를 비교한다. HTTP API 키 검사와 내부 통신의 peer 보호를 각각 확인한다. 연결·방화벽·서버 수신과 최종 reader 기록을 구분하고 서비스에 필요한 통신만 허용한다. |

관련 공개 기록: CVE-2025-29783, CVE-2025-32444, CVE-2025-30165, CVE-2025-47277, CVE-2026-3059, CVE-2026-3060, CVE-2026-7301, CVE-2026-14890, CVE-2026-93088, CVE-2026-93034

실행 상태: 미실행 / 설치 환경 판정: 미확인. 정상 대조·거부·부수 동작을 확인하고 시험용 변경을 회수해야 한다.

## 관련 ISMS-P 요구와 추가 운영 확인

| 요구·적용 조건 | 이 항목이 확인하는 부분 | 추가 운영 확인 |
| --- | --- | --- |
| 2.6.1 네트워크 접근<br>서빙 구성요소가 네트워크에 연결될 때 | 부분 대응<br>엔진의 허용 목적지·포트·프로토콜·작업과 최종 송신을 대조한다. | [2.6.1 공통 운영 확인](../../site/index.html#view=framework&doc=부록_F_외부기준과_선행연구.md&anchor=isms-p-2-6-1) |
| 2.6.7 인터넷 접속 통제<br>서빙 호스트·엔진이 인터넷에 접속할 때 | 부분 대응<br>모델 취득·서비스·관측 단계의 실제 최종 목적지와 비허용 송신 차단을 확인한다. | 관리·개인정보 취급 단말의 인터넷 통제와 해당 환경에 적용되는 망 차단 의무를 별도로 확인한다. |

[대응 원장](../ISMS-P_관련요구_대응.json)

## 외부 기준과 대응 범위

AC-4, SC-7 / 요구 직접 대응

승인된 통신·정보 흐름만 허용한다.

엔진의 실제 송신 목적지와 수행 작업을 정책에 대조한다.

도메인 허용만으로 최종 IP·redirect·작업 권한까지 확인했다고 판단하지 않는다.
