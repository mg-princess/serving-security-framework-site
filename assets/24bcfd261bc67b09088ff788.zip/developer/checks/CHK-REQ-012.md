# CHK-REQ-012 취소·연결 종료 후 늦게 나온 결과가 다른 요청이나 재시도에 섞이지 않는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-REQ-012.md) · [vLLM 판본 차이](../adapters/vllm/CHK-REQ-012.md) · [SGLang 판본 차이](../adapters/sglang/CHK-REQ-012.md)

## 적용 대상

취소·연결 종료 뒤 늦은 결과를 기본 확인한다. 자동 retry가 있으면 이전 시도와 새 시도를 추가 대조한다.

## 권장 설정·조치

- 요청과 실행 시도마다 식별정보를 구분하고 취소 대상·종료 상태를 기록한다. 종료된 시도의 늦은 출력을 버리거나 격리하고 같은 외부 ID의 새 요청에 이전 취소·결과가 적용되지 않게 한다.

## 시험 전 준비

안전하게 지연을 주입할 방법과 attempt를 식별할 관측 방법을 준비한다.

## 확인 방법

취소 대상·Core abort·worker finished·출력 폐기/반환을 연결한다. retry 사용 시 이전/새 attempt를 따로 추적한다.

## 정상 대조

정상 완료 요청과 취소 없는 재요청이 서로 독립 처리된다.

## 시험 순서

1. A가 생성 중일 때 취소하거나 연결을 종료한다.
2. 같은 외부 ID로 새 B 요청을 보낸다.
3. 늦은 A 결과와 B 결과·작업 상태를 대조한다.

## 필수 증거

1. 내부 attempt ID/abort 도달/늦은 chunk·B 결과·작업 상태

## 충족

취소가 올바른 대상에 적용되고 늦은 결과가 비허용 소비자에게 전달되지 않는다. 실제 작업·자원 회수는 6.4 종결·자원 회수의 CHK-LIF-010·CHK-LIF-011에서 별도로 판정한다.

## 미충족

늦은 A 결과가 B에 섞이거나 B가 A의 취소를 잘못 승계한다.

## 미확인

abort 접수만 확인했거나 취소 대상·내부 attempt·늦은 chunk의 폐기/전달과 새 요청·시도의 연결을 확인하지 못했다. 실제 GPU 작업 중단·참조·자원 회수의 증거 부족은 CHK-LIF-010·CHK-LIF-011의 해당 결과에 남긴다.

## 기능·환경별 분기

1. - name: 취소 뒤 GPU 작업·출력·참조 잔존
- scenario_ids: 1. SC-18-01
- apply_when: 일반/streaming의 대기·계산·출력 단계에서 취소·연결 종료·timeout·stop 종료를 확인한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-18-01
2. - name: 자동 재시도로 중복 실행·결과 혼입
- scenario_ids: 1. SC-18-03
- apply_when: 실제 추론 retry 또는 복수 시도가 있다. 취득 SDK retry와 구분한다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-18-03

## 시험 식별자

1. Q-C08/SC-18-01
2. Q-C08/SC-18-03

## 외부 기준과 대응 범위

SC-4, AC-4 / 일부 대응

종료 뒤에도 공유 자원·정보 흐름의 권한을 유지한다.

취소 후 late output이 다른 요청·재시도에 혼입되는지 확인한다.

출력 혼입 판정과 실제 계산 종료·자원 회수 판정을 분리한다.
