# CHK-SUP-007 생성된 코드·파일과 공유 컴파일 캐시를 허가 없이 바꾸지 못하게 하는가?

[기준판의 상세 시험·구현 근거](../adapters/baseline/CHK-SUP-007.md) · [vLLM 판본 차이](../adapters/vllm/CHK-SUP-007.md) · [SGLang 판본 차이](../adapters/sglang/CHK-SUP-007.md)

## 적용 대상

실제 compile/AOT·파생 cache의 생성·읽기 경로를 먼저 확인한다. 명시적 활성 옵션이 없다는 이유로 기본 cache를 제외하지 않는다.

## 권장 설정·조치

- 컴파일 결과·생성 파일·캐시의 작성자와 읽는 프로세스를 구분하고 저장 위치의 쓰기 권한을 제한한다. 생성 입력·도구·설정의 식별정보를 기록하고, 무단 변경된 결과를 읽기 전에 거부하거나 승인한 조건으로 다시 생성한다.

## 시험 전 준비

격리된 cache와 안전한 관측 방법을 준비한다. 임의 코드를 실행하는 payload는 사용하지 않는다.

## 확인 방법

실제 파생·compiled·npcache의 생성자·writer·경로·consumer·reader와 소비 전 무결성 집행을 확인한다. 비허용 writer의 무해 변경·교체를 승인 생성물의 정상 소비와 비교하고, 변경된 파일이 실제 읽히는지와 거부를 기록한다. pickle 등 reader의 해석 안전성은 CHK-SUP-012와 증거를 공유한다. 실제 backend·AOT·기본 cache 활성값·의존성 판본을 고정하고 VLLM_CACHE_ROOT·compilation_config.cache_dir·TORCHINDUCTOR_CACHE_DIR·TRITON_CACHE_DIR 중 사용 경로와 rank별 파일을 조사한다. 타 계정과 엔진 자신의 잔존 writer·오염 지속성을 각각 확인한다. 근거 원문: [F03](https://github.com/mg-princess/serving-security-framework/blob/8a0c7fe42446ff0d3a1f58e2a18cf3069d5c714e/data/checklist.json#L33609).

## 정상 대조

새 묶음의 빈 cache에서 생성하고 동일 묶음으로 정상 재기동한다.

## 시험 순서

1. vLLM·Inductor·Triton 실제 cache 경로를 확인한다.
2. 비허용 계정의 무해 표식 변경을 시도한다.
3. 재기동 시 소비 전 제한과 실제 읽기를 확인한다.

## 필수 증거

1. cache 경로·소유자·writer/묶음 식별·cache key/pickle 등 reader 도달과 소비 기록

## 충족

허용되지 않은 생성·변조 결과를 소비하지 않는다. 생성 결과마다 사람의 별도 승인을 필수로 요구하지 않는다.

## 미충족

비허용 writer가 바꾼 생성물을 요구한 검사 없이 소비한다.

## 미확인

cache 파일 변경은 확인했지만 소비 도달·내용 검증·권한 집행을 확인하지 못했다.

## 기능·환경별 분기

1. - name: 공유 컴파일 캐시 변조를 통한 코드 실행
- scenario_ids: 1. SC-12-01
- apply_when: 유효 compile/AOT·파생 cache의 생성·읽기 경로를 조사한다. 기본 비활성이나 safetensors 정책만으로 제외하지 않는다.
- common_rules_ref: assessment_registry.common_applicability_rules
- focus_ref: question
- implementation_basis_ref: SC-12-01

## 시험 식별자

1. Q-R05-04/SC-12-01

## 외부 기준과 대응 범위

SI-7, CM-5 / 요구 직접 대응

생성 코드·정보의 무단 변경과 사용을 제한한다.

공유 컴파일 캐시의 작성자·소비자·재기동 뒤 실제 사용을 연결한다.

캐시 파일 변경과 코드 실행·계산 사용 여부를 분리한다.
