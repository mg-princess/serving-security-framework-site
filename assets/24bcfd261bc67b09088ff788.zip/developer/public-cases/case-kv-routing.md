# case-kv-routing 요청 ID에 넣은 주소로 KV 캐시가 전송된다

| 항목 | 내용 |
| --- | --- |
| 위협 유형(STRIDE) | I · E / STRIDE 제안 분류 · 공지는 STRIDE를 지정하지 않음 |
| 약점(CWE) | CWE-918 |
| 취약점(CVE) | 연결한 공지의 CVE 없음 |
| 공개 공지 | [GHSA-vfp2-c8pq-v6h6](https://github.com/vllm-project/vllm/security/advisories/GHSA-vfp2-c8pq-v6h6) / 연결 CVE 미확인 |
| 관련 점검 | [CHK-REQ-004](../checks/CHK-REQ-004.md) · [CHK-PLT-007](../checks/CHK-PLT-007.md) · [CHK-PLT-008](../checks/CHK-PLT-008.md) · [CHK-REQ-014](../checks/CHK-REQ-014.md) |

## 개요

요청 ID를 목적지 정보로 해석하면 이용자가 엔진의 연결 상대와 KV 전송 주소에 영향을 줄 수 있다.

## 공격자와 필요 권한

API 요청 ID를 정할 수 있는 이용자. 실제 배포에서 요구하는 API 키·접근 조건을 따른다.

## 성립 조건

공지 대상 P2pNcclConnector의 프롬프트 입력을 계산하는 쪽(prefill)의 역할과 관련 KV 전송 경로를 사용할 때 적용한다. 일반 요청 ID 처리나 다른 연결 모듈과 구분한다.

## 발생 과정

1. 이용자가 X-Request-Id에 전송 목적지로 해석되는 정보를 넣는다.
2. 연결 모듈이 그 ID에서 주소를 뽑아 외부 상대에 연결한다.
3. 해당 요청의 KV 텐서가 허용되지 않은 상대에게 전송될 수 있다.

## 영향

전송 대상 제한을 우회하고 해당 요청의 중간 상태가 다른 목적지로 전달될 수 있다.

## 보호 조치

요청 식별자와 전송 목적지를 분리한다. 신뢰된 상대·주소·전송 자료를 확인하고 실제 송신을 제한한다.

## 점검 사항

요청 ID→최종 연결 상대→실제 KV 전송을 추적하고 정상 상대와 금지 상대의 결과를 비교한다.

## 유의 사항

공지의 P2pNcclConnector와 SC-08-04의 NIXL 조건은 다르다. KV가 다른 이용자의 자료라는 주장으로 확대하지 않고 실제 해당 요청·수신 자료를 확인한다.

