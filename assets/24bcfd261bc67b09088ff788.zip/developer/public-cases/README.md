# 공개 사례 카드

공개 공지가 보고한 조건·판본과 우리 설치 환경의 결과는 각각 확인한다. STRIDE 제안과 공지의 CWE·CVE를 구분한다.

- [모델의 도구 호출 인자를 해석하다가 서버에서 코드가 실행된다](case-output-parser.md)
- [공개 입력으로 공유 메모리 참조를 위조해 worker에서 코드 실행](case-mm-shm.md)
- [미디어 URL로 서버가 내부 주소에 접속하게 한다](case-media-fetch.md)
- [요청 ID에 넣은 주소로 KV 캐시가 전송된다](case-kv-routing.md)
- [허용 길이의 오디오가 큰 중간 행렬을 만들어 GPU 메모리를 소진시킨다](case-media-budget.md)
- [한도 검사 전에 미디어를 전부 읽어 자원을 소진시킨다](case-media-limit-before-read.md)
- [이용자가 만든 멀티모달 상태를 신뢰된 처리 결과로 사용한다](case-mm-features.md)
- [형식을 속인 이미지가 외부 해석기를 실행시킨다](case-media-decoder.md)
