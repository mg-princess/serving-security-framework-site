"""Read-only consistency check for the extracted developer bundle. No network or engine calls."""
from pathlib import Path
from html.parser import HTMLParser
import json,re,collections,hashlib
ROOT=Path(__file__).resolve().parents[1]
def rd(p):return json.loads(p.read_text())
master=rd(ROOT/'ISMS-P_관련요구_대응.json');checks={p.stem:rd(p)for p in(ROOT/'machine/checks').glob('CHK-*.json')};assert len(checks)==79
assert sum(len(x['test_branch_conditions'])for x in checks.values())==125
criteria={r['id']:r for r in master['criteria']};assert len(criteria)==36
expected=[]
for row in criteria.values():
 for t in row['targets']:
  assert t['relationship']in master['relationship_types']
  if t['kind']=='check':
   assert t['check_id']in checks;expected.append((row['id'],t['check_id']))
   rel=next(x for x in checks[t['check_id']]['related_isms_p_requirements']if x['criterion_id']==row['id'])
   for k in ['relationship','scope','applicability','additional_operations','major_question_numbers']:assert rel[k]==t[k],(row['id'],t['check_id'],k)
assert len(expected)==len(set(expected))
actual=[(r['criterion_id'],id)for id,x in checks.items()for r in x['related_isms_p_requirements']];assert collections.Counter(actual)==collections.Counter(expected)
class Rows(HTMLParser):
 def __init__(self):super().__init__();self.rows=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='tr'and'data-isms-target'in a:self.rows.append((a['data-isms-id'],a['data-isms-target']))
p=Rows();p.feed((ROOT/'authoring/common-and-baseline.html').read_text());assert collections.Counter(p.rows)==collections.Counter(expected)
reader=(ROOT.parent/'site/index.html').read_text();m=re.search(r'\bconst\s+pages\s*=\s*',reader);assert m;pages,_=json.JSONDecoder().raw_decode(reader[m.end():]);appendix=pages['부록_F_외부기준과_선행연구.md']['html']
for row in criteria.values():
 assert 'id="'+row['anchor']+'"'in appendix
 source=ROOT.parent/'site'/row['source']['local_reference'];assert source.is_file();assert hashlib.sha256(source.read_bytes()).hexdigest()==row['source']['source_file_sha256']
 for target in row['targets']:
  if target['kind']=='document':assert 'id="'+target['anchor']+'"'in pages[target['document']]['html']
print(json.dumps(dict(check_ids=79,branches=125,criteria=len(criteria),related_checks=len({id for cid,id in expected}),bidirectional_relations=len(expected),source_hashes_verified=True),ensure_ascii=False))
