# 원본 분리와 조립

`common-and-baseline.html`에는 공통 설명·기준판 구현·시험을 두고 `version-blocks/`에는 79개 항목별 판본 차이 원문을 둔다. 각 블록의 엔진별 세부 내용은 `adapters/엔진/버전/CHK.html`에서도 확인할 수 있다.

`<!-- ENGINE_VERSION_BLOCK:CHK-ID -->` 자리에 해당 블록을 삽입하면 현행 체크리스트 HTML과 바이트 단위로 같아진다. 배포 HTML에서는 조립해서 제공하므로 사용자는 기존처럼 한 화면에서 읽는다. 공통 요구·판정과 분기는 `../machine/checks/`의 항목별 JSON에도 보존했다. Markdown은 읽기용 파생 자료다. 원본 수정 후에는 이 묶음을 다시 생성해야 한다.
